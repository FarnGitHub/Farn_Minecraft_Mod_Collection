package farn.customsky;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import net.minecraft.client.Minecraft;
import net.minecraft.src.RenderEngine;
import net.minecraft.src.World;
import org.lwjgl.opengl.GL11;

public class CustomSky {

	private static CustomSkyLayer[][] worldSkyLayers = null;

	private static Minecraft mc;

	public static void reset() {
		worldSkyLayers = null;
	}

	public static void update(RenderEngine var0) {
		reset();
		if(var0 != null) {
			worldSkyLayers = readCustomSkies(var0);
		}
	}

	private static CustomSkyLayer[][] readCustomSkies(RenderEngine var0) {
		CustomSkyLayer[][] var1 = new CustomSkyLayer[10][0];
		String var2 = "/terrain/sky";
		int var3 = -1;

		int var4;
		for(var4 = 0; var4 < var1.length; ++var4) {
			String var5 = var2 + var4 + "/sky";
			List<CustomSkyLayer> var6 = new ArrayList<>();

			for(int var7 = 1; var7 < 1000; ++var7) {
				String var8 = var5 + var7 + ".properties";

				try {
					InputStream var9 = getMinecraft().texturePackList.selectedTexturePack.func_6481_a(var8);
					if(var9 == null) {
						break;
					}

					Properties var10 = new Properties();
					var10.load(var9);
					System.out.println("CustomSky properties: " + var8);
					String var11 = var5 + var7 + ".png";
					CustomSkyLayer var12 = new CustomSkyLayer(var10, var11);
					if(var12.isValid(var8)) {
						var12.textureId = var0.getTexture(var12.source);
						var6.add(var12);
						var9.close();
					}
				} catch (FileNotFoundException var13) {
					break;
				} catch (Exception var14) {
					var14.printStackTrace();
				}
			}

			if(!var6.isEmpty()) {
				CustomSkyLayer[] var17 = new CustomSkyLayer[var6.size()];
				var6.toArray(var17);
				var1[var4] = var17;
				var3 = var4;
			}
		}

		if(var3 < 0) {
			return null;
		} else {
			var4 = var3 + 1;
			CustomSkyLayer[][] var15 = new CustomSkyLayer[var4][0];

			for(int var16 = 0; var16 < var15.length; ++var16) {
				var15[var16] = var1[var16];
			}

			return var15;
		}
	}

	public static void renderSky(World var0, RenderEngine var1, float var2, float var3) {
		if(worldSkyLayers != null) {
			int var4 = var0.worldProvider.field_4218_e;
			if(var4 >= 0 && var4 < worldSkyLayers.length) {
				CustomSkyLayer[] var5 = worldSkyLayers[var4];
				if(var5 != null) {
					long var6 = var0.worldTime;
					int var8 = (int)(var6 % 24000L);

					for(int var9 = 0; var9 < var5.length; ++var9) {
						CustomSkyLayer var10 = var5[var9];
						if(var10.isActive(var8)) {
							var10.render(var8, var1, var2, var3);
						}
					}

					clearBlend(var3);
				}
			}
		}
	}

	public static boolean hasSkyLayers(World var0) {
		if(worldSkyLayers == null) {
			return false;
		} else {
			int var1 = var0.worldProvider.field_4218_e;
			if(var1 >= 0 && var1 < worldSkyLayers.length) {
				CustomSkyLayer[] var2 = worldSkyLayers[var1];
				return var2 != null && var2.length > 0;
			} else {
				return false;
			}
		}
	}

	private static void clearBlend(float var0) {
		GL11.glDisable(GL11.GL_ALPHA_TEST);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, var0);
	}

	public static Minecraft getMinecraft() {
		if(mc == null) {
			try {
				ThreadGroup e = Thread.currentThread().getThreadGroup();
				Thread[] threads = new Thread[e.activeCount()];
				e.enumerate(threads);

				for(Thread currentThread : threads) {
					if(currentThread.getName().equals("Minecraft main thread")) {
						mc = getField(Thread.class, currentThread, "target");
						break;
					}
				}
			} catch (SecurityException securityException4) {
				throw new RuntimeException(securityException4);
			}
		}

		return mc;
	}

	@SuppressWarnings("unchecked")
	private static <T>T getField(Class<?> instanceclass, Object instance, String field) {
		try {
			Field e = instanceclass.getDeclaredField(field);
			e.setAccessible(true);
			return (T)e.get(instance);
		} catch (Exception illegalAccessException4) {
			return null;
		}
	}
}
