package net.minecraft.src;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;

public class mod_AdvanceTooltipPlus extends BaseMod {
	private static AdvanceToolTipPlusConfig config;
	private static Minecraft mc = ModLoader.getMinecraftInstance();

	public mod_AdvanceTooltipPlus() {
		config = AdvanceToolTipPlusConfig.getInstance;
		config.readConfig();
	}

	public static void renderTooltip(GuiScreen screen, Slot stackSlot, int mouseX, int mouseY, int left, int right) {
		StringTranslate translation = StringTranslate.getInstance();
		ItemStack stack = stackSlot.getStack();
		String itemName = translation.translateKey(String.format("%s.name", new Object[]{stack.getItemName().trim()}));
		ArrayList<String> textList = new ArrayList<>();
		ArrayList<Integer> colorList = new ArrayList<>();
		addText(itemName, 16777215, textList, colorList);
		if(stack.getItem().shiftedIndex == Item.compass.shiftedIndex) {
			String compassText;
			if(mc.theWorld.worldProvider.isNether) {
				compassText = config.compassSpinning;
			} else {
				int x = MathHelper.floor_double((double)mc.theWorld.getSpawnPoint().x);
				int z = MathHelper.floor_double((double)mc.theWorld.getSpawnPoint().z);
				compassText = String.format(config.compassPointing, new Object[]{Integer.valueOf(x), Integer.valueOf(z)});
			}

			addText(compassText, -6250336, textList, colorList);
		} else if(stack.getItem().shiftedIndex == Item.pocketSundial.shiftedIndex) {
			float times = (mc.theWorld.getCelestialAngle(1.0F) * 24.0F + 12.0F) % 24.0F;
			int hours = (int)Math.floor((double) times);
			int minutes = (int)Math.floor((double)(times * 60.0F)) - hours * 60;
			addText(String.format(config.clockTime, new Object[]{Integer.valueOf(hours), Integer.valueOf(minutes)}), -6250336, textList, colorList);
		} else if(stack.getItem() instanceof ItemFood) {
			addText(String.format(config.foodHeal, new Object[]{Integer.valueOf(((ItemFood) stack.getItem()).getHealAmount())}), 5592575, textList, colorList);
		} else if(stack.getItem() instanceof ItemRecord) {
			String currentText = capitalizeFirst(((ItemRecord) stack.getItem()).recordName);
			addText(String.format(config.music, new Object[]{currentText}), -6250336, textList, colorList);
		} else  {
			try {
				int damage;
				if((damage = stack.getItem().getDamageVsEntity((Entity)null)) != 1) {
					addText(String.format(config.toolDamage, new Object[]{stack.getItem().getDamageVsEntity((Entity)null)}), 5592575, textList, colorList) ;
				}
			} catch (Exception e) {
			}

			if(stack.isItemStackDamageable()) {
				int durability = stack.getMaxDamage() - stack.getItemDamage();
				int maxDurability = stack.getMaxDamage();
				String var16 = String.format(config.durability, config.formatDurability(durability, maxDurability));
				addText(var16, -6250336, textList, colorList);
			}
		}

		int tooltipX = mouseX - left + 12;
		int tooltipY = mouseY - right - 12;
		int[] var17 = IntegerListToIntArray(colorList);
		drawTooltip(screen, (String[]) textList.toArray(new String[0]), var17, tooltipX, tooltipY);
	}

	public static void drawTooltip(GuiScreen screen, String[] lines, int[] colors, int x, int y) {
		if (lines.length == 0) return;


		int width = 0;
		for (String line : lines) {
			int lineWidth = mc.fontRenderer.getStringWidth(line);
			if (lineWidth > width) width = lineWidth;
		}

		int height = lines.length * 8 + (lines.length - 1) * 2;

		if (x + width > screen.width) {
			x -= 28 + width;
		}
		if (y + height + 6 > screen.height) {
			y = screen.height - height - 6;
		}

		if(config.modernStyle) {
			drawTooltipBackground(screen, x, y, width, height);
		} else {
			screen.drawGradientRect(x - 3, y - 3, x + width + 3, y + height + 3, -1073741824, -1073741824);
		}

		int yOffset = 0;
		for (int i = 0; i < lines.length; i++) {
			if(i != 0) yOffset += 8 + 2;
			int color = (colors != null && i < colors.length) ? colors[i] : 0xFFFFFF;
			mc.fontRenderer.drawString(lines[i], x, y + yOffset, color);
		}
	}

	public static void drawTooltipBackground(GuiScreen screen, int x, int y, int width, int height) {
		int bgColor = -33554432;
		int borderStart = 1347440895;
		int borderEnd = (borderStart & 16777214) >> 1 | borderStart & -16777216;
		screen.drawGradientRect(x - 3, y - 4, x + width + 3, y - 3, bgColor, bgColor);
		screen.drawGradientRect(x - 3, y + height + 3, x + width + 3, y + height + 4, bgColor, bgColor);
		screen.drawGradientRect(x - 3, y - 3, x + width + 3, y + height + 3, bgColor, bgColor);
		screen.drawGradientRect(x - 4, y - 3, x - 3, y + height + 3, bgColor, bgColor);
		screen.drawGradientRect(x + width + 3, y - 3, x + width + 4, y + height + 3, bgColor, bgColor);
		screen.drawGradientRect(x - 3, y - 2, x - 2, y + height + 2, borderStart, borderEnd);
		screen.drawGradientRect(x + width + 2, y - 2, x + width + 3, y + height + 2, borderStart, borderEnd);
		screen.drawGradientRect(x - 3, y - 3, x + width + 3, y - 2, borderStart, borderStart);
		screen.drawGradientRect(x - 3, y + height + 2, x + width + 3, y + height + 3, borderEnd, borderEnd);
	}

	public static void addText(String text, int color, List<String> textList, List<Integer> colorList) {
		textList.add(text);
		colorList.add(Integer.valueOf(color));
	}

	public static int[] IntegerListToIntArray(List<Integer> integerList) {
		int[] colorsArray = new int[integerList.size()];
		for (int i = 0; i < integerList.size(); i++) {
			colorsArray[i] = integerList.get(i);
		}
		return colorsArray;
	}

	private static String capitalizeFirst(String s) {
		if (s == null || s.isEmpty()) return s;
		return s.substring(0, 1).toUpperCase() + s.substring(1);
	}

	public String Version() {
		return "V7";
	}
}
