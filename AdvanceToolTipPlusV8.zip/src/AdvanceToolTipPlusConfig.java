package net.minecraft.src;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import net.minecraft.client.Minecraft;

public class AdvanceToolTipPlusConfig {
	public String compassPointing = "Pointing: X:%d / Z:%d";
	public String compassSpinning = "Spinning";
	public String clockTime = "Time: %02d:%02d";
	public String foodHeal = "+%d Health Point";
	public String durability = "Durability: %s";
	public String durabilityAsNormal = "%d/%d";
	public String durabilityAsPercentage = "%.2f%%";
	public String music = "Music: %s";
	public String toolDamage = "+%d Attack Damage";
	public boolean modernStyle = true;
	public boolean enabledDurabilityAsPercentage = false;
	public static final AdvanceToolTipPlusConfig getInstance = new AdvanceToolTipPlusConfig();
	private final File configFile;
	private final Properties prop;

	private AdvanceToolTipPlusConfig() {
		ModLoader.getMinecraftInstance();
		this.configFile = new File(Minecraft.getMinecraftDir(), "config/AdvanceTooltipConfig.prop");
		this.prop = new Properties();
	}

	public void readConfig() {
		if(this.configFile.exists()) {
			try {
				FileInputStream var1 = new FileInputStream(this.configFile);
				Throwable var2 = null;

				try {
					this.prop.load(var1);
					this.compassPointing = this.prop.getProperty("compassPointing", this.compassPointing);
					this.compassSpinning = this.prop.getProperty("compassSpinning", this.compassSpinning);
					this.clockTime = this.prop.getProperty("clockTime", this.clockTime);
					this.foodHeal = this.prop.getProperty("foodHeal", this.foodHeal);
					this.durability = this.prop.getProperty("durability", this.durability);
					this.durabilityAsNormal = this.prop.getProperty("durabilityAsNormal", this.durabilityAsNormal);
					this.durabilityAsPercentage = this.prop.getProperty("durabilityAsPercentage", this.durabilityAsPercentage);
					this.enabledDurabilityAsPercentage = Boolean.parseBoolean(this.prop.getProperty("enabledDurabilityAsPercentage", String.valueOf(this.enabledDurabilityAsPercentage)));
					this.music = this.prop.getProperty("music", this.music);
					this.toolDamage = this.prop.getProperty("toolDamage", this.toolDamage);
					this.modernStyle = Boolean.parseBoolean(this.prop.getProperty("modernStyle", String.valueOf(this.modernStyle)));
				} catch (Throwable var12) {
					var2 = var12;
					throw var12;
				} finally {
					if(var1 != null) {
						if(var2 != null) {
							try {
								var1.close();
							} catch (Throwable var11) {
								var2.addSuppressed(var11);
							}
						} else {
							var1.close();
						}
					}

				}
			} catch (IOException var14) {
				System.out.println("Failed to load AdvanceTooltipConfig.prop");
				var14.printStackTrace();
			}
		} else {
			this.createOptionFile();
		}

	}

	public void createOptionFile() {
		try {
			FileOutputStream var1 = new FileOutputStream(this.configFile);
			Throwable var2 = null;

			try {
				this.prop.setProperty("compassPointing", this.compassPointing);
				this.prop.setProperty("compassSpinning", this.compassSpinning);
				this.prop.setProperty("clockTime", this.clockTime);
				this.prop.setProperty("foodHeal", this.foodHeal);
				this.prop.setProperty("durability", this.durability);
				this.prop.setProperty("durabilityAsNormal", this.durabilityAsNormal);
				this.prop.setProperty("durabilityAsPercentage", this.durabilityAsPercentage);
				this.prop.setProperty("enabledDurabilityAsPercentage", String.valueOf(this.enabledDurabilityAsPercentage));
				this.prop.setProperty("music", this.music);
				this.prop.setProperty("toolDamage", this.toolDamage);
				this.prop.setProperty("modernStyle", String.valueOf(this.modernStyle));
				this.prop.store(var1, "Advance Tooltip Plus Config");
			} catch (Throwable var12) {
				var2 = var12;
				throw var12;
			} finally {
				if(var1 != null) {
					if(var2 != null) {
						try {
							var1.close();
						} catch (Throwable var11) {
							var2.addSuppressed(var11);
						}
					} else {
						var1.close();
					}
				}

			}
		} catch (IOException var14) {
			System.out.println("Failed to save AdvanceTooltipConfig.prop");
			var14.printStackTrace();
		}

	}

	public String formatDurability(int var1, int var2) {
		if(this.enabledDurabilityAsPercentage) {
			double var3 = (double)var1 / (double)var2 * 100.0D;
			return String.format(this.durabilityAsPercentage, new Object[]{Double.valueOf(var3)});
		} else {
			return String.format(this.durabilityAsNormal, new Object[]{Integer.valueOf(var1), Integer.valueOf(var2)});
		}
	}
}
