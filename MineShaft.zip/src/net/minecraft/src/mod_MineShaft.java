package net.minecraft.src;

import farn.mineshaft.MineShaftGenerator;
import worldgen.WorldGeneratorOverrides;
import worldgen.api.ChunkProviderGenerator;
import worldgen.api.GenerationEnabled;
import worldsettings.api.settings.SettingSupplier;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.Random;

public class mod_MineShaft extends BaseMod implements GenerationEnabled {

    @MLProp(name = "LangMineShaft")
    public static String langMineshaft = "Mineshaft";

    public static final String KEY_LANG_MINESHAFT = "worldgen.mineshaft";
    public static MineShaftGenerator mineshaftGen;

    private static Field ENABLED_CHUNK_PROVIDERS_field;
    private static Map<ChunkProviderGenerator, SettingSupplier<Boolean>> ENABLED_CHUNK_PROVIDERS;

    public mod_MineShaft() {
        ModLoader.AddLocalization(KEY_LANG_MINESHAFT, langMineshaft);
        mineshaftGen = new MineShaftGenerator(StringTranslate.getInstance().translateKey(KEY_LANG_MINESHAFT));
        WorldGeneratorOverrides.addChunkProviderOverride(mineshaftGen);
        try {
            ENABLED_CHUNK_PROVIDERS_field = WorldGeneratorOverrides.class.getDeclaredField("ENABLED_CHUNK_PROVIDERS");
            ENABLED_CHUNK_PROVIDERS_field.setAccessible(true);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
    }

    public void GenerateSurface(World world, Random random, int chunkX, int chunkZ) {
        if(isMineShaftEnabled()) {
            mineshaftGen.mapGenMineshaft.generateStructuresInChunk(world, random, chunkX >> 4, chunkZ >> 4);
        }
    }

    private static boolean isMineShaftEnabled() {
        try {
            ENABLED_CHUNK_PROVIDERS = (Map<ChunkProviderGenerator, SettingSupplier<Boolean>>) ENABLED_CHUNK_PROVIDERS_field.get((Object) null);
            return ENABLED_CHUNK_PROVIDERS.get(mineshaftGen).getValue();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static Random getItemRand() {
        return Item.itemRand;
    }

    @Override
    public boolean isSurfaceEnabled() {
        return true;
    }

    @Override
    public boolean isNetherEnabled() {
        return false;
    }

    @Override
    public String Version() {
        return "1.0.0";
    }
}
