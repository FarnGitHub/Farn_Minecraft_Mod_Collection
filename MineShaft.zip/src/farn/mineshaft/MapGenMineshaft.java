package farn.mineshaft;

import net.minecraft.src.ModLoader;

public class MapGenMineshaft extends MapGenStructure {
	protected boolean canSpawnStructureAtCoords(int i, int j) {
		return this.rand.nextInt(100) == 0 && this.rand.nextInt(80) < Math.max(Math.abs(i), Math.abs(j));
	}

	protected StructureStart getStructureStart(int i, int j) {
		return new StructureMineshaftStart(worldObj, this.rand, i, j);
	}
}
