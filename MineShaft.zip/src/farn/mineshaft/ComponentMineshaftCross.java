package farn.mineshaft;

import net.minecraft.src.Block;
import net.minecraft.src.World;

import java.util.List;
import java.util.Random;

public class ComponentMineshaftCross extends StructureComponent {
	private final int corridorDirection;
	private final boolean isMultipleFloors;

	public ComponentMineshaftCross(int i, Random random, StructureBoundingBox structureboundingbox, int j) {
		super(i);
		this.corridorDirection = j;
		this.boundingBox = structureboundingbox;
		this.isMultipleFloors = structureboundingbox.getYSize() > 3;
	}

	public static StructureBoundingBox findValidPlacement(List list, Random random, int i, int j, int k, int l) {
		StructureBoundingBox structureboundingbox = new StructureBoundingBox(i, j, k, i, j + 2, k);
		if(random.nextInt(4) == 0) {
			structureboundingbox.maxY += 4;
		}

		switch(l) {
		case 0:
			structureboundingbox.minX = i - 1;
			structureboundingbox.maxX = i + 3;
			structureboundingbox.maxZ = k + 4;
			break;
		case 1:
			structureboundingbox.minX = i - 4;
			structureboundingbox.minZ = k - 1;
			structureboundingbox.maxZ = k + 3;
			break;
		case 2:
			structureboundingbox.minX = i - 1;
			structureboundingbox.maxX = i + 3;
			structureboundingbox.minZ = k - 4;
			break;
		case 3:
			structureboundingbox.maxX = i + 4;
			structureboundingbox.minZ = k - 1;
			structureboundingbox.maxZ = k + 3;
		}

		return StructureComponent.findIntersecting(list, structureboundingbox) == null ? structureboundingbox : null;
	}

	public void buildComponent(StructureComponent structurecomponent, List list, Random random) {
		int i = this.getComponentType();
		switch(this.corridorDirection) {
		case 0:
			StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX + 1, this.boundingBox.minY, this.boundingBox.maxZ + 1, 0, i);
			StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX - 1, this.boundingBox.minY, this.boundingBox.minZ + 1, 1, i);
			StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.maxX + 1, this.boundingBox.minY, this.boundingBox.minZ + 1, 3, i);
			break;
		case 1:
			StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX + 1, this.boundingBox.minY, this.boundingBox.minZ - 1, 2, i);
			StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX + 1, this.boundingBox.minY, this.boundingBox.maxZ + 1, 0, i);
			StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX - 1, this.boundingBox.minY, this.boundingBox.minZ + 1, 1, i);
			break;
		case 2:
			StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX + 1, this.boundingBox.minY, this.boundingBox.minZ - 1, 2, i);
			StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX - 1, this.boundingBox.minY, this.boundingBox.minZ + 1, 1, i);
			StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.maxX + 1, this.boundingBox.minY, this.boundingBox.minZ + 1, 3, i);
			break;
		case 3:
			StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX + 1, this.boundingBox.minY, this.boundingBox.minZ - 1, 2, i);
			StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX + 1, this.boundingBox.minY, this.boundingBox.maxZ + 1, 0, i);
			StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.maxX + 1, this.boundingBox.minY, this.boundingBox.minZ + 1, 3, i);
		}

		if(this.isMultipleFloors) {
			if(random.nextBoolean()) {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX + 1, this.boundingBox.minY + 3 + 1, this.boundingBox.minZ - 1, 2, i);
			}

			if(random.nextBoolean()) {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX - 1, this.boundingBox.minY + 3 + 1, this.boundingBox.minZ + 1, 1, i);
			}

			if(random.nextBoolean()) {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.maxX + 1, this.boundingBox.minY + 3 + 1, this.boundingBox.minZ + 1, 3, i);
			}

			if(random.nextBoolean()) {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX + 1, this.boundingBox.minY + 3 + 1, this.boundingBox.maxZ + 1, 0, i);
			}
		}

	}

	public boolean addComponentParts(World world, Random random, StructureBoundingBox structureboundingbox) {
		if(this.isLiquidInStructureBoundingBox(world, structureboundingbox)) {
			return false;
		} else {
			if(this.isMultipleFloors) {
				this.fillWithBlocks(world, structureboundingbox, this.boundingBox.minX + 1, this.boundingBox.minY, this.boundingBox.minZ, this.boundingBox.maxX - 1, this.boundingBox.minY + 3 - 1, this.boundingBox.maxZ, 0, 0, false);
				this.fillWithBlocks(world, structureboundingbox, this.boundingBox.minX, this.boundingBox.minY, this.boundingBox.minZ + 1, this.boundingBox.maxX, this.boundingBox.minY + 3 - 1, this.boundingBox.maxZ - 1, 0, 0, false);
				this.fillWithBlocks(world, structureboundingbox, this.boundingBox.minX + 1, this.boundingBox.maxY - 2, this.boundingBox.minZ, this.boundingBox.maxX - 1, this.boundingBox.maxY, this.boundingBox.maxZ, 0, 0, false);
				this.fillWithBlocks(world, structureboundingbox, this.boundingBox.minX, this.boundingBox.maxY - 2, this.boundingBox.minZ + 1, this.boundingBox.maxX, this.boundingBox.maxY, this.boundingBox.maxZ - 1, 0, 0, false);
				this.fillWithBlocks(world, structureboundingbox, this.boundingBox.minX + 1, this.boundingBox.minY + 3, this.boundingBox.minZ + 1, this.boundingBox.maxX - 1, this.boundingBox.minY + 3, this.boundingBox.maxZ - 1, 0, 0, false);
			} else {
				this.fillWithBlocks(world, structureboundingbox, this.boundingBox.minX + 1, this.boundingBox.minY, this.boundingBox.minZ, this.boundingBox.maxX - 1, this.boundingBox.maxY, this.boundingBox.maxZ, 0, 0, false);
				this.fillWithBlocks(world, structureboundingbox, this.boundingBox.minX, this.boundingBox.minY, this.boundingBox.minZ + 1, this.boundingBox.maxX, this.boundingBox.maxY, this.boundingBox.maxZ - 1, 0, 0, false);
			}

			this.fillWithBlocks(world, structureboundingbox, this.boundingBox.minX + 1, this.boundingBox.minY, this.boundingBox.minZ + 1, this.boundingBox.minX + 1, this.boundingBox.maxY, this.boundingBox.minZ + 1, Block.planks.blockID, 0, false);
			this.fillWithBlocks(world, structureboundingbox, this.boundingBox.minX + 1, this.boundingBox.minY, this.boundingBox.maxZ - 1, this.boundingBox.minX + 1, this.boundingBox.maxY, this.boundingBox.maxZ - 1, Block.planks.blockID, 0, false);
			this.fillWithBlocks(world, structureboundingbox, this.boundingBox.maxX - 1, this.boundingBox.minY, this.boundingBox.minZ + 1, this.boundingBox.maxX - 1, this.boundingBox.maxY, this.boundingBox.minZ + 1, Block.planks.blockID, 0, false);
			this.fillWithBlocks(world, structureboundingbox, this.boundingBox.maxX - 1, this.boundingBox.minY, this.boundingBox.maxZ - 1, this.boundingBox.maxX - 1, this.boundingBox.maxY, this.boundingBox.maxZ - 1, Block.planks.blockID, 0, false);

			for(int i = this.boundingBox.minX; i <= this.boundingBox.maxX; ++i) {
				for(int j = this.boundingBox.minZ; j <= this.boundingBox.maxZ; ++j) {
					int k = this.getBlockIdAtCurrentPosition(world, i, this.boundingBox.minY - 1, j, structureboundingbox);
					if(k == 0) {
						this.placeBlockAtCurrentPosition(world, Block.planks.blockID, 0, i, this.boundingBox.minY - 1, j, structureboundingbox);
					}
				}
			}

			return true;
		}
	}
}
