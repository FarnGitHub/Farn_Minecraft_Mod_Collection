package farn.mineshaft;

public class StructurePieceTreasure extends WeightedRandomChoice {
	public int itemID;
	public int itemMetadata;
	public int minItemStack;
	public int maxItemStack;

	public StructurePieceTreasure(int i, int j, int k, int l, int i1) {
		super(i1);
		this.itemID = i;
		this.itemMetadata = j;
		this.minItemStack = k;
		this.maxItemStack = l;
	}
}
