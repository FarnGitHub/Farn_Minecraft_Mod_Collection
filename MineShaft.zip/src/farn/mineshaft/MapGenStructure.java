package farn.mineshaft;

import net.minecraft.src.*;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public abstract class MapGenStructure extends MapGenBase {
	protected HashMap coordMap = new HashMap();
	public World worldObj;

	public void func_867_a(IChunkProvider ichunkprovider, World world, int i, int j, byte[] abyte0) {
		worldObj = world;
		super.func_867_a(ichunkprovider, world, i, j, abyte0);
	}

	protected void func_868_a(World world, int i, int j, int k, int l, byte[] abyte0) {
		if(!this.coordMap.containsKey((long) ChunkCoordIntPair.chunkXZ2Int(i, j))) {
			this.rand.nextInt();
			if(this.canSpawnStructureAtCoords(i, j)) {
				StructureStart structurestart = this.getStructureStart(i, j);
				this.coordMap.put((long)ChunkCoordIntPair.chunkXZ2Int(i, j), structurestart);
			}
		}

	}

	public boolean generateStructuresInChunk(World world, Random random, int i, int j) {
		int k = (i << 4) + 8;
		int l = (j << 4) + 8;
		boolean flag = false;
		Iterator iterator = this.coordMap.values().iterator();

		while(iterator.hasNext()) {
			StructureStart structurestart = (StructureStart)iterator.next();
			if(structurestart.isSizeableStructure() && structurestart.getBoundingBox().intersectsWith(k, l, k + 15, l + 15)) {
				structurestart.generateStructure(world, random, new StructureBoundingBox(k, l, k + 15, l + 15));
				flag = true;
			}
		}

		return flag;
	}

	public boolean func_40483_a(int i, int j, int k) {
		Iterator iterator = this.coordMap.values().iterator();

		while(true) {
			StructureStart structurestart;
			do {
				do {
					if(!iterator.hasNext()) {
						return false;
					}

					structurestart = (StructureStart)iterator.next();
				} while(!structurestart.isSizeableStructure());
			} while(!structurestart.getBoundingBox().intersectsWith(i, k, i, k));

			Iterator iterator1 = structurestart.getComponents().iterator();

			while(iterator1.hasNext()) {
				StructureComponent structurecomponent = (StructureComponent)iterator1.next();
				if(structurecomponent.getBoundingBox().isVecInside(i, j, k)) {
					return true;
				}
			}
		}
	}

	public ChunkPosition getNearestInstance(World world, int i, int j, int k) {
		this.worldObj = world;
		this.rand.setSeed(world.getRandomSeed());
		long l = this.rand.nextLong();
		long l1 = this.rand.nextLong();
		long l2 = (long)(i >> 4) * l;
		long l3 = (long)(k >> 4) * l1;
		this.rand.setSeed(l2 ^ l3 ^ world.getRandomSeed());
		this.func_868_a(world, i >> 4, k >> 4, 0, 0, (byte[])null);
		double d = Double.MAX_VALUE;
		ChunkPosition chunkposition = null;
		Iterator iterator = this.coordMap.values().iterator();

		int j1;
		int i2;
		while(iterator.hasNext()) {
			StructureStart list = (StructureStart)iterator.next();
			if(list.isSizeableStructure()) {
				StructureComponent chunkposition3 = (StructureComponent)list.getComponents().get(0);
				ChunkPosition iterator1 = chunkposition3.getCenter();
				int chunkposition2 = iterator1.x - i;
				j1 = iterator1.y - j;
				i2 = iterator1.z - k;
				double k2 = (double)(chunkposition2 + chunkposition2 * j1 * j1 + i2 * i2);
				if(k2 < d) {
					d = k2;
					chunkposition = iterator1;
				}
			}
		}

		if(chunkposition != null) {
			return chunkposition;
		} else {
			List list1 = this.func_40482_a();
			if(list1 != null) {
				ChunkPosition chunkposition31 = null;
				Iterator iterator11 = list1.iterator();

				while(iterator11.hasNext()) {
					ChunkPosition chunkposition21 = (ChunkPosition)iterator11.next();
					j1 = chunkposition21.x - i;
					i2 = chunkposition21.y - j;
					int k21 = chunkposition21.z - k;
					double d2 = (double)(j1 + j1 * i2 * i2 + k21 * k21);
					if(d2 < d) {
						d = d2;
						chunkposition31 = chunkposition21;
					}
				}

				return chunkposition31;
			} else {
				return null;
			}
		}
	}

	protected List func_40482_a() {
		return null;
	}

	protected abstract boolean canSpawnStructureAtCoords(int i1, int i2);

	protected abstract StructureStart getStructureStart(int i1, int i2);
}
