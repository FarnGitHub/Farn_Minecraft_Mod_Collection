package farn.mineshaft;

import net.minecraft.src.World;

import java.util.Random;

public class StructureMineshaftStart extends StructureStart {
	public StructureMineshaftStart(World world, Random random, int i, int j) {
		ComponentMineshaftRoom componentmineshaftroom = new ComponentMineshaftRoom(0, random, (i << 4) + 2, (j << 4) + 2);
		this.components.add(componentmineshaftroom);
		componentmineshaftroom.buildComponent(componentmineshaftroom, this.components, random);
		this.updateBoundingBox();
		this.markAvailableHeight(world, random, 10);
	}
}
