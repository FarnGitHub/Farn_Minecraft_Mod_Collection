package farn.mineshaft;

import java.util.Collection;
import java.util.Iterator;
import java.util.Random;

public class WeightedRandom {
	public static int getTotalWeight(Collection collection) {
		int i = 0;

		WeightedRandomChoice weightedrandomchoice;
		for(Iterator iterator = collection.iterator(); iterator.hasNext(); i += weightedrandomchoice.itemWeight) {
			weightedrandomchoice = (WeightedRandomChoice)iterator.next();
		}

		return i;
	}

	public static WeightedRandomChoice getRandomItem(Random random, Collection collection, int i) {
		if(i <= 0) {
			throw new IllegalArgumentException();
		} else {
			int j = random.nextInt(i);
			Iterator iterator = collection.iterator();

			while(iterator.hasNext()) {
				WeightedRandomChoice weightedrandomchoice = (WeightedRandomChoice)iterator.next();
				j -= weightedrandomchoice.itemWeight;
				if(j < 0) {
					return weightedrandomchoice;
				}
			}

			return null;
		}
	}

	public static WeightedRandomChoice getRandomItem(Random random, Collection collection) {
		return getRandomItem(random, collection, getTotalWeight(collection));
	}

	public static int getTotalWeight(WeightedRandomChoice[] aweightedrandomchoice) {
		int i = 0;
		WeightedRandomChoice[] aweightedrandomchoice1 = aweightedrandomchoice;
		int j = aweightedrandomchoice.length;

		for(int k = 0; k < j; ++k) {
			WeightedRandomChoice weightedrandomchoice = aweightedrandomchoice1[k];
			i += weightedrandomchoice.itemWeight;
		}

		return i;
	}

	public static WeightedRandomChoice getRandomItem(Random random, WeightedRandomChoice[] aweightedrandomchoice, int i) {
		if(i <= 0) {
			throw new IllegalArgumentException();
		} else {
			int j = random.nextInt(i);
			WeightedRandomChoice[] aweightedrandomchoice1 = aweightedrandomchoice;
			int k = aweightedrandomchoice.length;

			for(int l = 0; l < k; ++l) {
				WeightedRandomChoice weightedrandomchoice = aweightedrandomchoice1[l];
				j -= weightedrandomchoice.itemWeight;
				if(j < 0) {
					return weightedrandomchoice;
				}
			}

			return null;
		}
	}

	public static WeightedRandomChoice getRandomItem(Random random, WeightedRandomChoice[] aweightedrandomchoice) {
		return getRandomItem(random, aweightedrandomchoice, getTotalWeight(aweightedrandomchoice));
	}
}
