package farn.mineshaft;

import net.minecraft.src.BiomeGenBase;
import net.minecraft.src.Chunk;
import net.minecraft.src.ChunkProviderGenerate;
import worldgen.api.ChunkProviderGenerateGenerator;

import java.util.Random;

public class MineShaftGenerator extends ChunkProviderGenerateGenerator {
    public MapGenMineshaft mapGenMineshaft = new MapGenMineshaft();

    public MineShaftGenerator(String displayString) {
        super(displayString);
    }

    @Override
    public void preLight(ChunkProviderGenerate chunkProvider, Random random, byte[] blocks, Chunk chunk, BiomeGenBase[] biomes, double[] temperature) {
        mapGenMineshaft.func_867_a(chunkProvider, chunk.worldObj, chunk.xPosition, chunk.zPosition, blocks);
    }
}
