package farn.mineshaft;

import net.minecraft.src.World;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

public abstract class StructureStart {
	protected LinkedList components = new LinkedList();
	protected StructureBoundingBox boundingBox;

	public StructureBoundingBox getBoundingBox() {
		return this.boundingBox;
	}

	public LinkedList getComponents() {
		return this.components;
	}

	public void generateStructure(World world, Random random, StructureBoundingBox structureboundingbox) {
		Iterator iterator = this.components.iterator();

		while(iterator.hasNext()) {
			StructureComponent structurecomponent = (StructureComponent)iterator.next();
			if(structurecomponent.getBoundingBox().intersectsWith(structureboundingbox) && !structurecomponent.addComponentParts(world, random, structureboundingbox)) {
				iterator.remove();
			}
		}

	}

	protected void updateBoundingBox() {
		this.boundingBox = StructureBoundingBox.getNewBoundingBox();
		Iterator iterator = this.components.iterator();

		while(iterator.hasNext()) {
			StructureComponent structurecomponent = (StructureComponent)iterator.next();
			this.boundingBox.expandTo(structurecomponent.getBoundingBox());
		}

	}

	protected void markAvailableHeight(World world, Random random, int i) {
		int j = 63 - i;
		int k = this.boundingBox.getYSize() + 1;
		if(k < j) {
			k += random.nextInt(j - k);
		}

		int l = k - this.boundingBox.maxY;
		this.boundingBox.offset(0, l, 0);
		Iterator iterator = this.components.iterator();

		while(iterator.hasNext()) {
			StructureComponent structurecomponent = (StructureComponent)iterator.next();
			structurecomponent.getBoundingBox().offset(0, l, 0);
		}

	}

	protected void setRandomHeight(World world, Random random, int i, int j) {
		int k = j - i + 1 - this.boundingBox.getYSize();
		boolean flag = true;
		int l;
		if(k > 1) {
			l = i + random.nextInt(k);
		} else {
			l = i;
		}

		int i1 = l - this.boundingBox.minY;
		this.boundingBox.offset(0, i1, 0);
		Iterator iterator = this.components.iterator();

		while(iterator.hasNext()) {
			StructureComponent structurecomponent = (StructureComponent)iterator.next();
			structurecomponent.getBoundingBox().offset(0, i1, 0);
		}

	}

	public boolean isSizeableStructure() {
		return true;
	}
}
