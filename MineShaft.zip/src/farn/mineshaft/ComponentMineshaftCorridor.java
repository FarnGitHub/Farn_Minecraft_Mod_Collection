package farn.mineshaft;

import net.minecraft.src.*;

import java.util.List;
import java.util.Random;

public class ComponentMineshaftCorridor extends StructureComponent {
	private final boolean hasRails;
	private final boolean hasSpiders;
	private boolean spawnerPlaced;
	private int sectionCount;

	public ComponentMineshaftCorridor(int i, Random random, StructureBoundingBox structureboundingbox, int j) {
		super(i);
		this.coordBaseMode = j;
		this.boundingBox = structureboundingbox;
		this.hasRails = random.nextInt(3) == 0;
		this.hasSpiders = !this.hasRails && random.nextInt(23) == 0;
		if(this.coordBaseMode != 2 && this.coordBaseMode != 0) {
			this.sectionCount = structureboundingbox.getXSize() / 5;
		} else {
			this.sectionCount = structureboundingbox.getZSize() / 5;
		}

	}

	public static StructureBoundingBox findValidPlacement(List list, Random random, int i, int j, int k, int l) {
		StructureBoundingBox structureboundingbox = new StructureBoundingBox(i, j, k, i, j + 2, k);

		int i1;
		for(i1 = random.nextInt(3) + 2; i1 > 0; --i1) {
			int j1 = i1 * 5;
			switch(l) {
			case 0:
				structureboundingbox.maxX = i + 2;
				structureboundingbox.maxZ = k + (j1 - 1);
				break;
			case 1:
				structureboundingbox.minX = i - (j1 - 1);
				structureboundingbox.maxZ = k + 2;
				break;
			case 2:
				structureboundingbox.maxX = i + 2;
				structureboundingbox.minZ = k - (j1 - 1);
				break;
			case 3:
				structureboundingbox.maxX = i + (j1 - 1);
				structureboundingbox.maxZ = k + 2;
			}

			if(StructureComponent.findIntersecting(list, structureboundingbox) == null) {
				break;
			}
		}

		return i1 <= 0 ? null : structureboundingbox;
	}

	public void buildComponent(StructureComponent structurecomponent, List list, Random random) {
		int i = this.getComponentType();
		int j = random.nextInt(4);
		switch(this.coordBaseMode) {
		case 0:
			if(j <= 1) {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX, this.boundingBox.minY - 1 + random.nextInt(3), this.boundingBox.maxZ + 1, this.coordBaseMode, i);
			} else if(j == 2) {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX - 1, this.boundingBox.minY - 1 + random.nextInt(3), this.boundingBox.maxZ - 3, 1, i);
			} else {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.maxX + 1, this.boundingBox.minY - 1 + random.nextInt(3), this.boundingBox.maxZ - 3, 3, i);
			}
			break;
		case 1:
			if(j <= 1) {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX - 1, this.boundingBox.minY - 1 + random.nextInt(3), this.boundingBox.minZ, this.coordBaseMode, i);
			} else if(j == 2) {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX, this.boundingBox.minY - 1 + random.nextInt(3), this.boundingBox.minZ - 1, 2, i);
			} else {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX, this.boundingBox.minY - 1 + random.nextInt(3), this.boundingBox.maxZ + 1, 0, i);
			}
			break;
		case 2:
			if(j <= 1) {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX, this.boundingBox.minY - 1 + random.nextInt(3), this.boundingBox.minZ - 1, this.coordBaseMode, i);
			} else if(j == 2) {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX - 1, this.boundingBox.minY - 1 + random.nextInt(3), this.boundingBox.minZ, 1, i);
			} else {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.maxX + 1, this.boundingBox.minY - 1 + random.nextInt(3), this.boundingBox.minZ, 3, i);
			}
			break;
		case 3:
			if(j <= 1) {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.maxX + 1, this.boundingBox.minY - 1 + random.nextInt(3), this.boundingBox.minZ, this.coordBaseMode, i);
			} else if(j == 2) {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.maxX - 3, this.boundingBox.minY - 1 + random.nextInt(3), this.boundingBox.minZ - 1, 2, i);
			} else {
				StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.maxX - 3, this.boundingBox.minY - 1 + random.nextInt(3), this.boundingBox.maxZ + 1, 0, i);
			}
		}

		if(i < 8) {
			int l;
			int j1;
			if(this.coordBaseMode != 2 && this.coordBaseMode != 0) {
				for(l = this.boundingBox.minX + 3; l + 3 <= this.boundingBox.maxX; l += 5) {
					j1 = random.nextInt(5);
					if(j1 == 0) {
						StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, l, this.boundingBox.minY, this.boundingBox.minZ - 1, 2, i + 1);
					} else if(j1 == 1) {
						StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, l, this.boundingBox.minY, this.boundingBox.maxZ + 1, 0, i + 1);
					}
				}
			} else {
				for(l = this.boundingBox.minZ + 3; l + 3 <= this.boundingBox.maxZ; l += 5) {
					j1 = random.nextInt(5);
					if(j1 == 0) {
						StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX - 1, this.boundingBox.minY, l, 1, i + 1);
					} else if(j1 == 1) {
						StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.maxX + 1, this.boundingBox.minY, l, 3, i + 1);
					}
				}
			}
		}

	}

	public boolean addComponentParts(World world, Random random, StructureBoundingBox structureboundingbox) {
		if(this.isLiquidInStructureBoundingBox(world, structureboundingbox)) {
			return false;
		} else {
			int i = this.sectionCount * 5 - 1;
			this.fillWithBlocks(world, structureboundingbox, 0, 0, 0, 2, 1, i, 0, 0, false);
			this.randomlyFillWithBlocks(world, structureboundingbox, random, 0.8F, 0, 2, 0, 2, 2, i, 0, 0, false);
			if(this.hasSpiders) {
				this.randomlyFillWithBlocks(world, structureboundingbox, random, 0.6F, 0, 0, 0, 2, 1, i, Block.web.blockID, 0, false);
			}

			int l;
			int k1;
			int i2;
			for(l = 0; l < this.sectionCount; ++l) {
				k1 = 2 + l * 5;
				this.fillWithBlocks(world, structureboundingbox, 0, 0, k1, 0, 1, k1, Block.fence.blockID, 0, false);
				this.fillWithBlocks(world, structureboundingbox, 2, 0, k1, 2, 1, k1, Block.fence.blockID, 0, false);
				if(random.nextInt(4) != 0) {
					this.fillWithBlocks(world, structureboundingbox, 0, 2, k1, 2, 2, k1, Block.planks.blockID, 0, false);
				} else {
					this.fillWithBlocks(world, structureboundingbox, 0, 2, k1, 0, 2, k1, Block.planks.blockID, 0, false);
					this.fillWithBlocks(world, structureboundingbox, 2, 2, k1, 2, 2, k1, Block.planks.blockID, 0, false);
				}

				this.randomlyPlaceBlock(world, structureboundingbox, random, 0.1F, 0, 2, k1 - 1, Block.web.blockID, 0);
				this.randomlyPlaceBlock(world, structureboundingbox, random, 0.1F, 2, 2, k1 - 1, Block.web.blockID, 0);
				this.randomlyPlaceBlock(world, structureboundingbox, random, 0.1F, 0, 2, k1 + 1, Block.web.blockID, 0);
				this.randomlyPlaceBlock(world, structureboundingbox, random, 0.1F, 2, 2, k1 + 1, Block.web.blockID, 0);
				this.randomlyPlaceBlock(world, structureboundingbox, random, 0.05F, 0, 2, k1 - 2, Block.web.blockID, 0);
				this.randomlyPlaceBlock(world, structureboundingbox, random, 0.05F, 2, 2, k1 - 2, Block.web.blockID, 0);
				this.randomlyPlaceBlock(world, structureboundingbox, random, 0.05F, 0, 2, k1 + 2, Block.web.blockID, 0);
				this.randomlyPlaceBlock(world, structureboundingbox, random, 0.05F, 2, 2, k1 + 2, Block.web.blockID, 0);
				if(random.nextInt(100) == 0) {
					this.createTreasureChestAtCurrentPosition(world, structureboundingbox, random, 2, 0, k1 - 1, StructureMineshaftPieces.getTreasurePieces(), 3 + random.nextInt(4));
				}

				if(random.nextInt(100) == 0) {
					this.createTreasureChestAtCurrentPosition(world, structureboundingbox, random, 0, 0, k1 + 1, StructureMineshaftPieces.getTreasurePieces(), 3 + random.nextInt(4));
				}

				if(this.hasSpiders && !this.spawnerPlaced) {
					i2 = this.getYWithOffset(0);
					int j2 = k1 - 1 + random.nextInt(3);
					int k2 = this.getXWithOffset(1, j2);
					j2 = this.getZWithOffset(1, j2);
					if(structureboundingbox.isVecInside(k2, i2, j2)) {
						this.spawnerPlaced = true;
						world.setBlockWithNotify(k2, i2, j2, Block.mobSpawner.blockID);
						TileEntityMobSpawner tileentitymobspawner = (TileEntityMobSpawner)world.getBlockTileEntity(k2, i2, j2);
						if(tileentitymobspawner != null) {
							tileentitymobspawner.setMobID("Spider");
						}
					}
				}
			}

			for(l = 0; l <= 2; ++l) {
				for(k1 = 0; k1 <= i; ++k1) {
					i2 = this.getBlockIdAtCurrentPosition(world, l, -1, k1, structureboundingbox);
					if(i2 == 0) {
						this.placeBlockAtCurrentPosition(world, Block.planks.blockID, 0, l, -1, k1, structureboundingbox);
					}
				}
			}

			if(this.hasRails) {
				for(l = 0; l <= i; ++l) {
					k1 = this.getBlockIdAtCurrentPosition(world, 1, -1, l, structureboundingbox);
					if(k1 > 0 && Block.opaqueCubeLookup[k1]) {
						this.randomlyPlaceBlock(world, structureboundingbox, random, 0.7F, 1, 0, l, Block.rail.blockID, this.getMetadataWithOffset(Block.rail.blockID, 0));
					}
				}
			}

			return true;
		}
	}
}
