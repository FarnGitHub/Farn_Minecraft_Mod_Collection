package farn.mineshaft;

import net.minecraft.src.Block;
import net.minecraft.src.World;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class ComponentMineshaftRoom extends StructureComponent {
	private LinkedList chidStructures = new LinkedList();

	public ComponentMineshaftRoom(int i, Random random, int j, int k) {
		super(i);
		this.boundingBox = new StructureBoundingBox(j, 50, k, j + 7 + random.nextInt(6), 54 + random.nextInt(6), k + 7 + random.nextInt(6));
	}

	public void buildComponent(StructureComponent structurecomponent, List list, Random random) {
		int i = this.getComponentType();
		int j = this.boundingBox.getYSize() - 3 - 1;
		if(j <= 0) {
			j = 1;
		}

		int j1;
		StructureComponent structurecomponent4;
		StructureBoundingBox structureboundingbox3;
		for(j1 = 0; j1 < this.boundingBox.getXSize(); j1 += 4) {
			j1 += random.nextInt(this.boundingBox.getXSize());
			if(j1 + 3 > this.boundingBox.getXSize()) {
				break;
			}

			structurecomponent4 = StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX + j1, this.boundingBox.minY + random.nextInt(j) + 1, this.boundingBox.minZ - 1, 2, i);
			if(structurecomponent4 != null) {
				structureboundingbox3 = structurecomponent4.getBoundingBox();
				this.chidStructures.add(new StructureBoundingBox(structureboundingbox3.minX, structureboundingbox3.minY, this.boundingBox.minZ, structureboundingbox3.maxX, structureboundingbox3.maxY, this.boundingBox.minZ + 1));
			}
		}

		for(j1 = 0; j1 < this.boundingBox.getXSize(); j1 += 4) {
			j1 += random.nextInt(this.boundingBox.getXSize());
			if(j1 + 3 > this.boundingBox.getXSize()) {
				break;
			}

			structurecomponent4 = StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX + j1, this.boundingBox.minY + random.nextInt(j) + 1, this.boundingBox.maxZ + 1, 0, i);
			if(structurecomponent4 != null) {
				structureboundingbox3 = structurecomponent4.getBoundingBox();
				this.chidStructures.add(new StructureBoundingBox(structureboundingbox3.minX, structureboundingbox3.minY, this.boundingBox.maxZ - 1, structureboundingbox3.maxX, structureboundingbox3.maxY, this.boundingBox.maxZ));
			}
		}

		for(j1 = 0; j1 < this.boundingBox.getZSize(); j1 += 4) {
			j1 += random.nextInt(this.boundingBox.getZSize());
			if(j1 + 3 > this.boundingBox.getZSize()) {
				break;
			}

			structurecomponent4 = StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.minX - 1, this.boundingBox.minY + random.nextInt(j) + 1, this.boundingBox.minZ + j1, 1, i);
			if(structurecomponent4 != null) {
				structureboundingbox3 = structurecomponent4.getBoundingBox();
				this.chidStructures.add(new StructureBoundingBox(this.boundingBox.minX, structureboundingbox3.minY, structureboundingbox3.minZ, this.boundingBox.minX + 1, structureboundingbox3.maxY, structureboundingbox3.maxZ));
			}
		}

		for(j1 = 0; j1 < this.boundingBox.getZSize(); j1 += 4) {
			j1 += random.nextInt(this.boundingBox.getZSize());
			if(j1 + 3 > this.boundingBox.getZSize()) {
				break;
			}

			structurecomponent4 = StructureMineshaftPieces.getNextComponent(structurecomponent, list, random, this.boundingBox.maxX + 1, this.boundingBox.minY + random.nextInt(j) + 1, this.boundingBox.minZ + j1, 3, i);
			if(structurecomponent4 != null) {
				structureboundingbox3 = structurecomponent4.getBoundingBox();
				this.chidStructures.add(new StructureBoundingBox(this.boundingBox.maxX - 1, structureboundingbox3.minY, structureboundingbox3.minZ, this.boundingBox.maxX, structureboundingbox3.maxY, structureboundingbox3.maxZ));
			}
		}

	}

	public boolean addComponentParts(World world, Random random, StructureBoundingBox structureboundingbox) {
		if(this.isLiquidInStructureBoundingBox(world, structureboundingbox)) {
			return false;
		} else {
			this.fillWithBlocks(world, structureboundingbox, this.boundingBox.minX, this.boundingBox.minY, this.boundingBox.minZ, this.boundingBox.maxX, this.boundingBox.minY, this.boundingBox.maxZ, Block.dirt.blockID, 0, true);
			this.fillWithBlocks(world, structureboundingbox, this.boundingBox.minX, this.boundingBox.minY + 1, this.boundingBox.minZ, this.boundingBox.maxX, Math.min(this.boundingBox.minY + 3, this.boundingBox.maxY), this.boundingBox.maxZ, 0, 0, false);
			Iterator iterator = this.chidStructures.iterator();

			while(iterator.hasNext()) {
				StructureBoundingBox structureboundingbox1 = (StructureBoundingBox)iterator.next();
				this.fillWithBlocks(world, structureboundingbox, structureboundingbox1.minX, structureboundingbox1.maxY - 2, structureboundingbox1.minZ, structureboundingbox1.maxX, structureboundingbox1.maxY, structureboundingbox1.maxZ, 0, 0, false);
			}

			this.randomlyRareFillWithBlocks(world, structureboundingbox, this.boundingBox.minX, this.boundingBox.minY + 4, this.boundingBox.minZ, this.boundingBox.maxX, this.boundingBox.maxY, this.boundingBox.maxZ, 0, false);
			return true;
		}
	}
}
