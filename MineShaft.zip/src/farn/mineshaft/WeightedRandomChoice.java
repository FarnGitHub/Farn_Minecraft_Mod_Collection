package farn.mineshaft;

public class WeightedRandomChoice {
	protected int itemWeight;

	public WeightedRandomChoice(int i) {
		this.itemWeight = i;
	}
}
