package farn.mineshaft;

import net.minecraft.src.*;

import java.util.List;
import java.util.Random;

public class StructureMineshaftPieces {
	private static final StructurePieceTreasure[] lootArray = new StructurePieceTreasure[]{new StructurePieceTreasure(Item.ingotIron.shiftedIndex, 0, 1, 5, 10), new StructurePieceTreasure(Item.ingotGold.shiftedIndex, 0, 1, 3, 5), new StructurePieceTreasure(Item.redstone.shiftedIndex, 0, 4, 9, 5), new StructurePieceTreasure(Item.dyePowder.shiftedIndex, 4, 4, 9, 5), new StructurePieceTreasure(Item.coal.shiftedIndex, 0, 3, 8, 10), new StructurePieceTreasure(Item.wheat.shiftedIndex, 0, 1, 3, 15), new StructurePieceTreasure(Item.pickaxeSteel.shiftedIndex, mod_MineShaft.getItemRand().nextInt(370) + 30, 1, 1, 1), new StructurePieceTreasure(Block.rail.blockID, 0, 4, 8, 1)};

	private static StructureComponent getRandomComponent(List list, Random random, int i, int j, int k, int l, int i1) {
		int j1 = random.nextInt(100);
		StructureBoundingBox structureboundingbox2;
		if(j1 >= 80) {
			structureboundingbox2 = ComponentMineshaftCross.findValidPlacement(list, random, i, j, k, l);
			if(structureboundingbox2 != null) {
				return new ComponentMineshaftCross(i1, random, structureboundingbox2, l);
			}
		} else if(j1 >= 70) {
			structureboundingbox2 = ComponentMineshaftStairs.findValidPlacement(list, random, i, j, k, l);
			if(structureboundingbox2 != null) {
				return new ComponentMineshaftStairs(i1, random, structureboundingbox2, l);
			}
		} else {
			structureboundingbox2 = ComponentMineshaftCorridor.findValidPlacement(list, random, i, j, k, l);
			if(structureboundingbox2 != null) {
				return new ComponentMineshaftCorridor(i1, random, structureboundingbox2, l);
			}
		}

		return null;
	}

	private static StructureComponent getNextMineShaftComponent(StructureComponent structurecomponent, List list, Random random, int i, int j, int k, int l, int i1) {
		if(i1 > 8) {
			return null;
		} else if(Math.abs(i - structurecomponent.getBoundingBox().minX) <= 80 && Math.abs(k - structurecomponent.getBoundingBox().minZ) <= 80) {
			StructureComponent structurecomponent1 = getRandomComponent(list, random, i, j, k, l, i1 + 1);
			if(structurecomponent1 != null) {
				list.add(structurecomponent1);
				structurecomponent1.buildComponent(structurecomponent, list, random);
			}

			return structurecomponent1;
		} else {
			return null;
		}
	}

	static StructureComponent getNextComponent(StructureComponent structurecomponent, List list, Random random, int i, int j, int k, int l, int i1) {
		return getNextMineShaftComponent(structurecomponent, list, random, i, j, k, l, i1);
	}

	static StructurePieceTreasure[] getTreasurePieces() {
		return lootArray;
	}
}
