package farn.mineshaft;

import net.minecraft.src.*;

import java.util.Iterator;
import java.util.List;
import java.util.Random;

public abstract class StructureComponent {
	protected StructureBoundingBox boundingBox;
	protected int coordBaseMode;
	protected int componentType;

	protected StructureComponent(int i) {
		this.componentType = i;
		this.coordBaseMode = -1;
	}

	public void buildComponent(StructureComponent structurecomponent, List list, Random random) {
	}

	public abstract boolean addComponentParts(World world1, Random random2, StructureBoundingBox structureBoundingBox3);

	public StructureBoundingBox getBoundingBox() {
		return this.boundingBox;
	}

	public int getComponentType() {
		return this.componentType;
	}

	public static StructureComponent findIntersecting(List list, StructureBoundingBox structureboundingbox) {
		Iterator iterator = list.iterator();

		StructureComponent structurecomponent;
		do {
			if(!iterator.hasNext()) {
				return null;
			}

			structurecomponent = (StructureComponent)iterator.next();
		} while(structurecomponent.getBoundingBox() == null || !structurecomponent.getBoundingBox().intersectsWith(structureboundingbox));

		return structurecomponent;
	}

	public ChunkPosition getCenter() {
		return new ChunkPosition(this.boundingBox.getCenterX(), this.boundingBox.getCenterY(), this.boundingBox.getCenterZ());
	}

	protected boolean isLiquidInStructureBoundingBox(World world, StructureBoundingBox structureboundingbox) {
		int i = Math.max(this.boundingBox.minX - 1, structureboundingbox.minX);
		int j = Math.max(this.boundingBox.minY - 1, structureboundingbox.minY);
		int k = Math.max(this.boundingBox.minZ - 1, structureboundingbox.minZ);
		int l = Math.min(this.boundingBox.maxX + 1, structureboundingbox.maxX);
		int i1 = Math.min(this.boundingBox.maxY + 1, structureboundingbox.maxY);
		int j1 = Math.min(this.boundingBox.maxZ + 1, structureboundingbox.maxZ);

		int i2;
		int l2;
		int k3;
		for(i2 = i; i2 <= l; ++i2) {
			for(l2 = k; l2 <= j1; ++l2) {
				k3 = world.getBlockId(i2, j, l2);
				if(k3 > 0 && Block.blocksList[k3].blockMaterial.getIsLiquid()) {
					return true;
				}

				k3 = world.getBlockId(i2, i1, l2);
				if(k3 > 0 && Block.blocksList[k3].blockMaterial.getIsLiquid()) {
					return true;
				}
			}
		}

		for(i2 = i; i2 <= l; ++i2) {
			for(l2 = j; l2 <= i1; ++l2) {
				k3 = world.getBlockId(i2, l2, k);
				if(k3 > 0 && Block.blocksList[k3].blockMaterial.getIsLiquid()) {
					return true;
				}

				k3 = world.getBlockId(i2, l2, j1);
				if(k3 > 0 && Block.blocksList[k3].blockMaterial.getIsLiquid()) {
					return true;
				}
			}
		}

		for(i2 = k; i2 <= j1; ++i2) {
			for(l2 = j; l2 <= i1; ++l2) {
				k3 = world.getBlockId(i, l2, i2);
				if(k3 > 0 && Block.blocksList[k3].blockMaterial.getIsLiquid()) {
					return true;
				}

				k3 = world.getBlockId(l, l2, i2);
				if(k3 > 0 && Block.blocksList[k3].blockMaterial.getIsLiquid()) {
					return true;
				}
			}
		}

		return false;
	}

	protected int getXWithOffset(int i, int j) {
		switch(this.coordBaseMode) {
		case 0:
		case 2:
			return this.boundingBox.minX + i;
		case 1:
			return this.boundingBox.maxX - j;
		case 3:
			return this.boundingBox.minX + j;
		default:
			return i;
		}
	}

	protected int getYWithOffset(int i) {
		return this.coordBaseMode != -1 ? i + this.boundingBox.minY : i;
	}

	protected int getZWithOffset(int i, int j) {
		switch(this.coordBaseMode) {
		case 0:
			return this.boundingBox.minZ + j;
		case 1:
		case 3:
			return this.boundingBox.minZ + i;
		case 2:
			return this.boundingBox.maxZ - j;
		default:
			return j;
		}
	}

	protected int getMetadataWithOffset(int i, int j) {
		if(i == Block.rail.blockID) {
			if(this.coordBaseMode == 1 || this.coordBaseMode == 3) {
				return j != 1 ? 1 : 0;
			}
		} else if(i != Block.doorWood.blockID && i != Block.doorSteel.blockID) {
			if(i != Block.stairCompactCobblestone.blockID && i != Block.stairCompactPlanks.blockID) {
				if(i == Block.ladder.blockID) {
					if(this.coordBaseMode == 0) {
						if(j == 2) {
							return 3;
						}

						if(j == 3) {
							return 2;
						}
					} else if(this.coordBaseMode == 1) {
						if(j == 2) {
							return 4;
						}

						if(j == 3) {
							return 5;
						}

						if(j == 4) {
							return 2;
						}

						if(j == 5) {
							return 3;
						}
					} else if(this.coordBaseMode == 3) {
						if(j == 2) {
							return 5;
						}

						if(j == 3) {
							return 4;
						}

						if(j == 4) {
							return 2;
						}

						if(j == 5) {
							return 3;
						}
					}
				} else if(i == Block.button.blockID) {
					if(this.coordBaseMode == 0) {
						if(j == 3) {
							return 4;
						}

						if(j == 4) {
							return 3;
						}
					} else if(this.coordBaseMode == 1) {
						if(j == 3) {
							return 1;
						}

						if(j == 4) {
							return 2;
						}

						if(j == 2) {
							return 3;
						}

						if(j == 1) {
							return 4;
						}
					} else if(this.coordBaseMode == 3) {
						if(j == 3) {
							return 2;
						}

						if(j == 4) {
							return 1;
						}

						if(j == 2) {
							return 3;
						}

						if(j == 1) {
							return 4;
						}
					}
				}
			} else if(this.coordBaseMode == 0) {
				if(j == 2) {
					return 3;
				}

				if(j == 3) {
					return 2;
				}
			} else if(this.coordBaseMode == 1) {
				if(j == 0) {
					return 2;
				}

				if(j == 1) {
					return 3;
				}

				if(j == 2) {
					return 0;
				}

				if(j == 3) {
					return 1;
				}
			} else if(this.coordBaseMode == 3) {
				if(j == 0) {
					return 2;
				}

				if(j == 1) {
					return 3;
				}

				if(j == 2) {
					return 1;
				}

				if(j == 3) {
					return 0;
				}
			}
		} else if(this.coordBaseMode == 0) {
			if(j == 0) {
				return 2;
			}

			if(j == 2) {
				return 0;
			}
		} else {
			if(this.coordBaseMode == 1) {
				return j + 1 & 3;
			}

			if(this.coordBaseMode == 3) {
				return j + 3 & 3;
			}
		}

		return j;
	}

	protected void placeBlockAtCurrentPosition(World world, int i, int j, int k, int l, int i1, StructureBoundingBox structureboundingbox) {
		int j1 = this.getXWithOffset(k, i1);
		int k1 = this.getYWithOffset(l);
		int l1 = this.getZWithOffset(k, i1);
		if(structureboundingbox.isVecInside(j1, k1, l1)) {
			world.setBlockAndMetadata(j1, k1, l1, i, j);
		}

	}

	protected int getBlockIdAtCurrentPosition(World world, int i, int j, int k, StructureBoundingBox structureboundingbox) {
		int l = this.getXWithOffset(i, k);
		int i1 = this.getYWithOffset(j);
		int j1 = this.getZWithOffset(i, k);
		return structureboundingbox.isVecInside(l, i1, j1) ? world.getBlockId(l, i1, j1) : 0;
	}

	protected void fillWithBlocks(World world, StructureBoundingBox structureboundingbox, int i, int j, int k, int l, int i1, int j1, int k1, int l1, boolean flag) {
		for(int i2 = j; i2 <= i1; ++i2) {
			for(int j2 = i; j2 <= l; ++j2) {
				for(int k2 = k; k2 <= j1; ++k2) {
					if(!flag || this.getBlockIdAtCurrentPosition(world, j2, i2, k2, structureboundingbox) != 0) {
						if(i2 != j && i2 != i1 && j2 != i && j2 != l && k2 != k && k2 != j1) {
							this.placeBlockAtCurrentPosition(world, l1, 0, j2, i2, k2, structureboundingbox);
						} else {
							this.placeBlockAtCurrentPosition(world, k1, 0, j2, i2, k2, structureboundingbox);
						}
					}
				}
			}
		}

	}

	protected void fillWithRandomizedBlocks(World world, StructureBoundingBox structureboundingbox, int i, int j, int k, int l, int i1, int j1, boolean flag, Random random, StructurePieceBlockSelector structurepieceblockselector) {
		for(int k1 = j; k1 <= i1; ++k1) {
			for(int l1 = i; l1 <= l; ++l1) {
				for(int i2 = k; i2 <= j1; ++i2) {
					if(!flag || this.getBlockIdAtCurrentPosition(world, l1, k1, i2, structureboundingbox) != 0) {
						structurepieceblockselector.selectBlocks(random, l1, k1, i2, k1 == j || k1 == i1 || l1 == i || l1 == l || i2 == k || i2 == j1);
						this.placeBlockAtCurrentPosition(world, structurepieceblockselector.getSelectedBlockId(), structurepieceblockselector.getSelectedBlockMetaData(), l1, k1, i2, structureboundingbox);
					}
				}
			}
		}

	}

	protected void randomlyFillWithBlocks(World world, StructureBoundingBox structureboundingbox, Random random, float f, int i, int j, int k, int l, int i1, int j1, int k1, int l1, boolean flag) {
		for(int i2 = j; i2 <= i1; ++i2) {
			for(int j2 = i; j2 <= l; ++j2) {
				for(int k2 = k; k2 <= j1; ++k2) {
					if(random.nextFloat() <= f && (!flag || this.getBlockIdAtCurrentPosition(world, j2, i2, k2, structureboundingbox) != 0)) {
						if(i2 != j && i2 != i1 && j2 != i && j2 != l && k2 != k && k2 != j1) {
							this.placeBlockAtCurrentPosition(world, l1, 0, j2, i2, k2, structureboundingbox);
						} else {
							this.placeBlockAtCurrentPosition(world, k1, 0, j2, i2, k2, structureboundingbox);
						}
					}
				}
			}
		}

	}

	protected void randomlyPlaceBlock(World world, StructureBoundingBox structureboundingbox, Random random, float f, int i, int j, int k, int l, int i1) {
		if(random.nextFloat() < f) {
			this.placeBlockAtCurrentPosition(world, l, i1, i, j, k, structureboundingbox);
		}

	}

	protected void randomlyRareFillWithBlocks(World world, StructureBoundingBox structureboundingbox, int i, int j, int k, int l, int i1, int j1, int k1, boolean flag) {
		float f = (float)(l - i + 1);
		float f1 = (float)(i1 - j + 1);
		float f2 = (float)(j1 - k + 1);
		float f3 = (float)i + f / 2.0F;
		float f4 = (float)k + f2 / 2.0F;

		for(int l1 = j; l1 <= i1; ++l1) {
			float f5 = (float)(l1 - j) / f1;

			for(int i2 = i; i2 <= l; ++i2) {
				float f6 = ((float)i2 - f3) / (f * 0.5F);

				for(int j2 = k; j2 <= j1; ++j2) {
					float f7 = ((float)j2 - f4) / (f2 * 0.5F);
					if(!flag || this.getBlockIdAtCurrentPosition(world, i2, l1, j2, structureboundingbox) != 0) {
						float f8 = f6 * f6 + f5 * f5 + f7 * f7;
						if(f8 <= 1.05F) {
							this.placeBlockAtCurrentPosition(world, k1, 0, i2, l1, j2, structureboundingbox);
						}
					}
				}
			}
		}

	}

	protected void clearCurrentPositionBlocksUpwards(World world, int i, int j, int k, StructureBoundingBox structureboundingbox) {
		int l = this.getXWithOffset(i, k);
		int i1 = this.getYWithOffset(j);
		int j1 = this.getZWithOffset(i, k);
		if(structureboundingbox.isVecInside(l, i1, j1)) {
			while(!world.isAirBlock(l, i1, j1) && i1 < 255) {
				world.setBlockAndMetadata(l, i1, j1, 0, 0);
				++i1;
			}
		}

	}

	protected void fillCurrentPositionBlocksDownwards(World world, int i, int j, int k, int l, int i1, StructureBoundingBox structureboundingbox) {
		int j1 = this.getXWithOffset(k, i1);
		int k1 = this.getYWithOffset(l);
		int l1 = this.getZWithOffset(k, i1);
		if(structureboundingbox.isVecInside(j1, k1, l1)) {
			while((world.isAirBlock(j1, k1, l1) || world.getBlockMaterial(j1, k1, l1).getIsLiquid()) && k1 > 1) {
				world.setBlockAndMetadata(j1, k1, l1, i, j);
				--k1;
			}
		}

	}

	protected void createTreasureChestAtCurrentPosition(World world, StructureBoundingBox structureboundingbox, Random random, int i, int j, int k, StructurePieceTreasure[] astructurepiecetreasure, int l) {
		int i1 = this.getXWithOffset(i, k);
		int j1 = this.getYWithOffset(j);
		int k1 = this.getZWithOffset(i, k);
		if(structureboundingbox.isVecInside(i1, j1, k1) && world.getBlockId(i1, j1, k1) != Block.chest.blockID) {
			world.setBlockWithNotify(i1, j1, k1, Block.chest.blockID);
			TileEntityChest tileentitychest = (TileEntityChest)world.getBlockTileEntity(i1, j1, k1);
			if(tileentitychest != null) {
				fillTreasureChestWithLoot(random, astructurepiecetreasure, tileentitychest, l);
			}
		}

	}

	private static void fillTreasureChestWithLoot(Random random, StructurePieceTreasure[] astructurepiecetreasure, TileEntityChest tileentitychest, int i) {
		for(int j = 0; j < i; ++j) {
			StructurePieceTreasure structurepiecetreasure = (StructurePieceTreasure)WeightedRandom.getRandomItem(random, (WeightedRandomChoice[])astructurepiecetreasure);
			int k = structurepiecetreasure.minItemStack + random.nextInt(structurepiecetreasure.maxItemStack - structurepiecetreasure.minItemStack + 1);
			if(Item.itemsList[structurepiecetreasure.itemID].getItemStackLimit() >= k) {
				tileentitychest.setInventorySlotContents(random.nextInt(tileentitychest.getSizeInventory()), new ItemStack(structurepiecetreasure.itemID, k, structurepiecetreasure.itemMetadata));
			} else {
				for(int l = 0; l < k; ++l) {
					tileentitychest.setInventorySlotContents(random.nextInt(tileentitychest.getSizeInventory()), new ItemStack(structurepiecetreasure.itemID, 1, structurepiecetreasure.itemMetadata));
				}
			}
		}

	}
}
