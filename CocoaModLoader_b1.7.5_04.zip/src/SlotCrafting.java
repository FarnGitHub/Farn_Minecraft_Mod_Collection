package net.minecraft.src;

public class SlotCrafting extends Slot {
	private final IInventory craftMatrix;
	private EntityPlayer thePlayer;

	public SlotCrafting(EntityPlayer var1, IInventory var2, IInventory var3, int var4, int var5, int var6) {
		super(var3, var4, var5, var6);
		this.thePlayer = var1;
		this.craftMatrix = var2;
	}

	public boolean isItemValid(ItemStack var1) {
		return false;
	}

	public void onPickupFromSlot(ItemStack var1) {
		var1.onCrafting(this.thePlayer.worldObj, this.thePlayer);
		if(var1.itemID == Block.workbench.blockID) {
			this.thePlayer.addStat(AchievementList.buildWorkBench, 1);
		} else if(var1.itemID == Item.pickaxeWood.shiftedIndex) {
			this.thePlayer.addStat(AchievementList.buildPickaxe, 1);
		} else if(var1.itemID == Block.stoneOvenIdle.blockID) {
			this.thePlayer.addStat(AchievementList.buildFurnace, 1);
		} else if(var1.itemID != Item.hoeWood.shiftedIndex && var1.itemID != Item.hoeStone.shiftedIndex && var1.itemID != Item.hoeSteel.shiftedIndex && var1.itemID != Item.hoeGold.shiftedIndex && var1.itemID != Item.hoeDiamond.shiftedIndex) {
			if(var1.itemID == Item.bread.shiftedIndex) {
				this.thePlayer.addStat(AchievementList.makeBread, 1);
			} else if(var1.itemID == Item.cake.shiftedIndex) {
				this.thePlayer.addStat(AchievementList.bakeCake, 1);
			} else if(var1.itemID == Item.pickaxeStone.shiftedIndex) {
				this.thePlayer.addStat(AchievementList.buildBetterPickaxe, 1);
			} else if(var1.itemID != Item.swordWood.shiftedIndex && var1.itemID != Item.swordStone.shiftedIndex && var1.itemID != Item.swordSteel.shiftedIndex && var1.itemID != Item.swordGold.shiftedIndex && var1.itemID != Item.swordDiamond.shiftedIndex) {
				if(var1.itemID == Block.sponge.blockID) {
					this.thePlayer.addStat(AchievementList.getSponge, 1);
				}
			} else {
				this.thePlayer.addStat(AchievementList.buildSword, 1);
			}
		} else {
			this.thePlayer.addStat(AchievementList.buildHoe, 1);
		}

		if(var1.itemID != 0) {
			this.thePlayer.addToPlayerScore(this.thePlayer, 4);
		}

		ModLoader.TakenFromCrafting(this.thePlayer, var1);

		for(int var2 = 0; var2 < this.craftMatrix.getSizeInventory(); ++var2) {
			ItemStack var3 = this.craftMatrix.getStackInSlot(var2);
			if(var3 != null) {
				this.craftMatrix.decrStackSize(var2, 1);
				if(var3.getItem().hasContainerItem()) {
					this.craftMatrix.setInventorySlotContents(var2, new ItemStack(var3.getItem().getContainerItem()));
				}
			}
		}

		CraftingManager.getInstance().onCraftResult((InventoryCrafting)this.craftMatrix);
	}
}
