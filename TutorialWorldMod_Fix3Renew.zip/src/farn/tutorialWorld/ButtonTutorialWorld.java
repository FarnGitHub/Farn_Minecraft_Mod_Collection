package farn.tutorialWorld;

import net.minecraft.client.Minecraft;
import net.minecraft.src.*;
import overrideapi.OverrideAPI;
import overrideapi.utils.gui.ButtonHandler;
import overrideapi.utils.gui.GuiHandler;

import java.util.List;

public class ButtonTutorialWorld implements ButtonHandler {
    private int tutorialWorldButtonID;

    @Override
    public void initGui(GuiScreen screen, List buttonsRaw) {
        if(screen instanceof GuiMainMenu) {
            GuiButton button = getMPButton((GuiMainMenu) screen);
            int spacing = screen.height / 4 + 48;
            if(button != null) {
                buttonsRaw.remove(button);
                buttonsRaw.add(new GuiButton(tutorialWorldButtonID = OverrideAPI.getUniqueButtonID(), screen.width / 2 - 100, spacing + 24, "Play Tutorial World"));
            }
        }

    }

    @Override
    public void actionPerformed(GuiScreen screen, GuiButton button) {
        if(screen instanceof GuiMainMenu && button.id == tutorialWorldButtonID) {
            Minecraft mc = ModLoader.getMinecraftInstance();
            if(mc.getSaveLoader().func_22173_b(WorldCopy.worldFileName) == null) {
                WorldCopy.cloneTutorialWorld();
            }
            mc.playerController = new PlayerControllerSP(mc);
            mc.startWorld(WorldCopy.worldFileName, WorldCopy.worldDisplayName, 0);
            mc.displayGuiScreen(null);
            preventJoinWorldCrash();
        }
    }

    private static void preventJoinWorldCrash() {
        try {
            ModLoader.setPrivateValue(GuiHandler.class, OverrideAPI.GUI_HANDLER, "prevGuiScreen", null);
            ModLoader.setPrivateValue(GuiHandler.class, OverrideAPI.GUI_HANDLER, "callOnNextTick", false);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static GuiButton getMPButton(GuiMainMenu menu) {
        try {
            return (GuiButton)ModLoader.getPrivateValue(GuiMainMenu.class, menu, "l");
        } catch (NoSuchFieldException e) {
            return null;
        }
    }
}
