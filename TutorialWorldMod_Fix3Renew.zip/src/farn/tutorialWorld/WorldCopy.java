package farn.tutorialWorld;

import net.minecraft.src.mod_TutorialWorld;

import java.io.File;
import java.net.URLDecoder;

public class WorldCopy {
    public static final File ModJarPath;
    public static final String worldFileName = "TutorialWorld";
    public static final String worldDisplayName = "Tutorial World";
    public static final String worldResourcePath = "farn/tutorialWorld/world/tu3TutorialWorld/";

    public static void extractWorldFromJar(File jarFile, File targetDir) throws Exception {
        java.util.jar.JarFile jar = new java.util.jar.JarFile(jarFile);
        java.util.Enumeration<java.util.jar.JarEntry> entries = jar.entries();

        while (entries.hasMoreElements()) {
            java.util.jar.JarEntry e = entries.nextElement();
            String name = e.getName();

            // only entries inside assets/tutorialworld/
            if (!name.startsWith(worldResourcePath))
                continue;

            String relative = name.substring(worldResourcePath.length());
            File outFile = new File(targetDir, relative);

            if (e.isDirectory()) {
                outFile.mkdirs();
                continue;
            }

            java.io.InputStream in = jar.getInputStream(e);
            java.io.FileOutputStream out = new java.io.FileOutputStream(outFile);

            byte[] buf = new byte[4096];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }

            in.close();
            out.close();
        }

        jar.close();
    }

    public static void cloneTutorialWorld() {
        try {
            File saves = mod_TutorialWorld.getSaveDirectory();
            File target = new File(saves, worldFileName);

            if (!target.exists()) {
                extractWorldFromJar(ModJarPath, target);
                System.out.println("[Tutorial World] Clone Tutorial World To Save Folder");
            } else {
                System.out.println("[Tutorial World] Tutorial World File Already Exist");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static {
        try {
            String rawJarPath = URLDecoder.decode(mod_TutorialWorld.class.getProtectionDomain().getCodeSource().getLocation().getPath(), "UTF-8");
            rawJarPath = rawJarPath.replace("jar:", "").replace("file:/", "").replace("file:\\", ""); /* replace scheme part */
            if(rawJarPath.contains(".jar!")) {
                rawJarPath = rawJarPath.substring(0, rawJarPath.lastIndexOf(".jar!") + ".jar".length());
            }
            rawJarPath = new File(rawJarPath).getAbsolutePath();
            ModJarPath = new File(rawJarPath);
        } catch(Exception e) {
            throw new RuntimeException("[Tutorial World] can't find a jar path for this mod");
        }
    }
}
