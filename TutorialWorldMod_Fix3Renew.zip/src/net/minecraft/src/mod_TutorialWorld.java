package net.minecraft.src;

import farn.tutorialWorld.ButtonTutorialWorld;
import net.minecraft.client.Minecraft;
import overrideapi.OverrideAPI;

import java.io.File;

public class mod_TutorialWorld extends BaseMod {

    public static File getSaveDirectory() {
        if(ModLoader.getMinecraftInstance().getSaveLoader() instanceof SaveFormatOld) {
            return ((SaveFormatOld)ModLoader.getMinecraftInstance().getSaveLoader()).field_22180_a;
        }
        return new File(Minecraft.getMinecraftDir(), "saves");
    }

    static {
        OverrideAPI.registerButtonHandler(new ButtonTutorialWorld());
    }

    @Override
    public String Version() {
        return "3";
    }
}
