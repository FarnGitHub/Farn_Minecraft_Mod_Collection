package cc.noxiuam.titanic.bridge.minecraft.entity;

import cc.noxiuam.titanic.bridge.minecraft.block.MaterialBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.inventory.CraftingInventoryCBBridge;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface EntityPlayerBridge {

    String bridge$getUsername();

    double bridge$getX();
    double bridge$getY();
    double bridge$getZ();

    void bridge$sendChatMessage(String msg);

    void bridge$setSkinURL(String url);
    void bridge$setCapeURL(String url);

    boolean bridge$isInsideOfMaterial(MaterialBridge material);

    boolean bridge$isSneaking();

    InventoryPlayerBridge bridge$getInventory();

    float bridge$getDistanceWalkedModified();
    float bridge$getPrevDistanceWalkedModified();

    float bridge$getCameraYaw();
    float bridge$getPrevCameraYaw();

    float bridge$getCameraPitch();
    float bridge$getPrevCameraPitch();

    float bridge$getRotationYaw();

    CraftingInventoryCBBridge bridge$getCraftingInventory1();
    CraftingInventoryCBBridge bridge$getCraftingInventory2();

}
