package cc.noxiuam.titanic.client.ui.screen.module.container;

import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.ui.AbstractContainer;
import cc.noxiuam.titanic.client.ui.screen.module.container.module.ModulePreviewContainer;
import lombok.Setter;

public class ModuleListContainer extends AbstractContainer {

    private final FooterContainer footer = new FooterContainer();
    private final ModulePreviewContainer previewContainer = new ModulePreviewContainer(this);

    @Setter private AbstractComponent currentComponent;

    public ModuleListContainer() {
        super("/");
        this.currentComponent = this.previewContainer;
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        this.currentComponent.position(this.x, this.y + 3);
        this.currentComponent.size(this.width, this.height);
        this.currentComponent.draw(mouseX, mouseY);

        if (this.currentComponent == this.previewContainer) {
            this.footer.position(this.x, this.y + 13);
            this.footer.size(this.width, this.height);
            this.footer.draw(mouseX, mouseY);
        }
    }

    @Override
    public void handleUpdate() {
        this.currentComponent.handleUpdate();
    }

    @Override
    public void keyTyped(char character, int key) {
        this.currentComponent.keyTyped(character, key);
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        if (this.currentComponent == this.previewContainer) {
            this.footer.mouseClicked(mouseX, mouseY);
        }

        this.currentComponent.mouseClicked(mouseX, mouseY);
    }

}
