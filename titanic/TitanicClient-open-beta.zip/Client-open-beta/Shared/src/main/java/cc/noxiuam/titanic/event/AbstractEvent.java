package cc.noxiuam.titanic.event;

import lombok.Getter;
import lombok.Setter;

@Getter
public abstract class AbstractEvent {

    @Setter
    private boolean cancelled;

    public void cancel() {
        this.cancelled = true;
    }

}
