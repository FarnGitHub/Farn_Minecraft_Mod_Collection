package cc.noxiuam.titanic.client.module.impl.fix.impl;

import cc.noxiuam.titanic.bridge.minecraft.entity.EntityPlayerBridge;
import cc.noxiuam.titanic.bridge.minecraft.item.ItemStackBridge;
import cc.noxiuam.titanic.client.module.impl.fix.AbstractFixModule;
import cc.noxiuam.titanic.event.impl.world.player.model.CapeRenderEvent;
import cc.noxiuam.titanic.event.impl.world.player.model.PlayerModelRenderEvent;
import cc.noxiuam.titanic.event.impl.world.player.model.SpecialModelRenderEvent;

/**
 * Fixes the cape model going inside the chestplate model,
 * as well as the player's head model positions being incorrect when sneaking and unsneaking.
 */
public class PlayerModelFix extends AbstractFixModule {

    public PlayerModelFix() {
        super("Player Model Fix");
        this.addEvent(CapeRenderEvent.class, this::fixCapeModel);
        this.addEvent(PlayerModelRenderEvent.class, this::fixPlayerHeadModel);
        this.addEvent(SpecialModelRenderEvent.class, this::fixSpecialPlayerModel);
    }

    private void fixSpecialPlayerModel(SpecialModelRenderEvent event) {
        if (event.getRenderPassModel() != null) {
            event.getRenderPassModel().bridge$setSwingProgress(event.getMainModel().bridge$getSwingProgress());
        }
    }

    public void fixPlayerHeadModel(PlayerModelRenderEvent event) {
        event.getModel().bridge$getHeadWear().bridge$setOffsetY(event.getModel().bridge$isModelSneaking() ? 1.0F : 0.0F);
    }

    public void fixCapeModel(CapeRenderEvent event) {
        EntityPlayerBridge player = event.getPlayer();
        ItemStackBridge chestplate = player.bridge$getInventory().bridge$armorItemInSlot(2);
        ItemStackBridge leggings = player.bridge$getInventory().bridge$armorItemInSlot(3);
        boolean raiseDueToArmor = chestplate != null || leggings != null;

        if (player.bridge$isSneaking()) {
            event.cancel();
            event.value += 19.0F;
            if (raiseDueToArmor) {
                event.value += 20.0F;
            }
        }
    }

}
