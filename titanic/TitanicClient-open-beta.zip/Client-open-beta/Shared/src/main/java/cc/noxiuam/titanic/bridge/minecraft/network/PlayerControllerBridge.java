package cc.noxiuam.titanic.bridge.minecraft.network;

import cc.noxiuam.titanic.bridge.minecraft.entity.EntityPlayerBridge;

public interface PlayerControllerBridge {

    void bridge$func_20085_a(int var1, int var2, int var3, EntityPlayerBridge player);

}
