package cc.noxiuam.titanic.event.impl.network;

import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class DownloadImageEvent extends AbstractEvent {

    public String url;

}
