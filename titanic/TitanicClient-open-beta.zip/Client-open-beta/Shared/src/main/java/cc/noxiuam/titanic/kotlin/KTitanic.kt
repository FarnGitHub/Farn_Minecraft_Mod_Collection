package cc.noxiuam.titanic.kotlin

import cc.noxiuam.titanic.Ref
import cc.noxiuam.titanic.bridge.Bridge
import cc.noxiuam.titanic.bridge.minecraft.client.MinecraftBridge
import cc.noxiuam.titanic.client.command.CommandManager
import cc.noxiuam.titanic.client.config.ConfigManager
import cc.noxiuam.titanic.client.module.ModuleManager
import cc.noxiuam.titanic.client.network.cosmetic.type.emote.EmoteManager
import cc.noxiuam.titanic.client.network.manager.PlayerProfileManager
import cc.noxiuam.titanic.client.network.manager.discord.DiscordRPCHandler
import cc.noxiuam.titanic.client.network.manager.friend.FriendManager
import cc.noxiuam.titanic.client.network.manager.server.ServerManager
import cc.noxiuam.titanic.client.registry.MinecraftVersion
import cc.noxiuam.titanic.client.ui.screen.friend.FriendsListScreen
import cc.noxiuam.titanic.client.ui.screen.module.HudLayoutEditor
import cc.noxiuam.titanic.client.util.SmoothUtil
import cc.noxiuam.titanic.client.util.chat.ChatColor
import cc.noxiuam.titanic.event.EventManager
import cc.noxiuam.titanic.event.impl.chat.ChatReceivedEvent
import cc.noxiuam.titanic.event.impl.font.DrawStringEvent
import cc.noxiuam.titanic.event.impl.gui.GuiScreenDrawEvent
import cc.noxiuam.titanic.event.impl.keyboard.KeyboardEvent
import cc.noxiuam.titanic.event.impl.network.DownloadImageEvent
import cc.noxiuam.titanic.kotlin.client.VersionImpl
import cc.noxiuam.titanic.kotlin.client.logger.Logger
import com.google.gson.JsonParser
import lombok.SneakyThrows
import org.lwjgl.input.Keyboard
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

// main accent color: 0xFF1471FF
// (based off of: 0xFF27388B)
class KTitanic {

    private val logger = Logger("Titanic")
    private val chatLogger = Logger("Chat")

    val debug : Boolean = false

    private var updatesAvailable = false

    private var gitCommitId = "?"
    private var gitBranch = "?"

    // do not make private just yet
    lateinit var discordRPCHandler : DiscordRPCHandler
    lateinit var eventManager: EventManager
    lateinit var configManager: ConfigManager
    lateinit var friendManager: FriendManager
    lateinit var emoteManager: EmoteManager
    lateinit var profileManager: PlayerProfileManager
    lateinit var serverManager: ServerManager
    lateinit var moduleManager: ModuleManager

    lateinit var bridge: Bridge

    fun init(mc: MinecraftBridge) {
        val initLogger = Logger("Initialization")
        initLogger.info("Starting KTitanic setup")

        bridge = Bridge()
        initLogger.info("Setup Bridge")

        bridge.setupMinecraftBridge(mc)
        initLogger.info("Setup MC Bridge")

        val versionImpl: VersionImpl
        try {
            val versionMain = Class.forName("cc.noxiuam.titanic.VersionMain")
            versionImpl = versionMain.getConstructor().newInstance() as VersionImpl
            Ref.MC_VERSION = versionImpl.getVersion()
        } catch (e: Exception) {
            e.printStackTrace()
            exitProcess(0)
        }

        discordRPCHandler = DiscordRPCHandler()
        discordRPCHandler.connectToDiscord()
        initLogger.info("Initialized Discord RPC Handler")

        eventManager = EventManager()
        initLogger.info("Initialized Event Manager")

        fixThreadDownloadImage()
        configManager = ConfigManager()
        initLogger.info("Initialized Config Manager")

        loadGitInformation()
        initLogger.info("Loading Git Information")

        friendManager = FriendManager()
        initLogger.info("Initialized Friend Manager")

        emoteManager = EmoteManager()
        initLogger.info("Initialized Emote Manager")

        profileManager = PlayerProfileManager()
        initLogger.info("Initialized Profile Manager")

        serverManager = ServerManager()
        initLogger.info("Initialized Server Manager")

        moduleManager = ModuleManager()
        initLogger.info("Initialized Module Manager")

        configManager.readConfigs()
        initLogger.info("Reading Module Configuration Files")

        CommandManager()
        initLogger.info("Initialized Command Manager")

        logger.info("Starting update check thread")
        startUpdateCheckThread()

        eventManager.addEvent(GuiScreenDrawEvent::class.java) { event ->
            if (event.screen.`bridge$shouldDrawWatermark`()) {
                if (updatesAvailable) {
                    Bridge.getInstance().`bridge$getMinecraft`().`bridge$getFontRenderer`().`bridge$drawStringWithShadow`(
                            "A new update is available!",
                            2,
                            event.screen.`bridge$getHeight`() - 20,
                            16200747
                    )
                }

                Bridge.getInstance().`bridge$getMinecraft`().`bridge$getFontRenderer`().`bridge$drawStringWithShadow`(
                        "Titanic Client ($gitCommitId/$gitBranch)",
                        2,
                        event.screen.`bridge$getHeight`() - 10,
                        5263440
                )
            }
        }

        eventManager.addEvent(DrawStringEvent::class.java) { event ->
            var flag = false
            if (Ref.MC_VERSION == MinecraftVersion.B1_1_02 && event.string == "Vote succeeded! Time set to day") {
                for (address in serverManager.featuredServers[0].addresses) {
                    if (serverManager.getCurrentServerAddress().equals(address, ignoreCase = true)) {
                        flag = true
                        break
                    }
                }

                if (flag) {
                    event.cancel()
                    event.string = ChatColor.GREEN.toString() + "Vote succeeded! Time set to day."
                }
            }
        }

        eventManager.addEvent(KeyboardEvent::class.java) { event ->
            val key = event.key

            if (key == Keyboard.KEY_TAB && Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
                mc.`bridge$displayGuiScreen`(Bridge.getInstance().`bridge$initCustomGuiScreen`(
                        FriendsListScreen()
                ))
            }

            if (key == Keyboard.KEY_RSHIFT) {
                mc.`bridge$displayGuiScreen`(
                        Bridge.getInstance().`bridge$initCustomGuiScreen`(
                                HudLayoutEditor()
                        )
                )
            }

            if (key == Keyboard.KEY_SLASH) {
                mc.`bridge$displayGuiScreen`(
                        Bridge.getInstance().`bridge$createGuiChatWithDefaultText`("/")
                )
            }
        }

        eventManager.addEvent(ChatReceivedEvent::class.java) {
                chatReceivedEvent -> chatLogger.info(chatReceivedEvent.message)
        }
        SmoothUtil.inject()

        val shutdownThread = Thread {
            configManager.saveConfigs()
        }
        Runtime.getRuntime().addShutdownHook(shutdownThread)

    }

    private fun loadGitInformation() {
        val path = "/titanic/properties/git.properties"
        try {
            val property = Properties()
            val fileInputStream = javaClass.getResourceAsStream(path) ?: return

            property.load(fileInputStream)
            fileInputStream.close()

            gitCommitId = property.getProperty("git.commit.id.abbrev")
            gitBranch = property.getProperty("git.branch")
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun startUpdateCheckThread() {
        Thread {
            try {
                while (true) {
                    try {
                        if (!updatesAvailable) {
                            checkForUpdates()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    TimeUnit.MINUTES.sleep(5L)
                }
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
        }.start()
    }

    @SneakyThrows
    private fun checkForUpdates() {
        logger.info("Checking for updates...")
        val url = URL("https://api.github.com/repos/TitanicClient/Client/releases/latest")
        val connection = url.openConnection() as HttpURLConnection

        connection.requestMethod = "GET"
        connection.addRequestProperty("User-Agent", "Mozilla/4.0")

        val br = BufferedReader(InputStreamReader(connection.inputStream))
        val releaseData = JsonParser().parse(br).asJsonObject
        val latestCommitId = releaseData["tag_name"].asString

        if (gitCommitId != latestCommitId) {
            updatesAvailable = true
            logger.info("New update is available!")
        } else {
            logger.debug("No new updates found.")
        }
    }

    private fun fixThreadDownloadImage() {
        val whitelistedUrls = arrayOf(
                "https://mineskin.eu/helm/",
                "https://noxiuam.cc/titanic-client/"
        )
        eventManager.addEvent(DownloadImageEvent::class.java) { downloadImageEvent ->
            for (url in whitelistedUrls) {
                if (downloadImageEvent.url.lowercase(Locale.getDefault()).startsWith(url)) {
                    downloadImageEvent.cancel()
                }
            }
        }
    }

}