package cc.noxiuam.titanic;

import cc.noxiuam.titanic.bridge.minecraft.client.MinecraftBridge;
import cc.noxiuam.titanic.kotlin.KTitanic;
import lombok.Getter;

// temp for now
public class Client {

    @Getter
    private static KTitanic instance;

    public Client(MinecraftBridge mc) {
        instance = new KTitanic();
        instance.init(mc);
    }

}
