package cc.noxiuam.titanic.event.impl.world.player;

import cc.noxiuam.titanic.bridge.minecraft.entity.EntityPlayerBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class NametagRenderEvent extends AbstractEvent {

    private EntityPlayerBridge player;
    private float f3;

}
