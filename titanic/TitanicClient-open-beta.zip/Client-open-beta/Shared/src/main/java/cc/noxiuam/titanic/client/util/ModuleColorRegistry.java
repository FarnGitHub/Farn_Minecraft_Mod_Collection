package cc.noxiuam.titanic.client.util;

import cc.noxiuam.titanic.client.util.chat.ChatColor;
import lombok.experimental.UtilityClass;

import java.util.LinkedHashMap;
import java.util.Map;

@UtilityClass
public class ModuleColorRegistry {

    public final Map<String, ChatColor> TEXT_COLORS = new LinkedHashMap<>();
    
    static {
        TEXT_COLORS.put("White", ChatColor.WHITE);
        TEXT_COLORS.put("Aqua", ChatColor.AQUA);
        TEXT_COLORS.put("Red", ChatColor.RED);
        TEXT_COLORS.put("Gold", ChatColor.GOLD);
        TEXT_COLORS.put("Green", ChatColor.GREEN);
        TEXT_COLORS.put("Purple", ChatColor.LIGHT_PURPLE);
        TEXT_COLORS.put("Yellow", ChatColor.YELLOW);
        TEXT_COLORS.put("Blue", ChatColor.DARK_BLUE);
        TEXT_COLORS.put("Gray", ChatColor.GRAY);
        TEXT_COLORS.put("Dark Red", ChatColor.DARK_RED);
        TEXT_COLORS.put("Dark Green", ChatColor.DARK_GREEN);
        TEXT_COLORS.put("Dark Purple", ChatColor.DARK_PURPLE);
        TEXT_COLORS.put("Dark Blue", ChatColor.DARK_BLUE);
        TEXT_COLORS.put("Dark Aqua", ChatColor.DARK_AQUA);
        TEXT_COLORS.put("Dark Gray", ChatColor.DARK_GRAY);
    }
    
}
