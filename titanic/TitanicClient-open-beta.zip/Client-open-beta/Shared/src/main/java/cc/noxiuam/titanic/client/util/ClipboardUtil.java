package cc.noxiuam.titanic.client.util;

import lombok.experimental.UtilityClass;

import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
@UtilityClass
public class ClipboardUtil {

    public String getClipboardString() {
        try {
            Transferable contents = Toolkit.getDefaultToolkit().getSystemClipboard().getContents((Object) null);
            if (contents != null && contents.isDataFlavorSupported(DataFlavor.stringFlavor)) {
                return (String) contents.getTransferData(DataFlavor.stringFlavor);
            }
        } catch (Exception ignored) {
        }
        return null;
    }

}
