package cc.noxiuam.titanic.bridge.minecraft.client.gui.chat;

public interface ChatLineBridge {
}
