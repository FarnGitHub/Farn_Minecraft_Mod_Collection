package cc.noxiuam.titanic.bridge.minecraft.block;

public interface BlockAccessBridge {

    int bridge$getBlockMetadata(int x, int y, int z);

    boolean bridge$isBlockOpaqueCube(int x, int y, int z);

    int bridge$getBlockId(int x, int y, int z);

    MaterialBridge bridge$getBlockMaterial(int x, int y, int z);

}
