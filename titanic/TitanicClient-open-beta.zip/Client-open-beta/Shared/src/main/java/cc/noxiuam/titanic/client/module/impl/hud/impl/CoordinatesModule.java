package cc.noxiuam.titanic.client.module.impl.hud.impl;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.minecraft.entity.EntityPlayerBridge;
import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.ChoiceSetting;
import cc.noxiuam.titanic.client.module.impl.hud.AbstractMovableModule;

import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.client.util.MathUtil;
import cc.noxiuam.titanic.event.impl.gui.GuiDrawEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class CoordinatesModule extends AbstractMovableModule {

    private final ChoiceSetting displayMode;
    private final BooleanSetting showBackground, showY;

    public CoordinatesModule() {
        super("coordinates", "Coordinates", "Shows your current position.", false);

        this.addSettings(
                this.displayMode = new ChoiceSetting(
                        "displayMode",
                        "Display Mode",
                        "Horizontal",
                        "Horizontal", "Vertical"
                ),
                this.textColor(),
                this.showBackground = new BooleanSetting("showBackground", "Show Background", true),
                this.showY = new BooleanSetting("showY", "Show Y Level", true)
        );

        this.addEvent(GuiDrawEvent.class, this::drawCoordinates);
    }

    private void drawCoordinates(GuiDrawEvent event) {
        GL11.glPushMatrix();
        EntityPlayerBridge player = Bridge.getInstance().bridge$getMinecraft().bridge$getThePlayer();
        int playerX = MathUtil.floor_double(player.bridge$getX());
        int playerY = MathUtil.floor_double(player.bridge$getY());
        int playerZ = MathUtil.floor_double(player.bridge$getZ());

        String x = this.getPrefixedTextColor() + "X: " + playerX;
        String y = this.getPrefixedTextColor() + " Y: " + playerY;
        String z = this.getPrefixedTextColor() + " Z: " + playerZ;

        List<String> positions = new ArrayList<>();
        positions.add(x);
        if (this.showY.value()) {
            positions.add(y);
        }
        positions.add(z);

        String position = this.getPrefixedTextColor() + x + (this.showY.value() ? y : "") + z;

        if (this.displayMode.value().equalsIgnoreCase("Horizontal")) {
            this.setSize(this.mc.bridge$getFontRenderer().bridge$getStringWidth(position) + 10, 20);
        } else {
            String longest = positions.stream().max(Comparator.comparingInt(String::length)).get();
            this.setSize(this.mc.bridge$getFontRenderer().bridge$getStringWidth(longest) + 9, this.showY.value() ? 44 : 32);
        }

        this.resizeToScale();

        if (this.displayMode.value().equalsIgnoreCase("Horizontal")) {
            if (this.showBackground.value()) {
                RenderUtil.drawRect(this.x(), this.y(), this.x() + this.width(), this.y() + this.height(), 0x6F000000);
            }
            this.mc.bridge$getFontRenderer().bridge$drawCenteredString(position, (int) (this.x() + this.width() / 2F) + 1, (int) this.y() + 6, -1, true);
        } else {
            if (this.showBackground.value()) {
                RenderUtil.drawRect(this.x(), this.y(), this.x() + this.width(), this.y() + this.height(), 0x6F000000);
            }
            this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(x, (int) (this.x() + 5), (int) this.y() + 6, -1);

            if (this.showY.value()) {
                this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(y, (int) (this.x() + 1), (int) this.y() + 18, -1);
            }

            this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(z, (int) (this.x() + 1), (int) this.y() + (this.showY.value() ? 30 : 18), -1);
        }
        GL11.glPopMatrix();
    }

}
