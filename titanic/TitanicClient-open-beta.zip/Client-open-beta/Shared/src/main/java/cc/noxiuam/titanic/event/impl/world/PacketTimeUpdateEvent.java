package cc.noxiuam.titanic.event.impl.world;

import cc.noxiuam.titanic.bridge.minecraft.network.impl.PacketTimeBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class PacketTimeUpdateEvent extends AbstractEvent {

    private final PacketTimeBridge packet;

}
