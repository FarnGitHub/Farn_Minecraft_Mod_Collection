package cc.noxiuam.titanic.event.impl.gui;

import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ScaledResolutionInitEvent extends AbstractEvent {

    private int scale;

}
