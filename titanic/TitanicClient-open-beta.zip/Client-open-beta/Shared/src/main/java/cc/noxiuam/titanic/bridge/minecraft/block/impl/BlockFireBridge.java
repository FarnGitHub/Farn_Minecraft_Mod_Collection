package cc.noxiuam.titanic.bridge.minecraft.block.impl;

import cc.noxiuam.titanic.bridge.minecraft.block.BlockAccessBridge;
import cc.noxiuam.titanic.bridge.minecraft.block.BlockBridge;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface BlockFireBridge extends BlockBridge {

    boolean bridge$canBlockCatchFire(BlockAccessBridge blockAccessBridge, int x, int y, int z);

}
