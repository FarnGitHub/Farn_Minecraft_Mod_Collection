package cc.noxiuam.titanic.client.registry;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

@Getter
@AllArgsConstructor
public enum MinecraftVersion {

    B1_7_3("b1.7.3", "Minecraft Beta 1.7.3"),
    B1_5_01("b1.5_01", "Minecraft Beta 1.5_01"),
    B1_2_02("b1.2_02", "Minecraft Beta 1.2_02"),
    B1_1_02("b1.1_02", "Minecraft Beta 1.1_02"),

    A1_2_6("a1.2.6", "Minecraft Alpha v1.2.6"),
    A1_1_2_01("a1.1.2_01", "Minecraft Alpha v1.1.2_01"),

    UNKNOWN("unknown", "Unknown Minecraft Version");

    private final String version, watermarkString;

    public static List<MinecraftVersion> getAllVersions() {
        List<MinecraftVersion> filtered = new ArrayList<>();

        for (MinecraftVersion version : values()) {
            if (version != UNKNOWN) {
                filtered.add(version);
            }
        }
        return filtered;
    }

    public boolean isAboveOrEqual(MinecraftVersion version) {
        return version.ordinal() >= this.ordinal();
    }

    public boolean isBelowOrEqual(MinecraftVersion version) {
        return version.ordinal() <= this.ordinal();
    }

}