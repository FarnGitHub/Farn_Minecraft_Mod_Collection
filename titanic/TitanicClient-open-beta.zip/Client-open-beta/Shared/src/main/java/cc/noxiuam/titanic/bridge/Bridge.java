package cc.noxiuam.titanic.bridge;

import cc.noxiuam.titanic.bridge.minecraft.client.MinecraftBridge;
import cc.noxiuam.titanic.kotlin.client.logger.Logger;
import lombok.Getter;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.gq">...</a>
 * <p></p>
 * Otherwise, known as the Tunnel.
 */
@Getter
public class Bridge {

    private final Logger logger = new Logger("Bridge");

    private static IBridge instance;

    private MinecraftBridge minecraftBridge;

    /**
     * Sets up a new Bridge Implementation.
     *
     * @param bridge The new bridge instance.
     */
    public void setupBridge(IBridge bridge) {
        if (instance != null) {
            logger.error("Bridge Implementation can not be reinitialized!");
            return;
        }

        instance = bridge;
    }

    /**
     * Setup Minecraft Bridge instance for use
     * One of the main reasons this exists is because Minecraft.getMinecraft() does not.
     * <p></p>
     * @param bridge The Minecraft class, usually on older versions it will be "MinecraftImpl"
     */
    public void setupMinecraftBridge(MinecraftBridge bridge) {
        if (minecraftBridge != null) {
            logger.error("Minecraft Bridge can not be reinitialized!");
            return;
        }

        minecraftBridge = bridge;
        logger.info("Minecraft Bridge is \"" + bridge.getClass().getSimpleName() + "\"");
    }

    public static IBridge getInstance() {
        return instance;
    }

}
