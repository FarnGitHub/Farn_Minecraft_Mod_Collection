package cc.noxiuam.titanic.client.network.manager.discord;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.client.util.executor.AsyncThreadExecutor;
import com.jagrosh.discordipc.IPCClient;
import com.jagrosh.discordipc.IPCListener;
import com.jagrosh.discordipc.entities.RichPresence;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public class DiscordRPCHandler {

    @Getter
    @Setter
    private IPCClient rpcClient;

    public void connectToDiscord() {
        AsyncThreadExecutor.run(() -> {
            try {
                IPCClient client = new IPCClient(1101585684122320928L);

                client.setListener(new IPCListener() {
                    @Override
                    public void onReady(IPCClient client) {
                        setRpcClient(client);
                        updateRPC();
                    }
                });

                client.connect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public void updateRPC() {
        RichPresence.Builder rpc = new RichPresence.Builder();
        rpc.setDetails(Ref.MC_VERSION.getWatermarkString())
                .setStartTimestamp(OffsetDateTime.now())
                .setLargeImage("titanic");
        this.getRpcClient().sendRichPresence(rpc.build());
    }

}
