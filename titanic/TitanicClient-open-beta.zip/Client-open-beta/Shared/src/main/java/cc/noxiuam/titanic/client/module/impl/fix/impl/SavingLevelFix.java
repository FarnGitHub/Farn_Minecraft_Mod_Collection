package cc.noxiuam.titanic.client.module.impl.fix.impl;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.client.module.impl.fix.AbstractFixModule;
import cc.noxiuam.titanic.event.impl.font.DrawStringEvent;

/**
 * Removes "Saving level..." in the pause menu when in multiplayer
 */
public class SavingLevelFix extends AbstractFixModule {

    public SavingLevelFix() {
        super("Saving Level Fix");
        this.addEvent(DrawStringEvent.class, event -> {
            if (event.getString().equals("Saving level..")
                    && Bridge.getInstance().bridge$getMinecraft().bridge$isMultiplayerWorld()
                    && BridgeRef.getCurrentScreen() != null) {
                event.cancel();
                event.setString("");
            }
        });
    }

}
