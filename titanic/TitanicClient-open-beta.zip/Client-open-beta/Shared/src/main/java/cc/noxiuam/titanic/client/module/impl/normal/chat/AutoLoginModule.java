package cc.noxiuam.titanic.client.module.impl.normal.chat;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.data.ModuleCategory;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.StringSetting;
import cc.noxiuam.titanic.client.util.chat.ChatColor;
import cc.noxiuam.titanic.event.impl.chat.ChatReceivedEvent;
import cc.noxiuam.titanic.event.impl.chat.ChatSendEvent;
import com.google.common.collect.ImmutableList;

public class AutoLoginModule extends AbstractModule {

    private final StringSetting password;
    private final BooleanSetting autoUpdatePassword;
    private final BooleanSetting showUpdateMessages;

    public AutoLoginModule() {
        super(
                "autoLogin",
                "Auto Login",
                "A mod for supported servers that automatically logs you in.",
                false,
                ImmutableList.of(
                        MinecraftVersion.A1_1_2_01,
                        MinecraftVersion.A1_2_6,
                        MinecraftVersion.B1_1_02,
                        MinecraftVersion.B1_7_3
                ),
                ImmutableList.of(
                        ModuleCategory.CHAT
                )
        );
        this.addSettings(
                this.password = new StringSetting("autoLoginPassword", "Auto Login Password", "password", 15),
                this.autoUpdatePassword = new BooleanSetting("autoUpdatePassword", "Update Password on Login", true),
                this.showUpdateMessages = new BooleanSetting("showUpdateMessages", "Show Update Messages", true)
        );

        this.password.setEncryptText(true);

        this.addEvent(ChatReceivedEvent.class, event -> {
            if (event.getMessage().equals(Ref.AUTO_LOGIN_AUTH_MESSAGE)) {
                Bridge.getInstance().bridge$getMinecraft().bridge$getThePlayer().bridge$sendChatMessage("/login " + this.password.value());
            }
        });

        this.addEvent(ChatSendEvent.class, event -> {
            if (this.autoUpdatePassword.value() && event.getMessage().startsWith("/login")) {
                this.password.value(event.getMessage().replaceAll("/login ", ""));
                if (this.showUpdateMessages.value()) {
                    Bridge.getInstance().bridge$getMinecraft().bridge$getIngameGui().bridge$addChatMessage(
                            ChatColor.DARK_AQUA + "[Titanic] " + ChatColor.WHITE + "Updated password."
                    );
                }
            }
        });
    }

}
