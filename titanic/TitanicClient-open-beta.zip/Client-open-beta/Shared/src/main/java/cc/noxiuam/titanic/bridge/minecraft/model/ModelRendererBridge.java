package cc.noxiuam.titanic.bridge.minecraft.model;

public interface ModelRendererBridge {

    float bridge$getRotateAngleX();
    void bridge$setRotateAngleX(float rotateAngleX);

    float bridge$getRotateAngleY();
    void bridge$setRotateAngleY(float rotateAngleY);

    float bridge$getRotateAngleZ();
    void bridge$setRotateAngleZ(float rotateAngleZ);

    void bridge$setOffsetY(float offsetY);

}
