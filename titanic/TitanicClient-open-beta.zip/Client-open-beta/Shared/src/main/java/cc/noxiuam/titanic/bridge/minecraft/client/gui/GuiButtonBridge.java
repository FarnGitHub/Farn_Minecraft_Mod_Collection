package cc.noxiuam.titanic.bridge.minecraft.client.gui;

import cc.noxiuam.titanic.bridge.minecraft.client.MinecraftBridge;

public interface GuiButtonBridge {

    int bridge$getButtonID();

    void bridge$setText(String text);

    void bridge$setX(int x);
    void bridge$setY(int y, boolean adjustYOffset);

    void bridge$setWidth(int width);
    void bridge$setHeight(int height);

    void bridge$drawButton(MinecraftBridge mc, int mouseX, int mouseY);

    void bridge$setEnabled(boolean enabled);

}
