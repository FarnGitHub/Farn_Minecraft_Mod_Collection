package cc.noxiuam.titanic.bridge.minecraft.model;

public interface ModelBipedBridge {

    ModelRendererBridge bridge$getHeadWear();

    ModelRendererBridge bridge$getLeftArm();

    boolean bridge$isModelSneaking();

}
