package cc.noxiuam.titanic.kotlin.client

import cc.noxiuam.titanic.client.registry.MinecraftVersion

interface VersionImpl {

    fun getVersion(): MinecraftVersion?

}