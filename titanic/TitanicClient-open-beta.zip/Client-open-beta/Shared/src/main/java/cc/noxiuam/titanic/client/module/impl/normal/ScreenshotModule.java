package cc.noxiuam.titanic.client.module.impl.normal;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.data.ModuleCategory;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.KeybindSetting;
import cc.noxiuam.titanic.client.util.chat.ChatColor;
import cc.noxiuam.titanic.event.impl.SuccessfulScreenshotEvent;
import cc.noxiuam.titanic.event.impl.keyboard.GuiKeyboardEvent;
import cc.noxiuam.titanic.event.impl.keyboard.KeyboardEvent;
import com.google.common.collect.ImmutableList;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ScreenshotModule extends AbstractModule {

    private final KeybindSetting screenshotKeybind;
    private final BooleanSetting copyAutomatically;

    public ScreenshotModule() {
        super(
                "screenShots",
                "Screenshots",
                "Modifies the way screenshots are taken.",
                false,
                MinecraftVersion.getAllVersions(),
                Collections.emptyList()
        );

        this.addSettings(
                this.screenshotKeybind = new KeybindSetting("screenshotKeybind", "Screenshot Keybind", Keyboard.KEY_F2),
                this.copyAutomatically = new BooleanSetting("copyAutomatically", "Copy Automatically", false)
        );

        this.addEvent(SuccessfulScreenshotEvent.class, this::onSuccessfulScreenshot);
        this.addEvent(KeyboardEvent.class, this::onKeyPress);
        this.addEvent(GuiKeyboardEvent.class, this::onGuiKeypress);
    }

    private void onKeyPress(KeyboardEvent event) {
        if (event.getKey() == this.screenshotKeybind.value()) {
            this.mc.bridge$getIngameGui().bridge$addChatMessage(Bridge.getInstance().bridge$createScreenshotHelper().bridge$saveScreenshot(
                    Bridge.getInstance().bridge$getMinecraft().bridge$getMinecraftDir(),
                    this.mc.bridge$getDisplayWidth(),
                    this.mc.bridge$getDisplayHeight()
            ));
            this.mc.bridge$setIsTakingScreenshot(true);
        } else {
            this.mc.bridge$setIsTakingScreenshot(false);
        }
    }

    private void onGuiKeypress(GuiKeyboardEvent event) {
        if (event.getKey() == this.screenshotKeybind.value()) {
            this.mc.bridge$getIngameGui().bridge$addChatMessage(Bridge.getInstance().bridge$createScreenshotHelper().bridge$saveScreenshot(
                    this.mc().bridge$getMinecraftDir(),
                    this.mc.bridge$getDisplayWidth(),
                    this.mc.bridge$getDisplayHeight()
            ));
            this.mc.bridge$setIsTakingScreenshot(true);
        } else {
            this.mc.bridge$setIsTakingScreenshot(false);
        }
    }

    private void onSuccessfulScreenshot(SuccessfulScreenshotEvent event) {
        if (!this.copyAutomatically.value()) {
            return;
        }

        String fileName = event.getScreenshotName();

        File screenshot = new File(this.mc.bridge$getMinecraftDir() + File.separator + "screenshots" + File.separator + fileName);
        List<File> listOfFiles = new ArrayList<>();
        listOfFiles.add(screenshot);

        this.mc.bridge$getIngameGui().bridge$addChatMessage(ChatColor.DARK_AQUA + "[Titanic] " + ChatColor.WHITE + "Copied screenshot.");

        FileList fileList = new FileList(listOfFiles);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(fileList, (clipboard, contents) -> System.out.println("Lost ownership"));
    }

    private static class FileList implements Transferable {

        private final List<File> files;

        public FileList(List<File> files) {
            this.files = files;
        }

        @Override
        public DataFlavor[] getTransferDataFlavors() {
            return new DataFlavor[]{DataFlavor.javaFileListFlavor};
        }

        @Override
        public boolean isDataFlavorSupported(DataFlavor flavor) {
            return DataFlavor.javaFileListFlavor.equals(flavor);
        }

        @Override
        public Object getTransferData(DataFlavor flavor) {
            return this.files;
        }
    }

}
