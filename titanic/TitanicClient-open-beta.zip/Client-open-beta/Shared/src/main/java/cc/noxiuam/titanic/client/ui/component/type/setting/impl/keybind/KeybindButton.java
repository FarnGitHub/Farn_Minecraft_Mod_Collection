package cc.noxiuam.titanic.client.ui.component.type.setting.impl.keybind;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiButtonBridge;
import cc.noxiuam.titanic.client.module.data.setting.impl.KeybindSetting;
import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.ui.transition.impl.ColorTransition;

import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.client.util.CaseUtils;
import cc.noxiuam.titanic.client.util.SoundUtil;
import org.lwjgl.input.Keyboard;

public class KeybindButton extends AbstractComponent {

    private boolean listening;

    private String text;

    private final KeybindSetting setting;

    private final GuiButtonBridge button;

    public KeybindButton(KeybindSetting setting) {
        this.setting = setting;
        this.text = CaseUtils.capitalizeFirst(Keyboard.getKeyName(setting.value()));

        this.button = Bridge.getInstance().bridge$createNewGuiButton(
                1000,
                0,
                0,
                0,
                20,
                this.text
        );
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        this.button.bridge$setX((int) this.x);
        this.button.bridge$setY((int) this.y, true);
        this.button.bridge$setWidth((int) this.width);
        this.button.bridge$drawButton(BridgeRef.getMinecraft(), (int) mouseX, (int) mouseY);
        this.button.bridge$setText(this.text);
    }

    @Override
    public void keyTyped(char character, int key) {
        if (this.listening) {
            this.setting.value(key);
            this.listening = false;
            this.text = CaseUtils.capitalizeFirst(Keyboard.getKeyName(this.setting.value()));
        }
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        float buttonX = (int) (this.x + 2);
        float buttonY = this.y;

        boolean mouseInsideButton = mouseX >= buttonX && mouseY >= buttonY && mouseX < buttonX + this.width && mouseY < buttonY + this.height;

        if (mouseInsideButton && !this.listening) {
            this.listening = true;
            this.text = "> " + this.text + " <";
            SoundUtil.playClick();
        } else if (mouseInsideButton) {
            this.listening = false;
            this.text = CaseUtils.capitalizeFirst(Keyboard.getKeyName(this.setting.value()));
            SoundUtil.playClick();
        }
    }

}
