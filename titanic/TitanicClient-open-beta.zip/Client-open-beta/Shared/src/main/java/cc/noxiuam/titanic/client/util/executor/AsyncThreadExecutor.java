package cc.noxiuam.titanic.client.util.executor;

import lombok.SneakyThrows;
import lombok.experimental.UtilityClass;

import java.util.concurrent.ForkJoinPool;

@UtilityClass
public class AsyncThreadExecutor {

    private final ForkJoinPool COMMON_POOL = ForkJoinPool.commonPool();

    @SneakyThrows
    public void run(Runnable consumer) {
        COMMON_POOL.execute(consumer);
    }

}

