package cc.noxiuam.titanic.client.ui.screen.module.container.module;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.data.ModuleCategory;
import cc.noxiuam.titanic.client.module.impl.fix.AbstractFixModule;
import cc.noxiuam.titanic.client.ui.component.type.button.RoundedTextButton;
import cc.noxiuam.titanic.client.ui.component.type.button.module.ModuleCategoryButton;
import cc.noxiuam.titanic.client.ui.screen.module.component.ModulePreviewComponent;
import cc.noxiuam.titanic.client.ui.screen.module.component.data.ModulePage;
import cc.noxiuam.titanic.client.ui.AbstractContainer;
import cc.noxiuam.titanic.client.ui.screen.module.container.ModuleListContainer;
import cc.noxiuam.titanic.client.ui.screen.module.container.module.setting.ModuleSettingsContainer;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.client.util.SoundUtil;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ModulePreviewContainer extends AbstractContainer {

    @Getter private final List<ModulePage> modulePages = new CopyOnWriteArrayList<>();
    @Getter private final List<AbstractModule> queuedModules = new CopyOnWriteArrayList<>();

    private final List<ModuleCategoryButton> categoryButtons = new CopyOnWriteArrayList<>();

    @Getter private final ModuleListContainer container;

    public int pageNumber = 0;

    private final RoundedTextButton leftButton = new RoundedTextButton("<");
    private final RoundedTextButton rightButton = new RoundedTextButton(">");

    public ModulePreviewContainer(ModuleListContainer container) {
        super("/mods");
        this.container = container;

        for (ModuleCategory category : ModuleCategory.values()) {
            this.categoryButtons.add(new ModuleCategoryButton(category));
        }

        this.categoryButtons.get(0).setSelected(true);
        this.categorizeMods(ModuleCategory.ALL);
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        for (ModuleCategoryButton categoryButton : this.categoryButtons) {
            categoryButton.draw(mouseX, mouseY);
            RenderUtil.drawComponentTooltip(categoryButton, mouseX, mouseY);
        }

        if (this.modulePages.size() > 0) {
            int height = 5;
            for (ModulePreviewComponent component : this.modulePages.get(this.pageNumber).getPreviewComponents()) {
                component.position(this.x, this.y + height);
                component.size(this.width, 20.0F);
                height += 23.0F;
            }

            for (ModulePreviewComponent previewComponent : this.modulePages.get(this.pageNumber).getPreviewComponents()) {
                previewComponent.draw(mouseX, mouseY);
                RenderUtil.drawComponentTooltip(previewComponent, mouseX, mouseY);
            }
        }

        boolean showPageButtons = this.modulePages.size() > 1;

        if (showPageButtons) {
            this.leftButton.setDisabled(this.pageNumber == 0);
            this.leftButton.position(this.x + this.width / 2.165F - 12, this.y + this.height);
            this.leftButton.size(16, 20);
            this.leftButton.draw(mouseX, mouseY);

            this.rightButton.setDisabled(this.pageNumber == this.modulePages.size() - 1);
            this.rightButton.position(this.x + this.width / 2.165F + 12, this.y + this.height);
            this.rightButton.size(16, 20);
            this.rightButton.draw(mouseX, mouseY);
        }
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        boolean showPageButtons = this.modulePages.size() > 1;

        if (this.modulePages.size() > 0) {
            for (ModulePreviewComponent previewComponent : this.modulePages.get(this.pageNumber).getPreviewComponents()) {
                if (previewComponent.mouseInside((int) mouseX, (int) mouseY)) {
                    if (previewComponent.getSettingsButton().mouseInside(mouseX, mouseY)
                            && previewComponent.getModule().settings().size() > 0) {
                        SoundUtil.playClick();
                        ModuleSettingsContainer moduleSettingsContainer =
                                new ModuleSettingsContainer(this.container, this, previewComponent.getModule());
                        this.container.setCurrentComponent(
                                moduleSettingsContainer
                        );
                        return;
                    }

                    SoundUtil.playClick();
                    previewComponent.getModule().toggle();
                    return;
                }
            }
        }

        if (showPageButtons && this.leftButton.mouseInside(mouseX, mouseY) && this.pageNumber > 0) {
            SoundUtil.playClick();
            this.pageNumber--;
            return;
        } else if (showPageButtons && this.rightButton.mouseInside(mouseX, mouseY) && this.pageNumber + 1 < this.modulePages.size()) {
            SoundUtil.playClick();
            this.pageNumber++;
            return;
        }

        for (ModuleCategoryButton categoryButton : this.categoryButtons) {
            if (categoryButton.mouseInside(mouseX, mouseY)) {
                for (ModuleCategoryButton otherButton : this.categoryButtons) {
                    if (otherButton == categoryButton) {
                        continue;
                    }
                    otherButton.setSelected(false);
                }

                SoundUtil.playClick();
                categoryButton.setSelected(true);
                this.categorizeMods(categoryButton.getCategory());
                break;
            }
        }
    }

    @Override
    public void position(float newX, float newY) {
        super.position(newX, newY + 10);

        float categoryHorizontalPos = 0.0F;
        for (ModuleCategoryButton categoryButton : this.categoryButtons) {
            categoryButton.position(newX + categoryHorizontalPos, newY - 7);
            categoryButton.size(
                    (float) BridgeRef.getMinecraft()
                            .bridge$getFontRenderer()
                            .bridge$getStringWidth(
                                    categoryButton.getCategory().toString().toUpperCase()
                            ) + 10F,
                    12F
            );
            categoryHorizontalPos += categoryButton.getWidth() + 4.0F;
        }
    }

    public void categorizeMods(ModuleCategory category) {
        this.modulePages.clear();
        this.queuedModules.clear();
        this.pageNumber = 0;

        List<AbstractModule> mods = new ArrayList<>(Ref.getModuleManager().getMods());
        mods.removeIf(mod -> mod instanceof AbstractFixModule);
        mods.removeIf(mod -> !mod.categories().contains(category));

        if (category == ModuleCategory.ALL) {
            mods.clear();
            mods = new ArrayList<>(Ref.getModuleManager().getMods());
            mods.removeIf(mod -> mod instanceof AbstractFixModule);
        }

        for (float i = 0; i < mods.size() / 5F; i++) {
            this.modulePages.add(new ModulePage());
        }

        for (AbstractModule module : mods) {
            for (ModulePage modulePage : this.modulePages) {
                if (module instanceof AbstractFixModule) {
                    continue;
                }

                if (this.queuedModules.contains(module)) {
                    continue;
                }

                if (modulePage.getPreviewComponents().size() >= 5) {
                    continue;
                }

                ModulePreviewComponent previewComponent = new ModulePreviewComponent(this, module);
                previewComponent.setTooltip(module.description());

                modulePage.getPreviewComponents().add(previewComponent);
                this.queuedModules.add(module);
            }
        }
    }

}
