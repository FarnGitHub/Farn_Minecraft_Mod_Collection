package cc.noxiuam.titanic.client.ui.screen.friend.container;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import cc.noxiuam.titanic.client.registry.Friend;
import cc.noxiuam.titanic.client.ui.AbstractContainer;
import cc.noxiuam.titanic.client.ui.component.type.button.RoundedTextButton;
import cc.noxiuam.titanic.client.ui.screen.friend.FriendsListScreen;
import cc.noxiuam.titanic.client.ui.screen.friend.component.FriendComponent;
import cc.noxiuam.titanic.client.ui.screen.friend.container.data.FriendPage;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.client.util.SoundUtil;
import lombok.Getter;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class FriendsListContainer extends AbstractContainer {

    @Getter
    private final List<FriendPage> friendPages = new CopyOnWriteArrayList<>();
    @Getter private final List<Friend> queuedFriends = new CopyOnWriteArrayList<>();

    private final RoundedTextButton leftButton = new RoundedTextButton("<");
    private final RoundedTextButton rightButton = new RoundedTextButton(">");

    public FriendComponent selectedFriend;
    public int pageNumber = 0;

    public FriendsListContainer() {
        super("/friends/list");

        List<Friend> friends = Ref.getFriendManager().getFriends();

        if (friends.size() == 0) {
            this.friendPages.add(new FriendPage());
        } else {
            for (float i = 0; i < friends.size() / 9F; i++) {
                this.friendPages.add(new FriendPage());
            }
        }

        for (Friend friend : Ref.getFriendManager().getFriends()) {
            for (FriendPage friendPage : this.friendPages) {
                if (this.queuedFriends.contains(friend)) {
                    continue;
                }

                if (friendPage.getFriendComponents().size() >= 9) {
                    continue;
                }

                friendPage.getFriendComponents().add(new FriendComponent(friend));
                this.queuedFriends.add(friend);
            }
        }
    }

    @Override
    public void handleUpdate() {
        if (this.selectedFriend != null) {
            this.selectedFriend.handleUpdate();
        }
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        RenderUtil.drawRect(
                this.x - this.width,
                this.y + this.height - 47,
                this.x + this.width - 4,
                this.y + this.height - 46,
                0x80292929
        );

        RenderUtil.drawRoundedRect(
                this.x,
                this.y,
                this.x + this.width - 8,
                this.y + this.height - 50,
                5,
                0x20292929
        );

        RenderUtil.drawRoundedOutline(
                this.x,
                this.y,
                this.x + this.width - 8,
                this.y + this.height - 50,
                5,
                3,
                0x50C2C2C2
        );

        RenderUtil.drawRect(
                this.x,
                this.y + 17,
                this.x + this.width - 8,
                this.y + 18,
                0x50C2C2C2
        );

        if (Ref.getFriendManager().getFriends().size() == 0) {
            this.mc.bridge$getFontRenderer().bridge$drawCenteredString(
                    "No friends.",
                    (int) (this.x + this.width / 2 - 2),
                    (int) (this.y + 50),
                    -1,
                    true
            );
            this.mc.bridge$getFontRenderer().bridge$drawCenteredString(
                    "Add a few below!",
                    (int) (this.x + this.width / 2 - 2),
                    (int) (this.y + 65),
                    -1,
                    true
            );
        } else {
            int size = Ref.getFriendManager().getFriends().size();
            this.mc.bridge$getFontRenderer().bridge$drawCenteredString(
                    size + " Friend" + (size == 1 ? "" : "s"),
                    (int) (this.x + this.width / 2 - 2),
                    (int) (this.y + 5),
                    -1,
                    true
            );
        }

        int height = 23;
        for (FriendComponent friendComponent : this.friendPages.get(this.pageNumber).getFriendComponents()) {
            friendComponent.position(this.x + 5, this.y + height);
            friendComponent.size(friendComponent.selected ? 132 : this.mc.bridge$getFontRenderer().bridge$getStringWidth(friendComponent.getFriend().getPreferredName()) + 35, friendComponent.selected ? 32.0F : 16.0F);
            friendComponent.draw(mouseX, mouseY);
            height += friendComponent.selected ? 36.0F : 18.0F;
        }

        this.leftButton.setDisabled(this.pageNumber == 0);
        this.leftButton.position((int) (this.x + this.width / 4 + 10),this.y + this.height - 42);
        this.leftButton.size(15, 15);
        this.leftButton.draw(mouseX, mouseY);

        this.rightButton.setDisabled(this.pageNumber == this.friendPages.size() - 1);
        this.rightButton.position((int) (this.x + this.width / 4 + 35),this.y + this.height - 42);
        this.rightButton.size(15, 15);
        this.rightButton.draw(mouseX, mouseY);
    }

    @Override
    public void keyTyped(char character, int key) {
        if (this.selectedFriend != null) {
            this.selectedFriend.keyTyped(character, key);
        }
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        for (FriendComponent friendComponent : this.friendPages.get(this.pageNumber).getFriendComponents()) {
            if (friendComponent.getRemoveButton().mouseInside(mouseX, mouseY)) {
                SoundUtil.playClick();
                if (this.selectedFriend != null) {
                    this.selectedFriend.selected = false;
                    this.selectedFriend = null;
                }
                Ref.getFriendManager().getFriends().remove(friendComponent.getFriend());

                GuiScreenBridge screen = Bridge.getInstance().bridge$initCustomGuiScreen(new FriendsListScreen());
                this.mc.bridge$displayGuiScreen(screen);
                return;
            }

            if (friendComponent.getNicknameBox().mouseInside(mouseX, mouseY)) {
                friendComponent.getNicknameBox().mouseClicked(mouseX, mouseY);
                return;
            }

            if (friendComponent.mouseInside(mouseX, mouseY)) {
                SoundUtil.playClick();
                if (this.selectedFriend == friendComponent) {
                    this.selectedFriend.selected = false;
                    this.selectedFriend = null;
                    return;
                }

                if (this.selectedFriend != null) {
                    // get rid of the old one
                    this.selectedFriend.selected = false;
                }

                // set the new one
                this.selectedFriend = friendComponent;
                this.selectedFriend.selected = true;
                this.selectedFriend.mouseClicked(mouseX, mouseY);
                return;
            }
        }

        if (this.selectedFriend != null) {
            this.selectedFriend.selected = false;
        }
        this.selectedFriend = null;

        boolean showPageButtons = this.friendPages.size() > 1;
        if (showPageButtons && this.leftButton.mouseInside(mouseX, mouseY) && this.pageNumber > 0) {
            SoundUtil.playClick();
            this.pageNumber--;
        } else if (showPageButtons && this.rightButton.mouseInside(mouseX, mouseY) && this.pageNumber + 1 < this.friendPages.size()) {
            SoundUtil.playClick();
            this.pageNumber++;
        }

    }

}
