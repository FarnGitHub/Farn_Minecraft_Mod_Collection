package cc.noxiuam.titanic.client.ui.screen.friend;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import cc.noxiuam.titanic.client.registry.Friend;
import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.ui.component.type.button.RoundedTextButton;
import cc.noxiuam.titanic.client.ui.component.type.text.TextBoxComponent;
import cc.noxiuam.titanic.client.ui.screen.friend.container.FriendsListContainer;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.client.util.chat.ChatUtil;
import cc.noxiuam.titanic.client.util.SoundUtil;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

// Name changed to "FriendListRapper" from "FriendListWrapper"
// because of something the GG said lmao - Nox (5/1/2023)
public class FriendListWrapper extends AbstractComponent {

    private final FriendsListContainer friendsListContainer = new FriendsListContainer();

    private final TextBoxComponent addBox = new TextBoxComponent("Username...");
    private final RoundedTextButton addButton = new RoundedTextButton("Add");

    @Override
    public void handleUpdate() {
        this.addBox.handleUpdate();
        this.friendsListContainer.handleUpdate();
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        RenderUtil.drawRect(
                this.x,
                this.y,
                this.x + this.width,
                this.y + this.height,
                0x80000000
        );

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        RenderUtil.drawIcon(
                "/titanic/logo.png",
                this.x + this.width / 2 - 32,
                this.y + 5,
                115 / 1.7F,
                28 / 1.7F
        );

        this.addBox.position(this.x + 4, this.y + this.height - 18);
        this.addBox.size(110, 12);
        this.addBox.draw(mouseX, mouseY);

        this.addButton.position(this.x + this.addBox.getWidth() + 10, this.y + this.height - 19.5F);
        this.addButton.size(28, 14);
        this.addButton.draw(mouseX, mouseY);

        this.friendsListContainer.draw(mouseX, mouseY);
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        if (this.addButton.mouseInside(mouseX, mouseY) && this.addBox.getText().length() > 0) {
            SoundUtil.playClick();
            this.addNewFriend();
            return;
        }

        if (!this.addBox.using && this.addBox.mouseInside(mouseX, mouseY)) {
            this.addBox.mouseClicked(mouseX, mouseY);
        } else {
            this.addBox.using = false;
        }

        this.friendsListContainer.mouseClicked(mouseX, mouseY);
    }

    @Override
    public void keyTyped(char character, int key) {
        if (this.addBox.using) {
            if (key == Keyboard.KEY_RETURN && this.addBox.getText().length() > 0) {
                this.addNewFriend();
                return;
            }
            this.addBox.keyTyped(character, key);
        }

        this.friendsListContainer.keyTyped(character, key);
    }

    private void addNewFriend() {
        if (Bridge.getInstance()
                .bridge$getMinecraft()
                .bridge$getThePlayer()
                .bridge$getUsername().equalsIgnoreCase(this.addBox.getText())) {
            ChatUtil.addChatMessage("You can not friend yourself!");
            this.addBox.setText("");
            return;
        }

        if (Ref.getFriendManager().isFriend(this.addBox.getText())) {
            ChatUtil.addChatMessage(this.addBox.getText() + " is already your friend!");
            this.addBox.setText("");
            return;
        }

        Friend newFriend = new Friend(this.addBox.getText(), "");
        Ref.getFriendManager().getFriends().add(newFriend);

        GuiScreenBridge screen = Bridge.getInstance().bridge$initCustomGuiScreen(new FriendsListScreen());
        this.mc.bridge$displayGuiScreen(screen);
    }

    @Override
    public void size(float width, float height) {
        super.size(width, height);
        this.friendsListContainer.size(width, height - 21);
    }

    @Override
    public void position(float newX, float newY) {
        super.position(newX, newY);
        this.friendsListContainer.position(newX + 4, newY + 25);
    }

}
