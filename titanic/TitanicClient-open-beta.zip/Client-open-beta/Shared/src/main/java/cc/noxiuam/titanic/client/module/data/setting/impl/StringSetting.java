package cc.noxiuam.titanic.client.module.data.setting.impl;

import cc.noxiuam.titanic.client.module.data.setting.AbstractSetting;
import cc.noxiuam.titanic.client.ui.screen.module.container.module.setting.ModuleSettingsContainer;
import cc.noxiuam.titanic.client.ui.component.type.setting.AbstractSettingComponent;
import cc.noxiuam.titanic.client.ui.component.type.setting.impl.string.StringComponent;
import com.google.gson.JsonObject;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StringSetting extends AbstractSetting<String> {

    private final int maxLength;
    private boolean encryptText;

    public StringSetting(String id, String name, String defaultValue, int maxLength) {
        super(id, name, defaultValue);
        this.maxLength = maxLength;
    }

    @Override
    public AbstractSettingComponent<String> getComponent(ModuleSettingsContainer list) {
        return new StringComponent(this, list);
    }

    @Override
    public void save(JsonObject configObject) {
        configObject.addProperty(this.id(), this.value());
    }

    @Override
    public void load(JsonObject configObject) {
        this.value(configObject.get(this.id()).getAsString());
    }

}
