package cc.noxiuam.titanic.event.impl.world.block;

import cc.noxiuam.titanic.event.AbstractEvent;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public class PortalOverlayEvent extends AbstractEvent {
}
