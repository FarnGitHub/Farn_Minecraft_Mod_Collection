package cc.noxiuam.titanic.event.impl.gui.chat;

import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ChatPositionUpdateEvent extends AbstractEvent {

    private int position;
    private int firstPosition;

}
