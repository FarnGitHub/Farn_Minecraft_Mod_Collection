package cc.noxiuam.titanic.client.network.cosmetic;

import cc.noxiuam.titanic.client.network.cosmetic.type.misc.Cosmetic;
import cc.noxiuam.titanic.client.network.cosmetic.type.nametag.NametagIcon;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor
public class PlayerProfile {

    private String username;
    private NametagIcon nametagIcon;
    private Cosmetic cosmetic;

}
