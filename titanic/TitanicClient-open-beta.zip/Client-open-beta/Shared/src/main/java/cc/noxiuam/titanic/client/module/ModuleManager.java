package cc.noxiuam.titanic.client.module;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.client.module.impl.DiscordRPCModule;
import cc.noxiuam.titanic.client.module.impl.fix.impl.*;
import cc.noxiuam.titanic.client.module.impl.hud.impl.*;
import cc.noxiuam.titanic.client.module.impl.normal.*;
import cc.noxiuam.titanic.client.module.impl.normal.gui.crosshair.CrosshairModule;
import cc.noxiuam.titanic.client.module.impl.normal.gui.ModernInventoryModule;
import cc.noxiuam.titanic.client.module.impl.normal.gui.PackTweaksModule;
import cc.noxiuam.titanic.client.module.impl.normal.world.ChunkLoadingFix;
import cc.noxiuam.titanic.client.module.impl.normal.chat.AutoLoginModule;
import cc.noxiuam.titanic.client.module.impl.normal.chat.ChatEditorModule;
import cc.noxiuam.titanic.client.module.impl.normal.world.WorldEditor;
import cc.noxiuam.titanic.client.module.impl.normal.world.performance.PerformanceModule;
import cc.noxiuam.titanic.client.module.impl.normal.perspective.PerspectiveModule;
import cc.noxiuam.titanic.client.module.impl.normal.perspective.zoom.ZoomModule;
import lombok.Getter;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Getter
public class ModuleManager {

    private final List<AbstractModule> mods = new CopyOnWriteArrayList<>();

    private final PerspectiveModule perspectiveModule;
    private final ChatEditorModule chatEditorModule;
    private final PackTweaksModule packTweaksModule;

    private final WorldEditor worldEditor;

    private final PlayerAssetFix playerAssetFix;

    public ModuleManager() {
        // qol mods
        this.mods.add(new ModernInventoryModule());
        this.mods.add(new PerformanceModule());
        this.mods.add(this.perspectiveModule = new PerspectiveModule());
        this.mods.add(this.chatEditorModule = new ChatEditorModule());
        this.mods.add(new ZoomModule());

        this.mods.add(new FPSModule());
        this.mods.add(new CPSModule());
        this.mods.add(new CoordinatesModule());
        this.mods.add(new CompassModule());
        this.mods.add(this.packTweaksModule = new PackTweaksModule());
        this.mods.add(new NametagEditorModule());

        this.mods.add(new AutoLoginModule());
        this.mods.add(this.worldEditor = new WorldEditor());
        this.mods.add(new ScreenshotModule());
        this.mods.add(new CrosshairModule());

        this.mods.add(new ChunkLoadingFix());
        this.mods.add(new FofoModule());
        this.mods.add(new DiscordRPCModule());

        // game fixes
        this.mods.add(this.playerAssetFix = new PlayerAssetFix());
        this.mods.add(new PlayerModelFix());
        this.mods.add(new SavingLevelFix());
        this.mods.add(new ChestTextFix());
        this.mods.add(new DeadEntityRenderFix());

        // filter out any unsupported mods we do not want for the version.
        for (AbstractModule module : this.mods) {
            if (!module.supportedVersions().contains(Ref.MC_VERSION)) {
                this.mods.remove(module);
                module.enabled(false);
                module.onDisable();
                module.removeAllEvents();
            }
        }
    }

}
