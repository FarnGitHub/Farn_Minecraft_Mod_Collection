package cc.noxiuam.titanic.bridge.minecraft.block;

public interface BlockFluidsBridge {

    double bridge$getFlowDirection(BlockAccessBridge blockAccessBridge, int x, int y, int z, MaterialBridge materialBridge);

    float bridge$setFluidHeight(int i);

}
