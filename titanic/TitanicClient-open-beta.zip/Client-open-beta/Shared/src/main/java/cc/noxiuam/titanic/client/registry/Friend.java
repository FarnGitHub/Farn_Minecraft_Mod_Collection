package cc.noxiuam.titanic.client.registry;

import cc.noxiuam.titanic.client.util.CaseUtils;
import com.google.gson.JsonObject;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@AllArgsConstructor
public class Friend extends AbstractLoadable {

    private String username;
    @Setter private String nickname;

    @Override
    public void save(JsonObject obj) {
        obj.add(
                CaseUtils.toCamelCase(this.username, false),
                this.getSerialized()
        );
    }

    @Override
    public void load(JsonObject obj) {
        // Loading done via friend manager.
    }

    @Override
    public JsonObject getSerialized() {
        JsonObject friendObject = new JsonObject();
        friendObject.addProperty("username", this.username);
        friendObject.addProperty("nickname", this.nickname);
        return friendObject;
    }

    public String getPreferredName() {
        if (this.getNickname().length() > 0) {
            return this.nickname;
        }
        return this.username;
    }

}
