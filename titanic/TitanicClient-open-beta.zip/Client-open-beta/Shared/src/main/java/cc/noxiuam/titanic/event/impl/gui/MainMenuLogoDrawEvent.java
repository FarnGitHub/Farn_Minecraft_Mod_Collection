package cc.noxiuam.titanic.event.impl.gui;

import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiMainMenuBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class MainMenuLogoDrawEvent extends AbstractEvent {

    private GuiMainMenuBridge mainMenu;

}
