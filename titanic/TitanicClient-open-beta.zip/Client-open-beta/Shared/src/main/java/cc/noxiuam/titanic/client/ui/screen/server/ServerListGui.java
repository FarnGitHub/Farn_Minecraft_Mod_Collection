package cc.noxiuam.titanic.client.ui.screen.server;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiButtonBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import cc.noxiuam.titanic.bridge.minecraft.renderer.TessellatorBridge;
import cc.noxiuam.titanic.client.registry.FeaturedServer;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Noxiuam
 * https://noxiuam.cc
 */
public class ServerListGui implements GuiScreenBridge {

    private int field_6460_h = 0;
    private int field_6459_i = 32;
    private int backgroundHeight = this.bridge$getHeight() - 55 + 4;
    private int backgroundX = 0;
    private int backgroundWidth = this.bridge$getWidth();

    private final List<ServerComponent> serverComponents = new ArrayList<>();
    private final GuiScreenBridge parentScreen;
    private ServerComponent selectedServer;

    public ServerListGui(GuiScreenBridge parentScreen) {
        this.parentScreen = parentScreen;

        for (FeaturedServer server : Ref.getServerManager().getFeaturedServers()) {
            this.serverComponents.add(new ServerComponent(server));
        }
    }

    @Override
    public void bridge$initGui() {
        this.bridge$getButtonList().clear();

        this.field_6459_i = 32;
        this.backgroundHeight = this.bridge$getHeight() - 58 + 4;
        this.backgroundX = 0;
        this.backgroundWidth = this.bridge$getWidth();

        int buttonY = 38;

        // join button
        this.bridge$getButtonList().add(
                Bridge.getInstance().bridge$createNewGuiButton(
                        1,
                        this.bridge$getWidth() / 2 - 154,
                        this.bridge$getHeight() - buttonY,
                        100,
                        20,
                        "Join"
                )
        );

        // direct connect
        this.bridge$getButtonList().add(
                Bridge.getInstance().bridge$createNewGuiButton(
                        2,
                        this.bridge$getWidth() / 2 - 50,
                        this.bridge$getHeight() - buttonY,
                        100,
                        20,
                        "Direct Connect"
                )
        );

        // cancel
        this.bridge$getButtonList().add(
                Bridge.getInstance().bridge$createNewGuiButton(
                        0,
                        this.bridge$getWidth() / 2 + 54,
                        this.bridge$getHeight() - buttonY,
                        100,
                        20,
                        "Cancel"
                )
        );
    }

    @Override
    public void bridge$drawScreen(int x, int y, float partialTicks) {
        this.bridge$drawDefaultBackground();

        for (GuiButtonBridge button : this.bridge$getButtonList()) {
            button.bridge$drawButton(BridgeRef.getMinecraft(), x, y);
        }

        int var5 = this.serverComponents.size() * 36 - (this.backgroundHeight - this.field_6459_i - 4);
        if (var5 < 0) {
            var5 /= 2;
        }

        if (this.field_6460_h < 0) {
            this.field_6460_h = 0;
        }

        if (this.field_6460_h > var5) {
            this.field_6460_h = var5;
        }

        TessellatorBridge tessellator = BridgeRef.getTessellator();

        if (Bridge.getInstance().bridge$getTheWorld() == null) {
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            RenderUtil.drawRect(
                    this.backgroundX,
                    this.field_6459_i,
                    this.backgroundWidth,
                    this.backgroundHeight,
                    0x80000000
            );
        }

        BridgeRef.getMinecraft().bridge$getFontRenderer().bridge$drawCenteredString(
                "Featured Servers",
                this.bridge$getWidth() / 2,
                13,
                16777215,
                true
        );

        int height = 50;
        for (ServerComponent serverComponent : this.serverComponents) {
            serverComponent.size(249, 35);
            serverComponent.position(this.bridge$getWidth() / 2 - serverComponent.getWidth() / 2, height);
            serverComponent.draw(x, y);
            height += serverComponent.getHeight() + 5;
        }

        String[] noFeaturedServers = new String[] {
                "There are currently no featured servers for this version.",
                "Please try again later."
        };

        int noFeaturedServersHeight = 0;
        if (this.serverComponents.size() == 0) {
            for (String str : noFeaturedServers) {
                BridgeRef.getMinecraft().bridge$getFontRenderer().bridge$drawCenteredString(
                        str,
                        this.bridge$getWidth() / 2,
                        this.bridge$getHeight() / 2 - 15 + noFeaturedServersHeight,
                        16777215,
                        true
                );
                noFeaturedServersHeight += 15;
            }
        }

        int var18 = 4;
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_ALPHA_TEST);
        GL11.glShadeModel(GL11.GL_SMOOTH);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        tessellator.bridge$startDrawingQuads();
        tessellator.bridge$setColorRGBA_I(0, 0);
        tessellator.bridge$addVertexWithUV(this.backgroundX, (this.field_6459_i + var18), 0.0D, 0.0D, 1.0D);
        tessellator.bridge$addVertexWithUV(this.backgroundWidth, (this.field_6459_i + var18), 0.0D, 1.0D, 1.0D);
        tessellator.bridge$setColorRGBA_I(0, 255);
        tessellator.bridge$addVertexWithUV(this.backgroundWidth, this.field_6459_i, 0.0D, 1.0D, 0.0D);
        tessellator.bridge$addVertexWithUV(this.backgroundX, this.field_6459_i, 0.0D, 0.0D, 0.0D);
        tessellator.bridge$draw();
        tessellator.bridge$startDrawingQuads();
        tessellator.bridge$setColorRGBA_I(0, 255);
        tessellator.bridge$addVertexWithUV(this.backgroundX, this.backgroundHeight, 0.0D, 0.0D, 1.0D);
        tessellator.bridge$addVertexWithUV(this.backgroundWidth, this.backgroundHeight, 0.0D, 1.0D, 1.0D);
        tessellator.bridge$setColorRGBA_I(0, 0);
        tessellator.bridge$addVertexWithUV(this.backgroundWidth, (this.backgroundHeight - var18), 0.0D, 1.0D, 0.0D);
        tessellator.bridge$addVertexWithUV(this.backgroundX, (this.backgroundHeight - var18), 0.0D, 0.0D, 0.0D);
        tessellator.bridge$draw();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glShadeModel(GL11.GL_FLAT);
        GL11.glEnable(GL11.GL_ALPHA_TEST);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    @Override
    public void bridge$actionPerformed(GuiButtonBridge button) {
        if (button.bridge$getButtonID() == 0) {
            BridgeRef.getMinecraft().bridge$displayGuiScreen(
                    this.parentScreen
            );
        } else if (button.bridge$getButtonID() == 1 && this.selectedServer != null) {
            if (BridgeRef.getMinecraft().bridge$isMultiplayerWorld()) {
                Bridge.getInstance().bridge$getTheWorld().bridge$sendQuittingDisconnectingPacket();
            }
            BridgeRef.getMinecraft().bridge$displayGuiScreen(
                    Bridge.getInstance().bridge$getGuiConnecting(
                            BridgeRef.getMinecraft(),
                            this.selectedServer.getServer().getAddresses().get(0),
                            25565
                    )
            );
        } else if (button.bridge$getButtonID() == 2) {
            BridgeRef.getMinecraft().bridge$displayGuiScreen(
                    Bridge.getInstance().bridge$getGuiMultiplayer()
            );
        }
    }

    @Override
    public void bridge$mouseClicked(int x, int y, int button) {
        if (button == 0) {
            for (ServerComponent serverComponent : this.serverComponents) {
                if (serverComponent.mouseInside(x, y)) {
                    serverComponent.mouseClicked(x, y);

                    if (this.selectedServer != null) {
                        this.selectedServer.selected = false;
                    }

                    this.selectedServer = serverComponent;
                }
            }
        }
    }

}
