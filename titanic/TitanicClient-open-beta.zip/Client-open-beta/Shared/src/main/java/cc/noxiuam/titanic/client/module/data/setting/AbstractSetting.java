package cc.noxiuam.titanic.client.module.data.setting;

import cc.noxiuam.titanic.client.ui.screen.module.container.module.setting.ModuleSettingsContainer;
import cc.noxiuam.titanic.client.ui.component.type.setting.AbstractSettingComponent;
import com.google.gson.JsonObject;
import lombok.*;
import lombok.experimental.Accessors;

import java.util.Objects;
import java.util.function.Consumer;

@Getter
@ToString
@Accessors(fluent = true)
public abstract class AbstractSetting<T> {

    private final String id;
    @Setter private String name;
    @Setter private String description;

    private final T defaultValue;
    private T value;

    @Setter private Consumer<Object> onUpdate;

    public AbstractSetting(String id, String name, T defaultValue) {
        this.id = id;
        this.name = name;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public abstract AbstractSettingComponent<T> getComponent(ModuleSettingsContainer list);

    public abstract void save(JsonObject configObject);

    public abstract void load(JsonObject configObject);

    public void value(T newValue) {
        if (!Objects.equals(this.value, newValue)) {
            this.value = newValue;

            if (this.onUpdate != null) {
                this.onUpdate.accept(value);
            }
        }
    }

}
