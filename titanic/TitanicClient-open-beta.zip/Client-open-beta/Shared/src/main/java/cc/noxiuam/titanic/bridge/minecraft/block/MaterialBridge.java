package cc.noxiuam.titanic.bridge.minecraft.block;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface MaterialBridge {

    boolean bridge$isSolid();

    boolean bridge$isLiquid();

}
