package cc.noxiuam.titanic.bridge.minecraft.renderer;

import java.awt.image.BufferedImage;

public interface ImageBufferBridge {
    BufferedImage parseUserSkin(BufferedImage image);
}
