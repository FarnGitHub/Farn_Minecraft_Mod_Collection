package cc.noxiuam.titanic.client.network.manager;

import cc.noxiuam.titanic.Client;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.client.network.cosmetic.type.misc.Cosmetic;
import cc.noxiuam.titanic.client.network.cosmetic.type.nametag.NametagIcon;
import cc.noxiuam.titanic.client.network.cosmetic.PlayerProfile;
import cc.noxiuam.titanic.kotlin.client.logger.Logger;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lombok.Getter;
import lombok.SneakyThrows;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@Getter
public class PlayerProfileManager {

    private final List<PlayerProfile> playerProfileCache = new ArrayList<>();

    private static final Logger LOGGER = new Logger("Player Profile Management");

    public PlayerProfileManager() {
        new Thread(new ProfileCacheRefreshThread()).start();
    }

    @SneakyThrows
    public void downloadAllProfiles() {
        List<String> names = new ArrayList<>();

        URL url = new URL("https://noxiuam.cc/titanic-client/api/profiles.json");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        connection.setRequestMethod("GET");
        connection.addRequestProperty("User-Agent", "Mozilla/4.0");

        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));

        JsonArray remoteNames = new JsonParser().parse(br).getAsJsonArray();

        for (int i = 0; i < remoteNames.size(); i++) {
            names.add(remoteNames.get(i).toString().replaceAll("\"", ""));
        }

        for (String name : names) {
            this.downloadAndAddProfile(name);
        }
    }

    /**
     * Pulls the remote profile from the website, and creates it client-sided.
     * If the profile does not exist, a default profile gets returned.
     *
     * @param username The username to pull a profile from.
     */
    private void downloadAndAddProfile(String username) {
        LOGGER.debug("Downloading " + username + (username.endsWith("s") ? "'" : "'s") + " profile");

        try {
            URL url = new URL("https://noxiuam.cc/titanic-client/api/player/" + username);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("GET");
            connection.addRequestProperty("User-Agent", "Mozilla/4.0");

            BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            JsonObject playerObj = new JsonParser().parse(br).getAsJsonObject();

            boolean oblivious = false;

            if (playerObj.get("oblivious") != null) {
                oblivious = playerObj.get("oblivious").getAsBoolean();
            }

            NametagIcon nametagIcon = null;
            if (playerObj.get("nametagIcon") != null) {
                JsonObject nametagObj = playerObj.get("nametagIcon").getAsJsonObject();
                String iconUrl = "https://noxiuam.cc/titanic-client/api/cosmetic/nametag/" + nametagObj.get("name").getAsString() + ".png";
                int iconXOffset = nametagObj.get("xOffset").getAsInt();
                int iconWidth = nametagObj.get("width").getAsInt();
                int iconHeight = nametagObj.get("height").getAsInt();
                nametagIcon = new NametagIcon(iconUrl, iconXOffset, iconWidth, iconHeight);
            }

            Cosmetic equippedCosmetic = null;
            if (playerObj.get("cosmetic") != null) {
                JsonObject cosmetic = playerObj.get("cosmetic").getAsJsonObject();
                String cosmeticName = cosmetic.get("name").getAsString();
                String cosmeticDescription = cosmetic.get("description").getAsString();
                boolean isCosmeticEquipped = cosmetic.get("equipped").getAsBoolean();
                String cosmeticType = cosmetic.get("type").getAsString();
                String cosmeticLocation = cosmetic.get("location").getAsString();
                equippedCosmetic = new Cosmetic(cosmeticName, cosmeticDescription, isCosmeticEquipped, cosmeticType, cosmeticLocation);
            }

            PlayerProfile playerProfile = new PlayerProfile(username, nametagIcon, equippedCosmetic);
            this.playerProfileCache.add(playerProfile);

            connection.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (Client.getInstance().getDebug()) {
            Cosmetic debugCosmetic = new Cosmetic("Debug Cosmetic", "Cosmetic used for debugging purposes.", true, "cape", "https://noxiuam.cc/titanic-client/api/cosmetic/cape/avolition.png");
            NametagIcon debugNametagIcon = new NametagIcon("https://noxiuam.cc/titanic-client/api/cosmetic/nametag/phd.png", 4, 7, 7);
            PlayerProfile debugProfile = new PlayerProfile("Player", debugNametagIcon, debugCosmetic);
            this.playerProfileCache.add(debugProfile);
        }
    }

    /**
     * Checks if a profile exists.
     *
     * @param username The target player.
     */
    public boolean profileExists(String username) {
        for (PlayerProfile playerProfile : this.playerProfileCache) {
            if (playerProfile.getUsername().equals(username)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Gets a player profile from playerProfiles.
     *
     * @param target The username of the target player.
     */
    public PlayerProfile getProfile(String target) {
        for (PlayerProfile playerProfile : this.playerProfileCache) {
            if (playerProfile.getUsername().equals(target)) {
                return playerProfile;
            }
        }

        return new PlayerProfile(target, null, null);
    }

    class ProfileCacheRefreshThread implements Runnable {

        @Override
        public void run() {
            try {
                downloadAllProfiles();
                Thread.sleep(60000L);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

}
