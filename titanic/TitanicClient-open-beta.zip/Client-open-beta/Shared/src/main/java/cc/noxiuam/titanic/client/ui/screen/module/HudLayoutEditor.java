package cc.noxiuam.titanic.client.ui.screen.module;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.minecraft.client.MinecraftBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.impl.hud.AbstractMovableModule;
import cc.noxiuam.titanic.client.ui.component.type.button.RoundedIconButton;
import cc.noxiuam.titanic.client.ui.component.type.button.RoundedTextButton;
import cc.noxiuam.titanic.client.ui.transition.impl.ColorTransition;
import cc.noxiuam.titanic.client.ui.transition.impl.GradualTransition;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.client.util.SoundUtil;
import cc.noxiuam.titanic.client.util.chat.ChatColor;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class HudLayoutEditor implements GuiScreenBridge {

    private final GradualTransition logoFadeInTime = new GradualTransition(200L);

    private final MinecraftBridge mc = Bridge.getInstance().bridge$getMinecraft();
    private final List<AbstractMovableModule> hudModules = new CopyOnWriteArrayList<>();

    private final RoundedTextButton modsButton = new RoundedTextButton(
            "Mods"
    );

    private AbstractMovableModule selectedModule;

    private float xOffset;
    private float yOffset;

    public HudLayoutEditor() {
        for (AbstractModule module : Ref.getModuleManager().getMods()) {
            if (module instanceof AbstractMovableModule) {
                this.hudModules.add((AbstractMovableModule) module);
            }
        }
    }

    @Override
    public void bridge$onGuiClosed() {
        Ref.getConfigManager().saveConfigs();
    }

    @Override
    public void bridge$initGui() {
        this.modsButton.size(75, 20.5F);
        this.modsButton.position(this.bridge$getWidth() / 2.0F - this.modsButton.getWidth() / 2, this.bridge$getHeight() / 2.0F - 12);
        this.modsButton.setTooltip("Edit the mods that Titanic offers.");

        if (!this.logoFadeInTime.hasStarted()) {
            this.logoFadeInTime.startTransition();
        }
    }

    @Override
    public void bridge$drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (this.selectedModule != null && this.selectedModule.enabled()) {
            this.selectedModule.setPosition(mouseX - this.xOffset, mouseY - this.yOffset);
        }

        for (AbstractMovableModule module : this.hudModules) {
            if (!module.enabled()) {
                continue;
            }

            // Draw an overlay rectangle if you're hovering over the mod or if it's the selected mod
            if (module.mouseInside(mouseX, mouseY)) {
                GL11.glPushMatrix();
                RenderUtil.drawRect(
                        module.x(),
                        module.y(),
                        module.x() + module.width(),
                        module.y() + module.height(),
                        0x701471FF
                );

                GL11.glPopMatrix();
            }

            // Draw an outline around each of them
            GL11.glPushMatrix();
            RenderUtil.drawRoundedOutline(
                    module.x(),
                    module.y(),
                    module.x() + module.width(),
                    module.y() + module.height(),
                    0,
                    3,
                    0xFF1471FF
            );
            GL11.glPopMatrix();
        }

        GL11.glColor4f(1.0F, 1.0F, 1.0F, this.logoFadeInTime.getFadeAmount());
        RenderUtil.drawIcon(
                "/titanic/logo.png",
                this.bridge$getWidth() / 2 - 56,
                this.bridge$getHeight() / 2 - 45,
                115,
                28
        );

        // mod settings button
        this.modsButton.draw(mouseX, mouseY);
        RenderUtil.drawComponentTooltip(this.modsButton, mouseX, mouseY);

        // Indicator text
        String blueText = "HUD";
        String indicator = "You are currently editing the";
        this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(blueText + ChatColor.WHITE + ".",
                this.bridge$getWidth() / 2 + this.mc.bridge$getFontRenderer().bridge$getStringWidth(indicator) / 2 - 4, this.bridge$getHeight() / 2 + 15, 0xFF1471FF);

        this.mc.bridge$getFontRenderer().bridge$drawCenteredString(
                indicator, 
                this.bridge$getWidth() / 2 - this.mc.bridge$getFontRenderer().bridge$getStringWidth(blueText) / 2,
                this.bridge$getHeight() / 2 + 15, -1,
                true
        );
    }

    @Override
    public void bridge$mouseMovedOrUp(int mouseX, int mouseY, int button) {
        if (button == 0) {
            this.selectedModule = null;
        }
    }

    @Override
    public void bridge$mouseClicked(int mouseX, int mouseY, int button) {
        if (button != 0) {
            return;
        }

        if (this.modsButton.mouseInside(mouseX, mouseY)) {
            SoundUtil.playClick();

            GuiScreenBridge modSettingsEditor = Bridge.getInstance().bridge$initCustomGuiScreen(new ModSettingsEditor());
            this.mc.bridge$displayGuiScreen(modSettingsEditor);
        }

        for (AbstractMovableModule module : this.hudModules) {
            if (module.mouseInside(mouseX, mouseY)) {
                this.selectedModule = module;
                this.xOffset = mouseX - module.x();
                this.yOffset = mouseY - module.y();
            }
        }
    }

}
