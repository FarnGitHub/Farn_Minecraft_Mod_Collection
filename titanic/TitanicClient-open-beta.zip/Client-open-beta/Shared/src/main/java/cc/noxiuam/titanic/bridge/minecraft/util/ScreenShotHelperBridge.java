package cc.noxiuam.titanic.bridge.minecraft.util;

import java.io.File;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface ScreenShotHelperBridge {

    String bridge$saveScreenshot(File file, int width, int height);

}
