package cc.noxiuam.titanic.bridge.minecraft.entity;

import cc.noxiuam.titanic.bridge.minecraft.item.ItemStackBridge;

public interface InventoryPlayerBridge {

    ItemStackBridge bridge$armorItemInSlot(int slot);

    ItemStackBridge bridge$getStackInHand();

    int bridge$getSizeInventory();

}
