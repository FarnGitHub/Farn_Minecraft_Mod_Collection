package cc.noxiuam.titanic.client.network.cosmetic.type.emote.support;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.client.network.cosmetic.type.emote.EmoteManager;
import cc.noxiuam.titanic.client.network.cosmetic.type.emote.support.impl.A1_1_2AlphaPlaceEmoteSupport;
import cc.noxiuam.titanic.client.network.cosmetic.type.emote.support.impl.AlphaPlaceEmoteSupport;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Noxiuam
 * https://noxiuam.cc
 */
@Getter
public class EmoteSupportManager {

    private final List<EmoteManager.AbstractEmoteSupport> supportedServers = new ArrayList<>();

    public EmoteSupportManager() {
        if (Ref.MC_VERSION == MinecraftVersion.B1_1_02) {
            this.supportedServers.add(new AlphaPlaceEmoteSupport());
        }

        if (Ref.MC_VERSION == MinecraftVersion.A1_1_2_01) {
            this.supportedServers.add(new A1_1_2AlphaPlaceEmoteSupport());
        }
    }

    public EmoteManager.AbstractEmoteSupport getCurrentServerSupport() {
        JsonObject serverMapping = Ref.getServerManager().getServerMapping();

        if (serverMapping == null) {
            return null;
        }

        for (Map.Entry<String, JsonElement> entry : serverMapping.entrySet()) {
            String id = entry.getKey().toLowerCase();
            EmoteManager.AbstractEmoteSupport emoteSupport = this.getSupportByID(id);

            JsonObject serverObj = entry.getValue().getAsJsonObject();
            JsonArray addresses = serverObj.get("addresses").getAsJsonArray();

            if (emoteSupport != null && this.isOnServer(addresses)) {
                return emoteSupport;
            }
        }

        return null;
    }

    private boolean isOnServer(JsonArray addresses) {
        boolean flag = false;
        for (int i = 0; i < addresses.size(); i++) {
            String address = addresses.get(i).getAsString();
            if (Ref.getServerManager().getCurrentServerAddress().equals(address)) {
                flag = true;
            }
        }
        return flag;
    }

    private EmoteManager.AbstractEmoteSupport getSupportByID(String id) {
        for (EmoteManager.AbstractEmoteSupport emoteSupport : this.supportedServers) {
            if (emoteSupport.getServerID().equalsIgnoreCase(id)) {
                return emoteSupport;
            }
        }

        return null;
    }

}
