package cc.noxiuam.titanic.client.module.impl.normal.gui;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.block.impl.BlockPortalBridge;
import cc.noxiuam.titanic.bridge.minecraft.renderer.TessellatorBridge;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.data.ModuleCategory;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.KeybindSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.ChoiceSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.StringSetting;
import cc.noxiuam.titanic.client.util.chat.ChatUtil;
import cc.noxiuam.titanic.event.impl.font.DrawStringEvent;
import cc.noxiuam.titanic.event.impl.gui.*;
import cc.noxiuam.titanic.event.impl.keyboard.KeyboardEvent;
import cc.noxiuam.titanic.event.impl.world.block.PortalOverlayEvent;
import cc.noxiuam.titanic.event.impl.world.player.OnLivingUpdateEvent;
import cc.noxiuam.titanic.event.impl.world.player.PlayerBlockCollideEvent;
import com.google.common.collect.ImmutableList;
import lombok.SneakyThrows;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.util.Random;

public class PackTweaksModule extends AbstractModule {

    public int guiScale = 0;

    private final KeybindSetting debugKeybind, toggleHUD;
    private final StringSetting watermarkString;
    private final BooleanSetting showFireInFirstPerson;
    private BooleanSetting showPortalOverlay;
    private final ChoiceSetting guiScaleSetting;
    private ChoiceSetting mainMenuLogo;

    private final Random rand = new Random();

    public boolean showDebugInfo = false;
    public boolean showHUD = true;

    private boolean inPortal;

    private float timeInPortal;
    private float prevTimeInPortal;

    public PackTweaksModule() {
        super(
                "packTweaks",
                "Pack Tweaks",
                "Allows you to change numerous textures/strings in the game.",
                false,
                MinecraftVersion.getAllVersions(),
                ImmutableList.of(
                        ModuleCategory.GUI
                )
        );

        this.addSettings(
                this.toggleHUD = new KeybindSetting("toggleHUD", "Toggle HUD", Keyboard.KEY_F1),
                this.debugKeybind = new KeybindSetting("debugKeybind", "Toggle Debug Info", Keyboard.KEY_F3),
                this.guiScaleSetting = new ChoiceSetting(
                        "guiScaleSetting", "Gui Scale",
                        "Auto",
                        "Small", "Normal", "Large", "Auto"
                )
        );

        // Want to keep the vibe of Alpha + it has rendering issues
        if (Ref.MC_VERSION.isAboveOrEqual(MinecraftVersion.B1_1_02)) {
            this.addSettings(
                    this.mainMenuLogo = new ChoiceSetting(
                            "mainMenuLogo",
                            "Main Menu Logo",
                            "Classic",
                            "Classic", "Modern"
                    )
            );
            this.mainMenuLogo.description("Allows you to change the main menu logo to the new one.");
        }

        if (Ref.MC_VERSION.isAboveOrEqual(MinecraftVersion.B1_1_02)
                && Ref.MC_VERSION.isBelowOrEqual(MinecraftVersion.B1_7_3) /* will be changed when I figure out when it was added */) {
            this.addSettings(
                    this.showPortalOverlay = new BooleanSetting("showPortalOverlay", "Show Portal Overlay", false)
            );
        }

        this.addSettings(
                this.showFireInFirstPerson = new BooleanSetting("showFireInFirstPerson", "First Person Fire", true),
                this.watermarkString = new StringSetting("watermarkString", "Watermark String", Ref.MC_VERSION.getWatermarkString(), 35)
        );

        this.guiScaleSetting.description("Allows you to change your gui scale like in modern Minecraft.");
        this.guiScaleSetting.onUpdate(value -> {
            this.guiScale = this.getGuiScale();
            this.mc.bridge$displayGuiScreen(BridgeRef.getCurrentScreen());
        });

        if (Ref.MC_VERSION == MinecraftVersion.B1_1_02) {
            this.showPortalOverlay.description("This semi-backports the modern portal overlay.");
        }

        this.watermarkString.description("This allows you to edit the top left text.");

        this.addEvent(KeyboardEvent.class, this::keyTyped);
        this.addEvent(DebugDrawEvent.class, this::onDebugDraw);
        this.addEvent(MainMenuLogoDrawEvent.class, this::onMainMenuLogoDraw);
        this.addEvent(HUDDrawEvent.class, event -> {
            if (!this.showHUD) {
                event.cancel();
            }
        });

        this.addEvent(OnLivingUpdateEvent.class, this::onLivingUpdate);
        this.addEvent(PlayerBlockCollideEvent.class, this::onBlockCollision);
        this.addEvent(PortalOverlayEvent.class, this::onPortalOverlay);

        this.addEvent(FirstPersonFireDrawEvent.class, event -> {
            if (!this.showFireInFirstPerson.value()) {
                event.cancel();
            }
        });

        this.addEvent(ScaledResolutionInitEvent.class, event -> {
            if (!this.guiScaleSetting.value().equalsIgnoreCase("Auto")) {
                event.cancel();
                event.setScale(this.guiScale);
            }
        });

        this.addEvent(DrawStringEvent.class, event -> {
            if (event.getString().equalsIgnoreCase(Ref.MC_VERSION.getWatermarkString())) {
                event.cancel();
                event.setString(this.watermarkString.value());
            }
        });
    }

    private int getGuiScale() {
        switch (this.guiScaleSetting.value()) {
            case "Auto":
            case "Large":
                return 4;

            case "Normal":
                return 3;

            case "Small":
                return 2;
        }

        return 1;
    }

    @Override
    @SneakyThrows
    public void onToggle() {
        this.mc.bridge$displayGuiScreen(null);
        ChatUtil.addChatMessage("Gui Scale was reset to Default, and as a result closed your current menu.");
    }

    private void onLivingUpdate(OnLivingUpdateEvent event) {
        if (event.getPlayer() != Bridge.getInstance().bridge$getMinecraft().bridge$getThePlayer()) {
            return;
        }

        if (this.showPortalOverlay != null
                && !this.showPortalOverlay.value()
                && !event.getPlayer().bridge$isInsideOfMaterial(Bridge.getInstance().bridge$getPortalMaterial())
        ) {
            this.inPortal = false;
            return;
        }

        this.prevTimeInPortal = this.timeInPortal;

        if (this.inPortal) {
            if (this.timeInPortal == 0.0F) {
                this.mc.bridge$getSoundManager().bridge$playSound("portal.trigger", 1.0F, rand.nextFloat() * 0.4F + 0.8F);
            }
            this.timeInPortal += 0.0125F;

            if (this.timeInPortal >= 1.0F) {
                this.timeInPortal = 1.0F;
                this.inPortal = false;
            }
        } else {
            if (this.timeInPortal > 0.0F) {
                this.timeInPortal -= 0.05F;
            }

            if (this.timeInPortal < 0.0F) {
                this.timeInPortal = 0.0F;
            }
        }
    }

    private void onBlockCollision(PlayerBlockCollideEvent event) {
        if (event.getEntity() == Bridge.getInstance().bridge$getMinecraft().bridge$getThePlayer()
                && event.getBlock() instanceof BlockPortalBridge) {
            this.inPortal = true;
        }
    }

    private void onPortalOverlay(PortalOverlayEvent event) {
        if (this.showPortalOverlay != null
                && this.showPortalOverlay.value()
                && this.inPortal
                && Bridge.getInstance()
                .bridge$getMinecraft()
                .bridge$getThePlayer()
                .bridge$isInsideOfMaterial(
                        Bridge.getInstance().bridge$getPortalMaterial()
                )) {
            event.cancel();
        }
    }

    private void onMainMenuLogoDraw(MainMenuLogoDrawEvent event) {
        if (this.mainMenuLogo != null
                && this.mainMenuLogo.value().equalsIgnoreCase("Modern")) {
            event.cancel();

            TessellatorBridge tessellatorBridge = BridgeRef.getTessellator();

            int xOffset = 274;
            int x = event.getMainMenu().bridge$getWidth() / 2 - xOffset / 2;
            int yPos = 30;
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.bridge$getRenderEngine().bridge$getTexture("/title/mclogo.png"));
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            event.getMainMenu().bridge$drawTexturedModalRect(x, yPos, 0, 0, 155, 44);
            event.getMainMenu().bridge$drawTexturedModalRect(x + 155, yPos, 0, 45, 155, 44);
            tessellatorBridge.bridge$setColorOpaque_I(16777215);
        }
    }

    private void onDebugDraw(DebugDrawEvent event) {
        if (this.showDebugInfo && BridgeRef.getCurrentScreen() == null) {
            event.cancel();
        }
    }

    private void keyTyped(KeyboardEvent event) {
        int key = event.getKey();

        // Game HUD (F1)
        if (key == this.toggleHUD.value()) {
            this.showHUD = !this.showHUD;
        }

        // Game Debug (F3)
        if (key == this.debugKeybind.value()) {
            this.showDebugInfo = !this.showDebugInfo;
        }
    }

}
