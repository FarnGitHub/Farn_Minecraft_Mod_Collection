package cc.noxiuam.titanic.client.ui.component.type.button;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiButtonBridge;
import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.ui.transition.impl.ColorTransition;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import lombok.AllArgsConstructor;
import org.lwjgl.opengl.GL11;

@AllArgsConstructor
public class RoundedIconButton extends AbstractComponent {

    public String icon;
    public boolean showBackground;
    public float iconWidth;
    public float iconHeight;
    public float xOffset;
    public float yOffset;

    private final GuiButtonBridge button;

    public RoundedIconButton(
            String icon,
            boolean showBackground,
            float iconWidth,
            float iconHeight,
            float xOffset,
            float yOffset
    ) {
        this.button = Bridge.getInstance().bridge$createNewGuiButton(
                1000,
                0,
                0,
                0,
                0,
                "" // leave it blank, no text!
        );
        this.icon = icon;
        this.showBackground = showBackground;
        this.iconWidth = iconWidth;
        this.iconHeight = iconHeight;
        this.xOffset = xOffset;
        this.yOffset = yOffset;
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        if (this.showBackground) {
            this.button.bridge$setX((int) this.x);
            this.button.bridge$setY((int) this.y, true);
            this.button.bridge$setWidth((int) this.width);
            this.button.bridge$setHeight((int) this.height);
            this.button.bridge$drawButton(BridgeRef.getMinecraft(), (int) mouseX, (int) mouseY);
        }

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        RenderUtil.drawIcon(
                this.icon,
                this.x + this.xOffset,
                this.y + this.yOffset,
                this.iconWidth,
                this.iconHeight
        );
    }

}
