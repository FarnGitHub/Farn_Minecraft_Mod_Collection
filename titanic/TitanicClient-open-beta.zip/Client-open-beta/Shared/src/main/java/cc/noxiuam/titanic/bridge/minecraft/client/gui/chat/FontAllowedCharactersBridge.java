package cc.noxiuam.titanic.bridge.minecraft.client.gui.chat;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface FontAllowedCharactersBridge {

    String bridge$getAllowedCharacters();

}
