package cc.noxiuam.titanic.client.ui.screen.module.container;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import cc.noxiuam.titanic.client.ui.component.type.button.RoundedIconButton;
import cc.noxiuam.titanic.client.ui.screen.module.HudLayoutEditor;
import cc.noxiuam.titanic.client.ui.AbstractContainer;
import cc.noxiuam.titanic.client.util.SoundUtil;

public class FooterContainer extends AbstractContainer {

    private final RoundedIconButton editHudButton = new RoundedIconButton(
            "/titanic/icons/pencil.png",
            true,
            11,
            11,
            4.5F,
            4.5F
    );

    private final RoundedIconButton closeButton = new RoundedIconButton(
            "/titanic/icons/close.png",
            true,
            11,
            11,
            4F,
            4.5F
    );

    public FooterContainer() {
        super("/footer");
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        this.editHudButton.position(this.x, this.y + this.height);
        this.editHudButton.size(20, 20);
        this.editHudButton.draw(mouseX, mouseY);

        this.closeButton.position(this.x + this.width - 19, this.y + this.height);
        this.closeButton.size(20, 20);
        this.closeButton.draw(mouseX, mouseY);
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        if (this.closeButton.mouseInside(mouseX, mouseY)) {
            SoundUtil.playClick();
            mc.bridge$displayGuiScreen(null);
        } else if (this.editHudButton.mouseInside(mouseX, mouseY)) {
            SoundUtil.playClick();
            GuiScreenBridge screen = Bridge.getInstance().bridge$initCustomGuiScreen(new HudLayoutEditor());
            mc.bridge$displayGuiScreen(screen);
        }
    }

}
