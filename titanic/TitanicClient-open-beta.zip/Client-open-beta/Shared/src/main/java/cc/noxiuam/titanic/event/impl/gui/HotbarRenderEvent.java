package cc.noxiuam.titanic.event.impl.gui;

import cc.noxiuam.titanic.event.AbstractEvent;

public class HotbarRenderEvent extends AbstractEvent {
}
