package cc.noxiuam.titanic.bridge.minecraft.client.inventory;

import java.util.List;

public interface CraftingInventoryCBBridge {

    int bridge$getUnusedList();

    List<?> bridge$getSlots(); // field_20122_e

}
