package cc.noxiuam.titanic.client.network.manager.server;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.client.registry.FeaturedServer;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lombok.Getter;
import lombok.SneakyThrows;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Noxiuam
 * https://noxiuam.cc
 */
@Getter
public class ServerManager {

    public final List<FeaturedServer> featuredServers = new ArrayList<>();

    private JsonObject serverMapping;

    public String currentServerAddress;

    public ServerManager() {
        this.getLatestServerMetadata();
    }

    public String getCurrentServerAddress() {
        return currentServerAddress;
    }

    @SneakyThrows
    private void getLatestServerMetadata() {
        URL url = new URL("https://noxiuam.cc/titanic-client/api/servers/server-index.json");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        connection.setRequestMethod("GET");
        connection.addRequestProperty("User-Agent", "Mozilla/4.0");

        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));

        JsonObject serverMapping = null;

        try {
            serverMapping = new JsonParser()
                    .parse(br)
                    .getAsJsonObject()
                    .get(Ref.MC_VERSION.getVersion())
                    .getAsJsonObject();
        } catch (NullPointerException ignored) {
        }

        if (serverMapping == null) {
            return;
        }

        this.serverMapping = serverMapping;

        for (Map.Entry<String, JsonElement> entry : serverMapping.entrySet()) {
            JsonObject serverObj = entry.getValue().getAsJsonObject();

            String id = entry.getKey().toLowerCase();
            String formattedName = serverObj.get("formattedName").getAsString();
            String motd = serverObj.get("motd").getAsString();
            JsonArray addresses = serverObj.get("addresses").getAsJsonArray();

            List<String> addressesList = new ArrayList<>();
            for (int i = 0; i < addresses.size(); i++) {
                addressesList.add(addresses.get(i).getAsString());
            }

            String iconUrl = "https://noxiuam.cc/titanic-client/api/servers/icons/" + id + ".png";

            FeaturedServer server = new FeaturedServer(iconUrl, formattedName, motd, addressesList);

            Bridge.getInstance()
                    .bridge$getMinecraft()
                    .bridge$getRenderEngine()
                    .bridge$obtainImageData(
                            iconUrl,
                            Bridge.getInstance().bridge$createImageBufferDownload()
                    );

            this.featuredServers.add(server);
        }
    }

}
