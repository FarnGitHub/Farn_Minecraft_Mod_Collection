package cc.noxiuam.titanic.event.impl.world.player.model;

import cc.noxiuam.titanic.bridge.minecraft.entity.EntityPlayerBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public class CapeRenderEvent extends AbstractEvent {

    @Getter private EntityPlayerBridge player;
    public float value;

}
