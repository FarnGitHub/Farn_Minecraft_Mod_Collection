package cc.noxiuam.titanic.bridge.minecraft.renderer;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface RenderEngineBridge {

    int bridge$getTexture(String path);

    void bridge$bindTexture(int texture);

    int bridge$getTextureForDownloadableImage(String url, String fallback);

    void bridge$obtainImageData(String url, ImageBufferBridge imageBufferBridge);

    void bridge$releaseImageData(String url);

}
