package cc.noxiuam.titanic.client.ui.screen.module;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import cc.noxiuam.titanic.client.ui.component.type.setting.impl.keybind.KeybindButton;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import lombok.Getter;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class ModSettingsEditor implements GuiScreenBridge {

    public KeybindButton currentKeybind;

    private final MainListUI moduleList = new MainListUI();

    @Override
    public void bridge$initGui() {
        float width = 447.0F / 2;
        float height = 350.0F / 2;
        this.moduleList.size(width, height);
        this.moduleList.position(this.bridge$getWidth() / 2.0f - width / 2.0f, this.bridge$getHeight() / 2.0f - height / 2.0f);
        Keyboard.enableRepeatEvents(true);
    }

    @Override
    public void bridge$onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
        Ref.getConfigManager().saveConfigs();
    }

    @Override
    public void bridge$updateScreen() {
        this.moduleList.handleUpdate();
    }

    @Override
    public void bridge$drawScreen(int x, int y, float partialTicks) {
        this.moduleList.draw(x, y);

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        RenderUtil.drawIcon(
                "/titanic/logo.png",
                this.bridge$getWidth() / 2 - 56,
                this.moduleList.getY() - 32,
                115,
                28
        );
    }

    @Override
    public void bridge$keyTyped(char c, int n) {
        if (this.currentKeybind == null) {
            GuiScreenBridge.super.bridge$keyTyped(c, n);
        }

        this.moduleList.keyTyped(c, n);
    }

    @Override
    public void bridge$mouseClicked(int x, int y, int button) {
        if (button == 0) {
            this.moduleList.mouseClicked(x, y);
        }
    }

}
