package cc.noxiuam.titanic.client.module.impl.hud.impl;

import cc.noxiuam.titanic.client.module.impl.hud.AbstractMovableModule;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.event.impl.gui.GuiDrawEvent;
import com.google.common.collect.ImmutableList;
import org.lwjgl.opengl.GL11;

public class FofoModule extends AbstractMovableModule {

    public FofoModule() {
        super(
                "fofo",
                "Fofo",
                "Fofo made me do this.",
                false,
                ImmutableList.of(
                        MinecraftVersion.B1_1_02
                )
        );
        this.addEvent(GuiDrawEvent.class, this::draw);
    }

    private void draw(GuiDrawEvent event) {
        this.setSize(75, 100);
        String image = "/titanic/fofo.png";

        GL11.glPushMatrix();

        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        RenderUtil.drawIcon(
                image,
                this.x(),
                this.y(),
                75,
                100
        );

        GL11.glPopMatrix();
    }

}
