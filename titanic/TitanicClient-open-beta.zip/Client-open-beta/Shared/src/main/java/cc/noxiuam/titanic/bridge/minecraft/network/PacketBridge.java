package cc.noxiuam.titanic.bridge.minecraft.network;

public interface PacketBridge {
}
