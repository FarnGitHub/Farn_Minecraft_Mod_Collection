package cc.noxiuam.titanic.client.registry;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

/**
 * @author Noxiuam
 * https://noxiuam.cc
 */
@Getter
@AllArgsConstructor
public class FeaturedServer {

    public String iconUrl, formattedName, motd;
    public List<String> addresses;

}
