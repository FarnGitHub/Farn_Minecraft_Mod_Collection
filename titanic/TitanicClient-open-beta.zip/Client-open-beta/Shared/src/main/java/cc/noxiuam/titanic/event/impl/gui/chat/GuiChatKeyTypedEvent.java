package cc.noxiuam.titanic.event.impl.gui.chat;

import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@AllArgsConstructor
public class GuiChatKeyTypedEvent extends AbstractEvent {

    private char character;
    private int key;

}
