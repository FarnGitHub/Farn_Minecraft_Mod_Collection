package cc.noxiuam.titanic.client.ui.transition.impl;

import cc.noxiuam.titanic.client.ui.transition.AbstractTransition;

/**
 * @author - CheatBreaker, LLC
 */
public class FloatTransition extends AbstractTransition {

    public FloatTransition(long duration) {
        super(duration, 1.0f);
    }

    public FloatTransition(long duration, float f) {
        super(duration, f);
    }

    @Override
    protected float getValue() {
        return (float) (this.duration - this.getTimeLeft()) / (float) this.duration;
    }

}
