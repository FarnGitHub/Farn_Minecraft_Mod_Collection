package cc.noxiuam.titanic.bridge.minecraft.model;

public interface ModelBaseBridge {

    float bridge$getSwingProgress(); // field_1244_k

    void bridge$setSwingProgress(float swingProgress);

}
