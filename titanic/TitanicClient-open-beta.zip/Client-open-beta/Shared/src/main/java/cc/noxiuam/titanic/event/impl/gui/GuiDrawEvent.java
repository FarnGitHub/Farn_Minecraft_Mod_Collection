package cc.noxiuam.titanic.event.impl.gui;

import cc.noxiuam.titanic.bridge.minecraft.client.gui.ScaledResolutionBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class GuiDrawEvent extends AbstractEvent {

    private float partialTicks;
    private ScaledResolutionBridge resolution;

}
