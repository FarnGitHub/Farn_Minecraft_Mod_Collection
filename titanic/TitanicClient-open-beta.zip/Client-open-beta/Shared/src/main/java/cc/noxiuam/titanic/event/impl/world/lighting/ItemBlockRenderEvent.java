package cc.noxiuam.titanic.event.impl.world.lighting;

import cc.noxiuam.titanic.bridge.minecraft.block.BlockBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ItemBlockRenderEvent extends AbstractEvent {

    private BlockBridge block;
    private int renderType;

}
