package cc.noxiuam.titanic.event.impl.world.lighting;

import cc.noxiuam.titanic.bridge.minecraft.block.BlockBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@AllArgsConstructor
public class RenderBlockByRenderTypeEvent extends AbstractEvent {

    private final BlockBridge block;
    private final int blockX;
    private final int blockY;
    private final int blockZ;

    @Setter private boolean flag;

}
