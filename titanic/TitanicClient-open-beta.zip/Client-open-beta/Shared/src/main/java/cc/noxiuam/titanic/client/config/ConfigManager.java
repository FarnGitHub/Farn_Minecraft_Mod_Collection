package cc.noxiuam.titanic.client.config;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.data.setting.AbstractSetting;
import cc.noxiuam.titanic.client.module.impl.fix.AbstractFixModule;
import cc.noxiuam.titanic.client.module.impl.hud.AbstractMovableModule;
import cc.noxiuam.titanic.client.util.executor.AsyncThreadExecutor;
import cc.noxiuam.titanic.client.util.JsonUtil;
import cc.noxiuam.titanic.kotlin.client.logger.Logger;
import com.google.gson.*;
import lombok.Getter;
import lombok.SneakyThrows;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Getter
public class ConfigManager {

    private static final Logger LOGGER = new Logger("Config Manager");

    private final File titanicDir = new File(Ref.getBridge().getMinecraftBridge().bridge$getMinecraftDir() + File.separator + "titanic");
    private final File configDir = new File(titanicDir + File.separator + "config" + File.separator + Ref.MC_VERSION.name().toLowerCase());
    private final File thirdPartyModsDir = new File(titanicDir + File.separator + "external");
    private final File thirdPartyModsConfigDir = new File(thirdPartyModsDir + File.separator + "config");

    private final File modsConfig = new File(configDir + File.separator + "mods.json");
    private final File friendsConfig = new File(titanicDir + File.separator + "friends.json");

    public ConfigManager() {
        if (this.isSetup()) {
            LOGGER.info("Created all required config files.");
        }
    }

    public boolean isSetup() {
        try {
            return !(!this.configDir.exists() && !this.configDir.mkdirs()
                    || !this.thirdPartyModsDir.exists() && !this.thirdPartyModsDir.mkdirs()
                    || !this.thirdPartyModsConfigDir.exists() && !this.thirdPartyModsConfigDir.mkdirs()
                    || !this.modsConfig.exists() && !this.modsConfig.createNewFile()
                    || !this.friendsConfig.exists() && !this.friendsConfig.createNewFile()
            );
        } catch (IOException e) {
            e.printStackTrace();
        }

        return true;
    }

    public void saveConfigs() {
        AsyncThreadExecutor.run(() -> {
            if (this.isSetup()) {
                this.writeModsProfile();
                Ref.getFriendManager().saveFriends();
                for (AbstractModule module : Ref.getModuleManager().getMods()) {
                    module.writeModuleConfig();
                }
            }
        });
    }

    public void readConfigs() {
        if (this.isSetup()) {
            this.readModsProfile();
            Ref.getFriendManager().loadFriends();
            // TODO: Separate mod config reading
        }
    }

    @SneakyThrows
    private void writeModsProfile() {
        List<AbstractModule> modules = new ArrayList<>(Ref.getModuleManager().getMods());
        JsonObject configObj = new JsonObject();

        for (AbstractModule module : modules) {
            JsonObject modObj = new JsonObject();
            JsonObject info = new JsonObject();
            JsonObject settings = new JsonObject();

            info.addProperty("id", module.id());
            info.addProperty("state", module.enabled());

            if (module instanceof AbstractMovableModule) {
                float x = ((AbstractMovableModule) module).x();
                float y = ((AbstractMovableModule) module).y();
                info.addProperty("x", x);
                info.addProperty("y", y);
            }

            for (AbstractSetting<?> setting : module.settings()) {
                setting.save(settings);
            }

            modObj.add("info", info);
            modObj.add("settings", settings);
            configObj.add(module.id(), modObj);
        }

        JsonUtil.writeToFile(this.modsConfig, configObj, true);
    }

    @SneakyThrows
    private void readModsProfile() {
        List<AbstractModule> modules = new ArrayList<>(Ref.getModuleManager().getMods());

        for (AbstractModule module : modules) {
            if (module instanceof AbstractFixModule) {
                module.enabled(true);
                module.addAllEvents();
            }
        }

        JsonParser parser = new JsonParser();

        try {
            parser.parse(new FileReader(this.modsConfig)).getAsJsonObject();
        } catch (IllegalStateException | FileNotFoundException ignored) {
            // first time users will encounter this.
            this.writeModsProfile();
            this.readModsProfile();
            return;
        }

        JsonObject configObj = parser.parse(new FileReader(this.modsConfig)).getAsJsonObject();

        for (AbstractModule module : modules) {
            if (module instanceof AbstractFixModule) continue;

            if (configObj.get(module.id()) == null) {
                if (module.enabledByDefault()) {
                    module.addAllEvents();
                    module.onEnable();
                }
                continue;
            }

            JsonObject modObject = configObj.getAsJsonObject(module.id());

            JsonObject info = modObject.getAsJsonObject("info");
            JsonObject settings = modObject.getAsJsonObject("settings");

            boolean state = info.get("state").getAsBoolean();
            module.enabled(state);

            if (state) {
                module.addAllEvents();
                module.onEnable();
            }

            try {
                if (module instanceof AbstractMovableModule) {
                    float x = info.get("x").getAsFloat();
                    float y = info.get("y").getAsFloat();
                    ((AbstractMovableModule) module).x(x);
                    ((AbstractMovableModule) module).y(y);
                }
            } catch (NullPointerException e) { continue; }

            for (AbstractSetting<?> setting : module.settings()) {
                if (settings.get(setting.id()) == null) continue;
                setting.load(settings);
            }
        }

        this.saveConfigs();
    }

}
