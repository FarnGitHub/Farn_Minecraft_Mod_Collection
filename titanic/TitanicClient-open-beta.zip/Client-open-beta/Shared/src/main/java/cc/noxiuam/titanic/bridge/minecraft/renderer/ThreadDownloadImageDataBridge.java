package cc.noxiuam.titanic.bridge.minecraft.renderer;

public interface ThreadDownloadImageDataBridge {
}
