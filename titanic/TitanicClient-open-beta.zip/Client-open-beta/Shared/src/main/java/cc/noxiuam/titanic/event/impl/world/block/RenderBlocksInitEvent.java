package cc.noxiuam.titanic.event.impl.world.block;

import cc.noxiuam.titanic.bridge.minecraft.block.BlockAccessBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class RenderBlocksInitEvent extends AbstractEvent {

    private BlockAccessBridge blockAccess;

}
