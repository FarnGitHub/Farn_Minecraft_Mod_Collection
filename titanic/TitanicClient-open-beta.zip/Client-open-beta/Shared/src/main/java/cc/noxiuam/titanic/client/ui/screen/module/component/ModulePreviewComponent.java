package cc.noxiuam.titanic.client.ui.screen.module.component;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiButtonBridge;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.ui.component.type.button.RoundedIconButton;
import cc.noxiuam.titanic.client.ui.screen.module.container.module.ModulePreviewContainer;
import cc.noxiuam.titanic.client.ui.transition.impl.ColorTransition;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ModulePreviewComponent extends AbstractComponent {

    private final RoundedIconButton settingsButton = new RoundedIconButton(
            "/titanic/icons/double-cog.png",
            false,
            8,
            8,
            4.5F,
            4.5F
    );

    private final ModulePreviewContainer container;
    private final AbstractModule module;

    private final GuiButtonBridge button;

    public ModulePreviewComponent(ModulePreviewContainer container, AbstractModule module) {
        this.container = container;
        this.module = module;
        this.button = Bridge.getInstance().bridge$createNewGuiButton(
                1000,
                0,
                0,
                0,
                0,
                ""
        );
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        this.settingsButton.size(15, 15);
        this.settingsButton.position(this.x + width - 17, this.y + 2);

        this.button.bridge$setX((int) this.x);
        this.button.bridge$setY((int) this.y, false);
        this.button.bridge$setWidth((int) this.width + 2);
        this.button.bridge$setHeight(20);
        this.button.bridge$drawButton(BridgeRef.getMinecraft(), (int) mouseX, (int) mouseY);
        this.button.bridge$setEnabled(this.module.enabled());

        if (this.module.settings().size() > 0) {
            this.settingsButton.draw(mouseX, mouseY);
        }

        this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(
                this.module.name(),
                (int) this.x + 5,
                (int) this.y + 6,
                this.module.enabled() ? this.mouseInside(mouseX, mouseY) ? 16777120 : 14737632 : -6250336
        );
    }

}
