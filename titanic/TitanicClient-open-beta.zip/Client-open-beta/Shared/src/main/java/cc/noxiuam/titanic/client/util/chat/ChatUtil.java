package cc.noxiuam.titanic.client.util.chat;

import cc.noxiuam.titanic.bridge.Bridge;
import lombok.experimental.UtilityClass;

import java.util.regex.Pattern;

@UtilityClass
public class ChatUtil {

    private static final Pattern STRIP_COLOR_PATTERN = Pattern.compile("(?i)" + ChatColor.COLOR_CHAR + "[0-689A-F]");
    private static final Pattern STRIP_COLOR_PATTERN_FORMAL = Pattern.compile("(?i)" + "&" + "[0-689A-F]");

    public void addChatMessage(String msg) {
        if (Bridge.getInstance().bridge$getTheWorld() != null) {
            Bridge.getInstance()
                    .bridge$getMinecraft()
                    .bridge$getIngameGui()
                    .bridge$addChatMessage(ChatColor.DARK_AQUA + "[Titanic] " + ChatColor.WHITE + msg);
        }
    }

    public String removeColors(String str) {
        if (str == null) {
            return null;
        }

        String msg = STRIP_COLOR_PATTERN.matcher(str).replaceAll("");
        msg = STRIP_COLOR_PATTERN_FORMAL.matcher(msg).replaceAll("");

        return msg;
    }

}
