package cc.noxiuam.titanic.client.ui.component;

import cc.noxiuam.titanic.Client;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.minecraft.client.MinecraftBridge;
import cc.noxiuam.titanic.kotlin.KTitanic;
import lombok.Getter;
import lombok.Setter;

@Getter
public abstract class AbstractComponent {

    protected final MinecraftBridge mc = Bridge.getInstance().bridge$getMinecraft();
    protected final KTitanic titanic = Client.getInstance();

    @Setter
    private String tooltip;

    protected float x;
    protected float y;
    protected float width;
    protected float height;

    /**
     * Draws the component itself, very important!!!
     * <p></p>
     * @param mouseX The mouse's X position.
     * @param mouseY The mouse's Y position.
     */
    public abstract void draw(float mouseX, float mouseY);

    /**
     * Sets the width and height of the component.
     * <p></p>
     * @param width The new width.
     * @param height The new height.
     */
    public void size(float width, float height) {
        this.width = width;
        this.height = height;
    }

    /**
     * Sets the x and y coordinates of the component.
     * <p></p>
     * @param newX The new X.
     * @param newY The new Y.
     */
    public void position(float newX, float newY) {
        this.x = newX;
        this.y = newY;
    }

    /**
     * Called when the user's mouse is clicked
     * <p></p>
     * @param mouseX The mouse's X position.
     * @param mouseY The mouse's Y position.
     */
    public void mouseClicked(float mouseX, float mouseY) { }

    /**
     * Called when the user's keyboard is used.
     * <p></p>
     * @param character - Pressed key's char
     * @param key - Pressed key's int
     */
    public void keyTyped(char character, int key) { }

    /**
     * Checks to see if the user's mouse is inside the component.
     * <p></p>
     * @param mouseX The mouse's current X position.
     * @param mouseY The mouse's current Y position.
     */
    public boolean mouseInside(float mouseX, float mouseY) {
        return mouseX > this.x
                && mouseX < this.x + this.width
                && mouseY > this.y
                && mouseY < this.y + this.height;
    }

    /**
     * Handles any component updating when the current gui screen is updated.
     */
    public void handleUpdate() { }

}
