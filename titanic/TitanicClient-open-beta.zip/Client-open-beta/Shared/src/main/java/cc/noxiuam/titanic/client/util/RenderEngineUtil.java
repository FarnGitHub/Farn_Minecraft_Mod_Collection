package cc.noxiuam.titanic.client.util;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.minecraft.renderer.RenderEngineBridge;
import lombok.experimental.UtilityClass;

/**
 * @author Noxiuam
 * https://noxiuam.cc
 */
@UtilityClass
public class RenderEngineUtil {

    public int getTextureInt(String url, String fallback) {
        RenderEngineBridge renderEngineBridge = Bridge.getInstance().bridge$getMinecraft().bridge$getRenderEngine();
        return renderEngineBridge.bridge$getTextureForDownloadableImage(url, fallback);
    }

}
