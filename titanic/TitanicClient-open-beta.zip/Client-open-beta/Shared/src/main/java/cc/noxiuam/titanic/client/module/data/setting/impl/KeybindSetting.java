package cc.noxiuam.titanic.client.module.data.setting.impl;

import cc.noxiuam.titanic.client.module.data.setting.AbstractSetting;
import cc.noxiuam.titanic.client.ui.screen.module.container.module.setting.ModuleSettingsContainer;
import cc.noxiuam.titanic.client.ui.component.type.setting.AbstractSettingComponent;
import cc.noxiuam.titanic.client.ui.component.type.setting.impl.keybind.KeybindComponent;
import com.google.gson.JsonObject;

public class KeybindSetting extends AbstractSetting<Integer> {

    public KeybindSetting(String id, String name, Integer defaultValue) {
        super(id, name, defaultValue);
    }

    @Override
    public AbstractSettingComponent<Integer> getComponent(ModuleSettingsContainer list) {
        return new KeybindComponent(this, list);
    }

    @Override
    public void save(JsonObject configObject) {
        configObject.addProperty(this.id(), this.value());
    }

    @Override
    public void load(JsonObject configObject) {
        this.value(configObject.get(this.id()).getAsInt());
    }

}
