package cc.noxiuam.titanic.event.impl.world;

import cc.noxiuam.titanic.event.AbstractEvent;

public class PerspectiveUpdateEvent extends AbstractEvent {
}
