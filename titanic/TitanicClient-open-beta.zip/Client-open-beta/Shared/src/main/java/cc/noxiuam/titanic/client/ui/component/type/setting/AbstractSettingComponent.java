package cc.noxiuam.titanic.client.ui.component.type.setting;

import cc.noxiuam.titanic.client.module.data.setting.AbstractSetting;
import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.ui.screen.module.container.module.setting.ModuleSettingsContainer;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public abstract class AbstractSettingComponent<T> extends AbstractComponent {

    protected final AbstractSetting<T> setting;
    protected final ModuleSettingsContainer list;

    @Override
    public abstract float getHeight();

    @Override
    public void size(float width, float height) {
        super.size(width, this.getHeight());
    }

}
