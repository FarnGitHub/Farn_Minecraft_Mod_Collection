package cc.noxiuam.titanic.event.impl.gui;

import cc.noxiuam.titanic.event.AbstractEvent;

public class HUDDrawEvent extends AbstractEvent {
}
