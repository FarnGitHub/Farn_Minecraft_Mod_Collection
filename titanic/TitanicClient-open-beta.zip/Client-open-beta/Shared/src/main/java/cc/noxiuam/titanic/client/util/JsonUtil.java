package cc.noxiuam.titanic.client.util;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import lombok.experimental.UtilityClass;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

@UtilityClass
public class JsonUtil {

    public String beautify(JsonElement obj) {
        return new GsonBuilder()
                .setPrettyPrinting()
                .create()
                .toJson(obj);
    }


    public void writeToFile(File file, JsonElement jsonElement, boolean pretty) {
        try {
            FileWriter writer = new FileWriter(file);
            writer.write(pretty ? beautify(jsonElement) : jsonElement.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
