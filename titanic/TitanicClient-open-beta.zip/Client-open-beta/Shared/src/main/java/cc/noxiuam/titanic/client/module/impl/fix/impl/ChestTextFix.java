package cc.noxiuam.titanic.client.module.impl.fix.impl;

import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiChestBridge;
import cc.noxiuam.titanic.client.module.impl.fix.AbstractFixModule;
import cc.noxiuam.titanic.event.impl.font.DrawStringEvent;

public class ChestTextFix extends AbstractFixModule {

    public ChestTextFix() {
        super("Chest Text Fix");

        this.addEvent(DrawStringEvent.class, event -> {
            if (event.getString().equals("Large chest")
                    && BridgeRef.getCurrentScreen() instanceof GuiChestBridge) {
                event.cancel();
                event.setString("Large Chest");
            }
        });
    }

}
