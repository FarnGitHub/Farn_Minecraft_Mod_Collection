package cc.noxiuam.titanic.client.module.data.setting.impl;

import cc.noxiuam.titanic.client.module.data.setting.AbstractSetting;
import cc.noxiuam.titanic.client.ui.screen.module.container.module.setting.ModuleSettingsContainer;
import cc.noxiuam.titanic.client.ui.component.type.setting.AbstractSettingComponent;
import cc.noxiuam.titanic.client.ui.component.type.setting.impl.BooleanComponent;
import com.google.gson.JsonObject;

public class BooleanSetting extends AbstractSetting<Boolean> {

    public BooleanSetting(String id, String name, Boolean defaultValue) {
        super(id, name, defaultValue);
    }

    @Override
    public AbstractSettingComponent<Boolean> getComponent(ModuleSettingsContainer list) {
        return new BooleanComponent(this, list);
    }

    @Override
    public void save(JsonObject configObject) {
        configObject.addProperty(this.id(), this.value());
    }

    @Override
    public void load(JsonObject configObject) {
        this.value(configObject.get(this.id()).getAsBoolean());
    }

}
