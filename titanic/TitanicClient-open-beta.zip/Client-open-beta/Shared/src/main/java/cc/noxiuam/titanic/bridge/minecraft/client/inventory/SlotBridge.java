package cc.noxiuam.titanic.bridge.minecraft.client.inventory;

import cc.noxiuam.titanic.bridge.minecraft.item.ItemStackBridge;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface SlotBridge {

    boolean bridge$isItemValid(ItemStackBridge itemStackBridge);

    ItemStackBridge bridge$getStack();

    int bridge$getSlotStackLimit();

}
