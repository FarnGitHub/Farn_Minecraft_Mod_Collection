package cc.noxiuam.titanic.client.network.cosmetic.type.nametag;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class NametagIcon {

    private String iconUrl;
    private int xOffset;
    private int width;
    private int height;

}
