package cc.noxiuam.titanic.client.module.impl.normal.gui.crosshair;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.data.ModuleCategory;
import cc.noxiuam.titanic.client.module.data.setting.impl.NumberSetting;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.event.impl.gui.crosshair.CrosshairDrawEvent;
import com.google.common.collect.ImmutableList;
import org.lwjgl.opengl.GL11;

public class CrosshairModule extends AbstractModule {

    private final BooleanSetting hideInThirdPerson, showOutline;
    private final NumberSetting thickness, size, gap;

    public CrosshairModule() {
        super(
                "crosshair",
                "Crosshair",
                "Allows you to edit a custom crosshair to the game.",
                false,
                MinecraftVersion.getAllVersions(),
                ImmutableList.of(
                        ModuleCategory.GUI
                )
        );

        this.addSettings(
                this.hideInThirdPerson = new BooleanSetting("hideInThirdPerson", "Hide In 3rd Person", false),
                this.showOutline = new BooleanSetting("showOutline", "Outline", false),
                this.thickness = new NumberSetting("thickness", "Thickness", 1.5, 1.5, 2.5, 1),
                this.size = new NumberSetting("size", "Size", 5.0, 1.0, 10.0, 0),
                this.gap = new NumberSetting("gap", "Gap", 0.0, 0.0, 7.5, 0)
        );

        this.addEvent(CrosshairDrawEvent.class, event -> {
            event.cancel();
            this.drawCustomCrosshair(event.getX(), event.getY());
        });
    }

    /**
     * Renders the custom crosshair.
     */
    private void drawCustomCrosshair(float x, float y) {
        if (this.hideInThirdPerson.value()
                && BridgeRef.getGameSettings().bridge$isThirdPersonView()) {
            return;
        }

        GL11.glPushMatrix();

        float scale = 1.0F / this.getScaleFactor();
        int scaledX = (int) (x / scale);
        int scaledY = (int) (y / scale);
        GL11.glScalef(scale, scale, scale);

        float size = this.size.value().floatValue();
        float gap = this.gap.value().floatValue();
        float thickness = this.thickness.value().floatValue();
        int color = -1; // this will be changeable in the future.
        boolean outline = this.showOutline.value();

        int finalX = scaledX / 2;
        int finalY = scaledY / 2;

        if (outline) {
            RenderUtil.drawRectWithOutline(
                    finalX - gap - size,
                    finalY - thickness / 2.0F,
                    finalX - gap,
                    finalY + thickness / 2.0F,
                    0.5F,
                    0xAF000000,
                    color
            );
            RenderUtil.drawRectWithOutline(
                    finalX + gap,
                    finalY - thickness / 2.0F,
                    finalX + gap + size,
                    finalY + thickness / 2.0F,
                    0.5F,
                    0xAF000000,
                    color
            );
            RenderUtil.drawRectWithOutline(
                    finalX - thickness / 2.0F,
                    finalY - gap - size,
                    finalX + thickness / 2.0F,
                    finalY - gap,
                    0.5F,
                    0xAF000000,
                    color
            );
            RenderUtil.drawRectWithOutline(
                    finalX - thickness / 2.0F,
                    finalY + gap,
                    finalX + thickness / 2.0F,
                    finalY + gap + size,
                    0.5F,
                    0xAF000000,
                    color
            );
        } else {
            RenderUtil.drawRect(
                    finalX - gap - size,
                    finalY - thickness / 2.0F,
                    finalX - gap,
                    finalY + thickness / 2.0F,
                    color
            );
            RenderUtil.drawRect(
                    finalX + gap,
                    finalY - thickness / 2.0F,
                    finalX + gap + size,
                    finalY + thickness / 2.0F,
                    color
            );
            RenderUtil.drawRect(
                    finalX - thickness / 2.0F,
                    finalY - gap - size,
                    finalX + thickness / 2.0F,
                    finalY - gap,
                    color
            );
            RenderUtil.drawRect(
                    finalX - thickness / 2.0F,
                    finalY + gap,
                    finalX + thickness / 2.0F,
                    finalY + gap + size,
                    color
            );
        }

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glPopMatrix();
    }

    /**
     * Proper scaling for the crosshair.
     */
    public float getScaleFactor() {
        switch (Ref.getModuleManager().getPackTweaksModule().guiScale) {
            case 2: {
                return 2.0F;
            }
            case 3: {
                return 1.5F;
            }
            default: {
                return 1.0F;
            }
        }
    }

}
