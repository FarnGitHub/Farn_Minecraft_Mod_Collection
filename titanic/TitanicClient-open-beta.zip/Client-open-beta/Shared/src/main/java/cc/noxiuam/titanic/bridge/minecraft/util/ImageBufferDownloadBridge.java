package cc.noxiuam.titanic.bridge.minecraft.util;

import cc.noxiuam.titanic.bridge.minecraft.renderer.ImageBufferBridge;

public interface ImageBufferDownloadBridge extends ImageBufferBridge {
}
