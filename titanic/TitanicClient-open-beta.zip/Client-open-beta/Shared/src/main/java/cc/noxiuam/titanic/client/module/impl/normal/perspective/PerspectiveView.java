package cc.noxiuam.titanic.client.module.impl.normal.perspective;

public enum PerspectiveView {
    FIRST,
    SECOND,
    THIRD
}