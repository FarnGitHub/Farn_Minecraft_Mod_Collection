package cc.noxiuam.titanic.bridge;

import cc.noxiuam.titanic.bridge.minecraft.client.GameSettingsBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.MinecraftBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import cc.noxiuam.titanic.bridge.minecraft.renderer.TessellatorBridge;
import lombok.experimental.UtilityClass;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
@UtilityClass
public class BridgeRef {

    public MinecraftBridge getMinecraft() {
        return Bridge.getInstance().bridge$getMinecraft();
    }

    public GuiScreenBridge getCurrentScreen() {
        return getMinecraft().bridge$getCurrentScreen();
    }

    public TessellatorBridge getTessellator() {
        return Bridge.getInstance().bridge$createTessellator();
    }

    public GameSettingsBridge getGameSettings() {
        return Bridge.getInstance().bridge$getGameSettings();
    }

}