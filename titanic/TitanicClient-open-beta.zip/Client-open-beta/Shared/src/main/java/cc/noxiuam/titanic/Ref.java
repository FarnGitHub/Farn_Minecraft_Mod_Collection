package cc.noxiuam.titanic;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.client.config.ConfigManager;
import cc.noxiuam.titanic.client.module.ModuleManager;
import cc.noxiuam.titanic.client.network.manager.friend.FriendManager;
import cc.noxiuam.titanic.client.network.manager.PlayerProfileManager;
import cc.noxiuam.titanic.client.network.manager.server.ServerManager;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.network.cosmetic.type.emote.EmoteManager;
import cc.noxiuam.titanic.client.util.chat.ChatColor;
import cc.noxiuam.titanic.event.EventManager;
import cc.noxiuam.titanic.kotlin.KTitanic;
import lombok.experimental.UtilityClass;

/**
 * @author Noxiuam
 * https://noxiuam.cc
 */
@UtilityClass
public class Ref {

    public static MinecraftVersion MC_VERSION = MinecraftVersion.UNKNOWN;

    public String AUTO_LOGIN_AUTH_MESSAGE = ChatColor.RED + "Please log in using /login <password>.";

    public EventManager getEventManager() {
        return Client.getInstance().getEventManager();
    }

    public ModuleManager getModuleManager() {
        return Client.getInstance().getModuleManager();
    }

    public ConfigManager getConfigManager() {
        return Client.getInstance().getConfigManager();
    }

    public PlayerProfileManager getProfileManager() {
        return Client.getInstance().getProfileManager();
    }

    public FriendManager getFriendManager() {
        return Client.getInstance().getFriendManager();
    }

    public EmoteManager getEmoteManager() {
        return Client.getInstance().getEmoteManager();
    }

    public ServerManager getServerManager() {
        return Client.getInstance().getServerManager();
    }

    public Bridge getBridge() {
        return Client.getInstance().getBridge();
    }

    public KTitanic getTitanic() {
        return Client.getInstance();
    }

}
