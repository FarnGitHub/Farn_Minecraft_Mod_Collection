package cc.noxiuam.titanic.client.ui.component.type.setting.impl.keybind;

import cc.noxiuam.titanic.client.module.data.setting.AbstractSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.KeybindSetting;
import cc.noxiuam.titanic.client.ui.screen.module.container.module.setting.ModuleSettingsContainer;
import cc.noxiuam.titanic.client.ui.component.type.setting.AbstractSettingComponent;

public class KeybindComponent extends AbstractSettingComponent<Integer> {

    private final KeybindButton button;

    public KeybindComponent(AbstractSetting<Integer> setting, ModuleSettingsContainer list) {
        super(setting, list);
        this.button = new KeybindButton((KeybindSetting) setting);
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(
                this.setting.name(),
                (int) (this.x + 85),
                (int) (this.y + 6),
                -1
        );

        this.button.size(75, 20);
        this.button.position(this.x + 2, this.y);
        this.button.draw(mouseX, mouseY);
    }

    @Override
    public float getHeight() {
        return 20;
    }

    @Override
    public void keyTyped(char character, int key) {
        this.button.keyTyped(character, key);
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        this.button.mouseClicked(mouseX, mouseY);
    }

}
