package cc.noxiuam.titanic.kotlin.client.logger

import cc.noxiuam.titanic.kotlin.KTitanic

class Logger(private var section : String) {

    private val format = "[Titanic] [%s] (%s) %s"

    private fun log(level : String, msg : String) {
        val formatted = String.format(format, level, section, msg)
        println(formatted)
    }

    fun info(msg : String) {
        log("Info", msg)
    }

    fun error(msg : String) {
        log("Error", msg)
    }

    fun debug(msg : String) {
        if (KTitanic().debug) {
            log("Debug", msg)
        }
    }

}