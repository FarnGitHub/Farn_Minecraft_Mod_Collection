package cc.noxiuam.titanic.client.module.impl.normal;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.renderer.TessellatorBridge;
import cc.noxiuam.titanic.bridge.minecraft.renderer.FontRendererBridge;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.network.cosmetic.PlayerProfile;
import cc.noxiuam.titanic.client.registry.Friend;
import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.KeybindSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.ChoiceSetting;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.client.util.ModuleColorRegistry;
import cc.noxiuam.titanic.client.util.RenderEngineUtil;
import cc.noxiuam.titanic.client.util.chat.ChatColor;
import cc.noxiuam.titanic.event.impl.keyboard.KeyboardEvent;
import cc.noxiuam.titanic.event.impl.world.player.NametagRenderEvent;
import org.lwjgl.opengl.GL11;

import java.util.Collections;

public class NametagEditorModule extends AbstractModule {

    private final KeybindSetting toggleKeybind;
    private final BooleanSetting showBackground, showIcons, showFriendNicknames;

    private final ChoiceSetting color;
    private final ChoiceSetting friendColor;

    public boolean showNametags = true;

    public NametagEditorModule() {
        super(
                "nameTagEditor",
                "Nametag Editor",
                "Allows you to change the way player nametags look.",
                false,
                MinecraftVersion.getAllVersions(),
                Collections.emptyList()
        );

        this.addSettings(
                this.toggleKeybind = new KeybindSetting("toggleKeybind", "Temp Toggle Keybind", 0),
                this.color = new ChoiceSetting(
                        "color",
                        "Text Color",
                        "White",
                        "White", "Aqua", "Red", "Gold",
                        "Green", "Purple", "Yellow", "Blue",
                        "Gray", "Dark Red", "Dark Green", "Dark Purple",
                        "Dark Blue", "Dark Aqua", "Dark Gray"
                ),
                this.friendColor = new ChoiceSetting(
                        "friendColor",
                        "Friend Text Color",
                        "White",
                        "White", "Aqua", "Red", "Gold",
                        "Green", "Purple", "Yellow", "Blue",
                        "Gray", "Dark Red", "Dark Green", "Dark Purple",
                        "Dark Blue", "Dark Aqua", "Dark Gray"
                ),
                this.showBackground = new BooleanSetting("showBackground", "Show Background", true),
                this.showIcons = new BooleanSetting("showIcons", "Show Icons", true),
                this.showFriendNicknames = new BooleanSetting("showFriendNicknames", "Show Friend Nicknames", false)
        );

        this.showIcons.description("Some users have icons, enable this to see them!");
        this.friendColor.description("If you have friends, their name will be this color.");

        this.addEvent(KeyboardEvent.class, event -> {
            if (event.getKey() == this.toggleKeybind.value()) {
                this.showNametags = !this.showNametags;
            }
        });

        this.addEvent(NametagRenderEvent.class, this::onNameTagRender);
    }

    private void onNameTagRender(NametagRenderEvent event) {
        event.cancel();
        this.renderCustomNameTag(event);
    }

    public void renderCustomNameTag(NametagRenderEvent event) {
        FontRendererBridge fontRenderer = Bridge.getInstance().bridge$getMinecraft().bridge$getFontRenderer();
        String s = event.getPlayer().bridge$getUsername();
        float f3 = event.getF3();

        PlayerProfile playerProfile = Ref.getProfileManager().getProfile(s);
        boolean showIcon = this.showIcons.value()
                && playerProfile.getNametagIcon() != null;

        int iconTexture = 0;
        if (showIcon) {
            iconTexture = RenderEngineUtil.getTextureInt(playerProfile.getNametagIcon().getIconUrl(), null);
        }

        boolean nickedFriend = false;
        boolean sneaking = event.getPlayer().bridge$isSneaking();

        if (!this.showNametags) {
            GL11.glEnable(GL11.GL_LIGHTING);
            GL11.glDisable(GL11.GL_BLEND);
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            GL11.glPopMatrix();
            return;
        }

        if (this.showFriendNicknames.value()) {
            Friend friend = Ref.getFriendManager().getFriendByUsername(s);

            if (friend != null && friend.getNickname().length() > 0) {
                s = friend.getNickname();
                nickedFriend = true;
            }
        }

        if (sneaking) {
            GL11.glTranslatef(0.0F, 0.25F / f3, 0.0F);
        }

        GL11.glDepthMask(false);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(770, 771);

        TessellatorBridge tessellatorBridge = BridgeRef.getTessellator();

        int i = 0;
        if (event.getPlayer().bridge$getUsername().equals("deadmau5")) {
            i = -10;
        }

        GL11.glDisable(GL11.GL_TEXTURE_2D);

        int j = fontRenderer.bridge$getStringWidth(s) / 2;
        int toAdd = (showIcon && !sneaking ? playerProfile.getNametagIcon().getXOffset() : 0);
        j = j + toAdd;

        if (this.showBackground.value() && !sneaking) {
            tessellatorBridge.bridge$startDrawingQuads();
            tessellatorBridge.bridge$setColorRGBA_F(0.0F, 0.0F, 0.0F, 0.25F);
            tessellatorBridge.bridge$addVertex(-j - 1, sneaking ? -1D : -1 + i, 0.0D);
            tessellatorBridge.bridge$addVertex(-j - 1, sneaking ? 8D : 8 + i, 0.0D);
            tessellatorBridge.bridge$addVertex(j + 1, sneaking ? 8D : 8 + i, 0.0D);
            tessellatorBridge.bridge$addVertex(j + 1, sneaking ? -1D : -1 + i, 0.0D);
            tessellatorBridge.bridge$draw();
        }

        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(true);

        if (showIcon && !sneaking) {
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            RenderUtil.drawIconFromInt(
                    iconTexture,
                    (float) (-(j * 2)) / 2.0f,
                    0.0F,
                    playerProfile.getNametagIcon().getWidth(),
                    playerProfile.getNametagIcon().getHeight()
            );
        }

        this.drawNameTagText(s, fontRenderer, -fontRenderer.bridge$getStringWidth(s) / 2 + toAdd, i, Ref.getFriendManager().isFriend(s) || nickedFriend, sneaking);

        GL11.glEnable(GL11.GL_LIGHTING);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glPopMatrix();
    }

    private void drawNameTagText(String str, FontRendererBridge fontRenderer, int x, int y, boolean friend, boolean sneak) {
        ChatColor friendTextColor = ModuleColorRegistry.TEXT_COLORS.get(this.friendColor.value());
        int color = friend ? friendTextColor.getSolidColor() : this.getTextColor().getSolidColor();

        if (sneak) {
            color = friend ? friendTextColor.getSneakColor() : this.getTextColor().getSneakColor();
        }

        fontRenderer.bridge$drawString(str, x, y, color);
    }

    public ChatColor getTextColor() {
        return ModuleColorRegistry.TEXT_COLORS.get(this.color.value());
    }

}
