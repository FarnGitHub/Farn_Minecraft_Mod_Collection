package cc.noxiuam.titanic.client.ui.screen.friend.container.data;

import cc.noxiuam.titanic.client.ui.screen.friend.component.FriendComponent;
import lombok.Getter;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Getter
public class FriendPage {

    private final List<FriendComponent> friendComponents = new CopyOnWriteArrayList<>();

}
