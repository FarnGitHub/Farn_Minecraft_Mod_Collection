package cc.noxiuam.titanic.event.impl.gui.inventory;

import cc.noxiuam.titanic.bridge.minecraft.client.MinecraftBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.inventory.CraftingInventoryCBBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class SlotChangeEvent extends AbstractEvent {

    private final int i;
    private final int button;
    private final MinecraftBridge mc;
    private final CraftingInventoryCBBridge inventory;

}
