package cc.noxiuam.titanic.client.module.impl.normal.world.lighting;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.MathHelper;
import cc.noxiuam.titanic.bridge.minecraft.Vec3D;
import cc.noxiuam.titanic.bridge.minecraft.block.BlockAccessBridge;
import cc.noxiuam.titanic.bridge.minecraft.block.BlockBridge;
import cc.noxiuam.titanic.bridge.minecraft.block.MaterialBridge;
import cc.noxiuam.titanic.bridge.minecraft.block.impl.BlockDoorBridge;
import cc.noxiuam.titanic.bridge.minecraft.block.impl.BlockRedstoneWireBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.WorldBridge;
import cc.noxiuam.titanic.bridge.minecraft.renderer.TessellatorBridge;
import cc.noxiuam.titanic.client.module.impl.normal.world.WorldEditor;
import org.lwjgl.opengl.GL11;

/**
 * I can not be asked to figure out what was added/changed by the mod Windows ported
 * - Nox
 */
public class SmoothRenderBlocks {
    private BlockAccessBridge blockAccess;
    private int overrideBlockTexture = -1;
    private boolean flipTexture = false;
    private boolean renderAllFaces = false;
    public float hasSubtypes1r;
    public float dyeColors1g;
    public float field_21025_c1b;
    public float field_21004_c2r;
    public float field_21008_c2g;
    public float field_21010_c2b;
    public float field_21034_c3r;
    public float xLocation3g;
    public float instrumentType3b;
    public float sugar4r;
    public float field_21024_c4g;
    public float cake4b;
    public boolean field_21035_blen;
    public int field_21015_blsmooth;
    public float field_21011_llxyz;
    public float field_21026_bg0yz;
    public float field_21042_a;
    public float field_21047_llx0z;
    public float field_21020_aV00z;
    public float field_21036_b0z;
    public float field_21031_b;
    public float field_21045_d0Yz;
    public float field_21018_bf;
    public float field_21046_c0;
    public float field_21017_ll0y0;
    public float field_21033_llXy0;
    public float field_21039_d00;
    public float field_21010_ll000;
    public float field_21024_llX00;
    public float field_21021_aU0;
    public float field_21037_a0Y0;
    public float field_21009_llXY0;
    public float field_21025_llxyZ;
    public float field_21040_c0yZ;
    public float field_21013_llXyZ;
    public float field_21019_aW0Z;
    public float field_21034_ll00Z;
    public float field_21048_b0Z;
    public float field_21044_e;
    public float field_21016_ll0YZ;
    public float field_21032_llXYZ;

    private static final BlockBridge BLOCK_BRIDGE = Bridge.getInstance().bridge$getBlock();
    private static final BlockRedstoneWireBridge REDSTONE_WIRE_BRIDGE = Bridge.getInstance().bridge$getBlock().bridge$getRedstoneWire();

    private static final WorldEditor WORLD_EDITOR_MOD = Ref.getModuleManager().getWorldEditor();

    public SmoothRenderBlocks(BlockAccessBridge blockAccessBridge) {
        this.blockAccess = blockAccessBridge;
        this.hasSubtypes1r = this.field_21004_c2r = this.field_21034_c3r = this.sugar4r = this.dyeColors1g = this.field_21008_c2g = this.xLocation3g = this.field_21024_c4g = this.field_21025_c1b = this.field_21010_c2b = this.instrumentType3b = this.cake4b = 1.0F;
        this.field_21035_blen = false;
        this.field_21015_blsmooth = 1;
    }

    public void renderBlockUsingTexture(BlockBridge block, int i, int j, int k, int l) {
        this.overrideBlockTexture = l;
        this.renderBlockByRenderType(block, i, j, k);
        this.overrideBlockTexture = -1;
    }

    public boolean renderBlockByRenderType(BlockBridge block, int i, int j, int k) {
        int l = block.bridge$getRenderType();
        block.bridge$setBlockBoundsBasedOnState(this.blockAccess, i, j, k);
        return l == 0 ? this.renderStandardBlock(block, i, j, k) : (l == 4 ? this.renderBlockFluids(block, i, j, k) : (l == 13 ? this.renderBlockCactus(block, i, j, k) : (l == 1 ? this.renderBlockReed(block, i, j, k) : (l == 6 ? this.renderBlockCrops(block, i, j, k) : (l == 2 ? this.renderBlockTorch(block, i, j, k) : (l == 3 ? this.renderBlockFire(block, i, j, k) : (l == 5 ? this.renderBlockRedstoneWire(block, i, j, k) : (l == 8 ? this.renderBlockLadder(block, i, j, k) : (l == 7 ? this.renderBlockDoor(block, i, j, k) : (l == 9 ? this.renderBlockMinecartTrack(block, i, j, k) : (l == 10 ? this.renderBlockStairs(block, i, j, k) : (l == 11 ? this.renderBlockFence(block, i, j, k) : (l == 12 ? this.renderBlockLever(block, i, j, k) : false)))))))))))));
    }

    public boolean renderBlockTorch(BlockBridge block, int i, int j, int k) {
        int l = this.blockAccess.bridge$getBlockMetadata(i, j, k);
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        float f = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
        if (block.bridge$getLightValues()[block.bridge$getBlockID()] > 0) {
            f = 1.0F;
        }

        tessellator.bridge$setColorOpaque_F(f, f, f);
        double d = 0.4F;
        double d1 = 0.5D - d;
        double d2 = 0.2F;
        if (l == 1) {
            this.renderTorchAtAngle(block, (double) i - d1, (double) j + d2, (double) k, -d, 0.0D);
        } else if (l == 2) {
            this.renderTorchAtAngle(block, (double) i + d1, (double) j + d2, (double) k, d, 0.0D);
        } else if (l == 3) {
            this.renderTorchAtAngle(block, (double) i, (double) j + d2, (double) k - d1, 0.0D, -d);
        } else if (l == 4) {
            this.renderTorchAtAngle(block, (double) i, (double) j + d2, (double) k + d1, 0.0D, d);
        } else {
            this.renderTorchAtAngle(block, (double) i, (double) j, (double) k, 0.0D, 0.0D);
        }

        return true;
    }

    public boolean renderBlockLever(BlockBridge block, int i, int j, int k) {
        int l = this.blockAccess.bridge$getBlockMetadata(i, j, k);
        int i1 = l & 7;
        boolean flag = (l & 8) > 0;
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        boolean flag1 = this.overrideBlockTexture >= 0;
        if (!flag1) {
            this.overrideBlockTexture = BLOCK_BRIDGE.bridge$getCobblestone().bridge$getBlockIndexInTexture();
        }

        float f = 0.25F;
        float f1 = 3.0F / 16.0F;
        float f2 = 3.0F / 16.0F;
        if (i1 == 5) {
            block.bridge$setBlockBounds(0.5F - f1, 0.0F, 0.5F - f, 0.5F + f1, f2, 0.5F + f);
        } else if (i1 == 6) {
            block.bridge$setBlockBounds(0.5F - f, 0.0F, 0.5F - f1, 0.5F + f, f2, 0.5F + f1);
        } else if (i1 == 4) {
            block.bridge$setBlockBounds(0.5F - f1, 0.5F - f, 1.0F - f2, 0.5F + f1, 0.5F + f, 1.0F);
        } else if (i1 == 3) {
            block.bridge$setBlockBounds(0.5F - f1, 0.5F - f, 0.0F, 0.5F + f1, 0.5F + f, f2);
        } else if (i1 == 2) {
            block.bridge$setBlockBounds(1.0F - f2, 0.5F - f, 0.5F - f1, 1.0F, 0.5F + f, 0.5F + f1);
        } else if (i1 == 1) {
            block.bridge$setBlockBounds(0.0F, 0.5F - f, 0.5F - f1, f2, 0.5F + f, 0.5F + f1);
        }

        this.renderStandardBlock(block, i, j, k);
        if (!flag1) {
            this.overrideBlockTexture = -1;
        }

        float f3 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
        if (BLOCK_BRIDGE.bridge$getLightValues()[block.bridge$getBlockID()] > 0) {
            f3 = 1.0F;
        }

        tessellator.bridge$setColorOpaque_F(f3, f3, f3);
        int j1 = block.bridge$getBlockTextureFromSide(0);
        if (this.overrideBlockTexture >= 0) {
            j1 = this.overrideBlockTexture;
        }

        int k1 = (j1 & 15) << 4;
        int l1 = j1 & 240;
        float f4 = (float) k1 / 256.0F;
        float f5 = ((float) k1 + 15.99F) / 256.0F;
        float f6 = (float) l1 / 256.0F;
        float f7 = ((float) l1 + 15.99F) / 256.0F;
        Vec3D[] avec3d = new Vec3D[8];
        float f8 = 1.0F / 16.0F;
        float f9 = 1.0F / 16.0F;
        float f10 = 10.0F / 16.0F;
        avec3d[0] = Vec3D.createVector((double) (-f8), 0.0D, (double) (-f9));
        avec3d[1] = Vec3D.createVector((double) f8, 0.0D, (double) (-f9));
        avec3d[2] = Vec3D.createVector((double) f8, 0.0D, (double) f9);
        avec3d[3] = Vec3D.createVector((double) (-f8), 0.0D, (double) f9);
        avec3d[4] = Vec3D.createVector((double) (-f8), (double) f10, (double) (-f9));
        avec3d[5] = Vec3D.createVector((double) f8, (double) f10, (double) (-f9));
        avec3d[6] = Vec3D.createVector((double) f8, (double) f10, (double) f9);
        avec3d[7] = Vec3D.createVector((double) (-f8), (double) f10, (double) f9);

        for (int vec3d = 0; vec3d < 8; ++vec3d) {
            if (flag) {
                avec3d[vec3d].zCoord -= 1.0D / 16.0D;
                avec3d[vec3d].rotateAroundX(0.6981317F);
            } else {
                avec3d[vec3d].zCoord += 1.0D / 16.0D;
                avec3d[vec3d].rotateAroundX(-0.6981317F);
            }

            if (i1 == 6) {
                avec3d[vec3d].rotateAroundY(1.570796F);
            }

            if (i1 < 5) {
                avec3d[vec3d].yCoord -= 0.375D;
                avec3d[vec3d].rotateAroundX(1.570796F);
                if (i1 == 4) {
                    avec3d[vec3d].rotateAroundY(0.0F);
                }

                if (i1 == 3) {
                    avec3d[vec3d].rotateAroundY(3.141593F);
                }

                if (i1 == 2) {
                    avec3d[vec3d].rotateAroundY(1.570796F);
                }

                if (i1 == 1) {
                    avec3d[vec3d].rotateAroundY(-1.570796F);
                }

                avec3d[vec3d].xCoord += (double) i + 0.5D;
                avec3d[vec3d].yCoord += (double) ((float) j + 0.5F);
                avec3d[vec3d].zCoord += (double) k + 0.5D;
            } else {
                avec3d[vec3d].xCoord += (double) i + 0.5D;
                avec3d[vec3d].yCoord += (double) ((float) j + 2.0F / 16.0F);
                avec3d[vec3d].zCoord += (double) k + 0.5D;
            }
        }

        Vec3D var30 = null;
        Vec3D vec3d1 = null;
        Vec3D vec3d2 = null;
        Vec3D vec3d3 = null;

        for (int j2 = 0; j2 < 6; ++j2) {
            if (j2 == 0) {
                f4 = (float) (k1 + 7) / 256.0F;
                f5 = ((float) (k1 + 9) - 0.01F) / 256.0F;
                f6 = (float) (l1 + 6) / 256.0F;
                f7 = ((float) (l1 + 8) - 0.01F) / 256.0F;
            } else if (j2 == 2) {
                f4 = (float) (k1 + 7) / 256.0F;
                f5 = ((float) (k1 + 9) - 0.01F) / 256.0F;
                f6 = (float) (l1 + 6) / 256.0F;
                f7 = ((float) (l1 + 16) - 0.01F) / 256.0F;
            }

            if (j2 == 0) {
                var30 = avec3d[0];
                vec3d1 = avec3d[1];
                vec3d2 = avec3d[2];
                vec3d3 = avec3d[3];
            } else if (j2 == 1) {
                var30 = avec3d[7];
                vec3d1 = avec3d[6];
                vec3d2 = avec3d[5];
                vec3d3 = avec3d[4];
            } else if (j2 == 2) {
                var30 = avec3d[1];
                vec3d1 = avec3d[0];
                vec3d2 = avec3d[4];
                vec3d3 = avec3d[5];
            } else if (j2 == 3) {
                var30 = avec3d[2];
                vec3d1 = avec3d[1];
                vec3d2 = avec3d[5];
                vec3d3 = avec3d[6];
            } else if (j2 == 4) {
                var30 = avec3d[3];
                vec3d1 = avec3d[2];
                vec3d2 = avec3d[6];
                vec3d3 = avec3d[7];
            } else if (j2 == 5) {
                var30 = avec3d[0];
                vec3d1 = avec3d[3];
                vec3d2 = avec3d[7];
                vec3d3 = avec3d[4];
            }

            tessellator.bridge$addVertexWithUV(var30.xCoord, var30.yCoord, var30.zCoord, (double) f4, (double) f7);
            tessellator.bridge$addVertexWithUV(vec3d1.xCoord, vec3d1.yCoord, vec3d1.zCoord, (double) f5, (double) f7);
            tessellator.bridge$addVertexWithUV(vec3d2.xCoord, vec3d2.yCoord, vec3d2.zCoord, (double) f5, (double) f6);
            tessellator.bridge$addVertexWithUV(vec3d3.xCoord, vec3d3.yCoord, vec3d3.zCoord, (double) f4, (double) f6);
        }

        return true;
    }

    public boolean renderBlockFire(BlockBridge block, int i, int j, int k) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        int l = block.bridge$getBlockTextureFromSide(0);
        if (this.overrideBlockTexture >= 0) {
            l = this.overrideBlockTexture;
        }

        float f = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
        tessellator.bridge$setColorOpaque_F(f, f, f);
        int i1 = (l & 15) << 4;
        int j1 = l & 240;
        double d = (double) ((float) i1 / 256.0F);
        double d2 = (double) (((float) i1 + 15.99F) / 256.0F);
        double d4 = (double) ((float) j1 / 256.0F);
        double d6 = (double) (((float) j1 + 15.99F) / 256.0F);
        float f1 = 1.4F;
        double d11;
        double d13;
        double d15;
        double d17;
        double d19;
        double d21;
        double d23;
        if (!this.blockAccess.bridge$isBlockOpaqueCube(i, j - 1, k)
                && !BLOCK_BRIDGE.bridge$getFire().bridge$canBlockCatchFire(this.blockAccess, i, j - 1, k)) {
            float var46 = 0.2F;
            float f4 = 1.0F / 16.0F;
            if ((i + j + k & 1) == 1) {
                d = (double) ((float) i1 / 256.0F);
                d2 = (double) (((float) i1 + 15.99F) / 256.0F);
                d4 = (double) ((float) (j1 + 16) / 256.0F);
                d6 = (double) (((float) j1 + 15.99F + 16.0F) / 256.0F);
            }

            if ((i / 2 + j / 2 + k / 2 & 1) == 1) {
                d11 = d2;
                d2 = d;
                d = d11;
            }

            if (BLOCK_BRIDGE.bridge$getFire().bridge$canBlockCatchFire(this.blockAccess, i - 1, j, k)) {
                tessellator.bridge$addVertexWithUV((double) ((float) i + var46), (double) ((float) j + f1 + f4), (double) (k + 1), d2, d4);
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) (j + 0) + f4), (double) (k + 1), d2, d6);
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) (j + 0) + f4), (double) (k + 0), d, d6);
                tessellator.bridge$addVertexWithUV((double) ((float) i + var46), (double) ((float) j + f1 + f4), (double) (k + 0), d, d4);
                tessellator.bridge$addVertexWithUV((double) ((float) i + var46), (double) ((float) j + f1 + f4), (double) (k + 0), d, d4);
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) (j + 0) + f4), (double) (k + 0), d, d6);
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) (j + 0) + f4), (double) (k + 1), d2, d6);
                tessellator.bridge$addVertexWithUV((double) ((float) i + var46), (double) ((float) j + f1 + f4), (double) (k + 1), d2, d4);
            }

            if (BLOCK_BRIDGE.bridge$getFire().bridge$canBlockCatchFire(this.blockAccess, i + 1, j, k)) {
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) - var46), (double) ((float) j + f1 + f4), (double) (k + 0), d, d4);
                tessellator.bridge$addVertexWithUV((double) (i + 1 - 0), (double) ((float) (j + 0) + f4), (double) (k + 0), d, d6);
                tessellator.bridge$addVertexWithUV((double) (i + 1 - 0), (double) ((float) (j + 0) + f4), (double) (k + 1), d2, d6);
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) - var46), (double) ((float) j + f1 + f4), (double) (k + 1), d2, d4);
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) - var46), (double) ((float) j + f1 + f4), (double) (k + 1), d2, d4);
                tessellator.bridge$addVertexWithUV((double) (i + 1 - 0), (double) ((float) (j + 0) + f4), (double) (k + 1), d2, d6);
                tessellator.bridge$addVertexWithUV((double) (i + 1 - 0), (double) ((float) (j + 0) + f4), (double) (k + 0), d, d6);
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) - var46), (double) ((float) j + f1 + f4), (double) (k + 0), d, d4);
            }

            if (BLOCK_BRIDGE.bridge$getFire().bridge$canBlockCatchFire(this.blockAccess, i, j, k - 1)) {
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) j + f1 + f4), (double) ((float) k + var46), d2, d4);
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) (j + 0) + f4), (double) (k + 0), d2, d6);
                tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) (j + 0) + f4), (double) (k + 0), d, d6);
                tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) j + f1 + f4), (double) ((float) k + var46), d, d4);
                tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) j + f1 + f4), (double) ((float) k + var46), d, d4);
                tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) (j + 0) + f4), (double) (k + 0), d, d6);
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) (j + 0) + f4), (double) (k + 0), d2, d6);
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) j + f1 + f4), (double) ((float) k + var46), d2, d4);
            }

            if (BLOCK_BRIDGE.bridge$getFire().bridge$canBlockCatchFire(this.blockAccess, i, j, k + 1)) {
                tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) j + f1 + f4), (double) ((float) (k + 1) - var46), d, d4);
                tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) (j + 0) + f4), (double) (k + 1 - 0), d, d6);
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) (j + 0) + f4), (double) (k + 1 - 0), d2, d6);
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) j + f1 + f4), (double) ((float) (k + 1) - var46), d2, d4);
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) j + f1 + f4), (double) ((float) (k + 1) - var46), d2, d4);
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) (j + 0) + f4), (double) (k + 1 - 0), d2, d6);
                tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) (j + 0) + f4), (double) (k + 1 - 0), d, d6);
                tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) j + f1 + f4), (double) ((float) (k + 1) - var46), d, d4);
            }

            if (BLOCK_BRIDGE.bridge$getFire().bridge$canBlockCatchFire(this.blockAccess, i, j + 1, k)) {
                d11 = (double) i + 0.5D + 0.5D;
                d13 = (double) i + 0.5D - 0.5D;
                d15 = (double) k + 0.5D + 0.5D;
                d17 = (double) k + 0.5D - 0.5D;
                d19 = (double) i + 0.5D - 0.5D;
                d21 = (double) i + 0.5D + 0.5D;
                d23 = (double) k + 0.5D - 0.5D;
                double d24 = (double) k + 0.5D + 0.5D;
                double d1 = (double) ((float) i1 / 256.0F);
                double d3 = (double) (((float) i1 + 15.99F) / 256.0F);
                double d5 = (double) ((float) j1 / 256.0F);
                double d7 = (double) (((float) j1 + 15.99F) / 256.0F);
                ++j;
                float f2 = -0.2F;
                if ((i + j + k & 1) == 0) {
                    tessellator.bridge$addVertexWithUV(d19, (double) ((float) j + f2), (double) (k + 0), d3, d5);
                    tessellator.bridge$addVertexWithUV(d11, (double) (j + 0), (double) (k + 0), d3, d7);
                    tessellator.bridge$addVertexWithUV(d11, (double) (j + 0), (double) (k + 1), d1, d7);
                    tessellator.bridge$addVertexWithUV(d19, (double) ((float) j + f2), (double) (k + 1), d1, d5);
                    d1 = (double) ((float) i1 / 256.0F);
                    d3 = (double) (((float) i1 + 15.99F) / 256.0F);
                    d5 = (double) ((float) (j1 + 16) / 256.0F);
                    d7 = (double) (((float) j1 + 15.99F + 16.0F) / 256.0F);
                    tessellator.bridge$addVertexWithUV(d21, (double) ((float) j + f2), (double) (k + 1), d3, d5);
                    tessellator.bridge$addVertexWithUV(d13, (double) (j + 0), (double) (k + 1), d3, d7);
                    tessellator.bridge$addVertexWithUV(d13, (double) (j + 0), (double) (k + 0), d1, d7);
                    tessellator.bridge$addVertexWithUV(d21, (double) ((float) j + f2), (double) (k + 0), d1, d5);
                } else {
                    tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) j + f2), d24, d3, d5);
                    tessellator.bridge$addVertexWithUV((double) (i + 0), (double) (j + 0), d17, d3, d7);
                    tessellator.bridge$addVertexWithUV((double) (i + 1), (double) (j + 0), d17, d1, d7);
                    tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) j + f2), d24, d1, d5);
                    d1 = (double) ((float) i1 / 256.0F);
                    d3 = (double) (((float) i1 + 15.99F) / 256.0F);
                    d5 = (double) ((float) (j1 + 16) / 256.0F);
                    d7 = (double) (((float) j1 + 15.99F + 16.0F) / 256.0F);
                    tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) j + f2), d23, d3, d5);
                    tessellator.bridge$addVertexWithUV((double) (i + 1), (double) (j + 0), d15, d3, d7);
                    tessellator.bridge$addVertexWithUV((double) (i + 0), (double) (j + 0), d15, d1, d7);
                    tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) j + f2), d23, d1, d5);
                }
            }
        } else {
            double f3 = (double) i + 0.5D + 0.2D;
            d11 = (double) i + 0.5D - 0.2D;
            d13 = (double) k + 0.5D + 0.2D;
            d15 = (double) k + 0.5D - 0.2D;
            d17 = (double) i + 0.5D - 0.3D;
            d19 = (double) i + 0.5D + 0.3D;
            d21 = (double) k + 0.5D - 0.3D;
            d23 = (double) k + 0.5D + 0.3D;
            tessellator.bridge$addVertexWithUV(d17, (double) ((float) j + f1), (double) (k + 1), d2, d4);
            tessellator.bridge$addVertexWithUV(f3, (double) (j + 0), (double) (k + 1), d2, d6);
            tessellator.bridge$addVertexWithUV(f3, (double) (j + 0), (double) (k + 0), d, d6);
            tessellator.bridge$addVertexWithUV(d17, (double) ((float) j + f1), (double) (k + 0), d, d4);
            tessellator.bridge$addVertexWithUV(d19, (double) ((float) j + f1), (double) (k + 0), d2, d4);
            tessellator.bridge$addVertexWithUV(d11, (double) (j + 0), (double) (k + 0), d2, d6);
            tessellator.bridge$addVertexWithUV(d11, (double) (j + 0), (double) (k + 1), d, d6);
            tessellator.bridge$addVertexWithUV(d19, (double) ((float) j + f1), (double) (k + 1), d, d4);
            d = (double) ((float) i1 / 256.0F);
            d2 = (double) (((float) i1 + 15.99F) / 256.0F);
            d4 = (double) ((float) (j1 + 16) / 256.0F);
            d6 = (double) (((float) j1 + 15.99F + 16.0F) / 256.0F);
            tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) j + f1), d23, d2, d4);
            tessellator.bridge$addVertexWithUV((double) (i + 1), (double) (j + 0), d15, d2, d6);
            tessellator.bridge$addVertexWithUV((double) (i + 0), (double) (j + 0), d15, d, d6);
            tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) j + f1), d23, d, d4);
            tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) j + f1), d21, d2, d4);
            tessellator.bridge$addVertexWithUV((double) (i + 0), (double) (j + 0), d13, d2, d6);
            tessellator.bridge$addVertexWithUV((double) (i + 1), (double) (j + 0), d13, d, d6);
            tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) j + f1), d21, d, d4);
            f3 = (double) i + 0.5D - 0.5D;
            d11 = (double) i + 0.5D + 0.5D;
            d13 = (double) k + 0.5D - 0.5D;
            d15 = (double) k + 0.5D + 0.5D;
            d17 = (double) i + 0.5D - 0.4D;
            d19 = (double) i + 0.5D + 0.4D;
            d21 = (double) k + 0.5D - 0.4D;
            d23 = (double) k + 0.5D + 0.4D;
            tessellator.bridge$addVertexWithUV(d17, (double) ((float) j + f1), (double) (k + 0), d, d4);
            tessellator.bridge$addVertexWithUV(f3, (double) (j + 0), (double) (k + 0), d, d6);
            tessellator.bridge$addVertexWithUV(f3, (double) (j + 0), (double) (k + 1), d2, d6);
            tessellator.bridge$addVertexWithUV(d17, (double) ((float) j + f1), (double) (k + 1), d2, d4);
            tessellator.bridge$addVertexWithUV(d19, (double) ((float) j + f1), (double) (k + 1), d, d4);
            tessellator.bridge$addVertexWithUV(d11, (double) (j + 0), (double) (k + 1), d, d6);
            tessellator.bridge$addVertexWithUV(d11, (double) (j + 0), (double) (k + 0), d2, d6);
            tessellator.bridge$addVertexWithUV(d19, (double) ((float) j + f1), (double) (k + 0), d2, d4);
            d = (double) ((float) i1 / 256.0F);
            d2 = (double) (((float) i1 + 15.99F) / 256.0F);
            d4 = (double) ((float) j1 / 256.0F);
            d6 = (double) (((float) j1 + 15.99F) / 256.0F);
            tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) j + f1), d23, d, d4);
            tessellator.bridge$addVertexWithUV((double) (i + 0), (double) (j + 0), d15, d, d6);
            tessellator.bridge$addVertexWithUV((double) (i + 1), (double) (j + 0), d15, d2, d6);
            tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) j + f1), d23, d2, d4);
            tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) j + f1), d21, d, d4);
            tessellator.bridge$addVertexWithUV((double) (i + 1), (double) (j + 0), d13, d, d6);
            tessellator.bridge$addVertexWithUV((double) (i + 0), (double) (j + 0), d13, d2, d6);
            tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) j + f1), d21, d2, d4);
        }

        return true;
    }

    public boolean renderBlockRedstoneWire(BlockBridge block, int i, int j, int k) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        int l = block.bridge$getBlockTextureFromSideAndMetadata(1, this.blockAccess.bridge$getBlockMetadata(i, j, k));
        if (this.overrideBlockTexture >= 0) {
            l = this.overrideBlockTexture;
        }

        float f = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
        tessellator.bridge$setColorOpaque_F(f, f, f);
        int i1 = (l & 15) << 4;
        int j1 = l & 240;
        double d = (double) ((float) i1 / 256.0F);
        double d1 = (double) (((float) i1 + 15.99F) / 256.0F);
        double d2 = (double) ((float) j1 / 256.0F);
        double d3 = (double) (((float) j1 + 15.99F) / 256.0F);
        float f1 = 0.0F;
        float f2 = 0.03125F;
        boolean flag = REDSTONE_WIRE_BRIDGE.bridge$isPowerProviderOrWire(this.blockAccess, i - 1, j, k) || !this.blockAccess.bridge$isBlockOpaqueCube(i - 1, j, k) && REDSTONE_WIRE_BRIDGE.bridge$isPowerProviderOrWire(this.blockAccess, i - 1, j - 1, k);
        boolean flag1 = REDSTONE_WIRE_BRIDGE.bridge$isPowerProviderOrWire(this.blockAccess, i + 1, j, k) || !this.blockAccess.bridge$isBlockOpaqueCube(i + 1, j, k) && REDSTONE_WIRE_BRIDGE.bridge$isPowerProviderOrWire(this.blockAccess, i + 1, j - 1, k);
        boolean flag2 = REDSTONE_WIRE_BRIDGE.bridge$isPowerProviderOrWire(this.blockAccess, i, j, k - 1) || !this.blockAccess.bridge$isBlockOpaqueCube(i, j, k - 1) && REDSTONE_WIRE_BRIDGE.bridge$isPowerProviderOrWire(this.blockAccess, i, j - 1, k - 1);
        boolean flag3 = REDSTONE_WIRE_BRIDGE.bridge$isPowerProviderOrWire(this.blockAccess, i, j, k + 1) || !this.blockAccess.bridge$isBlockOpaqueCube(i, j, k + 1) && REDSTONE_WIRE_BRIDGE.bridge$isPowerProviderOrWire(this.blockAccess, i, j - 1, k + 1);
        if (!this.blockAccess.bridge$isBlockOpaqueCube(i, j + 1, k)) {
            if (this.blockAccess.bridge$isBlockOpaqueCube(i - 1, j, k) && REDSTONE_WIRE_BRIDGE.bridge$isPowerProviderOrWire(this.blockAccess, i - 1, j + 1, k)) {
                flag = true;
            }

            if (this.blockAccess.bridge$isBlockOpaqueCube(i + 1, j, k) && REDSTONE_WIRE_BRIDGE.bridge$isPowerProviderOrWire(this.blockAccess, i + 1, j + 1, k)) {
                flag1 = true;
            }

            if (this.blockAccess.bridge$isBlockOpaqueCube(i, j, k - 1) && REDSTONE_WIRE_BRIDGE.bridge$isPowerProviderOrWire(this.blockAccess, i, j + 1, k - 1)) {
                flag2 = true;
            }

            if (this.blockAccess.bridge$isBlockOpaqueCube(i, j, k + 1) && REDSTONE_WIRE_BRIDGE.bridge$isPowerProviderOrWire(this.blockAccess, i, j + 1, k + 1)) {
                flag3 = true;
            }
        }

        float f3 = 5.0F / 16.0F;
        float f4 = (float) (i + 0);
        float f5 = (float) (i + 1);
        float f6 = (float) (k + 0);
        float f7 = (float) (k + 1);
        byte byte0 = 0;
        if ((flag || flag1) && !flag2 && !flag3) {
            byte0 = 1;
        }

        if ((flag2 || flag3) && !flag1 && !flag) {
            byte0 = 2;
        }

        if (byte0 != 0) {
            d = (double) ((float) (i1 + 16) / 256.0F);
            d1 = (double) (((float) (i1 + 16) + 15.99F) / 256.0F);
            d2 = (double) ((float) j1 / 256.0F);
            d3 = (double) (((float) j1 + 15.99F) / 256.0F);
        }

        if (byte0 == 0) {
            if (flag1 || flag2 || flag3 || flag) {
                if (!flag) {
                    f4 += f3;
                }

                if (!flag) {
                    d += (double) (f3 / 16.0F);
                }

                if (!flag1) {
                    f5 -= f3;
                }

                if (!flag1) {
                    d1 -= (double) (f3 / 16.0F);
                }

                if (!flag2) {
                    f6 += f3;
                }

                if (!flag2) {
                    d2 += (double) (f3 / 16.0F);
                }

                if (!flag3) {
                    f7 -= f3;
                }

                if (!flag3) {
                    d3 -= (double) (f3 / 16.0F);
                }
            }

            tessellator.bridge$addVertexWithUV((double) (f5 + f1), (double) ((float) j + f2), (double) (f7 + f1), d1, d3);
            tessellator.bridge$addVertexWithUV((double) (f5 + f1), (double) ((float) j + f2), (double) (f6 - f1), d1, d2);
            tessellator.bridge$addVertexWithUV((double) (f4 - f1), (double) ((float) j + f2), (double) (f6 - f1), d, d2);
            tessellator.bridge$addVertexWithUV((double) (f4 - f1), (double) ((float) j + f2), (double) (f7 + f1), d, d3);
        }

        if (byte0 == 1) {
            tessellator.bridge$addVertexWithUV((double) (f5 + f1), (double) ((float) j + f2), (double) (f7 + f1), d1, d3);
            tessellator.bridge$addVertexWithUV((double) (f5 + f1), (double) ((float) j + f2), (double) (f6 - f1), d1, d2);
            tessellator.bridge$addVertexWithUV((double) (f4 - f1), (double) ((float) j + f2), (double) (f6 - f1), d, d2);
            tessellator.bridge$addVertexWithUV((double) (f4 - f1), (double) ((float) j + f2), (double) (f7 + f1), d, d3);
        }

        if (byte0 == 2) {
            tessellator.bridge$addVertexWithUV((double) (f5 + f1), (double) ((float) j + f2), (double) (f7 + f1), d1, d3);
            tessellator.bridge$addVertexWithUV((double) (f5 + f1), (double) ((float) j + f2), (double) (f6 - f1), d, d3);
            tessellator.bridge$addVertexWithUV((double) (f4 - f1), (double) ((float) j + f2), (double) (f6 - f1), d, d2);
            tessellator.bridge$addVertexWithUV((double) (f4 - f1), (double) ((float) j + f2), (double) (f7 + f1), d1, d2);
        }

        d = (double) ((float) (i1 + 16) / 256.0F);
        d1 = (double) (((float) (i1 + 16) + 15.99F) / 256.0F);
        d2 = (double) ((float) j1 / 256.0F);
        d3 = (double) (((float) j1 + 15.99F) / 256.0F);
        if (!this.blockAccess.bridge$isBlockOpaqueCube(i, j + 1, k)) {
            if (this.blockAccess.bridge$isBlockOpaqueCube(i - 1, j, k) && this.blockAccess.bridge$getBlockId(i - 1, j + 1, k) == REDSTONE_WIRE_BRIDGE.bridge$getBlockID()) {
                tessellator.bridge$addVertexWithUV((double) ((float) i + f2), (double) ((float) (j + 1) + f1), (double) ((float) (k + 1) + f1), d1, d2);
                tessellator.bridge$addVertexWithUV((double) ((float) i + f2), (double) ((float) (j + 0) - f1), (double) ((float) (k + 1) + f1), d, d2);
                tessellator.bridge$addVertexWithUV((double) ((float) i + f2), (double) ((float) (j + 0) - f1), (double) ((float) (k + 0) - f1), d, d3);
                tessellator.bridge$addVertexWithUV((double) ((float) i + f2), (double) ((float) (j + 1) + f1), (double) ((float) (k + 0) - f1), d1, d3);
            }

            if (this.blockAccess.bridge$isBlockOpaqueCube(i + 1, j, k) && this.blockAccess.bridge$getBlockId(i + 1, j + 1, k) == REDSTONE_WIRE_BRIDGE.bridge$getBlockID()) {
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) - f2), (double) ((float) (j + 0) - f1), (double) ((float) (k + 1) + f1), d, d3);
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) - f2), (double) ((float) (j + 1) + f1), (double) ((float) (k + 1) + f1), d1, d3);
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) - f2), (double) ((float) (j + 1) + f1), (double) ((float) (k + 0) - f1), d1, d2);
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) - f2), (double) ((float) (j + 0) - f1), (double) ((float) (k + 0) - f1), d, d2);
            }

            if (this.blockAccess.bridge$isBlockOpaqueCube(i, j, k - 1) && this.blockAccess.bridge$getBlockId(i, j + 1, k - 1) == REDSTONE_WIRE_BRIDGE.bridge$getBlockID()) {
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) + f1), (double) ((float) (j + 0) - f1), (double) ((float) k + f2), d, d3);
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) + f1), (double) ((float) (j + 1) + f1), (double) ((float) k + f2), d1, d3);
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 0) - f1), (double) ((float) (j + 1) + f1), (double) ((float) k + f2), d1, d2);
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 0) - f1), (double) ((float) (j + 0) - f1), (double) ((float) k + f2), d, d2);
            }

            if (this.blockAccess.bridge$isBlockOpaqueCube(i, j, k + 1) && this.blockAccess.bridge$getBlockId(i, j + 1, k + 1) == REDSTONE_WIRE_BRIDGE.bridge$getBlockID()) {
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) + f1), (double) ((float) (j + 1) + f1), (double) ((float) (k + 1) - f2), d1, d2);
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) + f1), (double) ((float) (j + 0) - f1), (double) ((float) (k + 1) - f2), d, d2);
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 0) - f1), (double) ((float) (j + 0) - f1), (double) ((float) (k + 1) - f2), d, d3);
                tessellator.bridge$addVertexWithUV((double) ((float) (i + 0) - f1), (double) ((float) (j + 1) + f1), (double) ((float) (k + 1) - f2), d1, d3);
            }
        }

        return true;
    }

    public boolean renderBlockMinecartTrack(BlockBridge block, int i, int j, int k) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        int l = this.blockAccess.bridge$getBlockMetadata(i, j, k);
        int i1 = block.bridge$getBlockTextureFromSideAndMetadata(0, l);
        if (this.overrideBlockTexture >= 0) {
            i1 = this.overrideBlockTexture;
        }

        float f = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
        tessellator.bridge$setColorOpaque_F(f, f, f);
        int j1 = (i1 & 15) << 4;
        int k1 = i1 & 240;
        double d = (double) ((float) j1 / 256.0F);
        double d1 = (double) (((float) j1 + 15.99F) / 256.0F);
        double d2 = (double) ((float) k1 / 256.0F);
        double d3 = (double) (((float) k1 + 15.99F) / 256.0F);
        float f1 = 1.0F / 16.0F;
        float f2 = (float) (i + 1);
        float f3 = (float) (i + 1);
        float f4 = (float) (i + 0);
        float f5 = (float) (i + 0);
        float f6 = (float) (k + 0);
        float f7 = (float) (k + 1);
        float f8 = (float) (k + 1);
        float f9 = (float) (k + 0);
        float f10 = (float) j + f1;
        float f11 = (float) j + f1;
        float f12 = (float) j + f1;
        float f13 = (float) j + f1;
        if (l != 1 && l != 2 && l != 3 && l != 7) {
            if (l == 8) {
                f3 = (float) (i + 0);
                f2 = f3;
                f5 = (float) (i + 1);
                f4 = f5;
                f9 = (float) (k + 1);
                f6 = f9;
                f8 = (float) (k + 0);
                f7 = f8;
            } else if (l == 9) {
                f5 = (float) (i + 0);
                f2 = f5;
                f4 = (float) (i + 1);
                f3 = f4;
                f7 = (float) (k + 0);
                f6 = f7;
                f9 = (float) (k + 1);
                f8 = f9;
            }
        } else {
            f5 = (float) (i + 1);
            f2 = f5;
            f4 = (float) (i + 0);
            f3 = f4;
            f7 = (float) (k + 1);
            f6 = f7;
            f9 = (float) (k + 0);
            f8 = f9;
        }

        if (l != 2 && l != 4) {
            if (l == 3 || l == 5) {
                ++f11;
                ++f12;
            }
        } else {
            ++f10;
            ++f13;
        }

        tessellator.bridge$addVertexWithUV((double) f2, (double) f10, (double) f6, d1, d2);
        tessellator.bridge$addVertexWithUV((double) f3, (double) f11, (double) f7, d1, d3);
        tessellator.bridge$addVertexWithUV((double) f4, (double) f12, (double) f8, d, d3);
        tessellator.bridge$addVertexWithUV((double) f5, (double) f13, (double) f9, d, d2);
        tessellator.bridge$addVertexWithUV((double) f5, (double) f13, (double) f9, d, d2);
        tessellator.bridge$addVertexWithUV((double) f4, (double) f12, (double) f8, d, d3);
        tessellator.bridge$addVertexWithUV((double) f3, (double) f11, (double) f7, d1, d3);
        tessellator.bridge$addVertexWithUV((double) f2, (double) f10, (double) f6, d1, d2);
        return true;
    }

    public boolean renderBlockLadder(BlockBridge block, int i, int j, int k) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        int l = block.bridge$getBlockTextureFromSide(0);
        if (this.overrideBlockTexture >= 0) {
            l = this.overrideBlockTexture;
        }

        float f = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
        tessellator.bridge$setColorOpaque_F(f, f, f);
        int i1 = (l & 15) << 4;
        int j1 = l & 240;
        double d = (double) ((float) i1 / 256.0F);
        double d1 = (double) (((float) i1 + 15.99F) / 256.0F);
        double d2 = (double) ((float) j1 / 256.0F);
        double d3 = (double) (((float) j1 + 15.99F) / 256.0F);
        int k1 = this.blockAccess.bridge$getBlockMetadata(i, j, k);
        float f1 = 0.0F;
        float f2 = 0.05F;
        if (k1 == 5) {
            tessellator.bridge$addVertexWithUV((double) ((float) i + f2), (double) ((float) (j + 1) + f1), (double) ((float) (k + 1) + f1), d, d2);
            tessellator.bridge$addVertexWithUV((double) ((float) i + f2), (double) ((float) (j + 0) - f1), (double) ((float) (k + 1) + f1), d, d3);
            tessellator.bridge$addVertexWithUV((double) ((float) i + f2), (double) ((float) (j + 0) - f1), (double) ((float) (k + 0) - f1), d1, d3);
            tessellator.bridge$addVertexWithUV((double) ((float) i + f2), (double) ((float) (j + 1) + f1), (double) ((float) (k + 0) - f1), d1, d2);
        }

        if (k1 == 4) {
            tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) - f2), (double) ((float) (j + 0) - f1), (double) ((float) (k + 1) + f1), d1, d3);
            tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) - f2), (double) ((float) (j + 1) + f1), (double) ((float) (k + 1) + f1), d1, d2);
            tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) - f2), (double) ((float) (j + 1) + f1), (double) ((float) (k + 0) - f1), d, d2);
            tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) - f2), (double) ((float) (j + 0) - f1), (double) ((float) (k + 0) - f1), d, d3);
        }

        if (k1 == 3) {
            tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) + f1), (double) ((float) (j + 0) - f1), (double) ((float) k + f2), d1, d3);
            tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) + f1), (double) ((float) (j + 1) + f1), (double) ((float) k + f2), d1, d2);
            tessellator.bridge$addVertexWithUV((double) ((float) (i + 0) - f1), (double) ((float) (j + 1) + f1), (double) ((float) k + f2), d, d2);
            tessellator.bridge$addVertexWithUV((double) ((float) (i + 0) - f1), (double) ((float) (j + 0) - f1), (double) ((float) k + f2), d, d3);
        }

        if (k1 == 2) {
            tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) + f1), (double) ((float) (j + 1) + f1), (double) ((float) (k + 1) - f2), d, d2);
            tessellator.bridge$addVertexWithUV((double) ((float) (i + 1) + f1), (double) ((float) (j + 0) - f1), (double) ((float) (k + 1) - f2), d, d3);
            tessellator.bridge$addVertexWithUV((double) ((float) (i + 0) - f1), (double) ((float) (j + 0) - f1), (double) ((float) (k + 1) - f2), d1, d3);
            tessellator.bridge$addVertexWithUV((double) ((float) (i + 0) - f1), (double) ((float) (j + 1) + f1), (double) ((float) (k + 1) - f2), d1, d2);
        }

        return true;
    }

    public boolean renderBlockReed(BlockBridge block, int i, int j, int k) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        float f = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
        tessellator.bridge$setColorOpaque_F(f, f, f);
        this.func_1239_a(block, this.blockAccess.bridge$getBlockMetadata(i, j, k), i, j, k);
        return true;
    }

    public boolean renderBlockCrops(BlockBridge block, int i, int j, int k) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        float f = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
        tessellator.bridge$setColorOpaque_F(f, f, f);
        this.func_1245_b(block, this.blockAccess.bridge$getBlockMetadata(i, j, k), i, ((float) j - 1.0F / 16.0F), k);
        return true;
    }

    public void renderTorchAtAngle(BlockBridge block, double d, double d1, double d2, double d3, double d4) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        int i = block.bridge$getBlockTextureFromSide(0);
        if (this.overrideBlockTexture >= 0) {
            i = this.overrideBlockTexture;
        }

        int j = (i & 15) << 4;
        int k = i & 240;
        float f = (float) j / 256.0F;
        float f1 = ((float) j + 15.99F) / 256.0F;
        float f2 = (float) k / 256.0F;
        float f3 = ((float) k + 15.99F) / 256.0F;
        double d5 = (double) f + 1.75D / 64.0D;
        double d6 = (double) f2 + 6.0D / 256.0D;
        double d7 = (double) f + 9.0D / 256.0D;
        double d8 = (double) f2 + 1.0D / 32.0D;
        d += 0.5D;
        d2 += 0.5D;
        double d9 = d - 0.5D;
        double d10 = d + 0.5D;
        double d11 = d2 - 0.5D;
        double d12 = d2 + 0.5D;
        double d13 = 1.0D / 16.0D;
        double d14 = 0.625D;
        tessellator.bridge$addVertexWithUV(d + d3 * (1.0D - d14) - d13, d1 + d14, d2 + d4 * (1.0D - d14) - d13, d5, d6);
        tessellator.bridge$addVertexWithUV(d + d3 * (1.0D - d14) - d13, d1 + d14, d2 + d4 * (1.0D - d14) + d13, d5, d8);
        tessellator.bridge$addVertexWithUV(d + d3 * (1.0D - d14) + d13, d1 + d14, d2 + d4 * (1.0D - d14) + d13, d7, d8);
        tessellator.bridge$addVertexWithUV(d + d3 * (1.0D - d14) + d13, d1 + d14, d2 + d4 * (1.0D - d14) - d13, d7, d6);
        tessellator.bridge$addVertexWithUV(d - d13, d1 + 1.0D, d11, (double) f, (double) f2);
        tessellator.bridge$addVertexWithUV(d - d13 + d3, d1 + 0.0D, d11 + d4, (double) f, (double) f3);
        tessellator.bridge$addVertexWithUV(d - d13 + d3, d1 + 0.0D, d12 + d4, (double) f1, (double) f3);
        tessellator.bridge$addVertexWithUV(d - d13, d1 + 1.0D, d12, (double) f1, (double) f2);
        tessellator.bridge$addVertexWithUV(d + d13, d1 + 1.0D, d12, (double) f, (double) f2);
        tessellator.bridge$addVertexWithUV(d + d3 + d13, d1 + 0.0D, d12 + d4, (double) f, (double) f3);
        tessellator.bridge$addVertexWithUV(d + d3 + d13, d1 + 0.0D, d11 + d4, (double) f1, (double) f3);
        tessellator.bridge$addVertexWithUV(d + d13, d1 + 1.0D, d11, (double) f1, (double) f2);
        tessellator.bridge$addVertexWithUV(d9, d1 + 1.0D, d2 + d13, (double) f, (double) f2);
        tessellator.bridge$addVertexWithUV(d9 + d3, d1 + 0.0D, d2 + d13 + d4, (double) f, (double) f3);
        tessellator.bridge$addVertexWithUV(d10 + d3, d1 + 0.0D, d2 + d13 + d4, (double) f1, (double) f3);
        tessellator.bridge$addVertexWithUV(d10, d1 + 1.0D, d2 + d13, (double) f1, (double) f2);
        tessellator.bridge$addVertexWithUV(d10, d1 + 1.0D, d2 - d13, (double) f, (double) f2);
        tessellator.bridge$addVertexWithUV(d10 + d3, d1 + 0.0D, d2 - d13 + d4, (double) f, (double) f3);
        tessellator.bridge$addVertexWithUV(d9 + d3, d1 + 0.0D, d2 - d13 + d4, (double) f1, (double) f3);
        tessellator.bridge$addVertexWithUV(d9, d1 + 1.0D, d2 - d13, (double) f1, (double) f2);
    }

    public void func_1239_a(BlockBridge block, int i, double d, double d1, double d2) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        int j = block.bridge$getBlockTextureFromSideAndMetadata(0, i);
        if (this.overrideBlockTexture >= 0) {
            j = this.overrideBlockTexture;
        }

        int k = (j & 15) << 4;
        int l = j & 240;
        double d3 = (double) ((float) k / 256.0F);
        double d4 = (double) (((float) k + 15.99F) / 256.0F);
        double d5 = (double) ((float) l / 256.0F);
        double d6 = (double) (((float) l + 15.99F) / 256.0F);
        double d7 = d + 0.5D - (double) 0.45F;
        double d8 = d + 0.5D + (double) 0.45F;
        double d9 = d2 + 0.5D - (double) 0.45F;
        double d10 = d2 + 0.5D + (double) 0.45F;
        tessellator.bridge$addVertexWithUV(d7, d1 + 1.0D, d9, d3, d5);
        tessellator.bridge$addVertexWithUV(d7, d1 + 0.0D, d9, d3, d6);
        tessellator.bridge$addVertexWithUV(d8, d1 + 0.0D, d10, d4, d6);
        tessellator.bridge$addVertexWithUV(d8, d1 + 1.0D, d10, d4, d5);
        tessellator.bridge$addVertexWithUV(d8, d1 + 1.0D, d10, d3, d5);
        tessellator.bridge$addVertexWithUV(d8, d1 + 0.0D, d10, d3, d6);
        tessellator.bridge$addVertexWithUV(d7, d1 + 0.0D, d9, d4, d6);
        tessellator.bridge$addVertexWithUV(d7, d1 + 1.0D, d9, d4, d5);
        tessellator.bridge$addVertexWithUV(d7, d1 + 1.0D, d10, d3, d5);
        tessellator.bridge$addVertexWithUV(d7, d1 + 0.0D, d10, d3, d6);
        tessellator.bridge$addVertexWithUV(d8, d1 + 0.0D, d9, d4, d6);
        tessellator.bridge$addVertexWithUV(d8, d1 + 1.0D, d9, d4, d5);
        tessellator.bridge$addVertexWithUV(d8, d1 + 1.0D, d9, d3, d5);
        tessellator.bridge$addVertexWithUV(d8, d1 + 0.0D, d9, d3, d6);
        tessellator.bridge$addVertexWithUV(d7, d1 + 0.0D, d10, d4, d6);
        tessellator.bridge$addVertexWithUV(d7, d1 + 1.0D, d10, d4, d5);
    }

    public void func_1245_b(BlockBridge block, int i, double d, double d1, double d2) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        int j = block.bridge$getBlockTextureFromSideAndMetadata(0, i);
        if (this.overrideBlockTexture >= 0) {
            j = this.overrideBlockTexture;
        }

        int k = (j & 15) << 4;
        int l = j & 240;
        double d3 = (double) ((float) k / 256.0F);
        double d4 = (double) (((float) k + 15.99F) / 256.0F);
        double d5 = (double) ((float) l / 256.0F);
        double d6 = (double) (((float) l + 15.99F) / 256.0F);
        double d7 = d + 0.5D - 0.25D;
        double d8 = d + 0.5D + 0.25D;
        double d9 = d2 + 0.5D - 0.5D;
        double d10 = d2 + 0.5D + 0.5D;
        tessellator.bridge$addVertexWithUV(d7, d1 + 1.0D, d9, d3, d5);
        tessellator.bridge$addVertexWithUV(d7, d1 + 0.0D, d9, d3, d6);
        tessellator.bridge$addVertexWithUV(d7, d1 + 0.0D, d10, d4, d6);
        tessellator.bridge$addVertexWithUV(d7, d1 + 1.0D, d10, d4, d5);
        tessellator.bridge$addVertexWithUV(d7, d1 + 1.0D, d10, d3, d5);
        tessellator.bridge$addVertexWithUV(d7, d1 + 0.0D, d10, d3, d6);
        tessellator.bridge$addVertexWithUV(d7, d1 + 0.0D, d9, d4, d6);
        tessellator.bridge$addVertexWithUV(d7, d1 + 1.0D, d9, d4, d5);
        tessellator.bridge$addVertexWithUV(d8, d1 + 1.0D, d10, d3, d5);
        tessellator.bridge$addVertexWithUV(d8, d1 + 0.0D, d10, d3, d6);
        tessellator.bridge$addVertexWithUV(d8, d1 + 0.0D, d9, d4, d6);
        tessellator.bridge$addVertexWithUV(d8, d1 + 1.0D, d9, d4, d5);
        tessellator.bridge$addVertexWithUV(d8, d1 + 1.0D, d9, d3, d5);
        tessellator.bridge$addVertexWithUV(d8, d1 + 0.0D, d9, d3, d6);
        tessellator.bridge$addVertexWithUV(d8, d1 + 0.0D, d10, d4, d6);
        tessellator.bridge$addVertexWithUV(d8, d1 + 1.0D, d10, d4, d5);
        d7 = d + 0.5D - 0.5D;
        d8 = d + 0.5D + 0.5D;
        d9 = d2 + 0.5D - 0.25D;
        d10 = d2 + 0.5D + 0.25D;
        tessellator.bridge$addVertexWithUV(d7, d1 + 1.0D, d9, d3, d5);
        tessellator.bridge$addVertexWithUV(d7, d1 + 0.0D, d9, d3, d6);
        tessellator.bridge$addVertexWithUV(d8, d1 + 0.0D, d9, d4, d6);
        tessellator.bridge$addVertexWithUV(d8, d1 + 1.0D, d9, d4, d5);
        tessellator.bridge$addVertexWithUV(d8, d1 + 1.0D, d9, d3, d5);
        tessellator.bridge$addVertexWithUV(d8, d1 + 0.0D, d9, d3, d6);
        tessellator.bridge$addVertexWithUV(d7, d1 + 0.0D, d9, d4, d6);
        tessellator.bridge$addVertexWithUV(d7, d1 + 1.0D, d9, d4, d5);
        tessellator.bridge$addVertexWithUV(d8, d1 + 1.0D, d10, d3, d5);
        tessellator.bridge$addVertexWithUV(d8, d1 + 0.0D, d10, d3, d6);
        tessellator.bridge$addVertexWithUV(d7, d1 + 0.0D, d10, d4, d6);
        tessellator.bridge$addVertexWithUV(d7, d1 + 1.0D, d10, d4, d5);
        tessellator.bridge$addVertexWithUV(d7, d1 + 1.0D, d10, d3, d5);
        tessellator.bridge$addVertexWithUV(d7, d1 + 0.0D, d10, d3, d6);
        tessellator.bridge$addVertexWithUV(d8, d1 + 0.0D, d10, d4, d6);
        tessellator.bridge$addVertexWithUV(d8, d1 + 1.0D, d10, d4, d5);
    }

    public boolean renderBlockFluids(BlockBridge block, int i, int j, int k) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        boolean flag = block.bridge$shouldSideBeRendered(this.blockAccess, i, j + 1, k, 1);
        boolean flag1 = block.bridge$shouldSideBeRendered(this.blockAccess, i, j - 1, k, 0);
        boolean[] aflag = new boolean[]{block.bridge$shouldSideBeRendered(this.blockAccess, i, j, k - 1, 2), block.bridge$shouldSideBeRendered(this.blockAccess, i, j, k + 1, 3), block.bridge$shouldSideBeRendered(this.blockAccess, i - 1, j, k, 4), block.bridge$shouldSideBeRendered(this.blockAccess, i + 1, j, k, 5)};
        if (!flag && !flag1 && !aflag[0] && !aflag[1] && !aflag[2] && !aflag[3]) {
            return false;
        } else {
            boolean flag2 = false;
            float f = 0.5F;
            float f1 = 1.0F;
            float f2 = 0.8F;
            float f3 = 0.6F;
            double d = 0.0D;
            double d1 = 1.0D;
            MaterialBridge material = block.bridge$getMaterial();
            int l = this.blockAccess.bridge$getBlockMetadata(i, j, k);
            float f4 = this.func_1224_a(i, j, k, material);
            float f5 = this.func_1224_a(i, j, k + 1, material);
            float f6 = this.func_1224_a(i + 1, j, k + 1, material);
            float f7 = this.func_1224_a(i + 1, j, k, material);
            int j1;
            int k2;
            float f12;
            float f14;
            float f16;
            if (this.renderAllFaces || flag) {
                flag2 = true;
                j1 = block.bridge$getBlockTextureFromSideAndMetadata(1, l);
                float k1 = (float) BLOCK_BRIDGE.bridge$getBlockFluids().bridge$getFlowDirection(this.blockAccess, i, j, k, material);
                if (k1 > -999.0F) {
                    j1 = block.bridge$getBlockTextureFromSideAndMetadata(2, l);
                }

                int i2 = (j1 & 15) << 4;
                k2 = j1 & 240;
                double l2 = ((double) i2 + 8.0D) / 256.0D;
                double j3 = ((double) k2 + 8.0D) / 256.0D;
                if (k1 < -999.0F) {
                    k1 = 0.0F;
                } else {
                    l2 = (double) ((float) (i2 + 16) / 256.0F);
                    j3 = (double) ((float) (k2 + 16) / 256.0F);
                }

                f12 = MathHelper.sin(k1) * 8.0F / 256.0F;
                f14 = MathHelper.cos(k1) * 8.0F / 256.0F;
                f16 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
                tessellator.bridge$setColorOpaque_F(f1 * f16, f1 * f16, f1 * f16);
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) j + f4), (double) (k + 0), l2 - (double) f14 - (double) f12, j3 - (double) f14 + (double) f12);
                tessellator.bridge$addVertexWithUV((double) (i + 0), (double) ((float) j + f5), (double) (k + 1), l2 - (double) f14 + (double) f12, j3 + (double) f14 + (double) f12);
                tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) j + f6), (double) (k + 1), l2 + (double) f14 + (double) f12, j3 + (double) f14 - (double) f12);
                tessellator.bridge$addVertexWithUV((double) (i + 1), (double) ((float) j + f7), (double) (k + 0), l2 + (double) f14 - (double) f12, j3 - (double) f14 - (double) f12);
            }

            if (this.renderAllFaces || flag1) {
                float var48 = block.bridge$getBlockBrightness(this.blockAccess, i, j - 1, k);
                tessellator.bridge$setColorOpaque_F(f * var48, f * var48, f * var48);
                this.renderBottomFace(block, (double) i, (double) j, (double) k, block.bridge$getBlockTextureFromSide(0));
                flag2 = true;
            }

            for (j1 = 0; j1 < 4; ++j1) {
                int var49 = i;
                k2 = k;
                if (j1 == 0) {
                    k2 = k - 1;
                }

                if (j1 == 1) {
                    ++k2;
                }

                if (j1 == 2) {
                    var49 = i - 1;
                }

                if (j1 == 3) {
                    ++var49;
                }

                int var50 = block.bridge$getBlockTextureFromSideAndMetadata(j1 + 2, l);
                int i3 = (var50 & 15) << 4;
                int var51 = var50 & 240;
                if (this.renderAllFaces || aflag[j1]) {
                    float f10;
                    float f17;
                    float f18;
                    if (j1 == 0) {
                        f10 = f4;
                        f12 = f7;
                        f14 = (float) i;
                        f17 = (float) (i + 1);
                        f16 = (float) k;
                        f18 = (float) k;
                    } else if (j1 == 1) {
                        f10 = f6;
                        f12 = f5;
                        f14 = (float) (i + 1);
                        f17 = (float) i;
                        f16 = (float) (k + 1);
                        f18 = (float) (k + 1);
                    } else if (j1 == 2) {
                        f10 = f5;
                        f12 = f4;
                        f14 = (float) i;
                        f17 = (float) i;
                        f16 = (float) (k + 1);
                        f18 = (float) k;
                    } else {
                        f10 = f7;
                        f12 = f6;
                        f14 = (float) (i + 1);
                        f17 = (float) (i + 1);
                        f16 = (float) k;
                        f18 = (float) (k + 1);
                    }

                    flag2 = true;
                    double d4 = (double) ((float) (i3 + 0) / 256.0F);
                    double d5 = ((double) (i3 + 16) - 0.01D) / 256.0D;
                    double d6 = (double) (((float) var51 + (1.0F - f10) * 16.0F) / 256.0F);
                    double d7 = (double) (((float) var51 + (1.0F - f12) * 16.0F) / 256.0F);
                    double d8 = ((double) (var51 + 16) - 0.01D) / 256.0D;
                    float f19 = block.bridge$getBlockBrightness(this.blockAccess, var49, j, k2);
                    if (j1 < 2) {
                        f19 *= f2;
                    } else {
                        f19 *= f3;
                    }

                    tessellator.bridge$setColorOpaque_F(f1 * f19, f1 * f19, f1 * f19);
                    tessellator.bridge$addVertexWithUV((double) f14, (double) ((float) j + f10), (double) f16, d4, d6);
                    tessellator.bridge$addVertexWithUV((double) f17, (double) ((float) j + f12), (double) f18, d5, d7);
                    tessellator.bridge$addVertexWithUV((double) f17, (double) (j + 0), (double) f18, d5, d8);
                    tessellator.bridge$addVertexWithUV((double) f14, (double) (j + 0), (double) f16, d4, d8);
                }
            }

            block.bridge$setMinY(d);
            block.bridge$setMaxX(d1);
            return flag2;
        }
    }

    private float func_1224_a(int i, int j, int k, MaterialBridge material) {
        int l = 0;
        float f = 0.0F;

        for (int i1 = 0; i1 < 4; ++i1) {
            int j1 = i - (i1 & 1);
            int l1 = k - (i1 >> 1 & 1);
            if (this.blockAccess.bridge$getBlockMaterial(j1, j + 1, l1) == material) {
                return 1.0F;
            }

            MaterialBridge material1 = this.blockAccess.bridge$getBlockMaterial(j1, j, l1);
            if (material1 != material) {
                if (!material1.bridge$isSolid()) {
                    ++f;
                    ++l;
                }
            } else {
                int i2 = this.blockAccess.bridge$getBlockMetadata(j1, j, l1);
                if (i2 >= 8 || i2 == 0) {
                    f += BLOCK_BRIDGE.bridge$getBlockFluids().bridge$setFluidHeight(i2) * 10.0F;
                    l += 10;
                }

                f += BLOCK_BRIDGE.bridge$getBlockFluids().bridge$setFluidHeight(i2);
                ++l;
            }
        }

        return 1.0F - f / (float) l;
    }

    public void func_1243_a(BlockBridge block, WorldBridge world, int i, int j, int k) {
        float f = 0.5F;
        float f1 = 1.0F;
        float f2 = 0.8F;
        float f3 = 0.6F;
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        tessellator.bridge$startDrawingQuads();
        float f4 = block.bridge$getBlockBrightness(world, i, j, k);
        float f5 = block.bridge$getBlockBrightness(world, i, j - 1, k);
        if (f5 < f4) {
            f5 = f4;
        }

        tessellator.bridge$setColorOpaque_F(f * f5, f * f5, f * f5);
        this.renderBottomFace(block, -0.5D, -0.5D, -0.5D, block.bridge$getBlockTextureFromSide(0));
        f5 = block.bridge$getBlockBrightness(world, i, j + 1, k);
        if (f5 < f4) {
            f5 = f4;
        }

        tessellator.bridge$setColorOpaque_F(f1 * f5, f1 * f5, f1 * f5);
        this.renderTopFace(block, -0.5D, -0.5D, -0.5D, block.bridge$getBlockTextureFromSide(1));
        f5 = block.bridge$getBlockBrightness(world, i, j, k - 1);
        if (f5 < f4) {
            f5 = f4;
        }

        tessellator.bridge$setColorOpaque_F(f2 * f5, f2 * f5, f2 * f5);
        this.renderEastFace(block, -0.5D, -0.5D, -0.5D, block.bridge$getBlockTextureFromSide(2));
        f5 = block.bridge$getBlockBrightness(world, i, j, k + 1);
        if (f5 < f4) {
            f5 = f4;
        }

        tessellator.bridge$setColorOpaque_F(f2 * f5, f2 * f5, f2 * f5);
        this.renderWestFace(block, -0.5D, -0.5D, -0.5D, block.bridge$getBlockTextureFromSide(3));
        f5 = block.bridge$getBlockBrightness(world, i - 1, j, k);
        if (f5 < f4) {
            f5 = f4;
        }

        tessellator.bridge$setColorOpaque_F(f3 * f5, f3 * f5, f3 * f5);
        this.renderNorthFace(block, -0.5D, -0.5D, -0.5D, block.bridge$getBlockTextureFromSide(4));
        f5 = block.bridge$getBlockBrightness(world, i + 1, j, k);
        if (f5 < f4) {
            f5 = f4;
        }

        tessellator.bridge$setColorOpaque_F(f3 * f5, f3 * f5, f3 * f5);
        this.renderSouthFace(block, -0.5D, -0.5D, -0.5D, block.bridge$getBlockTextureFromSide(5));
        tessellator.bridge$draw();
    }

    public boolean renderStandardBlock(BlockBridge block, int i, int j, int k) {
        int l = block.bridge$colorMultiplier(this.blockAccess, i, j, k);
        float f = (float) (l >> 16 & 255) / 255.0F;
        float f1 = (float) (l >> 8 & 255) / 255.0F;
        float f2 = (float) (l & 255) / 255.0F;
        return this.renderStandardBlockWithAmbientOcclusion(block, i, j, k, f, f1, f2);
    }

    public boolean renderBlockCactus(BlockBridge block, int i, int j, int k) {
        int l = block.bridge$colorMultiplier(this.blockAccess, i, j, k);
        float f = (float) (l >> 16 & 255) / 255.0F;
        float f1 = (float) (l >> 8 & 255) / 255.0F;
        float f2 = (float) (l & 255) / 255.0F;
        return this.func_1230_b(block, i, j, k, f, f1, f2);
    }

    public boolean func_1230_b(BlockBridge block, int i, int j, int k, float f, float f1, float f2) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        boolean flag = false;
        float f3 = 0.5F;
        float f4 = 1.0F;
        float f5 = 0.8F;
        float f6 = 0.6F;
        float f7 = f3 * f;
        float f8 = f4 * f;
        float f9 = f5 * f;
        float f10 = f6 * f;
        float f11 = f3 * f1;
        float f12 = f4 * f1;
        float f13 = f5 * f1;
        float f14 = f6 * f1;
        float f15 = f3 * f2;
        float f16 = f4 * f2;
        float f17 = f5 * f2;
        float f18 = f6 * f2;
        float f19 = 1.0F / 16.0F;
        float f20 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
        float f26;
        if (this.renderAllFaces || block.bridge$shouldSideBeRendered(this.blockAccess, i, j - 1, k, 0)) {
            f26 = block.bridge$getBlockBrightness(this.blockAccess, i, j - 1, k);
            tessellator.bridge$setColorOpaque_F(f7 * f26, f11 * f26, f15 * f26);
            this.renderBottomFace(block, (double) i, (double) j, (double) k, block.bridge$getBlockTexture(this.blockAccess, i, j, k, 0));
            flag = true;
        }

        if (this.renderAllFaces || block.bridge$shouldSideBeRendered(this.blockAccess, i, j + 1, k, 1)) {
            f26 = block.bridge$getBlockBrightness(this.blockAccess, i, j + 1, k);
            if (block.bridge$getMaxY() != 1.0D && !block.bridge$getMaterial().bridge$isLiquid()) {
                f26 = f20;
            }

            tessellator.bridge$setColorOpaque_F(f8 * f26, f12 * f26, f16 * f26);
            this.renderTopFace(block, (double) i, (double) j, (double) k, block.bridge$getBlockTexture(this.blockAccess, i, j, k, 1));
            flag = true;
        }

        if (this.renderAllFaces || block.bridge$shouldSideBeRendered(this.blockAccess, i, j, k - 1, 2)) {
            f26 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
            if (block.bridge$getMinZ() > 0.0D) {
                f26 = f20;
            }

            tessellator.bridge$setColorOpaque_F(f9 * f26, f13 * f26, f17 * f26);
            tessellator.bridge$setTranslationF(0.0F, 0.0F, f19);
            this.renderEastFace(block, (double) i, (double) j, (double) k, block.bridge$getBlockTexture(this.blockAccess, i, j, k, 2));
            tessellator.bridge$setTranslationF(0.0F, 0.0F, -f19);
            flag = true;
        }

        if (this.renderAllFaces || block.bridge$shouldSideBeRendered(this.blockAccess, i, j, k + 1, 3)) {
            f26 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
            if (block.bridge$getMaxZ() < 1.0D) {
                f26 = f20;
            }

            tessellator.bridge$setColorOpaque_F(f9 * f26, f13 * f26, f17 * f26);
            tessellator.bridge$setTranslationF(0.0F, 0.0F, -f19);
            this.renderWestFace(block, (double) i, (double) j, (double) k, block.bridge$getBlockTexture(this.blockAccess, i, j, k, 3));
            tessellator.bridge$setTranslationF(0.0F, 0.0F, f19);
            flag = true;
        }

        if (this.renderAllFaces || block.bridge$shouldSideBeRendered(this.blockAccess, i - 1, j, k, 4)) {
            f26 = block.bridge$getBlockBrightness(this.blockAccess, i - 1, j, k);
            if (block.bridge$getMinZ() > 0.0D) {
                f26 = f20;
            }

            tessellator.bridge$setColorOpaque_F(f10 * f26, f14 * f26, f18 * f26);
            tessellator.bridge$setTranslationF(f19, 0.0F, 0.0F);
            this.renderNorthFace(block, (double) i, (double) j, (double) k, block.bridge$getBlockTexture(this.blockAccess, i, j, k, 4));
            tessellator.bridge$setTranslationF(-f19, 0.0F, 0.0F);
            flag = true;
        }

        if (this.renderAllFaces || block.bridge$shouldSideBeRendered(this.blockAccess, i + 1, j, k, 5)) {
            f26 = block.bridge$getBlockBrightness(this.blockAccess, i + 1, j, k);
            if (block.bridge$getMaxX() < 1.0D) {
                f26 = f20;
            }

            tessellator.bridge$setColorOpaque_F(f10 * f26, f14 * f26, f18 * f26);
            tessellator.bridge$setTranslationF(-f19, 0.0F, 0.0F);
            this.renderSouthFace(block, (double) i, (double) j, (double) k, block.bridge$getBlockTexture(this.blockAccess, i, j, k, 5));
            tessellator.bridge$setTranslationF(f19, 0.0F, 0.0F);
            flag = true;
        }

        return flag;
    }

    public boolean renderBlockFence(BlockBridge block, int i, int j, int k) {
        boolean flag = false;
        float f = 6.0F / 16.0F;
        float f1 = 10.0F / 16.0F;
        block.bridge$setBlockBounds(f, 0.0F, f, f1, 1.0F, f1);
        this.renderStandardBlock(block, i, j, k);
        boolean flag1 = false;
        boolean flag2 = false;
        if (this.blockAccess.bridge$getBlockId(i - 1, j, k) == block.bridge$getBlockID() || this.blockAccess.bridge$getBlockId(i + 1, j, k) == block.bridge$getBlockID()) {
            flag1 = true;
        }

        if (this.blockAccess.bridge$getBlockId(i, j, k - 1) == block.bridge$getBlockID() || this.blockAccess.bridge$getBlockId(i, j, k + 1) == block.bridge$getBlockID()) {
            flag2 = true;
        }

        boolean flag3 = this.blockAccess.bridge$getBlockId(i - 1, j, k) == block.bridge$getBlockID();
        boolean flag4 = this.blockAccess.bridge$getBlockId(i + 1, j, k) == block.bridge$getBlockID();
        boolean flag5 = this.blockAccess.bridge$getBlockId(i, j, k - 1) == block.bridge$getBlockID();
        boolean flag6 = this.blockAccess.bridge$getBlockId(i, j, k + 1) == block.bridge$getBlockID();
        if (!flag1 && !flag2) {
            flag1 = true;
        }

        f = 7.0F / 16.0F;
        f1 = 9.0F / 16.0F;
        float f2 = 12.0F / 16.0F;
        float f3 = 15.0F / 16.0F;
        float f4 = flag3 ? 0.0F : f;
        float f5 = flag4 ? 1.0F : f1;
        float f6 = flag5 ? 0.0F : f;
        float f7 = flag6 ? 1.0F : f1;
        if (flag1) {
            block.bridge$setBlockBounds(f4, f2, f, f5, f3, f1);
            this.renderStandardBlock(block, i, j, k);
        }

        if (flag2) {
            block.bridge$setBlockBounds(f, f2, f6, f1, f3, f7);
            this.renderStandardBlock(block, i, j, k);
        }

        f2 = 6.0F / 16.0F;
        f3 = 9.0F / 16.0F;
        if (flag1) {
            block.bridge$setBlockBounds(f4, f2, f, f5, f3, f1);
            this.renderStandardBlock(block, i, j, k);
        }

        if (flag2) {
            block.bridge$setBlockBounds(f, f2, f6, f1, f3, f7);
            this.renderStandardBlock(block, i, j, k);
        }

        block.bridge$setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        return flag;
    }

    public boolean renderBlockStairs(BlockBridge block, int i, int j, int k) {
        boolean flag = false;
        int l = this.blockAccess.bridge$getBlockMetadata(i, j, k);
        if (l == 0) {
            block.bridge$setBlockBounds(0.0F, 0.0F, 0.0F, 0.5F, 0.5F, 1.0F);
            this.renderStandardBlock(block, i, j, k);
            block.bridge$setBlockBounds(0.5F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
            this.renderStandardBlock(block, i, j, k);
        } else if (l == 1) {
            block.bridge$setBlockBounds(0.0F, 0.0F, 0.0F, 0.5F, 1.0F, 1.0F);
            this.renderStandardBlock(block, i, j, k);
            block.bridge$setBlockBounds(0.5F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
            this.renderStandardBlock(block, i, j, k);
        } else if (l == 2) {
            block.bridge$setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 0.5F);
            this.renderStandardBlock(block, i, j, k);
            block.bridge$setBlockBounds(0.0F, 0.0F, 0.5F, 1.0F, 1.0F, 1.0F);
            this.renderStandardBlock(block, i, j, k);
        } else if (l == 3) {
            block.bridge$setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.5F);
            this.renderStandardBlock(block, i, j, k);
            block.bridge$setBlockBounds(0.0F, 0.0F, 0.5F, 1.0F, 0.5F, 1.0F);
            this.renderStandardBlock(block, i, j, k);
        }

        block.bridge$setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        return flag;
    }

    public boolean renderBlockDoor(BlockBridge block, int i, int j, int k) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        BlockDoorBridge blockdoor = (BlockDoorBridge) block;
        float f = 0.5F;
        float f1 = 1.0F;
        float f2 = 0.8F;
        float f3 = 0.6F;
        float f4 = blockdoor.bridge$getBlockBrightness(this.blockAccess, i, j, k);
        float f5 = blockdoor.bridge$getBlockBrightness(this.blockAccess, i, j - 1, k);
        if (blockdoor.bridge$getMinY() > 0.0D) {
            f5 = f4;
        }

        if (BLOCK_BRIDGE.bridge$getLightValues()[blockdoor.bridge$getBlockID()] > 0) {
            f5 = 1.0F;
        }

        tessellator.bridge$setColorOpaque_F(f * f5, f * f5, f * f5);
        this.renderBottomFace(blockdoor, (double) i, (double) j, (double) k, blockdoor.bridge$getBlockTexture(this.blockAccess, i, j, k, 0));
        f5 = blockdoor.bridge$getBlockBrightness(this.blockAccess, i, j + 1, k);
        if (blockdoor.bridge$getMaxY() < 1.0D) {
            f5 = f4;
        }

        if (BLOCK_BRIDGE.bridge$getLightValues()[blockdoor.bridge$getBlockID()] > 0) {
            f5 = 1.0F;
        }

        tessellator.bridge$setColorOpaque_F(f1 * f5, f1 * f5, f1 * f5);
        this.renderTopFace(blockdoor, (double) i, (double) j, (double) k, blockdoor.bridge$getBlockTexture(this.blockAccess, i, j, k, 1));
        f5 = blockdoor.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
        if (blockdoor.bridge$getMinZ() > 0.0D) {
            f5 = f4;
        }

        if (BLOCK_BRIDGE.bridge$getLightValues()[blockdoor.bridge$getBlockID()] > 0) {
            f5 = 1.0F;
        }

        tessellator.bridge$setColorOpaque_F(f2 * f5, f2 * f5, f2 * f5);
        int l = blockdoor.bridge$getBlockTexture(this.blockAccess, i, j, k, 2);
        if (l < 0) {
            this.flipTexture = true;
            l = -l;
        }

        this.renderEastFace(blockdoor, (double) i, (double) j, (double) k, l);
        this.flipTexture = false;
        f5 = blockdoor.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
        if (blockdoor.bridge$getMaxZ() < 1.0D) {
            f5 = f4;
        }

        if (BLOCK_BRIDGE.bridge$getLightValues()[blockdoor.bridge$getBlockID()] > 0) {
            f5 = 1.0F;
        }

        tessellator.bridge$setColorOpaque_F(f2 * f5, f2 * f5, f2 * f5);
        l = blockdoor.bridge$getBlockTexture(this.blockAccess, i, j, k, 3);
        if (l < 0) {
            this.flipTexture = true;
            l = -l;
        }

        this.renderWestFace(blockdoor, (double) i, (double) j, (double) k, l);
        this.flipTexture = false;
        f5 = blockdoor.bridge$getBlockBrightness(this.blockAccess, i - 1, j, k);
        if (blockdoor.bridge$getMinX() > 0.0D) {
            f5 = f4;
        }

        if (BLOCK_BRIDGE.bridge$getLightValues()[blockdoor.bridge$getBlockID()] > 0) {
            f5 = 1.0F;
        }

        tessellator.bridge$setColorOpaque_F(f3 * f5, f3 * f5, f3 * f5);
        l = blockdoor.bridge$getBlockTexture(this.blockAccess, i, j, k, 4);
        if (l < 0) {
            this.flipTexture = true;
            l = -l;
        }

        this.renderNorthFace(blockdoor, (double) i, (double) j, (double) k, l);
        this.flipTexture = false;
        f5 = blockdoor.bridge$getBlockBrightness(this.blockAccess, i + 1, j, k);
        if (blockdoor.bridge$getMaxX() < 1.0D) {
            f5 = f4;
        }

        if (BLOCK_BRIDGE.bridge$getLightValues()[blockdoor.bridge$getBlockID()] > 0) {
            f5 = 1.0F;
        }

        tessellator.bridge$setColorOpaque_F(f3 * f5, f3 * f5, f3 * f5);
        l = blockdoor.bridge$getBlockTexture(this.blockAccess, i, j, k, 5);
        if (l < 0) {
            this.flipTexture = true;
            l = -l;
        }

        this.renderSouthFace(blockdoor, (double) i, (double) j, (double) k, l);
        this.flipTexture = false;
        return true;
    }

    public void renderBottomFace(BlockBridge block, double d, double d1, double d2, int i) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        if (this.overrideBlockTexture >= 0) {
            i = this.overrideBlockTexture;
        }

        int j = (i & 15) << 4;
        int k = i & 240;
        double d3 = ((double) j + block.bridge$getMinX() * 16.0D) / 256.0D;
        double d4 = ((double) j + block.bridge$getMaxX() * 16.0D - 0.01D) / 256.0D;
        double d5 = ((double) k + block.bridge$getMinZ() * 16.0D) / 256.0D;
        double d6 = ((double) k + block.bridge$getMaxZ() * 16.0D - 0.01D) / 256.0D;
        if (block.bridge$getMinX() < 0.0D || block.bridge$getMaxX() > 1.0D) {
            d3 = (double) (((float) j + 0.0F) / 256.0F);
            d4 = (double) (((float) j + 15.99F) / 256.0F);
        }

        if (block.bridge$getMinZ() < 0.0D || block.bridge$getMaxZ() > 1.0D) {
            d5 = (double) (((float) k + 0.0F) / 256.0F);
            d6 = (double) (((float) k + 15.99F) / 256.0F);
        }

        double d7 = d + block.bridge$getMinX();
        double d8 = d + block.bridge$getMaxX();
        double d9 = d1 + block.bridge$getMinY();
        double d10 = d2 + block.bridge$getMinZ();
        double d11 = d2 + block.bridge$getMaxZ();
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.hasSubtypes1r, this.dyeColors1g, this.field_21025_c1b);
        }

        tessellator.bridge$addVertexWithUV(d7, d9, d11, d3, d6);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.field_21004_c2r, this.field_21008_c2g, this.field_21010_c2b);
        }

        tessellator.bridge$addVertexWithUV(d7, d9, d10, d3, d5);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.field_21034_c3r, this.xLocation3g, this.instrumentType3b);
        }

        tessellator.bridge$addVertexWithUV(d8, d9, d10, d4, d5);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.sugar4r, this.field_21024_c4g, this.cake4b);
        }

        tessellator.bridge$addVertexWithUV(d8, d9, d11, d4, d6);
    }

    public void renderTopFace(BlockBridge block, double d, double d1, double d2, int i) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        if (this.overrideBlockTexture >= 0) {
            i = this.overrideBlockTexture;
        }

        int j = (i & 15) << 4;
        int k = i & 240;
        double d3 = ((double) j + block.bridge$getMinX() * 16.0D) / 256.0D;
        double d4 = ((double) j + block.bridge$getMaxX() * 16.0D - 0.01D) / 256.0D;
        double d5 = ((double) k + block.bridge$getMinZ() * 16.0D) / 256.0D;
        double d6 = ((double) k + block.bridge$getMaxZ() * 16.0D - 0.01D) / 256.0D;
        if (block.bridge$getMinX() < 0.0D || block.bridge$getMaxX() > 1.0D) {
            d3 = (double) (((float) j + 0.0F) / 256.0F);
            d4 = (double) (((float) j + 15.99F) / 256.0F);
        }

        if (block.bridge$getMinZ() < 0.0D || block.bridge$getMaxZ() > 1.0D) {
            d5 = (double) (((float) k + 0.0F) / 256.0F);
            d6 = (double) (((float) k + 15.99F) / 256.0F);
        }

        double d7 = d + block.bridge$getMinX();
        double d8 = d + block.bridge$getMaxX();
        double d9 = d1 + block.bridge$getMaxY();
        double d10 = d2 + block.bridge$getMinZ();
        double d11 = d2 + block.bridge$getMaxZ();
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.hasSubtypes1r, this.dyeColors1g, this.field_21025_c1b);
        }

        tessellator.bridge$addVertexWithUV(d8, d9, d11, d4, d6);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.field_21004_c2r, this.field_21008_c2g, this.field_21010_c2b);
        }

        tessellator.bridge$addVertexWithUV(d8, d9, d10, d4, d5);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.field_21034_c3r, this.xLocation3g, this.instrumentType3b);
        }

        tessellator.bridge$addVertexWithUV(d7, d9, d10, d3, d5);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.sugar4r, this.field_21024_c4g, this.cake4b);
        }

        tessellator.bridge$addVertexWithUV(d7, d9, d11, d3, d6);
    }

    public void renderEastFace(BlockBridge block, double d, double d1, double d2, int i) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        if (this.overrideBlockTexture >= 0) {
            i = this.overrideBlockTexture;
        }

        int j = (i & 15) << 4;
        int k = i & 240;
        double d3 = ((double) j + block.bridge$getMinX() * 16.0D) / 256.0D;
        double d4 = ((double) j + block.bridge$getMaxX() * 16.0D - 0.01D) / 256.0D;
        double d5 = ((double) k + block.bridge$getMinY() * 16.0D) / 256.0D;
        double d6 = ((double) k + block.bridge$getMaxY() * 16.0D - 0.01D) / 256.0D;
        double d8;
        if (this.flipTexture) {
            d8 = d3;
            d3 = d4;
            d4 = d8;
        }

        if (block.bridge$getMinX() < 0.0D || block.bridge$getMaxX() > 1.0D) {
            d3 = (double) (((float) j + 0.0F) / 256.0F);
            d4 = (double) (((float) j + 15.99F) / 256.0F);
        }

        if (block.bridge$getMinY() < 0.0D || block.bridge$getMaxY() > 1.0D) {
            d5 = (double) (((float) k + 0.0F) / 256.0F);
            d6 = (double) (((float) k + 15.99F) / 256.0F);
        }

        d8 = d + block.bridge$getMinX();
        double d9 = d + block.bridge$getMaxX();
        double d10 = d1 + block.bridge$getMinY();
        double d11 = d1 + block.bridge$getMaxY();
        double d12 = d2 + block.bridge$getMinZ();
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.hasSubtypes1r, this.dyeColors1g, this.field_21025_c1b);
        }

        tessellator.bridge$addVertexWithUV(d8, d11, d12, d4, d5);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.field_21004_c2r, this.field_21008_c2g, this.field_21010_c2b);
        }

        tessellator.bridge$addVertexWithUV(d9, d11, d12, d3, d5);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.field_21034_c3r, this.xLocation3g, this.instrumentType3b);
        }

        tessellator.bridge$addVertexWithUV(d9, d10, d12, d3, d6);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.sugar4r, this.field_21024_c4g, this.cake4b);
        }

        tessellator.bridge$addVertexWithUV(d8, d10, d12, d4, d6);
    }

    public void renderWestFace(BlockBridge block, double d, double d1, double d2, int i) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        if (this.overrideBlockTexture >= 0) {
            i = this.overrideBlockTexture;
        }

        int j = (i & 15) << 4;
        int k = i & 240;
        double d3 = ((double) j + block.bridge$getMinX() * 16.0D) / 256.0D;
        double d4 = ((double) j + block.bridge$getMaxX() * 16.0D - 0.01D) / 256.0D;
        double d5 = ((double) k + block.bridge$getMinY() * 16.0D) / 256.0D;
        double d6 = ((double) k + block.bridge$getMaxY() * 16.0D - 0.01D) / 256.0D;
        double d8;
        if (this.flipTexture) {
            d8 = d3;
            d3 = d4;
            d4 = d8;
        }

        if (block.bridge$getMinX() < 0.0D || block.bridge$getMaxX() > 1.0D) {
            d3 = (double) (((float) j + 0.0F) / 256.0F);
            d4 = (double) (((float) j + 15.99F) / 256.0F);
        }

        if (block.bridge$getMinX() < 0.0D || block.bridge$getMaxX() > 1.0D) {
            d5 = (double) (((float) k + 0.0F) / 256.0F);
            d6 = (double) (((float) k + 15.99F) / 256.0F);
        }

        d8 = d + block.bridge$getMinX();
        double d9 = d + block.bridge$getMaxX();
        double d10 = d1 + block.bridge$getMinY();
        double d11 = d1 + block.bridge$getMaxY();
        double d12 = d2 + block.bridge$getMaxZ();
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.hasSubtypes1r, this.dyeColors1g, this.field_21025_c1b);
        }

        tessellator.bridge$addVertexWithUV(d8, d11, d12, d3, d5);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.field_21004_c2r, this.field_21008_c2g, this.field_21010_c2b);
        }

        tessellator.bridge$addVertexWithUV(d8, d10, d12, d3, d6);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.field_21034_c3r, this.xLocation3g, this.instrumentType3b);
        }

        tessellator.bridge$addVertexWithUV(d9, d10, d12, d4, d6);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.sugar4r, this.field_21024_c4g, this.cake4b);
        }

        tessellator.bridge$addVertexWithUV(d9, d11, d12, d4, d5);
    }

    public void renderNorthFace(BlockBridge block, double d, double d1, double d2, int i) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        if (this.overrideBlockTexture >= 0) {
            i = this.overrideBlockTexture;
        }

        int j = (i & 15) << 4;
        int k = i & 240;
        double d3 = ((double) j + block.bridge$getMinZ() * 16.0D) / 256.0D;
        double d4 = ((double) j + block.bridge$getMaxZ() * 16.0D - 0.01D) / 256.0D;
        double d5 = ((double) k + block.bridge$getMinY() * 16.0D) / 256.0D;
        double d6 = ((double) k + block.bridge$getMaxY() * 16.0D - 0.01D) / 256.0D;
        double d8;
        if (this.flipTexture) {
            d8 = d3;
            d3 = d4;
            d4 = d8;
        }

        if (block.bridge$getMinZ() < 0.0D || block.bridge$getMaxZ() > 1.0D) {
            d3 = (double) (((float) j + 0.0F) / 256.0F);
            d4 = (double) (((float) j + 15.99F) / 256.0F);
        }

        if (block.bridge$getMinY() < 0.0D || block.bridge$getMaxY() > 1.0D) {
            d5 = (double) (((float) k + 0.0F) / 256.0F);
            d6 = (double) (((float) k + 15.99F) / 256.0F);
        }

        d8 = d + block.bridge$getMinX();
        double d9 = d1 + block.bridge$getMinY();
        double d10 = d1 + block.bridge$getMaxY();
        double d11 = d2 + block.bridge$getMinZ();
        double d12 = d2 + block.bridge$getMaxZ();
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.hasSubtypes1r, this.dyeColors1g, this.field_21025_c1b);
        }

        tessellator.bridge$addVertexWithUV(d8, d10, d12, d4, d5);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.field_21004_c2r, this.field_21008_c2g, this.field_21010_c2b);
        }

        tessellator.bridge$addVertexWithUV(d8, d10, d11, d3, d5);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.field_21034_c3r, this.xLocation3g, this.instrumentType3b);
        }

        tessellator.bridge$addVertexWithUV(d8, d9, d11, d3, d6);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.sugar4r, this.field_21024_c4g, this.cake4b);
        }

        tessellator.bridge$addVertexWithUV(d8, d9, d12, d4, d6);
    }

    public void renderSouthFace(BlockBridge block, double d, double d1, double d2, int i) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        if (this.overrideBlockTexture >= 0) {
            i = this.overrideBlockTexture;
        }

        int j = (i & 15) << 4;
        int k = i & 240;
        double d3 = ((double) j + block.bridge$getMinZ() * 16.0D) / 256.0D;
        double d4 = ((double) j + block.bridge$getMaxZ() * 16.0D - 0.01D) / 256.0D;
        double d5 = ((double) k + block.bridge$getMinY() * 16.0D) / 256.0D;
        double d6 = ((double) k + block.bridge$getMaxY() * 16.0D - 0.01D) / 256.0D;
        double d8;
        if (this.flipTexture) {
            d8 = d3;
            d3 = d4;
            d4 = d8;
        }

        if (block.bridge$getMinZ() < 0.0D || block.bridge$getMaxZ() > 1.0D) {
            d3 = (double) (((float) j + 0.0F) / 256.0F);
            d4 = (double) (((float) j + 15.99F) / 256.0F);
        }

        if (block.bridge$getMinY() < 0.0D || block.bridge$getMaxY() > 1.0D) {
            d5 = (double) (((float) k + 0.0F) / 256.0F);
            d6 = (double) (((float) k + 15.99F) / 256.0F);
        }

        d8 = d + block.bridge$getMaxX();
        double d9 = d1 + block.bridge$getMinY();
        double d10 = d1 + block.bridge$getMaxY();
        double d11 = d2 + block.bridge$getMinZ();
        double d12 = d2 + block.bridge$getMaxZ();

        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.hasSubtypes1r, this.dyeColors1g, this.field_21025_c1b);
        }

        tessellator.bridge$addVertexWithUV(d8, d9, d12, d3, d6);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.field_21004_c2r, this.field_21008_c2g, this.field_21010_c2b);
        }

        tessellator.bridge$addVertexWithUV(d8, d9, d11, d4, d6);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.field_21034_c3r, this.xLocation3g, this.instrumentType3b);
        }

        tessellator.bridge$addVertexWithUV(d8, d10, d11, d4, d5);
        if (this.field_21035_blen) {
            tessellator.bridge$setColorOpaque_F(this.sugar4r, this.field_21024_c4g, this.cake4b);
        }

        tessellator.bridge$addVertexWithUV(d8, d10, d12, d3, d5);
    }

    public void func_1238_a(BlockBridge block, float f) {
        int i = block.bridge$getRenderType();
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        if (i == 0) {
            block.bridge$setBlockBoundsForItemRender();
            GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
            float f1 = 0.5F;
            float f2 = 1.0F;
            float f3 = 0.8F;
            float f4 = 0.6F;
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setColorRGBA_F(f2, f2, f2, f);
            this.renderBottomFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(0));
            tessellator.bridge$setColorRGBA_F(f1, f1, f1, f);
            this.renderTopFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(1));
            tessellator.bridge$setColorRGBA_F(f3, f3, f3, f);
            this.renderEastFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(2));
            this.renderWestFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(3));
            tessellator.bridge$setColorRGBA_F(f4, f4, f4, f);
            this.renderNorthFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(4));
            this.renderSouthFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(5));
            tessellator.bridge$draw();
            GL11.glTranslatef(0.5F, 0.5F, 0.5F);
        }

    }

    public void a(BlockBridge block, int i) {
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        int j = block.bridge$getRenderType();
        if (j == 0) {
            block.bridge$setBlockBoundsForItemRender();
            GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(0.0F, -1.0F, 0.0F);
            this.renderBottomFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSideAndMetadata(0, i));
            tessellator.bridge$draw();
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(0.0F, 1.0F, 0.0F);
            this.renderTopFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSideAndMetadata(1, i));
            tessellator.bridge$draw();
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(0.0F, 0.0F, -1.0F);
            this.renderEastFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSideAndMetadata(2, i));
            tessellator.bridge$draw();
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(0.0F, 0.0F, 1.0F);
            this.renderWestFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSideAndMetadata(3, i));
            tessellator.bridge$draw();
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(-1.0F, 0.0F, 0.0F);
            this.renderNorthFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSideAndMetadata(4, i));
            tessellator.bridge$draw();
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(1.0F, 0.0F, 0.0F);
            this.renderSouthFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSideAndMetadata(5, i));
            tessellator.bridge$draw();
            GL11.glTranslatef(0.5F, 0.5F, 0.5F);
        } else if (j == 1) {
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(0.0F, -1.0F, 0.0F);
            this.func_1239_a(block, i, -0.5D, -0.5D, -0.5D);
            tessellator.bridge$draw();
        } else if (j == 13) {
            block.bridge$setBlockBoundsForItemRender();
            GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
            float l = 1.0F / 16.0F;
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(0.0F, -1.0F, 0.0F);
            this.renderBottomFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(0));
            tessellator.bridge$draw();
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(0.0F, 1.0F, 0.0F);
            this.renderTopFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(1));
            tessellator.bridge$draw();
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(0.0F, 0.0F, -1.0F);
            tessellator.bridge$setTranslationF(0.0F, 0.0F, l);
            this.renderEastFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(2));
            tessellator.bridge$setTranslationF(0.0F, 0.0F, -l);
            tessellator.bridge$draw();
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(0.0F, 0.0F, 1.0F);
            tessellator.bridge$setTranslationF(0.0F, 0.0F, -l);
            this.renderWestFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(3));
            tessellator.bridge$setTranslationF(0.0F, 0.0F, l);
            tessellator.bridge$draw();
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(-1.0F, 0.0F, 0.0F);
            tessellator.bridge$setTranslationF(l, 0.0F, 0.0F);
            this.renderNorthFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(4));
            tessellator.bridge$setTranslationF(-l, 0.0F, 0.0F);
            tessellator.bridge$draw();
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(1.0F, 0.0F, 0.0F);
            tessellator.bridge$setTranslationF(-l, 0.0F, 0.0F);
            this.renderSouthFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(5));
            tessellator.bridge$setTranslationF(l, 0.0F, 0.0F);
            tessellator.bridge$draw();
            GL11.glTranslatef(0.5F, 0.5F, 0.5F);
        } else if (j == 6) {
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(0.0F, -1.0F, 0.0F);
            this.func_1245_b(block, i, -0.5D, -0.5D, -0.5D);
            tessellator.bridge$draw();
        } else if (j == 2) {
            tessellator.bridge$startDrawingQuads();
            tessellator.bridge$setNormal(0.0F, -1.0F, 0.0F);
            this.renderTorchAtAngle(block, -0.5D, -0.5D, -0.5D, 0.0D, 0.0D);
            tessellator.bridge$draw();
        } else {
            int var7;
            if (j == 10) {
                for (var7 = 0; var7 < 2; ++var7) {
                    if (var7 == 0) {
                        block.bridge$setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.5F);
                    }

                    if (var7 == 1) {
                        block.bridge$setBlockBounds(0.0F, 0.0F, 0.5F, 1.0F, 0.5F, 1.0F);
                    }

                    GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
                    tessellator.bridge$startDrawingQuads();
                    tessellator.bridge$setNormal(0.0F, -1.0F, 0.0F);
                    this.renderBottomFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(0));
                    tessellator.bridge$draw();
                    tessellator.bridge$startDrawingQuads();
                    tessellator.bridge$setNormal(0.0F, 1.0F, 0.0F);
                    this.renderTopFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(1));
                    tessellator.bridge$draw();
                    tessellator.bridge$startDrawingQuads();
                    tessellator.bridge$setNormal(0.0F, 0.0F, -1.0F);
                    this.renderEastFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(2));
                    tessellator.bridge$draw();
                    tessellator.bridge$startDrawingQuads();
                    tessellator.bridge$setNormal(0.0F, 0.0F, 1.0F);
                    this.renderWestFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(3));
                    tessellator.bridge$draw();
                    tessellator.bridge$startDrawingQuads();
                    tessellator.bridge$setNormal(-1.0F, 0.0F, 0.0F);
                    this.renderNorthFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(4));
                    tessellator.bridge$draw();
                    tessellator.bridge$startDrawingQuads();
                    tessellator.bridge$setNormal(1.0F, 0.0F, 0.0F);
                    this.renderSouthFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(5));
                    tessellator.bridge$draw();
                    GL11.glTranslatef(0.5F, 0.5F, 0.5F);
                }
            } else if (j == 11) {
                for (var7 = 0; var7 < 4; ++var7) {
                    float f1 = 2.0F / 16.0F;
                    if (var7 == 0) {
                        block.bridge$setBlockBounds(0.5F - f1, 0.0F, 0.0F, 0.5F + f1, 1.0F, f1 * 2.0F);
                    }

                    if (var7 == 1) {
                        block.bridge$setBlockBounds(0.5F - f1, 0.0F, 1.0F - f1 * 2.0F, 0.5F + f1, 1.0F, 1.0F);
                    }

                    f1 = 1.0F / 16.0F;
                    if (var7 == 2) {
                        block.bridge$setBlockBounds(0.5F - f1, 1.0F - f1 * 3.0F, -f1 * 2.0F, 0.5F + f1, 1.0F - f1, 1.0F + f1 * 2.0F);
                    }

                    if (var7 == 3) {
                        block.bridge$setBlockBounds(0.5F - f1, 0.5F - f1 * 3.0F, -f1 * 2.0F, 0.5F + f1, 0.5F - f1, 1.0F + f1 * 2.0F);
                    }

                    GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
                    tessellator.bridge$startDrawingQuads();
                    tessellator.bridge$setNormal(0.0F, -1.0F, 0.0F);
                    this.renderBottomFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(0));
                    tessellator.bridge$draw();
                    tessellator.bridge$startDrawingQuads();
                    tessellator.bridge$setNormal(0.0F, 1.0F, 0.0F);
                    this.renderTopFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(1));
                    tessellator.bridge$draw();
                    tessellator.bridge$startDrawingQuads();
                    tessellator.bridge$setNormal(0.0F, 0.0F, -1.0F);
                    this.renderEastFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(2));
                    tessellator.bridge$draw();
                    tessellator.bridge$startDrawingQuads();
                    tessellator.bridge$setNormal(0.0F, 0.0F, 1.0F);
                    this.renderWestFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(3));
                    tessellator.bridge$draw();
                    tessellator.bridge$startDrawingQuads();
                    tessellator.bridge$setNormal(-1.0F, 0.0F, 0.0F);
                    this.renderNorthFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(4));
                    tessellator.bridge$draw();
                    tessellator.bridge$startDrawingQuads();
                    tessellator.bridge$setNormal(1.0F, 0.0F, 0.0F);
                    this.renderSouthFace(block, 0.0D, 0.0D, 0.0D, block.bridge$getBlockTextureFromSide(5));
                    tessellator.bridge$draw();
                    GL11.glTranslatef(0.5F, 0.5F, 0.5F);
                }

                block.bridge$setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
            }
        }

    }

    public static boolean func_1219_a(int i) {
        return i == 0 ? true : (i == 13 ? true : (i == 10 ? true : i == 11));
    }

    public boolean renderStandardBlockWithAmbientOcclusion(BlockBridge block, int i, int j, int k, float f, float f1, float f2) {
        this.field_21035_blen = true;
        TessellatorBridge tessellator = BridgeRef.getTessellator();
        boolean flag = false;
        float f3 = this.field_21010_ll000;
        float f10 = this.field_21010_ll000;
        float f17 = this.field_21010_ll000;
        float f24 = this.field_21010_ll000;
        boolean flag1 = true;
        boolean flag2 = true;
        boolean flag3 = true;
        boolean flag4 = true;
        boolean flag5 = true;
        boolean flag6 = true;
        if (block.bridge$getBlockID() == 2) {
            flag6 = false;
            flag5 = flag6;
            flag4 = flag6;
            flag3 = flag6;
            flag1 = flag6;
        }

        this.field_21010_ll000 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
        this.field_21039_d00 = block.bridge$getBlockBrightness(this.blockAccess, i - 1, j, k);
        this.field_21017_ll0y0 = block.bridge$getBlockBrightness(this.blockAccess, i, j - 1, k);
        this.field_21020_aV00z = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
        this.field_21024_llX00 = block.bridge$getBlockBrightness(this.blockAccess, i + 1, j, k);
        this.field_21037_a0Y0 = block.bridge$getBlockBrightness(this.blockAccess, i, j + 1, k);
        this.field_21034_ll00Z = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
        float f9;
        float f16;
        float f23;
        float f30;
        if (this.renderAllFaces || block.bridge$shouldSideBeRendered(this.blockAccess, i, j - 1, k, 0)) {
            if (this.field_21015_blsmooth > 0) {
                --j;
                --i;
                this.field_21011_llxyz = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
                this.field_21046_c0 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
                this.field_21025_llxyZ = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
                ++i;
                this.field_21026_bg0yz = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
                this.field_21040_c0yZ = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
                ++i;
                this.field_21042_a = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
                this.field_21033_llXy0 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
                this.field_21013_llXyZ = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
                --i;
                ++j;
                f9 = (this.field_21025_llxyZ + this.field_21046_c0 + this.field_21040_c0yZ + this.field_21017_ll0y0) / 4.0F;
                f30 = (this.field_21040_c0yZ + this.field_21017_ll0y0 + this.field_21013_llXyZ + this.field_21033_llXy0) / 4.0F;
                f23 = (this.field_21017_ll0y0 + this.field_21026_bg0yz + this.field_21033_llXy0 + this.field_21042_a) / 4.0F;
                f16 = (this.field_21046_c0 + this.field_21011_llxyz + this.field_21017_ll0y0 + this.field_21026_bg0yz) / 4.0F;
            } else {
                f30 = this.field_21017_ll0y0;
                f23 = f30;
                f16 = f30;
                f9 = f30;
            }

            this.hasSubtypes1r = this.field_21004_c2r = this.field_21034_c3r = this.sugar4r = (flag1 ? f : 1.0F) * 0.5F;
            this.dyeColors1g = this.field_21008_c2g = this.xLocation3g = this.field_21024_c4g = (flag1 ? f1 : 1.0F) * 0.5F;
            this.field_21025_c1b = this.field_21010_c2b = this.instrumentType3b = this.cake4b = (flag1 ? f2 : 1.0F) * 0.5F;
            this.hasSubtypes1r *= f9;
            this.dyeColors1g *= f9;
            this.field_21025_c1b *= f9;
            this.field_21004_c2r *= f16;
            this.field_21008_c2g *= f16;
            this.field_21010_c2b *= f16;
            this.field_21034_c3r *= f23;
            this.xLocation3g *= f23;
            this.instrumentType3b *= f23;
            this.sugar4r *= f30;
            this.field_21024_c4g *= f30;
            this.cake4b *= f30;
            this.renderBottomFace(block, (double) i, (double) j, (double) k, block.bridge$getBlockTexture(this.blockAccess, i, j, k, 0));
            flag = true;
        }

        if (this.renderAllFaces || block.bridge$shouldSideBeRendered(this.blockAccess, i, j + 1, k, 1)) {
            if (this.field_21015_blsmooth > 0) {
                ++j;
                --i;
                this.field_21031_b = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
                this.field_21021_aU0 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
                this.field_21044_e = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
                ++i;
                this.field_21045_d0Yz = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
                this.field_21016_ll0YZ = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
                ++i;
                this.field_21018_bf = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
                this.field_21009_llXY0 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
                this.field_21032_llXYZ = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
                --i;
                --j;
                f30 = (this.field_21044_e + this.field_21021_aU0 + this.field_21016_ll0YZ + this.field_21037_a0Y0) / 4.0F;
                f9 = (this.field_21016_ll0YZ + this.field_21037_a0Y0 + this.field_21032_llXYZ + this.field_21009_llXY0) / 4.0F;
                f16 = (this.field_21037_a0Y0 + this.field_21045_d0Yz + this.field_21009_llXY0 + this.field_21018_bf) / 4.0F;
                f23 = (this.field_21021_aU0 + this.field_21031_b + this.field_21037_a0Y0 + this.field_21045_d0Yz) / 4.0F;
            } else {
                f30 = this.field_21037_a0Y0;
                f23 = f30;
                f16 = f30;
                f9 = f30;
            }

            this.hasSubtypes1r = this.field_21004_c2r = this.field_21034_c3r = this.sugar4r = flag2 ? f : 1.0F;
            this.dyeColors1g = this.field_21008_c2g = this.xLocation3g = this.field_21024_c4g = flag2 ? f1 : 1.0F;
            this.field_21025_c1b = this.field_21010_c2b = this.instrumentType3b = this.cake4b = flag2 ? f2 : 1.0F;
            this.hasSubtypes1r *= f9;
            this.dyeColors1g *= f9;
            this.field_21025_c1b *= f9;
            this.field_21004_c2r *= f16;
            this.field_21008_c2g *= f16;
            this.field_21010_c2b *= f16;
            this.field_21034_c3r *= f23;
            this.xLocation3g *= f23;
            this.instrumentType3b *= f23;
            this.sugar4r *= f30;
            this.field_21024_c4g *= f30;
            this.cake4b *= f30;
            this.renderTopFace(block, (double) i, (double) j, (double) k, block.bridge$getBlockTexture(this.blockAccess, i, j, k, 1));
            flag = true;
        }

        int k1;
        if (this.renderAllFaces || block.bridge$shouldSideBeRendered(this.blockAccess, i, j, k - 1, 2)) {
            if (this.field_21015_blsmooth > 0) {
                --k;
                --i;
                this.field_21011_llxyz = block.bridge$getBlockBrightness(this.blockAccess, i, j - 1, k);
                this.field_21047_llx0z = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
                this.field_21031_b = block.bridge$getBlockBrightness(this.blockAccess, i, j + 1, k);
                ++i;
                this.field_21026_bg0yz = block.bridge$getBlockBrightness(this.blockAccess, i, j - 1, k);
                this.field_21045_d0Yz = block.bridge$getBlockBrightness(this.blockAccess, i, j + 1, k);
                ++i;
                this.field_21042_a = block.bridge$getBlockBrightness(this.blockAccess, i, j - 1, k);
                this.field_21036_b0z = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
                this.field_21018_bf = block.bridge$getBlockBrightness(this.blockAccess, i, j + 1, k);
                --i;
                ++k;
                f9 = (this.field_21047_llx0z + this.field_21031_b + this.field_21020_aV00z + this.field_21045_d0Yz) / 4.0F;
                f16 = (this.field_21020_aV00z + this.field_21045_d0Yz + this.field_21036_b0z + this.field_21018_bf) / 4.0F;
                f23 = (this.field_21026_bg0yz + this.field_21020_aV00z + this.field_21042_a + this.field_21036_b0z) / 4.0F;
                f30 = (this.field_21011_llxyz + this.field_21047_llx0z + this.field_21026_bg0yz + this.field_21020_aV00z) / 4.0F;
            } else {
                f30 = this.field_21020_aV00z;
                f23 = f30;
                f16 = f30;
                f9 = f30;
            }

            this.hasSubtypes1r = this.field_21004_c2r = this.field_21034_c3r = this.sugar4r = (flag3 ? f : 1.0F) * 0.8F;
            this.dyeColors1g = this.field_21008_c2g = this.xLocation3g = this.field_21024_c4g = (flag3 ? f1 : 1.0F) * 0.8F;
            this.field_21025_c1b = this.field_21010_c2b = this.instrumentType3b = this.cake4b = (flag3 ? f2 : 1.0F) * 0.8F;
            this.hasSubtypes1r *= f9;
            this.dyeColors1g *= f9;
            this.field_21025_c1b *= f9;
            this.field_21004_c2r *= f16;
            this.field_21008_c2g *= f16;
            this.field_21010_c2b *= f16;
            this.field_21034_c3r *= f23;
            this.xLocation3g *= f23;
            this.instrumentType3b *= f23;
            this.sugar4r *= f30;
            this.field_21024_c4g *= f30;
            this.cake4b *= f30;

            k1 = block.bridge$getBlockTexture(this.blockAccess, i, j, k, 2);
            this.renderEastFace(block, i, j, k, k1);
            if (WORLD_EDITOR_MOD.getFancyGrass().value() && k1 == 3 && this.overrideBlockTexture < 0) {
                this.hasSubtypes1r *= f;
                this.field_21004_c2r *= f;
                this.field_21034_c3r *= f;
                this.sugar4r *= f;
                this.dyeColors1g *= f1;
                this.field_21008_c2g *= f1;
                this.xLocation3g *= f1;
                this.field_21024_c4g *= f1;
                this.field_21025_c1b *= f2;
                this.field_21010_c2b *= f2;
                this.instrumentType3b *= f2;
                this.cake4b *= f2;
                this.renderEastFace(block, i, j, k, 38);
            }

            flag = true;
        }

        if (this.renderAllFaces || block.bridge$shouldSideBeRendered(this.blockAccess, i, j, k + 1, 3)) {
            if (this.field_21015_blsmooth > 0) {
                ++k;
                --i;
                this.field_21025_llxyZ = block.bridge$getBlockBrightness(this.blockAccess, i, j - 1, k);
                this.field_21019_aW0Z = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
                this.field_21044_e = block.bridge$getBlockBrightness(this.blockAccess, i, j + 1, k);
                ++i;
                this.field_21040_c0yZ = block.bridge$getBlockBrightness(this.blockAccess, i, j - 1, k);
                this.field_21016_ll0YZ = block.bridge$getBlockBrightness(this.blockAccess, i, j + 1, k);
                ++i;
                this.field_21013_llXyZ = block.bridge$getBlockBrightness(this.blockAccess, i, j - 1, k);
                this.field_21048_b0Z = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
                this.field_21032_llXYZ = block.bridge$getBlockBrightness(this.blockAccess, i, j + 1, k);
                --i;
                --k;
                f9 = (this.field_21019_aW0Z + this.field_21044_e + this.field_21034_ll00Z + this.field_21016_ll0YZ) / 4.0F;
                f30 = (this.field_21034_ll00Z + this.field_21016_ll0YZ + this.field_21048_b0Z + this.field_21032_llXYZ) / 4.0F;
                f23 = (this.field_21040_c0yZ + this.field_21034_ll00Z + this.field_21013_llXyZ + this.field_21048_b0Z) / 4.0F;
                f16 = (this.field_21025_llxyZ + this.field_21019_aW0Z + this.field_21040_c0yZ + this.field_21034_ll00Z) / 4.0F;
            } else {
                f30 = this.field_21034_ll00Z;
                f23 = f30;
                f16 = f30;
                f9 = f30;
            }

            this.hasSubtypes1r = this.field_21004_c2r = this.field_21034_c3r = this.sugar4r = (flag4 ? f : 1.0F) * 0.8F;
            this.dyeColors1g = this.field_21008_c2g = this.xLocation3g = this.field_21024_c4g = (flag4 ? f1 : 1.0F) * 0.8F;
            this.field_21025_c1b = this.field_21010_c2b = this.instrumentType3b = this.cake4b = (flag4 ? f2 : 1.0F) * 0.8F;
            this.hasSubtypes1r *= f9;
            this.dyeColors1g *= f9;
            this.field_21025_c1b *= f9;
            this.field_21004_c2r *= f16;
            this.field_21008_c2g *= f16;
            this.field_21010_c2b *= f16;
            this.field_21034_c3r *= f23;
            this.xLocation3g *= f23;
            this.instrumentType3b *= f23;
            this.sugar4r *= f30;
            this.field_21024_c4g *= f30;
            this.cake4b *= f30;

            k1 = block.bridge$getBlockTexture(this.blockAccess, i, j, k, 3);
            this.renderWestFace(block, (double) i, (double) j, (double) k, k1);
            if (WORLD_EDITOR_MOD.getFancyGrass().value() && k1 == 3 && this.overrideBlockTexture < 0) {
                this.hasSubtypes1r *= f;
                this.field_21004_c2r *= f;
                this.field_21034_c3r *= f;
                this.sugar4r *= f;
                this.dyeColors1g *= f1;
                this.field_21008_c2g *= f1;
                this.xLocation3g *= f1;
                this.field_21024_c4g *= f1;
                this.field_21025_c1b *= f2;
                this.field_21010_c2b *= f2;
                this.instrumentType3b *= f2;
                this.cake4b *= f2;
                this.renderWestFace(block, (double) i, (double) j, (double) k, 38);
            }

            flag = true;
        }

        if (this.renderAllFaces || block.bridge$shouldSideBeRendered(this.blockAccess, i - 1, j, k, 4)) {
            if (this.field_21015_blsmooth > 0) {
                --i;
                --j;
                this.field_21011_llxyz = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
                this.field_21046_c0 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
                this.field_21025_llxyZ = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
                ++j;
                this.field_21047_llx0z = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
                this.field_21019_aW0Z = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
                ++j;
                this.field_21031_b = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
                this.field_21021_aU0 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
                this.field_21044_e = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
                --j;
                ++i;
                f30 = (this.field_21046_c0 + this.field_21025_llxyZ + this.field_21039_d00 + this.field_21019_aW0Z) / 4.0F;
                f9 = (this.field_21039_d00 + this.field_21019_aW0Z + this.field_21021_aU0 + this.field_21044_e) / 4.0F;
                f16 = (this.field_21047_llx0z + this.field_21039_d00 + this.field_21031_b + this.field_21021_aU0) / 4.0F;
                f23 = (this.field_21011_llxyz + this.field_21046_c0 + this.field_21047_llx0z + this.field_21039_d00) / 4.0F;
            } else {
                f30 = this.field_21039_d00;
                f23 = f30;
                f16 = f30;
                f9 = f30;
            }

            this.hasSubtypes1r = this.field_21004_c2r = this.field_21034_c3r = this.sugar4r = (flag5 ? f : 1.0F) * 0.6F;
            this.dyeColors1g = this.field_21008_c2g = this.xLocation3g = this.field_21024_c4g = (flag5 ? f1 : 1.0F) * 0.6F;
            this.field_21025_c1b = this.field_21010_c2b = this.instrumentType3b = this.cake4b = (flag5 ? f2 : 1.0F) * 0.6F;
            this.hasSubtypes1r *= f9;
            this.dyeColors1g *= f9;
            this.field_21025_c1b *= f9;
            this.field_21004_c2r *= f16;
            this.field_21008_c2g *= f16;
            this.field_21010_c2b *= f16;
            this.field_21034_c3r *= f23;
            this.xLocation3g *= f23;
            this.instrumentType3b *= f23;
            this.sugar4r *= f30;
            this.field_21024_c4g *= f30;
            this.cake4b *= f30;

            k1 = block.bridge$getBlockTexture(this.blockAccess, i, j, k, 4);
            this.renderNorthFace(block, (double) i, (double) j, (double) k, k1);
            if (WORLD_EDITOR_MOD.getFancyGrass().value() && k1 == 3 && this.overrideBlockTexture < 0) {
                this.hasSubtypes1r *= f;
                this.field_21004_c2r *= f;
                this.field_21034_c3r *= f;
                this.sugar4r *= f;
                this.dyeColors1g *= f1;
                this.field_21008_c2g *= f1;
                this.xLocation3g *= f1;
                this.field_21024_c4g *= f1;
                this.field_21025_c1b *= f2;
                this.field_21010_c2b *= f2;
                this.instrumentType3b *= f2;
                this.cake4b *= f2;
                this.renderNorthFace(block, (double) i, (double) j, (double) k, 38);
            }

            flag = true;
        }

        if (this.renderAllFaces || block.bridge$shouldSideBeRendered(this.blockAccess, i + 1, j, k, 5)) {
            if (this.field_21015_blsmooth > 0) {
                ++i;
                --j;
                this.field_21042_a = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
                this.field_21033_llXy0 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
                this.field_21013_llXyZ = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
                ++j;
                this.field_21036_b0z = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
                this.field_21048_b0Z = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
                ++j;
                this.field_21018_bf = block.bridge$getBlockBrightness(this.blockAccess, i, j, k - 1);
                this.field_21009_llXY0 = block.bridge$getBlockBrightness(this.blockAccess, i, j, k);
                this.field_21032_llXYZ = block.bridge$getBlockBrightness(this.blockAccess, i, j, k + 1);
                --j;
                --i;
                f9 = (this.field_21033_llXy0 + this.field_21013_llXyZ + this.field_21024_llX00 + this.field_21048_b0Z) / 4.0F;
                f30 = (this.field_21024_llX00 + this.field_21048_b0Z + this.field_21009_llXY0 + this.field_21032_llXYZ) / 4.0F;
                f23 = (this.field_21036_b0z + this.field_21024_llX00 + this.field_21018_bf + this.field_21009_llXY0) / 4.0F;
                f16 = (this.field_21042_a + this.field_21033_llXy0 + this.field_21036_b0z + this.field_21024_llX00) / 4.0F;
            } else {
                f30 = this.field_21024_llX00;
                f23 = f30;
                f16 = f30;
                f9 = f30;
            }

            this.hasSubtypes1r = this.field_21004_c2r = this.field_21034_c3r = this.sugar4r = (flag6 ? f : 1.0F) * 0.6F;
            this.dyeColors1g = this.field_21008_c2g = this.xLocation3g = this.field_21024_c4g = (flag6 ? f1 : 1.0F) * 0.6F;
            this.field_21025_c1b = this.field_21010_c2b = this.instrumentType3b = this.cake4b = (flag6 ? f2 : 1.0F) * 0.6F;
            this.hasSubtypes1r *= f9;
            this.dyeColors1g *= f9;
            this.field_21025_c1b *= f9;
            this.field_21004_c2r *= f16;
            this.field_21008_c2g *= f16;
            this.field_21010_c2b *= f16;
            this.field_21034_c3r *= f23;
            this.xLocation3g *= f23;
            this.instrumentType3b *= f23;
            this.sugar4r *= f30;
            this.field_21024_c4g *= f30;
            this.cake4b *= f30;

            k1 = block.bridge$getBlockTexture(this.blockAccess, i, j, k, 5);
            this.renderSouthFace(block, (double) i, (double) j, (double) k, k1);
            if (WORLD_EDITOR_MOD.getFancyGrass().value() && k1 == 3 && this.overrideBlockTexture < 0) {
                this.hasSubtypes1r *= f;
                this.field_21004_c2r *= f;
                this.field_21034_c3r *= f;
                this.sugar4r *= f;
                this.dyeColors1g *= f1;
                this.field_21008_c2g *= f1;
                this.xLocation3g *= f1;
                this.field_21024_c4g *= f1;
                this.field_21025_c1b *= f2;
                this.field_21010_c2b *= f2;
                this.instrumentType3b *= f2;
                this.cake4b *= f2;
                this.renderSouthFace(block, (double) i, (double) j, (double) k, 38);
            }

            flag = true;
        }

        this.field_21035_blen = false;
        return flag;
    }

}
