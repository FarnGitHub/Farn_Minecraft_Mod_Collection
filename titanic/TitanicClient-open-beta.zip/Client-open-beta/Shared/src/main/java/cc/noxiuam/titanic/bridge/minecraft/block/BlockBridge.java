package cc.noxiuam.titanic.bridge.minecraft.block;

import cc.noxiuam.titanic.bridge.minecraft.block.impl.BlockFireBridge;
import cc.noxiuam.titanic.bridge.minecraft.block.impl.BlockGrassBridge;
import cc.noxiuam.titanic.bridge.minecraft.block.impl.BlockPortalBridge;
import cc.noxiuam.titanic.bridge.minecraft.block.impl.BlockRedstoneWireBridge;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface BlockBridge {

    int bridge$getBlockIndexInTexture();

    double bridge$getMinX();
    double bridge$getMinY();
    double bridge$getMinZ();
    double bridge$getMaxX();
    double bridge$getMaxY();
    double bridge$getMaxZ();

    void bridge$setMinX(double minX);
    void bridge$setMinY(double minY);
    void bridge$setMinZ(double minZ);
    void bridge$setMaxX(double maxX);
    void bridge$setMaxY(double maxY);
    void bridge$setMaxZ(double maxZ);

    int bridge$getRenderType();

    void bridge$setBlockBoundsBasedOnState(BlockAccessBridge blockAccessBridge, int blockX, int blockY, int blockZ);

    int bridge$colorMultiplier(BlockAccessBridge blockAccessBridge, int x, int y, int z);

    float bridge$getBlockBrightness(BlockAccessBridge blockAccessBridge, int x, int y, int z);

    int[] bridge$getLightValues();

    int bridge$getBlockID();

    int bridge$getBlockTextureFromSide(int side);

    boolean bridge$shouldSideBeRendered(BlockAccessBridge blockAccessBridge, int x, int y, int z, int side);

    int bridge$getBlockTextureFromSideAndMetadata(int side, int metadata);

    int bridge$getBlockTexture(BlockAccessBridge blockAccessBridge, int x, int y, int z, int side);

    void bridge$setBlockBoundsForItemRender();

    void bridge$setBlockBounds(float minX, float minY, float minZ, float maxX, float maxY, float maxZ);

    MaterialBridge bridge$getMaterial();
    BlockFluidsBridge bridge$getBlockFluids();

    BlockFireBridge bridge$getFire();
    BlockPortalBridge bridge$getPortal();
    BlockGrassBridge bridge$getGrass();
    BlockRedstoneWireBridge bridge$getRedstoneWire();
    BlockBridge bridge$getCobblestone();

}
