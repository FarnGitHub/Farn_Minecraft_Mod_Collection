package cc.noxiuam.titanic.client.registry;

import com.google.gson.JsonObject;

public abstract class AbstractLoadable {

    /**
     * Save information.
     * <p>
     * @param obj - The obj to add to.
     */
    public abstract void save(JsonObject obj);

    /**
     * Load information.
     * <p>
     * @param obj - The obj to pull from.
     */
    public abstract void load(JsonObject obj);

    /**
     * This should only be serialized data.
     */
    public abstract JsonObject getSerialized();

}
