package cc.noxiuam.titanic.bridge.minecraft.item;

import cc.noxiuam.titanic.bridge.minecraft.client.inventory.ItemBridge;

public interface ItemStackBridge {

    int bridge$getDamage();
    int bridge$getItemID();
    int bridge$getMaxStackSize();
    int bridge$getStackSize();

    ItemBridge bridge$getItem();

}
