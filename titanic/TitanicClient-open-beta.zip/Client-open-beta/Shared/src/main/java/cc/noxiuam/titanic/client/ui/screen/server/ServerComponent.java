package cc.noxiuam.titanic.client.ui.screen.server;

import cc.noxiuam.titanic.client.registry.FeaturedServer;
import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.client.util.RenderEngineUtil;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Noxiuam
 * https://noxiuam.cc
 */
@Getter
@RequiredArgsConstructor
public class ServerComponent extends AbstractComponent {

    private final FeaturedServer server;

    public boolean selected;

    @Override
    public void draw(float mouseX, float mouseY) {
        if (this.selected) {
            RenderUtil.drawRect(
                    this.x - 1,
                    this.y - 1,
                    this.x + this.width + 1,
                    this.y + this.height + 1,
                    -1601138544
            );

            RenderUtil.drawRect(
                    this.x,
                    this.y,
                    this.x + this.width,
                    this.y + this.height,
                    Color.BLACK.getRGB()
            );
        }

        this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(
                this.server.getFormattedName(),
                (int) (this.x + 35),
                (int) (this.y + 3),
                -1
        );

        this.drawServerIcon();
        this.drawMOTD();
    }

    private void drawServerIcon() {
        int texture = RenderEngineUtil.getTextureInt(this.server.getIconUrl(), "/titanic/icons/steve.png");

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        if (texture >= 0) {
            RenderUtil.drawIconFromInt(
                    texture,
                    (int) this.x + 2,
                    (int) this.y + 2,
                    31,
                    31
            );
        }
    }

    private void drawMOTD() {
        List<String> motdLines = this.getMOTDStrings(
                this.server.getMotd()
        );

        int height = 0;
        for (String motdLine : motdLines) {
            this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(
                    motdLine,
                    (int) (this.x + 35),
                    (int) (this.y + 15 + height),
                    -1
            );
            height += 10;
        }
    }

    private List<String> getMOTDStrings(String motd) {
        List<String> newLines = new ArrayList<>();
        int maxLength = 44;

        for (int i = 0; i < motd.length(); i+= maxLength) {
            newLines.add(motd.substring(i, Math.min(motd.length(), i + maxLength)));
        }

        return newLines;
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        if (!this.selected
                && this.mouseInside(mouseX, mouseY)) {
            this.selected = true;
        }
    }

}
