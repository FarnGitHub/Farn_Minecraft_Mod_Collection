package cc.noxiuam.titanic.client.util;

import cc.noxiuam.titanic.bridge.Bridge;
import lombok.experimental.UtilityClass;

@UtilityClass
public class SoundUtil {

    public void playClick() {
        Bridge.getInstance()
                .bridge$getMinecraft()
                .bridge$getSoundManager()
                .bridge$playSound(
                        "random.click", 1.0F, 1.0F
                );
    }

}
