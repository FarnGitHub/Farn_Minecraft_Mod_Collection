package cc.noxiuam.titanic.client.module.impl.hud.impl;

import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.client.module.impl.hud.AbstractMovableModule;

import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.event.impl.gui.GuiDrawEvent;
import cc.noxiuam.titanic.event.impl.mouse.ClickEvent;
import cc.noxiuam.titanic.event.impl.world.TickEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

public class CPSModule extends AbstractMovableModule {

    private final List<Long> leftClicks = new ArrayList<>();
    private final List<Long> rightClicks = new ArrayList<>();

    private final BooleanSetting showBackground, showRightClicks;

    public CPSModule() {
        super("cps", "CPS", "Shows the amount of clicks per second you're getting.", false);

        this.addSettings(
                this.textColor(),
                this.showBackground = new BooleanSetting("showBackground", "Show Background", true),
                this.showRightClicks = new BooleanSetting("showRightClicks", "Show Right Clicks", false)
        );

        this.showRightClicks.description("Shows how many right clicks a second you are getting.");

        this.addEvent(GuiDrawEvent.class, this::draw);
        this.addEvent(ClickEvent.class, this::onClick);
        this.addEvent(TickEvent.class, this::tick);
    }

    private void draw(GuiDrawEvent event) {
        GL11.glPushMatrix();

        String cps = this.leftClicks.size() + (this.showRightClicks.value() ? " | " + this.rightClicks.size() : "") + " CPS";
        String text = this.getPrefixedTextColor() + cps;

        if (!this.showBackground.value()) {
            text = this.getPrefixedTextColor() + "[" + text + "]";
        }

        if (this.showBackground.value()) {
            this.setSize(56, 18);
            RenderUtil.drawRect(
                    this.x(),
                    this.y(),
                    this.x() + this.width(),
                    this.y() + this.height(),
                    0x6F000000
            );
        } else {
            this.setSize(this.mc.bridge$getFontRenderer().bridge$getStringWidth(text) + 5, 13);
        }

        this.resizeToScale();

        this.mc.bridge$getFontRenderer().bridge$drawCenteredString(
                text,
                (int) (this.x() + this.width() / 2F) + 1,
                (int) this.y() + (this.showBackground.value() ? 6 : 3),
                -1,
                true
        );

        GL11.glPopMatrix();
    }

    private void onClick(ClickEvent event) {
        if (event.getMouseButton() == 0) {
            this.leftClicks.add(System.currentTimeMillis());
        }
        if (event.getMouseButton() == 1) {
            this.rightClicks.add(System.currentTimeMillis());
        }
    }

    private void tick(TickEvent event) {
        this.leftClicks.removeIf(l -> l < System.currentTimeMillis() - 1000L);
        this.rightClicks.removeIf(l -> l < System.currentTimeMillis() - 1000L);
    }

}
