package cc.noxiuam.titanic.bridge.minecraft.client;

import cc.noxiuam.titanic.bridge.minecraft.block.BlockAccessBridge;
import cc.noxiuam.titanic.bridge.minecraft.entity.EntityPlayerBridge;

import java.util.List;
import java.util.Random;

public interface WorldBridge extends BlockAccessBridge {

    Random bridge$Random = new Random();

    List<EntityPlayerBridge> bridge$getPlayerEntities();

    void bridge$playSoundEffect(double var1, double var3, double var5, String var7, float var8, float var9);

    void bridge$spawnParticle(String var1, double var2, double var4, double var6, double var8, double var10, double var12);

    void bridge$setWorldTime(long newTime);

    void bridge$sendQuittingDisconnectingPacket();

}
