package cc.noxiuam.titanic.bridge;

import cc.noxiuam.titanic.bridge.minecraft.block.MaterialBridge;
import cc.noxiuam.titanic.bridge.minecraft.block.BlockBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.GameSettingsBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.MinecraftBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.WorldBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiButtonBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiChatBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.chat.FontAllowedCharactersBridge;
import cc.noxiuam.titanic.bridge.minecraft.renderer.TessellatorBridge;
import cc.noxiuam.titanic.bridge.minecraft.util.ImageBufferDownloadBridge;
import cc.noxiuam.titanic.bridge.minecraft.util.ScreenShotHelperBridge;

public interface IBridge {

    MinecraftBridge bridge$getMinecraft();
    GameSettingsBridge bridge$getGameSettings();
    WorldBridge bridge$getTheWorld();
    TessellatorBridge bridge$createTessellator();
    FontAllowedCharactersBridge bridge$getFontAllowedChars();
    ImageBufferDownloadBridge bridge$createImageBufferDownload();
    ScreenShotHelperBridge bridge$createScreenshotHelper();
    MaterialBridge bridge$getPortalMaterial();
    BlockBridge bridge$getBlock();
    GuiScreenBridge bridge$initCustomGuiScreen(GuiScreenBridge screen);
    GuiScreenBridge bridge$getGuiMultiplayer();
    GuiScreenBridge bridge$getGuiConnecting(MinecraftBridge mc, String address, int port);

    GuiButtonBridge bridge$createNewGuiButton(int id, int x, int y, int width, int height, String text);
    GuiChatBridge bridge$createGuiChatWithDefaultText(String text);

}
