package cc.noxiuam.titanic.client.ui.component.type.setting.impl.slider;

import cc.noxiuam.titanic.bridge.minecraft.renderer.FontRendererBridge;
import cc.noxiuam.titanic.client.module.data.setting.impl.NumberSetting;
import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.ui.transition.AbstractTransition;
import cc.noxiuam.titanic.client.ui.transition.impl.ColorTransition;
import cc.noxiuam.titanic.client.ui.transition.impl.GradualTransition;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class SliderComponent extends AbstractComponent {

    private final AbstractTransition ease = new GradualTransition(500L);

    private final ColorTransition outlineColor = new ColorTransition(0x00000000, 0xCCC2C2C2);

    private Number numericalValue;
    private final NumberSetting setting;

    private boolean using = false;

    public SliderComponent(NumberSetting setting) {
        this.setting = setting;
        this.numericalValue = setting.value();
    }

    @Override
    public void draw(float mouseX, float mouseY) {

        float f3;
        float correctHeight;
        float newValue;
        float finalX;
        float nextX;
        double d = 5;

        if (!Mouse.isButtonDown(0) && this.using) {
            this.using = false;
        }

        float minValue = this.setting.getMinValue().floatValue();
        float maxValue = this.setting.getMaxValue().floatValue();

        if (this.mouseInside(mouseX, mouseY) && Mouse.isButtonDown(0) && this.using) {
            if (this.ease.isOver()) {
                this.numericalValue = this.setting.value();
                this.ease.startTransition();
            }

            nextX = mouseX - this.x;

            finalX = nextX / this.width;
            newValue = minValue + finalX * (maxValue - minValue);
            if ((double) finalX <= 0.01) {
                newValue = minValue;
            } else if ((double) finalX >= 0.99) {
                newValue = maxValue;
            }
            this.setting.convertAndSet((double) Math.round((double) newValue * 100.0) / 100.0);
        }

        finalX = this.setting.getMinValue().floatValue();
        newValue = this.setting.getMaxValue().floatValue();

        float floatValue = this.setting.value().floatValue();
        float floatValue2 = (floatValue - finalX) / (newValue - finalX);
        float cursorEasedPosition = this.width * floatValue2;

        if (this.ease.isRunning()) {
            correctHeight = (float) (this.numericalValue.doubleValue() - (double) finalX) / (newValue - finalX);
            f3 = this.width * floatValue2;
            float f13 = this.width * correctHeight;
            float f14 = f13 - f3;
            cursorEasedPosition = f13 - f14 * this.ease.getFadeAmount();
        }

        FontRendererBridge fontRenderer = this.mc.bridge$getFontRenderer();
        String string = (double) Math.round((double) this.setting.value().floatValue() * 100.0) / 100.0 + "";
        nextX = fontRenderer.bridge$getStringWidth(string);

        fontRenderer.bridge$drawStringWithShadow(
                string,
                (int) (this.x - 8.0F - nextX),
                (int) (this.y + this.height / 2.0F - (float) (17 / 2) - 2.0F) + 4,
                -1
        );

        correctHeight = this.height / 4.0F + 3;
        RenderUtil.drawRoundedRect(
                this.x,
                this.y + 1.5F,
                this.x + this.width,
                this.y + this.height / 2.0F - correctHeight / 2.0F + 3F,
                4F,
                0x80000000
        );

        RenderUtil.drawRoundedOutline(
                this.x,
                this.y + 1.5F,
                this.x + this.width,
                this.y + this.height / 2.0F - correctHeight / 2.0F + 3F,
                4F,
                3F,
                this.outlineColor.getColor(this.mouseInside(mouseX, mouseY)).getRGB()
        );

        RenderUtil.setColor(0xFF1471FF);
        RenderUtil.drawCircle(
                (double) (this.x + cursorEasedPosition) + d / (double) 100,
                this.y + 4.25F,
                4.35
        );

        GL11.glPushMatrix();
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.15F);
        GL11.glTranslatef(0, 0, 10);
        RenderUtil.drawHollowRadial(
                this.x + cursorEasedPosition,
                this.y + 4.25F,
                correctHeight - 2,
                3,
                1.0,
                1,
                1.0
        );
        GL11.glPopMatrix();
    }

    @Override
    public float getHeight() {
        return 14F;
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        if (this.mouseInside(mouseX, mouseY)) {
            this.using = true;
        }
    }

}
