package cc.noxiuam.titanic.client.ui.util;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.client.MinecraftBridge;
import cc.noxiuam.titanic.bridge.minecraft.renderer.TessellatorBridge;
import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.util.MathUtil;
import lombok.experimental.UtilityClass;
import org.lwjgl.opengl.GL11;

@UtilityClass
public class RenderUtil {

    private final MinecraftBridge MC = Bridge.getInstance().bridge$getMinecraft();

    public void drawComponentTooltip(AbstractComponent component, float mouseX, float mouseY) {
        if (component.mouseInside(mouseX, mouseY) && component.getTooltip() != null) {
            int x = 3;
            int y = BridgeRef.getCurrentScreen().bridge$getHeight() - 15;

            String tooltip = component.getTooltip();

            RenderUtil.drawRoundedRect(
                    x,
                    y - 5,
                    x + MC.bridge$getFontRenderer().bridge$getStringWidth(tooltip) + 10,
                    y + 13,
                    5,
                    0xBF000000
            );
            MC.bridge$getFontRenderer().bridge$drawStringWithShadow(
                    tooltip,
                    x + 5,
                    y,
                    -1
            );
        }
    }

    public void drawTexturedModalRect(int x, int y, int u, int v, int width, int height, float zLevel) {
        float var7 = 0.00390625F;
        float var8 = 0.00390625F;
        TessellatorBridge tessellator = Bridge.getInstance().bridge$createTessellator();
        tessellator.bridge$startDrawingQuads();
        tessellator.bridge$addVertexWithUV((x), (y + height), zLevel, ((u) * var7), ((v + height) * var8));
        tessellator.bridge$addVertexWithUV((x + width), (y + height), zLevel, ((u + width) * var7), ((v + height) * var8));
        tessellator.bridge$addVertexWithUV((x + width), (y), zLevel, ((u + width) * var7), ((v) * var8));
        tessellator.bridge$addVertexWithUV((x), (y), zLevel, ((u) * var7), ((v) * var8));
        tessellator.bridge$draw();
    }

    public void drawIcon(String resourceLocation, float size, float x, float y) {
        float f4 = size * 2.0f;
        float f5 = size * 2.0f;
        float f6 = 0.0f;
        float f7 = 0.0f;

        GL11.glEnable(3042);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, Bridge.getInstance()
                .bridge$getMinecraft()
                .bridge$getRenderEngine()
                .bridge$getTexture(resourceLocation));
        GL11.glBegin(7);
        GL11.glTexCoord2d(f6 / size, f7 / size);
        GL11.glVertex2d(x, y);
        GL11.glTexCoord2d(f6 / size, (f7 + size) / size);
        GL11.glVertex2d(x, y + f5);
        GL11.glTexCoord2d((f6 + size) / size, (f7 + size) / size);
        GL11.glVertex2d(x + f4, y + f5);
        GL11.glTexCoord2d((f6 + size) / size, f7 / size);
        GL11.glVertex2d(x + f4, y);
        GL11.glEnd();
        GL11.glDisable(3042);
    }

    public void drawIconFromInt(int texture, float x, float y, float width, float height) {
        float f5 = width / 2.0f;
        float f6 = 0.0f;
        float f7 = 0.0f;
        GL11.glEnable(3042);
        Bridge.getInstance()
                .bridge$getMinecraft()
                .bridge$getRenderEngine()
                .bridge$bindTexture(texture);
        GL11.glBegin(7);
        GL11.glTexCoord2d(f6 / f5, f7 / f5);
        GL11.glVertex2d(x, y);
        GL11.glTexCoord2d(f6 / f5, (f7 + f5) / f5);
        GL11.glVertex2d(x, y + height);
        GL11.glTexCoord2d((f6 + f5) / f5, (f7 + f5) / f5);
        GL11.glVertex2d(x + width, y + height);
        GL11.glTexCoord2d((f6 + f5) / f5, f7 / f5);
        GL11.glVertex2d(x + width, y);
        GL11.glEnd();
        GL11.glDisable(3042);
    }

    public void drawIcon(String resourceLocation, float x, float y, float width, float height) {
        float f5 = width / 2.0f;
        float f6 = 0.0f;
        float f7 = 0.0f;
        GL11.glEnable(3042);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, Bridge.getInstance()
                .bridge$getMinecraft()
                .bridge$getRenderEngine()
                .bridge$getTexture(resourceLocation));
        GL11.glBegin(7);
        GL11.glTexCoord2d(f6 / f5, f7 / f5);
        GL11.glVertex2d(x, y);
        GL11.glTexCoord2d(f6 / f5, (f7 + f5) / f5);
        GL11.glVertex2d(x, y + height);
        GL11.glTexCoord2d((f6 + f5) / f5, (f7 + f5) / f5);
        GL11.glVertex2d(x + width, y + height);
        GL11.glTexCoord2d((f6 + f5) / f5, f7 / f5);
        GL11.glVertex2d(x + width, y);
        GL11.glEnd();
        GL11.glDisable(3042);
    }

    public void drawRectWithOutline(float f, float f2, float f3, float f4, float f5, int n, int n2) {
        drawRect(f + f5, f2 + f5, f3 - f5, f4 - f5, n2);
        drawRect(f, f2 + f5, f + f5, f4 - f5, n);
        drawRect(f3 - f5, f2 + f5, f3, f4 - f5, n);
        drawRect(f, f2, f3, f2 + f5, n);
        drawRect(f, f4 - f5, f3, f4, n);
    }

    public void drawRoundedRect(double x, double y, double width, double height, double radius, int color) {
        int n2;
        float f = (float) (color >> 24 & 0xFF) / (float) 255;
        float f2 = (float) (color >> 16 & 0xFF) / (float) 255;
        float f3 = (float) (color >> 8 & 0xFF) / (float) 255;
        float f4 = (float) (color & 0xFF) / (float) 255;
        GL11.glPushAttrib(0);
        GL11.glScaled(0.5, 0.5, 0.5);
        x *= 2;
        y *= 2;
        width *= 2;
        height *= 2;
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glColor4f(f2, f3, f4, f);
        GL11.glEnable(2848);
        GL11.glBegin(9);
        for (n2 = 0; n2 <= 90; n2 += 3) {
            GL11.glVertex2d(x + radius + Math.sin((double) n2 * (6.5973445528769465 * 0.4761904776096344) / (double) 180) * (radius * (double) -1), y + radius + Math.cos((double) n2 * (42.5 * 0.07391982714328925) / (double) 180) * (radius * (double) -1));
        }
        for (n2 = 90; n2 <= 180; n2 += 3) {
            GL11.glVertex2d(x + radius + Math.sin((double) n2 * (0.5711986642890533 * 5.5) / (double) 180) * (radius * (double) -1), height - radius + Math.cos((double) n2 * (0.21052631735801697 * 14.922564993369743) / (double) 180) * (radius * (double) -1));
        }
        for (n2 = 0; n2 <= 90; n2 += 3) {
            GL11.glVertex2d(width - radius + Math.sin((double) n2 * (4.466951941998311 * 0.7032967209815979) / (double) 180) * radius, height - radius + Math.cos((double) n2 * (28.33333396911621 * 0.11087973822685955) / (double) 180) * radius);
        }
        for (n2 = 90; n2 <= 180; n2 += 3) {
            GL11.glVertex2d(width - radius + Math.sin((double) n2 * ((double) 0.6f * 5.2359875479235365) / (double) 180) * radius, y + radius + Math.cos((double) n2 * (2.8529412746429443 * 1.1011767685204017) / (double) 180) * radius);
        }
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
        GL11.glDisable(3042);
        GL11.glEnable(3553);
        GL11.glScaled(2, 2, 2);
        GL11.glPopAttrib();
    }

    public void drawRoundedOutline(float x, float y, float width, float height, float radius, float lineWidth, int color) {
        GL11.glPushAttrib(0);
        GL11.glScalef(0.5f, 0.5f, 0.5f);

        x *= 2.0D;
        y *= 2.0D;
        width *= 2.0D;
        height *= 2.0D;

        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        setColor(color);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(lineWidth);
        GL11.glBegin(GL11.GL_LINE_LOOP);

        int i;
        for (i = 0; i <= 90; i += 3) {
            GL11.glVertex2d(x + radius + Math.sin(i * Math.PI / 180.0D) * radius * -1.0D, y + radius + Math.cos(i * Math.PI / 180.0D) * radius * -1.0D);
        }
        for (i = 90; i <= 180; i += 3) {
            GL11.glVertex2d(x + radius + Math.sin(i * Math.PI / 180.0D) * radius * -1.0D, height - radius + Math.cos(i * Math.PI / 180.0D) * radius * -1.0D);
        }
        for (i = 0; i <= 90; i += 3) {
            GL11.glVertex2d(width - radius + Math.sin(i * Math.PI / 180.0D) * radius, height - radius + Math.cos(i * Math.PI / 180.0D) * radius);
        }
        for (i = 90; i <= 180; i += 3) {
            GL11.glVertex2d(width - radius + Math.sin(i * Math.PI / 180.0D) * radius, y + radius + Math.cos(i * Math.PI / 180.0D) * radius);
        }

        GL11.glEnd();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glScalef(2.0f, 2.0f, 2.0f);
        GL11.glPopAttrib();
        GL11.glLineWidth(1);
        setColor(color);
    }

    public void drawRect(float i, float j, float k, float l, int i1) {
        float f = (float) (i1 >> 24 & 0xff) / 255F;
        float f1 = (float) (i1 >> 16 & 0xff) / 255F;
        float f2 = (float) (i1 >> 8 & 0xff) / 255F;
        float f3 = (float) (i1 & 0xff) / 255F;

        TessellatorBridge tessellator = BridgeRef.getTessellator();

        GL11.glEnable(3042 /*GL_BLEND*/);
        GL11.glDisable(3553 /*GL_TEXTURE_2D*/);
        GL11.glBlendFunc(770, 771);
        GL11.glColor4f(f1, f2, f3, f);
        tessellator.bridge$startDrawingQuads();
        tessellator.bridge$addVertex(i, l, 0.0D);
        tessellator.bridge$addVertex(k, l, 0.0D);
        tessellator.bridge$addVertex(k, j, 0.0D);
        tessellator.bridge$addVertex(i, j, 0.0D);
        tessellator.bridge$draw();
        GL11.glEnable(3553 /*GL_TEXTURE_2D*/);
        GL11.glDisable(3042 /*GL_BLEND*/);
    }

    public void startScissorBox(int x, int y, int width, int height, float scaledWidth, int scaledHeight) {
        int sY = height - y;
        int sX = width - x;
        int n8 = scaledHeight - height;
        GL11.glScissor((int) ((float) x * scaledWidth), (int) ((float) n8 * scaledWidth), (int) ((float) sX * scaledWidth), (int) ((float) sY * scaledWidth));
    }

    public void drawCircle(double x, double y, double size) {
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        TessellatorBridge tessellator = Bridge.getInstance().bridge$createTessellator();
        tessellator.bridge$startDrawing(6);
        tessellator.bridge$addVertex(x, y, 0);
        double pi = Math.PI * 2;
        double d5 = pi / 30;
        for (double d6 = -d5; d6 < pi; d6 += d5) {
            tessellator.bridge$addVertex(x + size * Math.cos(-d6), y + size * Math.sin(-d6), 0);
        }
        tessellator.bridge$draw();
        GL11.glEnable(3553);
        GL11.glDisable(GL11.GL_BLEND);
    }

    public void drawHollowRadial(double x, double y, double width, double height, double var8, int var10, double var11) {
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(2848);

        TessellatorBridge tessellator = Bridge.getInstance().bridge$createTessellator();

        var8 = (var8 + (double) var10) % (double) var10;
        for (double var13 = 360.0 / (double) var10 * var8; var13 < 360.0 / (double) var10 * (var8 + var11); var13 += 1.0) {
            double var15 = var13 * Math.PI / 180.0;
            double var17 = (var13 - 1.0) * Math.PI / 180.0;
            double[] var19 = new double[]{MathUtil.cos(var15) * width, -MathUtil.sin(var15) * width, MathUtil.cos(var17) * width, -MathUtil.sin(var17) * width};
            double[] var20 = new double[]{MathUtil.cos(var15) * height, -MathUtil.sin(var15) * height, MathUtil.cos(var17) * height, -MathUtil.sin(var17) * height};
            tessellator.bridge$startDrawing(7);
            tessellator.bridge$addVertex(x + var20[0], y + var20[1], 0.0);
            tessellator.bridge$addVertex(x + var20[2], y + var20[3], 0.0);
            tessellator.bridge$addVertex(x + var19[2], y + var19[3], 0.0);
            tessellator.bridge$addVertex(x + var19[0], y + var19[1], 0.0);
            tessellator.bridge$draw();
        }
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(2848);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
    }

    public void setColor(int color) {
        float a = (color >> 24 & 0xFF) / 255.0F;
        float r = (color >> 16 & 0xFF) / 255.0F;
        float g = (color >> 8 & 0xFF) / 255.0F;
        float b = (color & 0xFF) / 255.0F;

        GL11.glColor4f(r, g, b, a);
    }

}
