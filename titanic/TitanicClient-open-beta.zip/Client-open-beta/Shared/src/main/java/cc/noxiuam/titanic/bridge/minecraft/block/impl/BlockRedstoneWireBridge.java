package cc.noxiuam.titanic.bridge.minecraft.block.impl;

import cc.noxiuam.titanic.bridge.minecraft.block.BlockAccessBridge;
import cc.noxiuam.titanic.bridge.minecraft.block.BlockBridge;

public interface BlockRedstoneWireBridge extends BlockBridge {

    boolean bridge$isPowerProviderOrWire(BlockAccessBridge blockAccessBridge, int x, int y, int z);

}
