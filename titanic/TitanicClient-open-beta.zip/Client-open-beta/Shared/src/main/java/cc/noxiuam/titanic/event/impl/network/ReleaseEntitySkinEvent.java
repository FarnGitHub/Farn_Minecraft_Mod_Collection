package cc.noxiuam.titanic.event.impl.network;

import cc.noxiuam.titanic.bridge.minecraft.entity.EntityBridge;
import cc.noxiuam.titanic.bridge.minecraft.renderer.RenderEngineBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Noxiuam
 * https://noxiuam.cc
 */
@Getter
@AllArgsConstructor
public class ReleaseEntitySkinEvent extends AbstractEvent {

    private final RenderEngineBridge renderEngine;
    private final EntityBridge entity;

}
