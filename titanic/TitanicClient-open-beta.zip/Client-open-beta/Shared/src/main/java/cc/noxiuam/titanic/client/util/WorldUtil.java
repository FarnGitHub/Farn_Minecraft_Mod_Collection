package cc.noxiuam.titanic.client.util;

import cc.noxiuam.titanic.bridge.minecraft.item.ItemStackBridge;
import lombok.experimental.UtilityClass;

@UtilityClass
public class WorldUtil {

    public int getItemDamage(ItemStackBridge itemStack) {
        return itemStack.bridge$getDamage();
    }

}
