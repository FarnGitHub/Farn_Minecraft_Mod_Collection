package cc.noxiuam.titanic.bridge.minecraft.client.gui.screen;

public interface GuiMainMenuBridge extends GuiScreenBridge {
}
