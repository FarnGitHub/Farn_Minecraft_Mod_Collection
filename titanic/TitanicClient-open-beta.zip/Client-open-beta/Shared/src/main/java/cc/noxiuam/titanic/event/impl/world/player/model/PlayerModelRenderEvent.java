package cc.noxiuam.titanic.event.impl.world.player.model;

import cc.noxiuam.titanic.bridge.minecraft.model.ModelBipedBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class PlayerModelRenderEvent extends AbstractEvent {

    private ModelBipedBridge model;

}
