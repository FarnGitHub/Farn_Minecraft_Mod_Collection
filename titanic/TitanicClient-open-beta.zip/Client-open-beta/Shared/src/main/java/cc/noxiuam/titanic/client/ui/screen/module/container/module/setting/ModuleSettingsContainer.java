package cc.noxiuam.titanic.client.ui.screen.module.container.module.setting;

import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.impl.hud.AbstractMovableModule;
import cc.noxiuam.titanic.client.module.data.setting.AbstractSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.StringSetting;
import cc.noxiuam.titanic.client.ui.AbstractContainer;
import cc.noxiuam.titanic.client.ui.component.type.button.RoundedIconButton;
import cc.noxiuam.titanic.client.ui.component.type.button.RoundedTextButton;
import cc.noxiuam.titanic.client.ui.component.type.setting.AbstractSettingComponent;
import cc.noxiuam.titanic.client.ui.screen.module.component.data.SettingPage;
import cc.noxiuam.titanic.client.ui.screen.module.container.ModuleListContainer;
import cc.noxiuam.titanic.client.ui.screen.module.container.module.ModulePreviewContainer;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.client.util.SoundUtil;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ModuleSettingsContainer extends AbstractContainer {

    @Setter private AbstractModule module;
    private final ModuleListContainer container;
    private final AbstractContainer parent;

    private final RoundedIconButton resetSettingsButton = new RoundedIconButton(
            "/titanic/icons/reset-settings.png",
            true,
            11,
            11,
            4.5F,
            4.5F
    );

    private final RoundedIconButton resetPositionButton = new RoundedIconButton(
            "/titanic/icons/reset-position.png",
            true,
            11,
            11,
            4.5F,
            4.5F
    );

    private final RoundedIconButton backButton = new RoundedIconButton(
            "/titanic/icons/back.png",
            true,
            11,
            11,
            4.5F,
            4.5F
    );
    private final RoundedIconButton closeButton = new RoundedIconButton(
            "/titanic/icons/close.png",
            true,
            11,
            11,
            4F,
            4.5F
    );

    private final RoundedTextButton leftButton = new RoundedTextButton("<");
    private final RoundedTextButton rightButton = new RoundedTextButton(">");

    @Getter private final List<SettingPage> settingPages = new CopyOnWriteArrayList<>();
    @Getter private final List<AbstractSetting<?>> queuedSettings = new CopyOnWriteArrayList<>();

    public int pageNumber = 0;

    public ModuleSettingsContainer(ModuleListContainer container, ModulePreviewContainer parent, AbstractModule module) {
        super("/mods/settings?module=" + module.name());
        this.module = module;
        this.container = container;
        this.parent = parent;

        for (float i = 0; i < this.module.settings().size() / 5F; i++) {
            this.settingPages.add(new SettingPage());
        }

        for (AbstractSetting<?> setting : module.settings()) {
            for (SettingPage settingPage : this.settingPages) {
                if (this.queuedSettings.contains(setting)) {
                    continue;
                }
                if (settingPage.getSettingComponents().size() >= 5) {
                    continue;
                }
                settingPage.getSettingComponents().add(setting.getComponent(this));
                this.queuedSettings.add(setting);
            }
        }
    }

    @Override
    public void handleUpdate() {
        for (AbstractSettingComponent<?> component : this.settingPages.get(this.pageNumber).getSettingComponents()) {
            component.handleUpdate();
        }
    }

    @Override
    public void position(float newX, float newY) {
        super.position(newX, newY + 10);
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        float componentHeight = -15;
        for (AbstractSettingComponent<?> component : this.settingPages.get(this.pageNumber).getSettingComponents()) {
            component.size(this.width, this.height);
            component.position(this.x, this.y + componentHeight);
            component.draw(mouseX, mouseY);

            if (component.mouseInside(mouseX, mouseY) && component.getSetting().description() != null) {
                int descX = 3;
                int descY = BridgeRef.getCurrentScreen().bridge$getHeight() - 15;

                String desc = component.getSetting().description();

                RenderUtil.drawRoundedRect(
                        descX,
                        descY - 5,
                        descX + this.mc.bridge$getFontRenderer().bridge$getStringWidth(desc) + 10,
                        descY + 13,
                        5,
                        0xBF000000
                );
                this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(
                        desc,
                        descX + 5,
                        descY,
                        -1
                );
            }

            componentHeight += (component.getSetting() instanceof StringSetting) ? component.getHeight() + 10 : component.getHeight() + 5;
        }

        boolean showPageButtons = this.settingPages.size() > 1;
        if (showPageButtons) {
            this.leftButton.setDisabled(this.pageNumber == 0);
            this.leftButton.position(this.x + this.width / 2.165F - 12, this.y + this.height);
            this.leftButton.size(16, 20);
            this.leftButton.draw(mouseX, mouseY);

            this.rightButton.setDisabled(this.pageNumber == this.settingPages.size() - 1);
            this.rightButton.position(this.x + this.width / 2.165F + 12, this.y + this.height);
            this.rightButton.size(16, 20);
            this.rightButton.draw(mouseX, mouseY);
        }

        this.backButton.position(this.x, this.y + this.height);
        this.backButton.size(20, 20);
        this.backButton.draw(mouseX, mouseY);

        this.resetSettingsButton.position(this.x + this.backButton.getWidth() + 5, this.y + this.height);
        this.resetSettingsButton.size(20, 20);
        this.resetSettingsButton.draw(mouseX, mouseY);

        if (this.module instanceof AbstractMovableModule) {
            this.resetPositionButton.position(this.x + this.backButton.getWidth() + 30, this.y + this.height);
            this.resetPositionButton.size(20, 20);
            this.resetPositionButton.draw(mouseX, mouseY);
        }

        this.closeButton.position(this.x + this.width - 19, this.y + this.height);
        this.closeButton.size(20, 20);
        this.closeButton.draw(mouseX, mouseY);
    }

    @Override
    public void keyTyped(char character, int key) {
        for (AbstractSettingComponent<?> component : this.settingPages.get(this.pageNumber).getSettingComponents()) {
            component.keyTyped(character, key);
        }
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        for (AbstractSettingComponent<?> component : this.settingPages.get(this.pageNumber).getSettingComponents()) {
            if (component.mouseInside(mouseX, mouseY)) {
                component.mouseClicked(mouseX, mouseY);
            }
        }

        boolean showPageButtons = this.settingPages.size() > 1;
        if (showPageButtons && this.leftButton.mouseInside(mouseX, mouseY) && this.pageNumber > 0) {
            SoundUtil.playClick();
            this.pageNumber--;
        } else if (showPageButtons && this.rightButton.mouseInside(mouseX, mouseY) && this.pageNumber + 1 < this.settingPages.size()) {
            SoundUtil.playClick();
            this.pageNumber++;
        }

        if (this.closeButton.mouseInside(mouseX, mouseY)) {
            SoundUtil.playClick();
            this.mc.bridge$displayGuiScreen(null);
        } else if (this.backButton.mouseInside(mouseX, mouseY)) {
            SoundUtil.playClick();
            this.container.setCurrentComponent(this.parent);
        } else if (this.resetSettingsButton.mouseInside(mouseX, mouseY)) {
            SoundUtil.playClick();
            for (AbstractSetting setting : this.module.settings()) {
                setting.value(setting.defaultValue());
            }
            this.container.setCurrentComponent(new ModuleSettingsContainer(this.container, (ModulePreviewContainer) this.parent, this.module));
        } else if (this.resetPositionButton.mouseInside(mouseX, mouseY)
                && this.module instanceof AbstractMovableModule) {
            SoundUtil.playClick();
            ((AbstractMovableModule) this.module).setPosition(
                    ((AbstractMovableModule) this.module).defaultX(),
                    ((AbstractMovableModule) this.module).defaultY()
            );
        }
    }

}
