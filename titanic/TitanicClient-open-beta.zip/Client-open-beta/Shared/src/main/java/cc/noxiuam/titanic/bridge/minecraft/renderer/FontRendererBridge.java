package cc.noxiuam.titanic.bridge.minecraft.renderer;

public interface FontRendererBridge {

    void bridge$drawString(String text, int x, int y, int color);

    void bridge$drawStringWithShadow(String text, int x, int y, int color);

    int bridge$getStringWidth(String text);

    default void bridge$drawString(String text, int x, int y, int color, boolean shadow) {
        if (shadow) {
            bridge$drawStringWithShadow(text, x, y, color);
        } else {
            bridge$drawString(text, x, y, color);
        }
    }

    default void bridge$drawCenteredString(String text, int x, int y, int color, boolean shadow) {
        if (shadow) {
            bridge$drawStringWithShadow(text, x  - bridge$getStringWidth(text) / 2, y, color);
        } else {
            bridge$drawString(text, x - bridge$getStringWidth(text) / 2, y, color);
        }
    }

}
