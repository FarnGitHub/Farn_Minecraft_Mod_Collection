package cc.noxiuam.titanic.event.impl.world.fov;

import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class OrientCameraEvent extends AbstractEvent {

    private float partialTicks;

}
