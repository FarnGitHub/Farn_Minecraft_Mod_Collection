package cc.noxiuam.titanic.bridge.minecraft.renderer;

public interface TessellatorBridge {

    void bridge$startDrawing(int mode);
    void bridge$startDrawingQuads();
    void bridge$setColorRGBA_F(float red, float green, float blue, float alpha);
    void bridge$addVertex(double x, double y, double z);
    void bridge$draw();
    void bridge$setColorOpaque_I(int color);
    void bridge$addVertexWithUV(double var1, double var3, double var5, double var7, double var9);
    void bridge$setColorOpaque_F(float r, float g, float b);
    void bridge$setTranslationF(float x, float y, float z);
    void bridge$setNormal(float x, float y, float z);
    void bridge$setColorRGBA_I(int var1, int var2);

}
