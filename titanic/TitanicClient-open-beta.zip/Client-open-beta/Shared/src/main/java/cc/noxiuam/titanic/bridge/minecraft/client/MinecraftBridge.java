package cc.noxiuam.titanic.bridge.minecraft.client;

import cc.noxiuam.titanic.bridge.minecraft.SoundManagerBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiIngameBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import cc.noxiuam.titanic.bridge.minecraft.entity.EntityPlayerBridge;
import cc.noxiuam.titanic.bridge.minecraft.network.PlayerControllerBridge;
import cc.noxiuam.titanic.bridge.minecraft.renderer.RenderEngineBridge;
import cc.noxiuam.titanic.bridge.minecraft.renderer.RenderGlobalBridge;
import cc.noxiuam.titanic.bridge.minecraft.renderer.FontRendererBridge;
import cc.noxiuam.titanic.bridge.minecraft.util.SessionBridge;

import java.io.File;

public interface MinecraftBridge {

    String bridge$getDebug();

    int bridge$getDisplayWidth();
    int bridge$getDisplayHeight();

    void bridge$displayGuiScreen(GuiScreenBridge guiScreen);

    File bridge$getMinecraftDir();

    boolean bridge$isMultiplayerWorld();
    boolean bridge$isTakingScreenshot();

    void bridge$setIsTakingScreenshot(boolean isTakingScreenhot);

    GuiScreenBridge bridge$getCurrentScreen();
    FontRendererBridge bridge$getFontRenderer();
    GuiIngameBridge bridge$getIngameGui();
    SoundManagerBridge bridge$getSoundManager();
    EntityPlayerBridge bridge$getThePlayer();
    RenderEngineBridge bridge$getRenderEngine();
    RenderGlobalBridge bridge$getRenderGlobal();
    PlayerControllerBridge bridge$getPlayerController();
    SessionBridge bridge$getSession();

}