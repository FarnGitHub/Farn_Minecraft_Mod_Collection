package cc.noxiuam.titanic.event.impl.world.lighting;

import cc.noxiuam.titanic.event.AbstractEvent;

public class WorldRendererUpdateEvent extends AbstractEvent {
}
