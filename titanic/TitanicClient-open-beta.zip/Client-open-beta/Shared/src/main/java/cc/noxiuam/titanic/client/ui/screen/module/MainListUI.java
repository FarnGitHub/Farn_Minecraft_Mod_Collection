package cc.noxiuam.titanic.client.ui.screen.module;

import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.ui.screen.module.container.ModuleListContainer;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import lombok.Getter;
import org.lwjgl.opengl.GL11;

public class MainListUI extends AbstractComponent {

    @Getter
    private final ModuleListContainer moduleListContainer = new ModuleListContainer();

    @Override
    public void size(float width, float height) {
        super.size(width, height);
        this.moduleListContainer.size(width - 20, height - 50);
    }

    @Override
    public void position(float newX, float newY) {
        super.position(newX, newY);
        this.moduleListContainer.position(newX + 10, newY + 10);
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        RenderUtil.drawRoundedRect(
                this.x,
                this.y + 1.0f,
                this.x + this.width,
                this.y + this.height - 1.0f,
                5.0f,
                0x80000000
        );

        this.moduleListContainer.draw(mouseX, mouseY);
    }

    @Override
    public void handleUpdate() {
        this.moduleListContainer.handleUpdate();
    }

    @Override
    public void keyTyped(char character, int key) {
        this.moduleListContainer.keyTyped(character, key);
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        super.mouseClicked(mouseX, mouseY);
        this.moduleListContainer.mouseClicked(mouseX, mouseY);
    }

}
