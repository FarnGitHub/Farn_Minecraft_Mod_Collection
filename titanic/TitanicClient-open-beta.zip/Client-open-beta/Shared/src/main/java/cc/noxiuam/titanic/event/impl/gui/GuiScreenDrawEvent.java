package cc.noxiuam.titanic.event.impl.gui;

import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class GuiScreenDrawEvent extends AbstractEvent {

    public GuiScreenBridge screen;

}
