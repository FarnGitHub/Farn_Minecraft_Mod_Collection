package cc.noxiuam.titanic.client.module.impl.normal.world;

import cc.noxiuam.titanic.bridge.minecraft.network.impl.PacketMapChunkBridge;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.data.ModuleCategory;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.KeybindSetting;
import cc.noxiuam.titanic.event.impl.world.TickEvent;
import cc.noxiuam.titanic.event.impl.keyboard.KeyboardEvent;
import cc.noxiuam.titanic.event.impl.network.PacketReceivedEvent;
import com.google.common.collect.ImmutableList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ChunkLoadingFix extends AbstractModule {

    public final List<Long> cooldown = new ArrayList<>();

    private final KeybindSetting refreshKeybind;
    private final BooleanSetting automaticRefresh;

    public ChunkLoadingFix() {
        super(
                "chunkLoadingFix",
                "Chunk Loading Fix",
                "Fixes chunk loading when teleporting.",
                false,
                MinecraftVersion.getAllVersions(),
                Collections.emptyList()
        );
        this.addSettings(
                this.refreshKeybind = new KeybindSetting("refreshKeybind", "Refresh Keybind", 0),
                this.automaticRefresh = new BooleanSetting("automaticRefresh", "Automatically Refresh Blocks", true)
        );

        this.automaticRefresh.description("This automatically refreshes textures every 5 seconds.");

        this.addEvent(PacketReceivedEvent.class, this::onPacket);
        this.addEvent(TickEvent.class, this::onTick);
        this.addEvent(KeyboardEvent.class, event -> {
            if (event.getKey() == this.refreshKeybind.value()) {
                this.mc.bridge$getRenderGlobal().bridge$loadRenderers();
            }
        });
    }

    private void onTick(TickEvent ignored) {
        this.cooldown.removeIf(n -> n < System.currentTimeMillis() - 5000L);
    }

    private void onPacket(PacketReceivedEvent event) {
        if (event.getPacket() instanceof PacketMapChunkBridge && this.automaticRefresh.value() && this.cooldown.size() == 0) {
            for (int i = 0; i < 15; i++) {
                this.cooldown.add(System.currentTimeMillis());
            }
            this.mc.bridge$getRenderGlobal().bridge$loadRenderers();
        }
    }

}
