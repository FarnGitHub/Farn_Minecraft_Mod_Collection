package cc.noxiuam.titanic.client.module.impl;

import cc.noxiuam.titanic.Client;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.network.manager.discord.DiscordRPCHandler;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import com.jagrosh.discordipc.IPCClient;
import com.jagrosh.discordipc.entities.pipe.PipeStatus;

import java.util.Collections;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public class DiscordRPCModule extends AbstractModule {

    public DiscordRPCModule() {
        super(
                "discordRpc",
                "Discord RPC",
                "Shows the client on your Discord game status.",
                true,
                MinecraftVersion.getAllVersions(),
                Collections.emptyList()
        );
    }

    @Override
    public void onEnable() {
        try {
            DiscordRPCHandler discordRPCHandler = Client.getInstance().getDiscordRPCHandler();
            IPCClient ipc = discordRPCHandler.getRpcClient();

            if (ipc.getStatus() == PipeStatus.CLOSED || ipc.getStatus() == PipeStatus.DISCONNECTED) {
                discordRPCHandler.connectToDiscord();
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onDisable() {
        try {
            DiscordRPCHandler discordRPCHandler = Client.getInstance().getDiscordRPCHandler();
            IPCClient ipc = discordRPCHandler.getRpcClient();

            if (ipc.getStatus() != PipeStatus.CLOSED) {
                ipc.close();
            }
        } catch (Exception ignored) {
        }
    }

}
