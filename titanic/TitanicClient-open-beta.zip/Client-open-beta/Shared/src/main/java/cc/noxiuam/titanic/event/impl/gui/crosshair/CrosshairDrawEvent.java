package cc.noxiuam.titanic.event.impl.gui.crosshair;

import cc.noxiuam.titanic.bridge.minecraft.client.gui.ScaledResolutionBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class CrosshairDrawEvent extends AbstractEvent {

    private ScaledResolutionBridge scaledResolution;
    private int x, y;

}
