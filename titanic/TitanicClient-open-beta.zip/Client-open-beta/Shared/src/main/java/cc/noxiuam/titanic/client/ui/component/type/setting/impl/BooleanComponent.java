package cc.noxiuam.titanic.client.ui.component.type.setting.impl;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiButtonBridge;
import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.client.ui.screen.module.container.module.setting.ModuleSettingsContainer;
import cc.noxiuam.titanic.client.ui.component.type.setting.AbstractSettingComponent;
import cc.noxiuam.titanic.client.util.SoundUtil;

public class BooleanComponent extends AbstractSettingComponent<Boolean> {
    
    private final GuiButtonBridge button;

    public BooleanComponent(BooleanSetting setting, ModuleSettingsContainer list) {
        super(setting, list);

        this.button = Bridge.getInstance().bridge$createNewGuiButton(
                1000,
                0,
                0,
                BridgeRef.getMinecraft().bridge$getFontRenderer().bridge$getStringWidth(setting.name()) + 30,
                20,
                this.setting.name() + ": " + (this.setting.value() ? "ON" : "OFF")
        );
        
        this.button.bridge$setEnabled(setting.value());
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        this.button.bridge$setX((int) (this.x + 2));
        this.button.bridge$setY((int) this.y, false);
        this.button.bridge$drawButton(BridgeRef.getMinecraft(), (int) mouseX, (int) mouseY);
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        float buttonX = (int) (this.x + 2);
        float buttonY = this.y;

        if (mouseX >= buttonX && mouseY >= buttonY && mouseX < buttonX + this.width && mouseY < buttonY + this.height) {
            this.setting.value(!this.setting.value());
            this.button.bridge$setEnabled(this.setting.value());
            this.button.bridge$setText(this.setting.name() + ": " + (this.setting.value() ? "ON" : "OFF"));
            SoundUtil.playClick();
        }
    }

    @Override
    public float getHeight() {
        return 20;
    }

}
