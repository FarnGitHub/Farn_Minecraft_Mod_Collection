package cc.noxiuam.titanic.event.impl.gui.chat;

import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiChatBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class GuiChatDrawEvent extends AbstractEvent {

    private GuiChatBridge guiChat;

}
