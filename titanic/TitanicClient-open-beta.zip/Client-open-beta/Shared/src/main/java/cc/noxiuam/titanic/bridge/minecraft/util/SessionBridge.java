package cc.noxiuam.titanic.bridge.minecraft.util;

public interface SessionBridge {

    String bridge$getUsername();

}
