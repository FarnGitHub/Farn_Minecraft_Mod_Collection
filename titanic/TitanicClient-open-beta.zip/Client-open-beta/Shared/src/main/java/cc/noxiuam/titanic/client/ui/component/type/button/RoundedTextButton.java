package cc.noxiuam.titanic.client.ui.component.type.button;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiButtonBridge;
import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.ui.transition.impl.ColorTransition;

import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import lombok.AllArgsConstructor;
import lombok.Setter;

@Setter
@AllArgsConstructor
public class RoundedTextButton extends AbstractComponent {

    private String text;

    private boolean disabled;

    private final GuiButtonBridge button;

    public RoundedTextButton(String text) {
        this.text = text;

        this.button = Bridge.getInstance().bridge$createNewGuiButton(
                1000,
                0,
                0,
                0,
                0,
                this.text
        );
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        this.button.bridge$setX((int) this.x);
        this.button.bridge$setY((int) this.y, true);
        this.button.bridge$setWidth((int) this.width);
        this.button.bridge$setHeight((int) this.height);
        this.button.bridge$drawButton(BridgeRef.getMinecraft(), (int) mouseX, (int) mouseY);
        this.button.bridge$setEnabled(!this.disabled);
    }

}
