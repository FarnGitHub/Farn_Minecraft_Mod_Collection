package cc.noxiuam.titanic.client.module.impl.normal.world.performance;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.minecraft.block.impl.BlockCropsBridge;
import cc.noxiuam.titanic.bridge.minecraft.block.impl.BlockTorchBridge;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.data.ModuleCategory;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.event.impl.emote.EmotePlayEvent;
import cc.noxiuam.titanic.event.impl.world.block.BlockParticleRenderEvent;
import cc.noxiuam.titanic.event.impl.world.block.BlockRenderEvent;
import com.google.common.collect.ImmutableList;

import java.util.Collections;

public class PerformanceModule extends AbstractModule {

    private final BooleanSetting showCrops, showRandomBlockParticles, showEmotes;

    public PerformanceModule() {
        super(
                "performanceHelper",
                "Performance",
                "Numerous FPS improvements for Beta.",
                false,
                MinecraftVersion.getAllVersions(),
                Collections.emptyList()
        );

        this.addSettings(
                this.showCrops = new BooleanSetting("showCrops", "Show Crops", true),
                this.showRandomBlockParticles = new BooleanSetting("showRandomBlockParticles", "Show Random Block Particles", true),
                this.showEmotes = new BooleanSetting("showEmotes", "Show Emotes", false)
        );

        this.showRandomBlockParticles.description("Toggle things like torch particles, Redstone particles, etc.");

        this.showCrops.onUpdate(value -> {
            if (Bridge.getInstance().bridge$getMinecraft().bridge$getRenderGlobal() != null) {
                Bridge.getInstance().bridge$getMinecraft().bridge$getRenderGlobal().bridge$loadRenderers();
            }
        });

        this.addEvent(EmotePlayEvent.class, emotePlayEvent -> {
            if (!this.showEmotes.value()) {
                emotePlayEvent.cancel();
            }
        });

        this.addEvent(BlockRenderEvent.class, this::onBlockRender);
        this.addEvent(BlockParticleRenderEvent.class, this::onBlockParticleRender);
    }

    private void onBlockRender(BlockRenderEvent event) {
        if (!this.showCrops.value() &&
                (event.getBlock() instanceof BlockCropsBridge)
        ) {
            event.cancel();
        }
    }

    private void onBlockParticleRender(BlockParticleRenderEvent event) {
        if (!this.showRandomBlockParticles.value() &&
                (event.getBlock() instanceof BlockTorchBridge)
        ) {
            event.cancel();
        }
    }

}
