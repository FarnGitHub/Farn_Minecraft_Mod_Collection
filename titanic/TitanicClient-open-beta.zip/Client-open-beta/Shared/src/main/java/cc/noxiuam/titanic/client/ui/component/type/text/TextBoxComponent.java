package cc.noxiuam.titanic.client.ui.component.type.text;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.client.module.data.setting.impl.StringSetting;
import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.ui.transition.impl.ColorTransition;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.client.util.ClipboardUtil;
import cc.noxiuam.titanic.client.util.SoundUtil;
import lombok.Getter;
import lombok.Setter;
import org.lwjgl.input.Keyboard;

public class TextBoxComponent extends AbstractComponent {

    private final ColorTransition outlineColor = new ColorTransition(0x00000000, 0xCCC2C2C2);
    private final ColorTransition activeOutlineColor = new ColorTransition(0x00000000, 0xFF1471FF);
    private final ColorTransition backgroundColor = new ColorTransition(0x80000000, 0xBF000000);

    public boolean using;

    @Getter @Setter
    private String text;

    @Setter
    private String previewText;

    @Setter private int maxLength = 16;
    private final StringSetting setting;

    private int counter = 0;

    public TextBoxComponent(String previewText) {
        this.setting = null;
        this.previewText = previewText;
        this.text = "";
    }

    public TextBoxComponent(StringSetting setting) {
        this.setting = setting;
        this.maxLength = setting.getMaxLength();
        this.text = setting.value();
    }

    @Override
    public void handleUpdate() {
        counter--;
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        RenderUtil.drawRoundedRect(
                this.x,
                this.y,
                this.x + this.width,
                this.y + this.height,
                5,
                backgroundColor.getColor(mouseInside(mouseX, mouseY)).getRGB()
        );

        RenderUtil.drawRoundedOutline(
                this.x,
                this.y,
                this.x + this.width,
                this.y + this.height,
                5.0F,
                3.0F,
                (this.using ? this.activeOutlineColor.getColor(true).getRGB() : this.outlineColor.getColor(mouseInside(mouseX, mouseY)).getRGB())
        );

        String text = this.using ? this.text + (counter / 6 % 2 != 0 ? "" : "_") : this.previewText;
        if (!this.using && this.text.length() > 0) {
            text = this.text;
        }

        if (this.setting != null
                && this.setting.isEncryptText()
                && !this.using
                && text != null) {
            text = text.replaceAll("(?s).", "*");
        }

        int color = this.using ? -1 : 0x50737373;
        if (!this.using && this.text.length() > 0) {
            color = -1;
        }

        Bridge.getInstance().bridge$getMinecraft().bridge$getFontRenderer().bridge$drawString(
                text, (int) (this.x + 5), (int) (this.y + 3), color
        );
    }

    @Override
    public void keyTyped(char character, int key) {
        if (this.using && this.setting != null && key == Keyboard.KEY_RETURN) {
            this.using = false;
            this.setting.value(this.text);
            SoundUtil.playClick();
            return;
        }

        if (key == Keyboard.KEY_BACK && this.text.length() > 0) {
            this.text = this.text.substring(0, this.text.length() - 1);
            return;
        }

        if (Keyboard.isKeyDown(Keyboard.KEY_LCONTROL)
                && ClipboardUtil.getClipboardString() != null
                && (this.text.length() + ClipboardUtil.getClipboardString().length() <= this.maxLength)
                && key == Keyboard.KEY_V) {
            this.text += ClipboardUtil.getClipboardString();
            return;
        }

        if (this.using
                && Bridge.getInstance().bridge$getFontAllowedChars().bridge$getAllowedCharacters().indexOf(character) >= 0
                && this.text.length() < this.maxLength) {
            this.text += character;
        }
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        if (mouseInside(mouseX, mouseY)) {
            SoundUtil.playClick();
            this.using = !this.using;
            if (!this.using && this.setting != null) {
                this.setting.value(this.text);
            }
        }
    }

}
