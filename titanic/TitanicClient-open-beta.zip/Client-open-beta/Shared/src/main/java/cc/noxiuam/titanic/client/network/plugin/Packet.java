package cc.noxiuam.titanic.client.network.plugin;

public interface Packet {

    int getId();

    void handle();

}
