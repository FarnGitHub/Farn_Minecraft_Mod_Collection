package cc.noxiuam.titanic.client.ui.component.type.button.module;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiButtonBridge;
import cc.noxiuam.titanic.client.module.data.ModuleCategory;
import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.ui.transition.impl.ColorTransition;
import cc.noxiuam.titanic.client.util.CaseUtils;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
@Getter
public class ModuleCategoryButton extends AbstractComponent {

    private final ModuleCategory category;

    @Setter private boolean selected;

    private final String text;

    private final GuiButtonBridge button;

    public ModuleCategoryButton(ModuleCategory category) {
        this.category = category;
        this.text = CaseUtils.toCamelCase(category.toString().toUpperCase(), true);
        this.button = Bridge.getInstance().bridge$createNewGuiButton(
                1000,
                (int) this.x,
                (int) this.y,
                (int) (BridgeRef.getMinecraft()
                        .bridge$getFontRenderer()
                        .bridge$getStringWidth(
                                this.category.toString().toUpperCase()
                        ) + 10F),
                20,
                this.text
        );
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        this.button.bridge$setX((int) this.x);
        this.button.bridge$setY((int) this.y, true);
        this.button.bridge$drawButton(Bridge.getInstance().bridge$getMinecraft(), (int) mouseX, (int) mouseY);
    }

}
