package cc.noxiuam.titanic.client.module.impl.hud.impl;

import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.MathHelper;
import cc.noxiuam.titanic.client.module.impl.hud.AbstractMovableModule;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.event.impl.gui.GuiDrawEvent;
import org.lwjgl.opengl.GL11;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public class CompassModule extends AbstractMovableModule {

    public CompassModule() {
        super("compass", "Compass", "Shows the direction you are facing.", false, MinecraftVersion.getAllVersions());
        this.addEvent(GuiDrawEvent.class, this::render);
    }

    private void render(GuiDrawEvent event) {
        GL11.glPushMatrix();

        int backgroundColor = 0xFF212121;
        this.setSize(66, 12);

        GL11.glTranslatef(this.x(), this.y(), 0);
        this.resizeToScale();

        GL11.glColor4f((float)(backgroundColor >> 16 & 0xFF) / (float)255, (float)(backgroundColor >> 8 & 0xFF) / (float)255, (float)(backgroundColor & 0xFF) / (float)255, (float)(backgroundColor >> 24 & 255) / (float)255);
        this.drawCompass();
        GL11.glColor4f((float)(backgroundColor >> 16 & 0xFF) / (float)255, (float)(backgroundColor >> 8 & 0xFF) / (float)255, (float)(backgroundColor & 0xFF) / (float)255, (float)(backgroundColor >> 24 & 255) / (float)255);

        GL11.glPopMatrix();
    }

    private void drawCompass() {
        int direction = MathHelper.floor_double((double) (this.mc.bridge$getThePlayer().bridge$getRotationYaw() * (float) 256 / (float) 360) + 0.5) & 0xFF;
        int yPos = 0;
        int xPos = 0;
        int backgroundColor = 0xFF212121;
        int directionColor = -1;
        int markerColor = 0xFFFF5555;

        String compass = "/titanic/mods/compass.png";
        int texture = BridgeRef.getMinecraft().bridge$getRenderEngine().bridge$getTexture(compass);

        BridgeRef.getMinecraft().bridge$getRenderEngine().bridge$bindTexture(texture);

        if (direction < 128) {
            GL11.glColor4f(
                    (float) (backgroundColor >> 16 & 0xFF) / (float) 255,
                    (float) (backgroundColor >> 8 & 0xFF) / (float) 255,
                    (float) (backgroundColor & 0xFF) / (float) 255,
                    (float) (backgroundColor >> 24 & 255) / (float) 255
            );
            RenderUtil.drawTexturedModalRect(xPos, yPos, direction, 0, 65, 12, -100);
        } else {
            RenderUtil.drawTexturedModalRect(xPos, yPos, direction - 128, 12, 65, 12, -100);
        }

        GL11.glColor4f(
                (float) (directionColor >> 16 & 0xFF) / (float) 255,
                (float) (directionColor >> 8 & 0xFF) / (float) 255,
                (float) (directionColor & 0xFF) / (float) 255,
                1.0F
        );

        if (direction < 128) {
            RenderUtil.drawTexturedModalRect(xPos, yPos, direction, 24, 65, 12, -100);
        } else {
            RenderUtil.drawTexturedModalRect(xPos, yPos, direction - 128, 36, 65, 12, -100);
        }

        BridgeRef.getMinecraft().bridge$getFontRenderer().bridge$drawString("|", xPos + 32, yPos + 1, markerColor);
        BridgeRef.getMinecraft().bridge$getFontRenderer().bridge$drawString("|", xPos + 32, yPos + 5, markerColor);
    }

}
