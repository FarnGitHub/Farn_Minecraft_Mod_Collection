package cc.noxiuam.titanic.bridge.minecraft.client.gui;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface ScaledResolutionBridge {

    int bridge$getScaledWidth();
    int bridge$getScaledHeight();
    int bridge$getScaleFactor();

}
