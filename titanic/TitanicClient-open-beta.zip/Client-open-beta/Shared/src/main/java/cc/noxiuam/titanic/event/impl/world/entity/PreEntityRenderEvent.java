package cc.noxiuam.titanic.event.impl.world.entity;

import cc.noxiuam.titanic.bridge.minecraft.entity.EntityBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class PreEntityRenderEvent extends AbstractEvent {

    private EntityBridge entity;

}
