package cc.noxiuam.titanic.bridge.minecraft.renderer;

import cc.noxiuam.titanic.bridge.minecraft.entity.EntityBridge;

public interface RenderGlobalBridge {

    void bridge$loadRenderers();

    void bridge$obtainEntitySkin(EntityBridge entity);

}
