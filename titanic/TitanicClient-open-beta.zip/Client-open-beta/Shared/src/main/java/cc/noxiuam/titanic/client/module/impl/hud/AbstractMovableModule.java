package cc.noxiuam.titanic.client.module.impl.hud;

import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.data.ModuleCategory;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.module.data.setting.impl.ChoiceSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.NumberSetting;
import cc.noxiuam.titanic.client.util.ModuleColorRegistry;
import cc.noxiuam.titanic.client.util.chat.ChatColor;
import com.google.common.collect.ImmutableList;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.lwjgl.opengl.GL11;

import java.util.List;

@Setter
@Getter
@Accessors(fluent = true)
public abstract class AbstractMovableModule extends AbstractModule {

    private float x;
    private float y;

    public float defaultX = 0.0f;
    public float defaultY = 0.0f;

    private float width;
    private float height;

    private final ChoiceSetting textColor;

    public final NumberSetting scale;

    public AbstractMovableModule(String id, String name, String description, boolean enabledByDefault, List<MinecraftVersion> supportedVersions) {
        super(id, name, description, enabledByDefault, supportedVersions, ImmutableList.of(ModuleCategory.HUD));

        this.addSettings(
                this.scale = new NumberSetting("scale", "Scale", 1.0D, 0.5D, 1.5D, 0)
        );

        this.textColor = new ChoiceSetting(
                "textColor",
                "Text Color",
                "White",
                "White", "Aqua", "Red", "Gold",
                "Green", "Purple", "Yellow", "Blue",
                "Gray", "Dark Red", "Dark Green", "Dark Purple",
                "Dark Blue", "Dark Aqua", "Dark Gray"
        );
    }

    public AbstractMovableModule(String id, String name, String description, boolean enabledByDefault) {
        super(id, name, description, enabledByDefault, MinecraftVersion.getAllVersions(), ImmutableList.of(ModuleCategory.HUD));

        this.addSettings(
                this.scale = new NumberSetting("scale", "Scale", 1.0D, 0.5D, 1.5D, 0)
        );

        this.textColor = new ChoiceSetting(
                "color",
                "Text Color",
                "White",
                "White", "Aqua", "Red", "Gold",
                "Green", "Purple", "Yellow", "Blue",
                "Gray", "Dark Red", "Dark Green", "Dark Purple",
                "Dark Blue", "Dark Aqua", "Dark Gray"
        );
    }

    public void setDefaultPosition(float defaultX, float defaultY) {
        this.defaultX = defaultX;
        this.defaultY = defaultY;
    }

    public void setPosition(float newX, float newY) {
        this.x = newX;
        this.y = newY;
    }

    public void setSize(float newWidth, float newHeight) {
        this.width = newWidth;
        this.height = newHeight;
    }

    public boolean mouseInside(float mouseX, float mouseY) {
        return mouseX > this.x
                && mouseX < this.x + this.width
                && mouseY > this.y
                && mouseY < this.y + this.height;
    }

    public void resizeToScale() {
        float scale = this.getScale();
        this.width *= scale;
        this.height *= scale;
        GL11.glScalef(scale, scale, scale);
    }

    public float getScale() {
        float scale = 1.0F;
        return this.scale.value().floatValue() * scale;
    }

    public String getPrefixedTextColor() {
        return this.getTextColor().toString();
    }

    public ChatColor getTextColor() {
        return ModuleColorRegistry.TEXT_COLORS.get(this.textColor.value());
    }

}
