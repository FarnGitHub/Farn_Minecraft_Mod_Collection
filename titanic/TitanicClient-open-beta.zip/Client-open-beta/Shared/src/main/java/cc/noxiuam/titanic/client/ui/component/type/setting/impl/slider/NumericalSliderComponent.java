package cc.noxiuam.titanic.client.ui.component.type.setting.impl.slider;

import cc.noxiuam.titanic.client.module.data.setting.impl.NumberSetting;
import cc.noxiuam.titanic.client.ui.component.type.setting.AbstractSettingComponent;
import cc.noxiuam.titanic.client.ui.screen.module.container.module.setting.ModuleSettingsContainer;

public class NumericalSliderComponent extends AbstractSettingComponent<Number> {

    private final SliderComponent slider;

    public NumericalSliderComponent(NumberSetting setting, ModuleSettingsContainer list) {
        super(setting, list);
        this.slider = new SliderComponent(setting);
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(
                this.setting.name(),
                (int) (this.x + 2.0F),
                (int) (this.y),
                -1
        );

        this.slider.position(this.x + this.width - 73, this.y);
        this.slider.size(75, this.height);
        this.slider.draw(mouseX, mouseY);
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        this.slider.mouseClicked(mouseX, mouseY);
    }

    @Override
    public float getHeight() {
        return 14F;
    }

}
