package cc.noxiuam.titanic.bridge.minecraft.client;

public interface GameSettingsBridge {

    boolean bridge$isThirdPersonView();

    void bridge$setThirdPersonView(boolean thirdPersonView);

    float bridge$getMouseSensitivity();

}
