package cc.noxiuam.titanic.bridge.minecraft.network.impl;

import cc.noxiuam.titanic.bridge.minecraft.network.PacketBridge;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface PacketMapChunkBridge extends PacketBridge {
}
