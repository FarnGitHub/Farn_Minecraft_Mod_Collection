package cc.noxiuam.titanic.event.impl.world.player;

import cc.noxiuam.titanic.bridge.minecraft.block.BlockBridge;
import cc.noxiuam.titanic.bridge.minecraft.entity.EntityBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class PlayerBlockCollideEvent extends AbstractEvent {

    private final EntityBridge entity;
    private final BlockBridge block;

}
