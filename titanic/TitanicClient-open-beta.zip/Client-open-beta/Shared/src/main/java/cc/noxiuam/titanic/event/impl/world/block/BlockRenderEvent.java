package cc.noxiuam.titanic.event.impl.world.block;

import cc.noxiuam.titanic.bridge.minecraft.block.BlockBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class BlockRenderEvent extends AbstractEvent {

    private BlockBridge block;

}
