package cc.noxiuam.titanic.client.module.impl.normal.chat;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiChatBridge;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.client.util.ClipboardUtil;
import cc.noxiuam.titanic.client.util.chat.ChatUtil;
import cc.noxiuam.titanic.event.impl.gui.GuiScreenInitEvent;
import cc.noxiuam.titanic.event.impl.gui.chat.*;
import cc.noxiuam.titanic.event.impl.world.TickEvent;
import lombok.Getter;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.util.ArrayList;
import java.util.List;

public class CustomChatHandler {

    private static final Clipboard SYSTEM_CLIPBOARD = Toolkit.getDefaultToolkit().getSystemClipboard();

    @Getter
    private final List<String> chatMessageHistory = new ArrayList<>();

    public int chatMessageIndex = -1;

    public int scrollPos = 0;
    public int cursorPosition = 0;

    private final ChatEditorModule chatMod;

    public CustomChatHandler(ChatEditorModule chatMod) {
        this.chatMod = chatMod;

        this.chatMod.addEvent(ChatLinesDrawEvent.class, event -> {
            if (this.chatMod.getScrolling().value()) {
                event.cancel();
                event.setAmount(this.scrollPos);
            }
        });

        this.chatMod.addEvent(TickEvent.class, this::onTick);

        this.chatMod.addEvent(ChatBackgroundDrawEvent.class, event -> {
            if (!this.chatMod.getChatBackground().value()) {
                event.cancel();
            }
        });

        this.chatMod.addEvent(ChatTextBoxBackgroundDrawEvent.class, event -> {
            if (!this.chatMod.getTextBoxBackground().value()) {
                event.cancel();
            }
        });

        this.chatMod.addEvent(GuiChatKeyTypedEvent.class, this::onChatKeyTyped);
        this.chatMod.addEvent(ChatPositionUpdateEvent.class, this::onSecondChatPositionUpdate);

        this.chatMod.addEvent(GuiChatDrawEvent.class, event -> {
            event.cancel();
            this.drawScreen(event);
        });

        this.chatMod.addEvent(GuiScreenInitEvent.class, event -> {
            if (event.getGuiScreen() instanceof GuiChatBridge) {
                this.onGuiInit();
            }
        });

        this.chatMod.addEvent(ChatTextDrawEvent.class, event -> {
            if (this.chatMod.getStripChatColors().value()) {
                event.cancel();
                event.setMessage(ChatUtil.removeColors(event.getMessage()));
            }
        });
    }

    private void onTick(TickEvent ignored) {
        if (this.chatMod.getScrolling().value()
                && this.chatMod.mc().bridge$getIngameGui() != null
                && BridgeRef.getCurrentScreen() instanceof GuiChatBridge) {

            int mouseWheelPos = Mouse.getDWheel();
            if (mouseWheelPos > 0) {
                if (this.scrollPos <= this.chatMod.mc().bridge$getIngameGui().bridge$getChatMessageList().size() - 8) {
                    this.scrollPos += 2;
                }
            } else if (mouseWheelPos < 0) {
                this.scrollPos -= 2;
                if (this.scrollPos < 0) {
                    this.scrollPos = 0;
                }
            }

        }
    }

    private void onSecondChatPositionUpdate(ChatPositionUpdateEvent event) {
        if (this.chatMod.getScrolling().value()) {
            event.cancel();
            event.setPosition((-event.getFirstPosition() + this.scrollPos) * 9);
        }
    }

    private void onChatKeyTyped(GuiChatKeyTypedEvent event) {
        event.cancel();
        this.keyTyped(event.getCharacter(), event.getKey());
    }

    public void onGuiInit() {
        GuiChatBridge guiChatBridge = ((GuiChatBridge) BridgeRef.getCurrentScreen());
        String message = guiChatBridge.bridge$getChatMessage();

        this.cursorPosition = message.length();
    }

    public void drawScreen(GuiChatDrawEvent event) {
        GuiChatBridge guiChatBridge = ((GuiChatBridge) BridgeRef.getCurrentScreen());
        String message = guiChatBridge.bridge$getChatMessage();

        int screenWidth = event.getGuiChat().bridge$getWidth();
        int screenHeight = event.getGuiChat().bridge$getHeight();

        ChatTextBoxBackgroundDrawEvent textBoxBackgroundDrawEvent = new ChatTextBoxBackgroundDrawEvent();
        Ref.getEventManager().handleEvent(textBoxBackgroundDrawEvent);

        if (!this.chatMod.isShowChat()) {
            this.chatMod.mc().bridge$getFontRenderer().bridge$drawStringWithShadow(
                    "Chat is hidden",
                    4,
                    event.getGuiChat().bridge$getHeight() - 39,
                    0xFF777777
            );
        }

        boolean extendedTextBox = this.chatMod.getExtendedTextBox().value();

        if (!textBoxBackgroundDrawEvent.isCancelled()) {
            RenderUtil.drawRect(2, screenHeight - (extendedTextBox ? 28 : 14), screenWidth - 2, screenHeight - 2, 0x80000000);
        }

        boolean useUnderscoreCursor = this.cursorPosition == message.length();
        String cursor = useUnderscoreCursor ? "_" : "|";
        String messageWithCursor;
        if (!this.chatMod.getExtendedTextBox().value() || message.length() < 70) {
            messageWithCursor = message.substring(0, this.cursorPosition)
                    + (event.getGuiChat().bridge$getUpdateCounter() / 6 % 2 == 0 ? cursor : " ")
                    + message.substring(this.cursorPosition);

            this.chatMod.mc().bridge$getFontRenderer().bridge$drawStringWithShadow("> " + messageWithCursor, extendedTextBox ? 7 : 4, screenHeight - (extendedTextBox ? 24 : 12), 14737632);
        } else {
            messageWithCursor = message.substring(0, this.cursorPosition)
                    + (event.getGuiChat().bridge$getUpdateCounter() / 6 % 2 == 0 ? cursor : " ")
                    + message.substring(this.cursorPosition);

            int b = messageWithCursor.substring(0, 70).lastIndexOf(" ");
            String chatLine1;
            String chatLine2;
            if (messageWithCursor.length() - b <= 70) {
                chatLine1 = messageWithCursor.substring(0, b);
                chatLine2 = messageWithCursor.substring(b);
            } else {
                chatLine1 = messageWithCursor.substring(0, 70);
                chatLine2 = messageWithCursor.substring(70);
            }

            this.chatMod.mc().bridge$getFontRenderer().bridge$drawStringWithShadow("> " + chatLine1, 7, screenHeight - 24, 14737632);
            this.chatMod.mc().bridge$getFontRenderer().bridge$drawStringWithShadow("   " + chatLine2, 4, screenHeight - 12, 14737632);
        }
    }

    public void keyTyped(char character, int key) {
        GuiChatBridge guiChatBridge = ((GuiChatBridge) BridgeRef.getCurrentScreen());

        if (guiChatBridge == null) {
            return;
        }

        String message = guiChatBridge.bridge$getChatMessage();

        if (key == Keyboard.KEY_LEFT && this.cursorPosition > 0) {
            --this.cursorPosition;
        } else if (key == Keyboard.KEY_RIGHT && this.cursorPosition < message.length()) {
            ++this.cursorPosition;
        }

        if (key == 200 && this.chatMod.getChatHistory().value()) {
            this.updateCurrentMessageFromHistory(-1);
            return;
        } else if (key == 208 && this.chatMod.getChatHistory().value()) {
            this.updateCurrentMessageFromHistory(1);
            return;
        }

        String str;
        int cursorPos;

        if (character == 22) {
            str = ClipboardUtil.getClipboardString();
            if (str == null) {
                str = "";
            }

            cursorPos = 140 - message.length();
            if (cursorPos > str.length()) {
                cursorPos = str.length();
            }

            if (cursorPos > 0) {
                guiChatBridge.bridge$setChatMessage(message.substring(0, this.cursorPosition)
                        + str.substring(0, cursorPos) + message.substring(this.cursorPosition));
                this.cursorPosition += cursorPos;
            }

            this.checkCursor();
        } else if (character == 3 && this.chatMod.getPasting().value()) {
            this.copy(message);
        } else if (key == 1) {
            this.scrollPos = 0;
            this.cursorPosition = 0;
            this.chatMessageIndex = this.chatMessageHistory.size();
            this.chatMod.mc().bridge$displayGuiScreen(null);
            scrollPos = 0;
        } else if (key != 28 && key != 156) {
            if (key == 14 && message.length() > 0 && this.cursorPosition > 0) {
                guiChatBridge.bridge$setChatMessage(message.substring(0, this.cursorPosition - 1)
                        + message.substring(this.cursorPosition));
                --this.cursorPosition;
            }

            if (Bridge.getInstance().bridge$getFontAllowedChars().bridge$getAllowedCharacters().indexOf(character) >= 0
                    && message.length() < 100) {
                guiChatBridge.bridge$setChatMessage(message.substring(0, this.cursorPosition)
                        + character + message.substring(this.cursorPosition));
                ++this.cursorPosition;
            }

        } else if (key == 28) {
            String trimmedChatMessage = message.trim();
            if (trimmedChatMessage.length() > 0) {
                Bridge.getInstance().bridge$getMinecraft().bridge$getThePlayer().bridge$sendChatMessage(trimmedChatMessage);
            }
            this.chatMod.mc().bridge$displayGuiScreen(null);
        }
    }

    public void updateCurrentMessageFromHistory(int increaseAmount) {
        GuiChatBridge guiChatBridge = ((GuiChatBridge) BridgeRef.getCurrentScreen());

        int newIndex = this.chatMessageIndex + increaseAmount;
        int historySize = this.chatMessageHistory.size();

        if (newIndex < 0) {
            newIndex = 0;
        }

        if (newIndex > historySize) {
            newIndex = historySize;
        }

        if (newIndex != this.chatMessageIndex) {
            String empty = "";
            if (newIndex == historySize) {
                this.chatMessageIndex = historySize;
                guiChatBridge.bridge$setChatMessage(empty);
            } else {
                if (this.chatMessageIndex == historySize) {
                    guiChatBridge.bridge$setChatMessage(empty);
                }

                guiChatBridge.bridge$setChatMessage(chatMessageHistory.get(newIndex));
                this.chatMessageIndex = newIndex;
            }
        }

        this.cursorPosition = guiChatBridge.bridge$getChatMessage().length();
    }

    private void copy(String contents) {
        try {
            StringSelection stringSelection = new StringSelection(contents);
            SYSTEM_CLIPBOARD.setContents(stringSelection, null);
        } catch (Exception ignored) {}
    }

    private void checkCursor() {
        GuiChatBridge guiChatBridge = ((GuiChatBridge) BridgeRef.getCurrentScreen());
        String message = guiChatBridge.bridge$getChatMessage();

        if (this.cursorPosition > message.length()) {
            this.cursorPosition = message.length();
        }

        if (this.cursorPosition < 0) {
            this.cursorPosition = 0;
        }
    }

}
