package cc.noxiuam.titanic.client.module.impl.fix.impl;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.entity.EntityBridge;
import cc.noxiuam.titanic.bridge.minecraft.entity.EntityPlayerBridge;
import cc.noxiuam.titanic.client.module.impl.fix.AbstractFixModule;
import cc.noxiuam.titanic.client.network.manager.PlayerProfileManager;
import cc.noxiuam.titanic.client.network.cosmetic.PlayerProfile;
import cc.noxiuam.titanic.client.util.HttpUtil;
import cc.noxiuam.titanic.client.util.MojangUtil;
import cc.noxiuam.titanic.event.impl.network.ObtainEntitySkinEvent;
import cc.noxiuam.titanic.event.impl.network.ReleaseEntitySkinEvent;
import cc.noxiuam.titanic.event.impl.world.player.PlayerLoadEvent;
import lombok.Getter;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Fixes/edits the following: Skins, Capes
 */
@Getter
public class PlayerAssetFix extends AbstractFixModule {

    private final PlayerProfileManager playerProfileManager = Ref.getProfileManager();

    private final Map<String, String> playerSkinCache = new LinkedHashMap<>();
    private final Map<String, String> playerCapeCache = new LinkedHashMap<>();

    public PlayerAssetFix() {
        super("Player Asset Fix");
        this.addEvent(PlayerLoadEvent.class, event -> new Thread(() -> this.fixPlayerAssets(event)).start());
        this.addEvent(ObtainEntitySkinEvent.class, this::onObtainEntityAssets);
        this.addEvent(ReleaseEntitySkinEvent.class, this::onReleaseEntityAssets);
    }

    private void onObtainEntityAssets(ObtainEntitySkinEvent event) {
        if (event.getEntity() instanceof EntityPlayerBridge) {
            EntityPlayerBridge player = ((EntityPlayerBridge) event.getEntity());
            String username = player.bridge$getUsername();

            if (this.playerProfileManager.profileExists(username)) {
                PlayerProfile profile = this.playerProfileManager.getProfile(username);

                if (profile.getNametagIcon() != null) {
                    Bridge.getInstance()
                            .bridge$getMinecraft()
                            .bridge$getRenderEngine()
                            .bridge$obtainImageData(
                                    profile.getNametagIcon().getIconUrl(),
                                    Bridge.getInstance().bridge$createImageBufferDownload()
                            );
                }
            }
        }
    }

    private void onReleaseEntityAssets(ReleaseEntitySkinEvent event) {
        if (event.getEntity() instanceof EntityPlayerBridge) {
            EntityPlayerBridge player = ((EntityPlayerBridge) event.getEntity());
            String username = player.bridge$getUsername();

            if (this.playerProfileManager.profileExists(username)) {
                PlayerProfile profile = this.playerProfileManager.getProfile(username);

                if (profile.getNametagIcon() != null) {
                    Bridge.getInstance()
                            .bridge$getMinecraft()
                            .bridge$getRenderEngine()
                            .bridge$releaseImageData(profile.getNametagIcon().getIconUrl());
                }
            }
        }
    }

    /**
     * Fixes player skins & applies custom capes, also has RetroMC cape support.
     */
    private void fixPlayerAssets(PlayerLoadEvent event) {
        EntityPlayerBridge player = event.getPlayer();
        String username = player.bridge$getUsername();
        String retroCapeUrl = "http://assets.retromc.org/capes/" + username + ".png";

        String skinUrl = MojangUtil.getTextureUrl(username, "SKIN");
        String capeUrl = MojangUtil.getTextureUrl(username, "CAPE");

        this.playerSkinCache.put(username, skinUrl);

        player.bridge$setSkinURL(this.playerSkinCache.get(username));

        // retro first, vanilla needs to override.
        if (HttpUtil.isValidURL(retroCapeUrl)) {
            player.bridge$setCapeURL(retroCapeUrl);
        }

        // not everyone has a cape.
        if (capeUrl != null) {
            this.playerCapeCache.put(username, capeUrl);
            player.bridge$setCapeURL(this.playerCapeCache.get(username));
        }

        if (this.playerProfileManager.profileExists(username)) {
            PlayerProfile playerProfile = this.playerProfileManager.getProfile(username);
            if (playerProfile.getCosmetic().isEquipped()) {
                player.bridge$setCapeURL(playerProfile.getCosmetic().getLocation());
            }
        }

        if (BridgeRef.getMinecraft().bridge$getRenderGlobal() != null) {
            BridgeRef.getMinecraft()
                    .bridge$getRenderGlobal()
                    .bridge$obtainEntitySkin((EntityBridge) player);
        }
    }

}