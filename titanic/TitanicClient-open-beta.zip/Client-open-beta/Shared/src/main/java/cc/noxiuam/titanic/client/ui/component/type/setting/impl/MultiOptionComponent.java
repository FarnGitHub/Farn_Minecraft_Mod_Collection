package cc.noxiuam.titanic.client.ui.component.type.setting.impl;

import cc.noxiuam.titanic.client.module.data.setting.impl.ChoiceSetting;
import cc.noxiuam.titanic.client.ui.component.type.button.RoundedTextButton;
import cc.noxiuam.titanic.client.ui.screen.module.container.module.setting.ModuleSettingsContainer;
import cc.noxiuam.titanic.client.ui.component.type.setting.AbstractSettingComponent;

import cc.noxiuam.titanic.client.util.SoundUtil;

public class MultiOptionComponent extends AbstractSettingComponent<String> {

    private final ChoiceSetting setting;

    private final RoundedTextButton leftButton = new RoundedTextButton("<");
    private final RoundedTextButton rightButton = new RoundedTextButton(">");

    public MultiOptionComponent(ChoiceSetting setting, ModuleSettingsContainer list) {
        super(setting, list);
        this.setting = setting;
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(
                this.setting.name(),
                (int) (this.x + 2.0F),
                (int) (this.y),
                -1
        );

        this.leftButton.size(12, 12);
        this.leftButton.position(this.x + this.width - 80, this.y);
        this.leftButton.draw(mouseX, mouseY);

        this.mc.bridge$getFontRenderer().bridge$drawCenteredString(
                this.setting.value(),
                (int) (this.x + this.width - 38),
                (int) (this.y + 2),
                -1,
                true
        );

        this.rightButton.size(12, 12);
        this.rightButton.position(this.x + this.width - 10, this.y);
        this.rightButton.draw(mouseX, mouseY);
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        int length = this.setting.getAcceptedValues().length;

        if (this.leftButton.mouseInside(mouseX, mouseY)) {
            SoundUtil.playClick();
            for (int i = 0; i < length; ++i) {
                if (!this.setting.getAcceptedValues()[i].toLowerCase().equalsIgnoreCase(this.setting.value())) {
                    continue;
                }

                if (i - 1 < 0) {
                    this.setting.value(((String[]) this.setting.getAcceptedValues())[length - 1]);
                    break;
                }

                this.setting.value(((String[]) this.setting.getAcceptedValues())[i - 1]);
            }
        }

        if (this.rightButton.mouseInside(mouseX, mouseY)) {
            SoundUtil.playClick();
            for (int i = 0; i < length; ++i) {
                if (!this.setting.getAcceptedValues()[i].toLowerCase().equalsIgnoreCase(this.setting.value())) {
                    continue;
                }

                if (i + 1 >= length) {
                    this.setting.value(this.setting.getAcceptedValues()[0]);
                    break;
                }

                this.setting.value(this.setting.getAcceptedValues()[i + 1]);
                break;
            }
        }
    }

    @Override
    public float getHeight() {
        return 10;
    }

}
