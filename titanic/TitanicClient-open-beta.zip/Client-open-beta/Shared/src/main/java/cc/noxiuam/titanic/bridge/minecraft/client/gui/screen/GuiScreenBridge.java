package cc.noxiuam.titanic.bridge.minecraft.client.gui.screen;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiButtonBridge;

import java.util.List;

public interface GuiScreenBridge extends GuiBridge {

    default int bridge$getWidth() {
        return Bridge.getInstance()
                .bridge$getMinecraft()
                .bridge$getCurrentScreen()
                .bridge$getWidth();
    }

    default int bridge$getHeight() {
        return Bridge.getInstance()
                .bridge$getMinecraft()
                .bridge$getCurrentScreen()
                .bridge$getHeight();
    }

    void bridge$initGui();

    void bridge$drawScreen(int mouseX, int mouseY, float partialTicks);

    void bridge$mouseClicked(int mouseX, int mouseY, int button);

    default void bridge$actionPerformed(GuiButtonBridge button) {}

    default void bridge$updateScreen() {}

    default void bridge$onGuiClosed() {}

    default void bridge$drawDefaultBackground() {
        BridgeRef.getCurrentScreen().bridge$drawDefaultBackground();
    }

    default void bridge$keyTyped(char c, int n) {}

    default void bridge$mouseMovedOrUp(int mouseX, int mouseY, int button) {}

    default boolean bridge$shouldDrawWatermark() {
        return false;
    }

    default List<GuiButtonBridge> bridge$getButtonList() {
        return BridgeRef.getCurrentScreen().bridge$getButtonList();
    }

}
