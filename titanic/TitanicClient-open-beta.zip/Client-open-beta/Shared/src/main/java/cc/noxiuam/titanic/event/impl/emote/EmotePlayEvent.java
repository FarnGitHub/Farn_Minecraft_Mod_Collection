package cc.noxiuam.titanic.event.impl.emote;

import cc.noxiuam.titanic.event.AbstractEvent;

/**
 * @author Noxiuam
 * https://noxiuam.cc
 */
public class EmotePlayEvent extends AbstractEvent {
}
