package cc.noxiuam.titanic.client.ui.screen.friend.component;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import cc.noxiuam.titanic.client.registry.Friend;
import cc.noxiuam.titanic.client.ui.component.AbstractComponent;
import cc.noxiuam.titanic.client.ui.component.type.button.RoundedTextButton;
import cc.noxiuam.titanic.client.ui.component.type.text.TextBoxComponent;
import cc.noxiuam.titanic.client.ui.screen.friend.FriendsListScreen;
import cc.noxiuam.titanic.client.ui.transition.impl.ColorTransition;
import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.client.util.RenderEngineUtil;
import cc.noxiuam.titanic.client.util.chat.ChatUtil;
import lombok.Getter;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

@Getter
public class FriendComponent extends AbstractComponent {

    private static final String BASE_SKIN_URL = "https://mineskin.eu/helm/";

    private final ColorTransition outlineColor = new ColorTransition(0x00000000, 0xCCC2C2C2);
    private final ColorTransition backgroundColor = new ColorTransition(0x80292929, 0xBF121212);
    private final ColorTransition enabledOutline = new ColorTransition(0x00000000, 0xFF1471FF);

    private final Friend friend;

    public boolean selected;

    private final RoundedTextButton removeButton = new RoundedTextButton("x");

    public final TextBoxComponent nicknameBox = new TextBoxComponent("Nickname...");

    public FriendComponent(Friend friend) {
        this.friend = friend;
//        this.removeButton.setYOffset(1);
        this.nicknameBox.setMaxLength(19);

        this.nicknameBox.setText(this.friend.getNickname());
    }

    @Override
    public void handleUpdate() {
        this.nicknameBox.handleUpdate();
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        int texture = RenderEngineUtil.getTextureInt(BASE_SKIN_URL + this.getFriend().getUsername(), "/titanic/icons/steve.png");

        RenderUtil.drawRoundedRect(
                this.x,
                this.y,
                this.x + this.width,
                this.y + this.height,
                5,
                this.backgroundColor.getColor((!this.nicknameBox.mouseInside(mouseX, mouseY) && this.selected) && !this.removeButton.mouseInside(mouseX, mouseY) && mouseInside(mouseX, mouseY)).getRGB()
        );

        if (this.selected) {
            this.nicknameBox.position(this.x + 3, this.y + this.height - 16);
            this.nicknameBox.size(126, 12);
            this.nicknameBox.draw(mouseX, mouseY);
        }

        RenderUtil.drawRoundedOutline(
                this.x,
                this.y,
                this.x + this.width,
                this.y + this.height,
                5.0F,
                3.0F,
                this.selected
                        ? this.enabledOutline.getColor(true).getRGB()
                        : this.outlineColor.getColor(!this.removeButton.mouseInside(mouseX, mouseY) && mouseInside(mouseX, mouseY)).getRGB()
        );

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        if (texture >= 0) {
            RenderUtil.drawIconFromInt(
                    texture,
                    (int) this.x + 2,
                    (int) this.y + 2,
                    12,
                    12
            );
        }

        if (this.selected) {
            this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(
                    this.friend.getUsername(),
                    (int) this.x + 17,
                    (int) this.y + 4,
                    -1
            );
        } else {
            this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(
                    this.friend.getPreferredName(),
                    (int) this.x + 17,
                    (int) this.y + 4,
                    -1
            );
        }

        this.removeButton.position(this.x + this.width - 15, this.y + 2);
        this.removeButton.size(12, 12);
        this.removeButton.draw(mouseX, mouseY);
    }

    @Override
    public void keyTyped(char character, int key) {
        if (this.nicknameBox.using && this.selected) {
            if (key == Keyboard.KEY_RETURN) {
                this.updateNickname();
                return;
            }
            this.nicknameBox.keyTyped(character, key);
        }
    }

    @Override
    public void mouseClicked(float mouseX, float mouseY) {
        if (!this.nicknameBox.using && this.selected && this.nicknameBox.mouseInside(mouseX, mouseY)) {
            this.nicknameBox.mouseClicked(mouseX, mouseY);
        } else {
            this.nicknameBox.using = false;
        }
    }

    private void updateNickname() {
        Friend friend = this.friend;
        String newNickname = this.nicknameBox.getText();

        if (newNickname.length() == 0
                || newNickname.equals(friend.getUsername())) {
            friend.setNickname("");
            ChatUtil.addChatMessage("Reset " + friend.getUsername() + (friend.getUsername().toLowerCase().endsWith("s") ? "'" : "'s") + " nickname.");
        } else {
            friend.setNickname(newNickname);
            ChatUtil.addChatMessage("Updated " + friend.getUsername() + (friend.getUsername().toLowerCase().endsWith("s") ? "'" : "'s") + " nickname to " + newNickname + ".");
        }

        GuiScreenBridge screen = Bridge.getInstance().bridge$initCustomGuiScreen(new FriendsListScreen());
        this.mc.bridge$displayGuiScreen(screen);
    }

}
