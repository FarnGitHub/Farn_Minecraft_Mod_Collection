package cc.noxiuam.titanic.client.util;

import cc.noxiuam.titanic.kotlin.client.logger.Logger;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lombok.experimental.UtilityClass;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
@UtilityClass
public class MojangUtil {

    private final Logger LOGGER = new Logger("Mojang Utility");

    public String getTextureUrl(String username, String type) {
        JsonObject decodedTextures = getDecodedTextures(username);

        if (decodedTextures == null) {
            return "";
        }

        JsonObject textures = decodedTextures.get("textures").getAsJsonObject();

        if (textures.get(type) == null) {
            return null;
        }

        return textures.get(type).getAsJsonObject().get("url").getAsString();
    }

    /**
     * Gets the decoded textures object that contains a player's skin/cape.
     * <p></p>
     * @param username - the name to get
     */
    public JsonObject getDecodedTextures(String username) {
        URL apiURL;
        URL sessionURL;

        try {
            // start minecraft profile
            apiURL = new URL("https://api.mojang.com/users/profiles/minecraft/" + username);
            HttpURLConnection connection = (HttpURLConnection) apiURL.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();

            int responseCode = connection.getResponseCode();

            if (responseCode != 200) {
                LOGGER.debug("There was a problem getting the skin for \"" + username + "\"");
            } else {
                BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                JsonObject profile = new JsonParser().parse(br).getAsJsonObject();
                connection.disconnect();

                // start session profile
                String id = profile.get("id").getAsString();
                sessionURL = new URL("https://sessionserver.mojang.com/session/minecraft/profile/" + id);
                connection = (HttpURLConnection) sessionURL.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();

                br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                JsonObject finalProfile = new JsonParser().parse(br).getAsJsonObject();
                connection.disconnect();

                JsonArray properties = finalProfile.get("properties").getAsJsonArray();

                String encodedTextures = properties.get(0).getAsJsonObject().get("value").getAsString();
                String decodedTextures = new String(Base64.getDecoder().decode(encodedTextures.getBytes()));

                return new JsonParser().parse(decodedTextures).getAsJsonObject();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

}
