package cc.noxiuam.titanic.client.network.cosmetic.type.emote;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.minecraft.entity.EntityPlayerBridge;
import cc.noxiuam.titanic.bridge.minecraft.model.ModelBipedBridge;
import cc.noxiuam.titanic.client.module.impl.normal.perspective.PerspectiveView;
import cc.noxiuam.titanic.client.ui.transition.AbstractTransition;
import lombok.Getter;

/**
 * @author Noxiuam
 * https://noxiuam.cc
 */
@Getter
public abstract class AbstractEmote {

    protected final AbstractTransition duration;

    public AbstractEmote(AbstractTransition duration) {
        this.duration = duration;
        duration.startTransition();
    }

    public abstract void playEmote(EntityPlayerBridge player, ModelBipedBridge modelBiped, float partialTicks);

    public abstract void tickEmote(EntityPlayerBridge player, float partialTicks);

    public boolean isDone() {
        return this.duration.isOver();
    }

    protected void stopPlaying(EntityPlayerBridge player) {
        if (player == null) {
            return;
        }

        if (player == Bridge.getInstance().bridge$getMinecraft().bridge$getThePlayer()) {
            if (Ref.getEmoteManager().isThePlayerPerformingEmote()) {
                Bridge.getInstance().bridge$getGameSettings().bridge$setThirdPersonView(false);

                if (Ref.getModuleManager().getPerspectiveModule().enabled()) {
                    Ref.getModuleManager().getPerspectiveModule().currentPerspective = PerspectiveView.FIRST;
                }

                Ref.getEmoteManager().setThePlayerPerformingEmote(false);
            }
        }
    }

}
