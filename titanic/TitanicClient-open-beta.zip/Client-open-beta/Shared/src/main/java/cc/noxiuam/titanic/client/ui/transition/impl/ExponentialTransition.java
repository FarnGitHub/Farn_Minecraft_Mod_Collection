package cc.noxiuam.titanic.client.ui.transition.impl;

/**
 * @author - CheatBreaker, LLC
 */
public class ExponentialTransition extends FloatTransition {

    public ExponentialTransition(long duration) {
        super(duration);
    }

    @Override
    public float getValue() {
        float value = super.getValue();
        return (float) Math.pow(value * (2.0f - value), 1.0);
    }

}
