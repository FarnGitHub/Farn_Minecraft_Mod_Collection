package cc.noxiuam.titanic.client.network.cosmetic.type.emote.support.impl;

import cc.noxiuam.titanic.client.network.cosmetic.type.emote.EmoteManager;

import java.util.regex.Pattern;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public class A1_1_2AlphaPlaceEmoteSupport extends EmoteManager.AbstractEmoteSupport {

    private final Pattern messagePattern = Pattern.compile("\\[(?<rank>.+)] (?<name>.+): (?<emote>.+).*");

    @Override
    public String getServerID() {
        return "alphaplace";
    }

    @Override
    public Pattern getPattern() {
        return this.messagePattern;
    }

}
