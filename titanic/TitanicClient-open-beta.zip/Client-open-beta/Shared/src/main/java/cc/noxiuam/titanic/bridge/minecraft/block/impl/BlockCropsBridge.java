package cc.noxiuam.titanic.bridge.minecraft.block.impl;

public interface BlockCropsBridge {
}
