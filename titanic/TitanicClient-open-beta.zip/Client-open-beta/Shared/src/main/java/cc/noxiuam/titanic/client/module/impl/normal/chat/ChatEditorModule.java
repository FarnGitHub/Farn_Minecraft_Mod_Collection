package cc.noxiuam.titanic.client.module.impl.normal.chat;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiChatBridge;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.data.ModuleCategory;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.registry.Friend;
import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.client.util.chat.ChatColor;
import cc.noxiuam.titanic.client.util.chat.ChatUtil;
import cc.noxiuam.titanic.event.impl.chat.ChatReceivedEvent;
import cc.noxiuam.titanic.event.impl.gui.HotbarRenderEvent;
import cc.noxiuam.titanic.event.impl.gui.chat.ChatDrawEvent;
import cc.noxiuam.titanic.event.impl.keyboard.KeyboardEvent;
import com.google.common.collect.ImmutableList;
import lombok.Getter;

@Getter
public class ChatEditorModule extends AbstractModule {

    private boolean showChat = true;

    /*private final KeybindSetting toggleChatKeybind;*/
    private final BooleanSetting
            hideChat,
            chatHistory,
            textBoxBackground,
            chatBackground,
            extendedTextBox,
            scrolling,
            pasting,
            hideHotbarWhileTyping,
            autoAcceptFriendTeleports,
            stripChatColors;

    private final CustomChatHandler customChatHandler = new CustomChatHandler(this);

    public ChatEditorModule() {
        super(
                "chatEditor",
                "Chat Editor",
                "Quality of life chat features, bundled into one mod.",
                false,
                MinecraftVersion.getAllVersions(),
                ImmutableList.of(
                        ModuleCategory.CHAT
                )
        );

        this.addSettings(
//                this.toggleChatKeybind = new KeybindSetting("toggleChatKeybind", "Toggle Chat", 0),
                this.hideChat = new BooleanSetting("hideChat", "Hide Chat", false),
                this.chatHistory = new BooleanSetting("chatHistory", "Message History", false),
                this.chatBackground = new BooleanSetting("chatBackground", "Chat Background", true),
                this.textBoxBackground = new BooleanSetting("textBoxBackground", "Text Box Background", true),
                this.extendedTextBox = new BooleanSetting("extendedTextBox", "Extended Text Box", false),
                this.scrolling = new BooleanSetting("scrolling", "Chat Scrolling", false),
                this.pasting = new BooleanSetting("pasting", "Clipboard Pasting", false),
                this.hideHotbarWhileTyping = new BooleanSetting("hideHotbarWhileTyping", "Hide Hotbar While Typing", true),
                this.autoAcceptFriendTeleports = new BooleanSetting("autoAcceptFriendTeleports", "Auto Accept Friend Teleports", false),
                this.stripChatColors = new BooleanSetting("stripChatColors", "Strip Colors", false)
        );

        this.scrolling.description("Allows you to scroll on previous chat messages.");
        this.pasting.description("Allows you to paste text into the chat box.");
        this.stripChatColors.description("Allows you to remove most colors from the chat.");
        this.extendedTextBox.description("Makes the text box taller and makes the display two lines.");

        this.chatHistory.description("Allows you to go back to previously sent messages.");
        this.hideHotbarWhileTyping.description("This is useful since the chat is obstructive.");

        this.hideChat.onUpdate(value -> this.showChat = !this.hideChat.value());

        this.addEvent(HotbarRenderEvent.class, this::onHotbarRender);
        this.addEvent(ChatReceivedEvent.class, this::onChatReceived);
        this.addEvent(ChatDrawEvent.class, this::onChatDraw);
        this.addEvent(KeyboardEvent.class, this::keyTyped);
    }

    private void keyTyped(KeyboardEvent event) {
        int key = event.getKey();

//        if (key == this.toggleChatKeybind.value()) {
//            this.showChat = !this.showChat;
//        }
    }

    private void onChatReceived(ChatReceivedEvent event) {
        String message = ChatUtil.removeColors(event.getMessage());
        if (this.autoAcceptFriendTeleports.value()) {
            if (event.getMessage().toLowerCase().endsWith(ChatColor.RED + " has requested to teleport to you.")
                    && Ref.MC_VERSION == MinecraftVersion.B1_1_02) {
                for (Friend friend : Ref.getFriendManager().getFriends()) {
                    if (message.contains(friend.getPreferredName())) {
                        Bridge.getInstance().bridge$getMinecraft().bridge$getThePlayer().bridge$sendChatMessage("/tpaccept");
                    }
                }
            }

            if (event.getMessage().toLowerCase().endsWith("type /a to accept")
                    && Ref.MC_VERSION == MinecraftVersion.A1_1_2_01) {
                for (Friend friend : Ref.getFriendManager().getFriends()) {
                    if (message.contains(friend.getPreferredName())) {
                        Bridge.getInstance().bridge$getMinecraft().bridge$getThePlayer().bridge$sendChatMessage("/a");
                    }
                }
            }

        }
    }

    private void onChatDraw(ChatDrawEvent event) {
        if (!this.showChat) {
            this.mc.bridge$getFontRenderer().bridge$drawStringWithShadow(
                    "Chat is hidden",
                    4,
                    event.getScaledResolution().bridge$getScaledHeight() - 24,
                    0xFF777777
            );
            event.cancel();
        }
    }

    private void onHotbarRender(HotbarRenderEvent event) {
        if (this.hideHotbarWhileTyping.value() && BridgeRef.getCurrentScreen() instanceof GuiChatBridge) {
            event.cancel();
        }
    }

}
