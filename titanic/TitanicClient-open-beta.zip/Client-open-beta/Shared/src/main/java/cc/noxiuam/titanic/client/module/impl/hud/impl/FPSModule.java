package cc.noxiuam.titanic.client.module.impl.hud.impl;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.client.module.impl.hud.AbstractMovableModule;

import cc.noxiuam.titanic.client.ui.util.RenderUtil;
import cc.noxiuam.titanic.event.impl.gui.GuiDrawEvent;
import org.apache.commons.lang3.StringUtils;
import org.lwjgl.opengl.GL11;

public class FPSModule extends AbstractMovableModule {

    private final BooleanSetting showBackground;

    public FPSModule() {
        super("fps", "FPS", "Shows your current frames per second.", false);

        this.addSettings(
                this.textColor(),
                this.showBackground = new BooleanSetting("showBackground", "Show Background", true)
        );

        this.addEvent(GuiDrawEvent.class, this::draw);
    }

    private void draw(GuiDrawEvent event) {
        GL11.glPushMatrix();

        String text = this.getPrefixedTextColor() + StringUtils.substringBefore(
                Bridge.getInstance().bridge$getMinecraft().bridge$getDebug(), " fps, "
        ) + " FPS";

        if (!this.showBackground.value()) {
            text = this.getPrefixedTextColor() + "[" + text + "]";
        }

        if (this.showBackground.value()) {
            this.setSize(56, 18);
            RenderUtil.drawRect(
                    this.x(),
                    this.y(),
                    this.x() + this.width(),
                    this.y() + this.height(),
                    0x6F000000
            );
        } else {
            this.setSize(this.mc.bridge$getFontRenderer().bridge$getStringWidth(text) + 5, 13);
        }

        this.resizeToScale();

        this.mc.bridge$getFontRenderer().bridge$drawCenteredString(
                text,
                (int) (this.x() + this.width() / 2F) + 1,
                (int) this.y() + (this.showBackground.value() ? 6 : 3),
                -1,
                true
        );

        GL11.glPopMatrix();
    }

}
