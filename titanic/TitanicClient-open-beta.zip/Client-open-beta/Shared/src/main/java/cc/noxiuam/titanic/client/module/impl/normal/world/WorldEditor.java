package cc.noxiuam.titanic.client.module.impl.normal.world;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.block.impl.BlockDoorBridge;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.data.ModuleCategory;
import cc.noxiuam.titanic.client.module.impl.normal.world.lighting.SmoothRenderBlocks;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.ChoiceSetting;
import cc.noxiuam.titanic.event.impl.world.CloudRenderEvent;
import cc.noxiuam.titanic.event.impl.world.PacketTimeUpdateEvent;
import cc.noxiuam.titanic.event.impl.world.block.RenderBlocksInitEvent;
import cc.noxiuam.titanic.event.impl.world.lighting.ItemBlockRenderEvent;
import cc.noxiuam.titanic.event.impl.world.lighting.RenderBlockByRenderTypeEvent;
import cc.noxiuam.titanic.event.impl.world.lighting.WorldRendererUpdateEvent;
import com.google.common.collect.ImmutableList;
import lombok.Getter;

import java.util.Collections;

@Getter
public class WorldEditor extends AbstractModule {

    private final ChoiceSetting currentTime;
    private final BooleanSetting hideClouds, smoothLighting;

    private BooleanSetting fancyGrass;

    private SmoothRenderBlocks renderBlocks;

    public WorldEditor() {
        super(
                "worldEditor",
                "World Editor",
                "Time Changer & Weather Changer built into one.",
                false,
                MinecraftVersion.getAllVersions(),
                Collections.emptyList()
        );

        this.addSettings(
                this.currentTime = new ChoiceSetting(
                        "currentTime",
                        "Current Time",
                        "Server",
                        "Server", "Morning", "Noon", "Evening", "Dusk", "Midnight", "Dawn"
                ),
                this.hideClouds = new BooleanSetting("hideClouds", "Hide Clouds", false)
        );

        this.smoothLighting = new BooleanSetting("smoothLighting", "Smooth Lighting", false);
        this.smoothLighting.description("Adds a smooth lighting effect for the world.");

        // Smooth lighting does not seem to work for a1.1.2_01, which is sad.
        if (Ref.MC_VERSION.isAboveOrEqual(MinecraftVersion.A1_1_2_01)) {
            this.addSettings(
                    this.smoothLighting
            );
        }

        this.fancyGrass = new BooleanSetting("fancyGrass", "Fancy Grass", false);
        this.fancyGrass.description("Adds the correct color to the sides of grass blocks.");
        this.fancyGrass.onUpdate(value -> {
            if (Bridge.getInstance().bridge$getMinecraft().bridge$getRenderGlobal() != null) {
                Bridge.getInstance().bridge$getMinecraft().bridge$getRenderGlobal().bridge$loadRenderers();
            }
        });

        if (Ref.MC_VERSION.isAboveOrEqual(MinecraftVersion.A1_2_6)
                && Ref.MC_VERSION.isBelowOrEqual(MinecraftVersion.B1_5_01)) {
            this.addSettings(
                    this.fancyGrass
            );
        }

        this.currentTime.description("Currently only works in Multiplayer.");

        this.smoothLighting.onUpdate(value -> {
            if (BridgeRef.getMinecraft().bridge$getRenderGlobal() != null) {
                BridgeRef.getMinecraft().bridge$getRenderGlobal().bridge$loadRenderers();
            }
        });

        Ref.getEventManager().addEvent(RenderBlocksInitEvent.class, renderBlocksInitEvent ->
                this.renderBlocks = new SmoothRenderBlocks(renderBlocksInitEvent.getBlockAccess())
        );

        this.addEvent(WorldRendererUpdateEvent.class, event -> {
            if (this.smoothLighting.value()) {
                event.cancel();
            }
        });

        this.addEvent(RenderBlockByRenderTypeEvent.class, event -> {
            if (this.smoothLighting.value()) {
                event.cancel();
                event.setFlag(
                        this.renderBlocks.renderBlockByRenderType(
                                event.getBlock(),
                                event.getBlockX(),
                                event.getBlockY(),
                                event.getBlockZ()
                        )
                );
            }
        });

        this.addEvent(ItemBlockRenderEvent.class, event -> {
            if (this.smoothLighting.value() && !(event.getBlock() instanceof BlockDoorBridge)) {
                event.cancel();
                this.renderBlocks.a(event.getBlock(), event.getRenderType());
            }
        });

        this.addEvent(CloudRenderEvent.class, event -> {
            if (this.hideClouds.value()) {
                event.cancel();
            }
        });

        this.addEvent(PacketTimeUpdateEvent.class, this::updateTime);
    }

    private void updateTime(PacketTimeUpdateEvent event) {
        if (!this.currentTime.value().equalsIgnoreCase("Server")) {
            event.cancel();
        }

        if (this.currentTime.value().equalsIgnoreCase("Morning")) {
            Bridge.getInstance().bridge$getTheWorld().bridge$setWorldTime(1484567587);
        } else if (this.currentTime.value().equalsIgnoreCase("Noon")) {
            Bridge.getInstance().bridge$getTheWorld().bridge$setWorldTime(1484549927);
        } else if (this.currentTime.value().equalsIgnoreCase("Evening")) {
            Bridge.getInstance().bridge$getTheWorld().bridge$setWorldTime(1484556647);
        } else if (this.currentTime.value().equalsIgnoreCase("Dusk")) {
            Bridge.getInstance().bridge$getTheWorld().bridge$setWorldTime(1484557647);
        } else if (this.currentTime.value().equalsIgnoreCase("Midnight")) {
            Bridge.getInstance().bridge$getTheWorld().bridge$setWorldTime(1484561967);
        } else if (this.currentTime.value().equalsIgnoreCase("Dawn")) {
            Bridge.getInstance().bridge$getTheWorld().bridge$setWorldTime(1484566587);
        }
    }

    @Override
    public void onToggle() {
        BridgeRef.getMinecraft().bridge$getRenderGlobal().bridge$loadRenderers();
    }

}
