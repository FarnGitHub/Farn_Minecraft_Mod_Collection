package cc.noxiuam.titanic.event.impl.network;

import cc.noxiuam.titanic.bridge.minecraft.network.PacketBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class PacketReceivedEvent extends AbstractEvent {

    private PacketBridge packet;

}