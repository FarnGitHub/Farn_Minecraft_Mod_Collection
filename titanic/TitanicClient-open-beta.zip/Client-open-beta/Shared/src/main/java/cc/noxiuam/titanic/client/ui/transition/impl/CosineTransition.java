package cc.noxiuam.titanic.client.ui.transition.impl;

/**
 * @author - CheatBreaker, LLC
 */
public class CosineTransition extends FloatTransition {

    public CosineTransition(long duration) {
        super(duration, 0.0f);
    }

    @Override
    protected float getValue() {
        float value = super.getValue();
        float f2 = value * 2.0f - 1.0f;
        return (float) (Math.cos((double) f2 * Math.PI) + 1.0) / 2.0f;
    }

}
