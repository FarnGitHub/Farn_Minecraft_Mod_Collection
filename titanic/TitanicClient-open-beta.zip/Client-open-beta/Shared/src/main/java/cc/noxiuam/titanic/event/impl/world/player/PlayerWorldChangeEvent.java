package cc.noxiuam.titanic.event.impl.world.player;

import cc.noxiuam.titanic.bridge.minecraft.client.WorldBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class PlayerWorldChangeEvent extends AbstractEvent {

    private final WorldBridge prevWorld;
    private final WorldBridge newWorld;

}
