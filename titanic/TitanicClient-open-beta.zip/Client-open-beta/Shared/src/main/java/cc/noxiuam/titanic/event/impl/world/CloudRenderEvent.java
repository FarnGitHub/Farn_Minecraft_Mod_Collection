package cc.noxiuam.titanic.event.impl.world;

import cc.noxiuam.titanic.event.AbstractEvent;

public class CloudRenderEvent extends AbstractEvent {
}
