package cc.noxiuam.titanic.client.network.manager.friend;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.client.registry.Friend;
import cc.noxiuam.titanic.client.util.JsonUtil;
import cc.noxiuam.titanic.kotlin.client.logger.Logger;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lombok.Getter;
import lombok.SneakyThrows;

import java.io.FileReader;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

@Getter
public class FriendManager {

    private static final Logger LOGGER = new Logger("Friend Management");

    private final List<Friend> friends = new CopyOnWriteArrayList<>();

    @SneakyThrows
    public void loadFriends() {
        JsonParser parser = new JsonParser();

        try {
            parser.parse(
                    new FileReader(Ref.getConfigManager().getFriendsConfig())
            ).getAsJsonObject();
        } catch (IllegalStateException ignored) {
            return;
        }

        JsonObject friendsObject = parser.parse(
                new FileReader(Ref.getConfigManager().getFriendsConfig())
        ).getAsJsonObject();

        for (Map.Entry<String, JsonElement> entry : friendsObject.entrySet()) {
            if (entry.getValue().getAsJsonObject().get("username") == null
                    || entry.getValue().getAsJsonObject().get("nickname") == null) {
                continue;
            }

            JsonObject obj = entry.getValue().getAsJsonObject();
            String username = obj.get("username").getAsString();
            String nickname = obj.get("nickname").getAsString();

            if (username != null) {
                Bridge.getInstance()
                        .bridge$getMinecraft()
                        .bridge$getRenderEngine()
                                .bridge$obtainImageData(
                                        "https://mineskin.eu/helm/" + username,
                                        Bridge.getInstance().bridge$createImageBufferDownload()
                                );
            }

            Ref.getFriendManager().getFriends().add(new Friend(username, nickname));
        }

        LOGGER.info("Loaded " + Ref.getFriendManager().getFriends().size() + " friends");
    }

    @SneakyThrows
    public void saveFriends() {
        List<Friend> friends = Ref.getFriendManager().getFriends();
        JsonObject friendsObject = new JsonObject();

        for (Friend friend : friends) {
            friend.save(friendsObject);
        }

        JsonUtil.writeToFile(Ref.getConfigManager().getFriendsConfig(), friendsObject, true);
    }

    public Friend getFriendByNameOrUsername(String query) {
        for (Friend friend : this.friends) {
            if (friend.getUsername().equalsIgnoreCase(query)
                    || friend.getNickname().equalsIgnoreCase(query)) {
                return friend;
            }
        }

        return null;
    }

    public Friend getFriendByUsername(String targetUsername) {
        for (Friend friend : this.friends) {
            if (friend.getUsername().equalsIgnoreCase(targetUsername)) {
                return friend;
            }
        }

        return null;
    }

    /**
     * Checks if a certain player is your friend.
     * <p>
     *
     * @param username The target username
     */
    public boolean isFriend(String username) {
        for (Friend friend : this.friends) {
            if (friend.getUsername().equalsIgnoreCase(username)
                    || friend.getNickname().equalsIgnoreCase(username)) {
                return true;
            }
        }
        return false;
    }

}
