package cc.noxiuam.titanic.client.network.cosmetic.type.emote.data;

/**
 * @author Noxiuam
 * https://noxiuam.cc
 */
public enum ModelRenderStage {
    START,
    END
}
