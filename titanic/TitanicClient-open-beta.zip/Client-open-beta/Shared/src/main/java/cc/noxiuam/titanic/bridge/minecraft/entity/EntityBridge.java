package cc.noxiuam.titanic.bridge.minecraft.entity;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface EntityBridge {

    boolean bridge$isDead();

}
