package cc.noxiuam.titanic.client.ui.screen.friend;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import cc.noxiuam.titanic.client.registry.Friend;
import org.lwjgl.input.Keyboard;

public class FriendsListScreen implements GuiScreenBridge {

    private final FriendListWrapper friendList = new FriendListWrapper();

    @Override
    public void bridge$initGui() {
        this.friendList.size(150, this.bridge$getHeight());
        this.friendList.position(0, 0);
        Keyboard.enableRepeatEvents(true);

        for (Friend friend : Ref.getFriendManager().getFriends()) {
            String username = friend.getUsername();
            if (username != null) {

                Bridge.getInstance()
                        .bridge$getMinecraft()
                        .bridge$getRenderEngine()
                        .bridge$obtainImageData(
                                "https://mineskin.eu/helm/" + username,
                                Bridge.getInstance().bridge$createImageBufferDownload()
                        );

            }
        }
    }

    @Override
    public void bridge$drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.bridge$drawDefaultBackground();
        this.friendList.draw(mouseX, mouseY);
    }

    @Override
    public void bridge$onGuiClosed() {
        GuiScreenBridge.super.bridge$onGuiClosed();
        Ref.getConfigManager().saveConfigs();
        Keyboard.enableRepeatEvents(false);
    }

    @Override
    public void bridge$updateScreen() {
        GuiScreenBridge.super.bridge$updateScreen();
        this.friendList.handleUpdate();
    }

    @Override
    public void bridge$mouseClicked(int mouseX, int mouseY, int button) {
        this.friendList.mouseClicked(mouseX, mouseY);
    }

    @Override
    public void bridge$keyTyped(char c, int n) {
        GuiScreenBridge.super.bridge$keyTyped(c, n);
        this.friendList.keyTyped(c, n);
    }

}
