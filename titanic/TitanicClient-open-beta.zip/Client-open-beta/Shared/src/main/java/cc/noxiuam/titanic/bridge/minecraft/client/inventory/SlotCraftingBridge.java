package cc.noxiuam.titanic.bridge.minecraft.client.inventory;

public interface SlotCraftingBridge {
}
