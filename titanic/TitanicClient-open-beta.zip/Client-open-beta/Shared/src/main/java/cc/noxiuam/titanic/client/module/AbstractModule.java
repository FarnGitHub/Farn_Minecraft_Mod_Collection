package cc.noxiuam.titanic.client.module;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.minecraft.client.MinecraftBridge;
import cc.noxiuam.titanic.client.module.data.ModuleCategory;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.module.data.setting.AbstractSetting;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

@Getter
@Setter
@Accessors(fluent = true)
public abstract class AbstractModule {

    protected final MinecraftBridge mc = Bridge.getInstance().bridge$getMinecraft();

    private final List<AbstractSetting<?>> settings;

    private final Map<Class<? extends AbstractEvent>, Consumer> activeEvents = new HashMap<>();

    private final String id;
    private final String name;
    private final String description;

    private boolean enabled;
    private final boolean enabledByDefault;

    private final List<MinecraftVersion> supportedVersions;
    private final List<ModuleCategory> categories;

    public AbstractModule(
            String id,
            String name,
            String description,
            boolean enabledByDefault,
            List<MinecraftVersion> supportedVersions,
            List<ModuleCategory> categories
    ) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.enabledByDefault = enabledByDefault;
        if (enabledByDefault) {
            this.enabled = true;
        }
        this.settings = new CopyOnWriteArrayList<>();
        this.supportedVersions = supportedVersions;
        this.categories = categories;
    }

    public <T extends AbstractEvent> void addEvent(Class<T> eventClass, Consumer<T> consumer) {
        this.activeEvents.put(eventClass, consumer);
    }

    public void addAllEvents() {
        for (Map.Entry<Class<? extends AbstractEvent>, Consumer> entry : this.activeEvents.entrySet()) {
            Ref.getEventManager().addEvent((Class<? extends AbstractEvent>) entry.getKey(), entry.getValue());
        }
    }

    protected void removeAllEvents() {
        for (Map.Entry<Class<? extends AbstractEvent>, Consumer> entry : this.activeEvents.entrySet()) {
            Ref.getEventManager().removeEvent((Class<? extends AbstractEvent>) entry.getKey(), entry.getValue());
        }
    }

    /**
     * Handles toggling of the module.
     */
    public void toggle() {
        this.enabled = !this.enabled;
        this.onToggle();

        if (this.enabled) {
            this.addAllEvents();
            this.onEnable();
        } else {
            this.removeAllEvents();
            this.onDisable();
        }
    }

    /**
     * What to do when the mod is enabled.
     */
    public void onEnable() { }

    /**
     * What to do when the mod is disabled.
     */
    public void onDisable() { }

    /**
     * What to do when the mod is generally toggled.
     */
    public void onToggle() { }

    /**
     * Adds a new setting to the mod's list.
     * <p>
     * @param settings A list of settings, or just one.
     */
    public void addSettings(AbstractSetting<?>... settings) {
        Collections.addAll(this.settings, settings);
    }

    /**
     * In the event we need to write special configs for 3rd party mods.
     */
    public void writeModuleConfig() { }

}
