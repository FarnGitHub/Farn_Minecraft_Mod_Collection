package cc.noxiuam.titanic.bridge.minecraft.network.impl;

import cc.noxiuam.titanic.bridge.minecraft.network.PacketBridge;

public interface PacketTimeBridge extends PacketBridge {
}
