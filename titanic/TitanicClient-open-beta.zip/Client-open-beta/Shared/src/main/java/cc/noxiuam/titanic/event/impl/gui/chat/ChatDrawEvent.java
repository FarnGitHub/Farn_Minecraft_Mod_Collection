package cc.noxiuam.titanic.event.impl.gui.chat;

import cc.noxiuam.titanic.bridge.minecraft.client.gui.ScaledResolutionBridge;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ChatDrawEvent extends AbstractEvent {

    private ScaledResolutionBridge scaledResolution;

}
