package cc.noxiuam.titanic.bridge.minecraft.client.gui.screen;

import cc.noxiuam.titanic.bridge.minecraft.client.gui.chat.ChatLineBridge;

import java.util.List;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface GuiIngameBridge {

    List<ChatLineBridge> bridge$getChatMessageList();

    void bridge$addChatMessage(String message);

}
