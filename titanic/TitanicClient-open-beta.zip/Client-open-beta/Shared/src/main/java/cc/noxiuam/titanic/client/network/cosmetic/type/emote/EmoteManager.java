package cc.noxiuam.titanic.client.network.cosmetic.type.emote;

import cc.noxiuam.titanic.Ref;
import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.minecraft.entity.EntityPlayerBridge;
import cc.noxiuam.titanic.client.network.cosmetic.type.emote.AbstractEmote;
import cc.noxiuam.titanic.client.network.cosmetic.type.emote.data.ModelRenderStage;
import cc.noxiuam.titanic.client.network.cosmetic.type.emote.impl.Wave;
import cc.noxiuam.titanic.client.network.cosmetic.type.emote.support.EmoteSupportManager;
import cc.noxiuam.titanic.client.registry.Friend;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.util.chat.ChatUtil;
import cc.noxiuam.titanic.event.impl.chat.ChatReceivedEvent;
import cc.noxiuam.titanic.event.impl.chat.ChatSendEvent;
import cc.noxiuam.titanic.event.impl.emote.EmotePlayEvent;
import cc.noxiuam.titanic.event.impl.mouse.ClickEvent;
import cc.noxiuam.titanic.event.impl.world.TickEvent;
import cc.noxiuam.titanic.event.impl.world.player.model.ModelRenderEvent;
import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.ImmutableBiMap;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
@Getter
@Setter
public class EmoteManager {

    private final Map<EntityPlayerBridge, AbstractEmote> runningEmotes = new ConcurrentHashMap<>();

    private final EmoteSupportManager emoteSupportManager;

    private boolean isThePlayerPerformingEmote;

    public static final BiMap<String, Class<? extends AbstractEmote>> EMOTE_REGISTRY = HashBiMap.create();

    public EmoteManager() {
        EMOTE_REGISTRY.put(":wave:", Wave.class);

        this.emoteSupportManager = new EmoteSupportManager();

        Ref.getEventManager().addEvent(TickEvent.class, this::onTick);
        Ref.getEventManager().addEvent(ModelRenderEvent.class, this::onModelRender);
        Ref.getEventManager().addEvent(ClickEvent.class, event -> {
            if (event.getMouseButton() == 0) {
                this.stopEmote(Bridge.getInstance().bridge$getMinecraft().bridge$getThePlayer());
            }
        });

        Ref.getEventManager().addEvent(ChatSendEvent.class, event -> {
            AbstractEmote emote = this.getEmote(event.getMessage());

            if (emote != null) {
                this.playEmote(Bridge.getInstance().bridge$getMinecraft().bridge$getThePlayer(), emote);
            }
        });

        Ref.getEventManager().addEvent(ChatReceivedEvent.class, event -> {
            Matcher matcher;
            String message = ChatUtil.removeColors(event.getMessage());

            AbstractEmoteSupport currentServer = null;
            if (Bridge.getInstance().bridge$getMinecraft().bridge$isMultiplayerWorld()) {
                currentServer = this.emoteSupportManager.getCurrentServerSupport();
            }

            if (currentServer != null && (matcher = currentServer.getPattern().matcher(message)).matches()) {
                String name = matcher.group("name");
                String emoteName = matcher.group("emote");

                AbstractEmote emote = this.getEmote(emoteName);

                if (Ref.getFriendManager().isFriend(name)) {
                    Friend friendByNameOrUsername = Ref.getFriendManager().getFriendByNameOrUsername(name);
                    EntityPlayerBridge player = this.getPlayerFromWorldByName(friendByNameOrUsername.getUsername());

                    if (player != null && emote != null) {
                        this.playEmote(player, emote);
                    }
                }
            }
        });
    }

    public void playEmote(EntityPlayerBridge player, AbstractEmote emote) {
        EmotePlayEvent event = new EmotePlayEvent();
        Ref.getEventManager().handleEvent(event);

        if (event.isCancelled()) {
            return;
        }

        if (player.bridge$getUsername().equals(Bridge.getInstance().bridge$getMinecraft().bridge$getThePlayer().bridge$getUsername())) {
            if (!Bridge.getInstance().bridge$getGameSettings().bridge$isThirdPersonView()) {
                Bridge.getInstance().bridge$getGameSettings().bridge$setThirdPersonView(true);
                this.isThePlayerPerformingEmote = true;
            }

        }
        this.runningEmotes.putIfAbsent(player, emote);
    }

    public void stopEmote(EntityPlayerBridge player) {
        if (this.runningEmotes.containsKey(player)) {
            AbstractEmote activeEmote = this.runningEmotes.get(player);
            activeEmote.stopPlaying(player);
            this.runningEmotes.remove(player);
        }
    }

    private void onModelRender(ModelRenderEvent event) {
        AbstractEmote playerActiveEmote = this.runningEmotes.get(event.getPlayer());

        if (playerActiveEmote != null) {
            if (event.getStage() == ModelRenderStage.START) {
                playerActiveEmote.playEmote(event.getPlayer(), event.getModel(), event.getPartialTicks());
            } else {
                playerActiveEmote.tickEmote(event.getPlayer(), event.getPartialTicks());
            }
        }
    }

    private void onTick(TickEvent event) {
        if (!this.runningEmotes.isEmpty()) {
            ArrayList<EntityPlayerBridge> list = new ArrayList<>();
            this.runningEmotes.forEach((player, emote) -> {
                EntityPlayerBridge entity = this.getPlayerFromWorld(player);
                if (emote.isDone() && entity != null && entity.bridge$getUsername() != null && this.runningEmotes.containsKey(entity)) {
                    runningEmotes.remove(entity);
                    emote.stopPlaying(entity);
                    list.add(player);
                }
            });
            list.forEach(this.runningEmotes::remove);
        }
    }

    private EntityPlayerBridge getPlayerFromWorldByName(String targetUsername) {
        for (EntityPlayerBridge player : Bridge.getInstance().bridge$getTheWorld().bridge$getPlayerEntities()) {
            if (player.bridge$getUsername().equals(targetUsername)) {
                return player;
            }
        }

        return null;
    }

    private EntityPlayerBridge getPlayerFromWorld(EntityPlayerBridge target) {
        for (EntityPlayerBridge player : Bridge.getInstance().bridge$getTheWorld().bridge$getPlayerEntities()) {
            if (target.bridge$getUsername().equals(player.bridge$getUsername())) {
                return player;
            }
        }

        return null;
    }

    public AbstractEmote getEmote(String name) {
        if (!EMOTE_REGISTRY.containsKey(name)) {
            return null;
        } else {
            try {
                return ((Class<? extends AbstractEmote>) EMOTE_REGISTRY.get(name)).newInstance();
            } catch (Exception var3) {
                var3.printStackTrace();
                return null;
            }
        }
    }

    /**
     * @author Noxiuam
     * <a href="https://noxiuam.cc">...</a>
     */
    public abstract static class AbstractEmoteSupport {

        public abstract String getServerID();

        public abstract Pattern getPattern();

    }
}
