package cc.noxiuam.titanic.client.module.impl.normal.perspective;

import cc.noxiuam.titanic.bridge.Bridge;
import cc.noxiuam.titanic.bridge.BridgeRef;
import cc.noxiuam.titanic.bridge.minecraft.MathHelper;
import cc.noxiuam.titanic.bridge.minecraft.entity.EntityPlayerBridge;
import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.module.data.ModuleCategory;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.module.data.setting.impl.BooleanSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.KeybindSetting;
import cc.noxiuam.titanic.client.module.data.setting.impl.NumberSetting;
import cc.noxiuam.titanic.event.AbstractEvent;
import cc.noxiuam.titanic.event.impl.keyboard.KeyboardEvent;
import cc.noxiuam.titanic.event.impl.perspective.CameraChangeEvent;
import cc.noxiuam.titanic.event.impl.perspective.ViewBobbingSetupEvent;
import cc.noxiuam.titanic.event.impl.world.PerspectiveUpdateEvent;
import cc.noxiuam.titanic.event.impl.world.fov.PreFOVUpdateEvent;
import com.google.common.collect.ImmutableList;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.util.Collections;

public class PerspectiveModule extends AbstractModule {

    public PerspectiveView currentPerspective = PerspectiveView.FIRST;

    private final KeybindSetting switchPerspectiveKeybind;

    private final BooleanSetting viewBobbingInThirdPerson, bobScreen, bobHand;
    private final NumberSetting cameraFov/*, handFov*/;

    public float rotationYaw;
    public float prevRotationYaw;
    public float rotationPitch;
    public float prevRotationPitch;

    public PerspectiveModule() {
        super(
                "perspectiveBundle",
                "Perspective",
                "Backports modern third person view & FOV options.",
                true,
                MinecraftVersion.getAllVersions(),
                Collections.emptyList()
        );

        this.addSettings(
                this.switchPerspectiveKeybind = new KeybindSetting("switchPerspectiveKeybind", "Switch Perspective", Keyboard.KEY_F5),
                this.viewBobbingInThirdPerson = new BooleanSetting("viewBobbingInThirdPerson", "Third Person View Bobbing", false),
                this.cameraFov = new NumberSetting("cameraFov", "Camera FOV", 70, 50, 100, 0),
                /*this.handFov = new NumberSetting("handFov", "Hand FOV", 70, 30, 120, 0),*/
                this.bobScreen = new BooleanSetting("bobScreen", "Bob Screen", true),
                this.bobHand = new BooleanSetting("bobHand", "Bob Hand", true)
        );

        this.viewBobbingInThirdPerson.description("In Vanilla, you can not see view bobbing in third person.");

        this.addEvent(PreFOVUpdateEvent.class, this::updateFOV);
        this.addEvent(CameraChangeEvent.class, this::getModernCamera);
        this.addEvent(KeyboardEvent.class, this::keyTyped);
        this.addEvent(ViewBobbingSetupEvent.class, this::onViewBob);
        this.addEvent(PerspectiveUpdateEvent.class, AbstractEvent::cancel);
    }

    private void keyTyped(KeyboardEvent event) {
        if (event.getKey() == switchPerspectiveKeybind.value()) {
            if (currentPerspective == PerspectiveView.FIRST) {
                currentPerspective = PerspectiveView.SECOND;
                BridgeRef.getGameSettings().bridge$setThirdPersonView(true);
            } else if (currentPerspective == PerspectiveView.SECOND) {
                currentPerspective = PerspectiveView.THIRD;
                BridgeRef.getGameSettings().bridge$setThirdPersonView(true);
            } else if (currentPerspective == PerspectiveView.THIRD) {
                currentPerspective = PerspectiveView.FIRST;
                BridgeRef.getGameSettings().bridge$setThirdPersonView(false);
            }
        }
    }

    private void onViewBob(ViewBobbingSetupEvent event) {
        event.cancel();
        setupViewBobbing(event.getValue(), event.getType());
    }

    private void updateFOV(PreFOVUpdateEvent event) {
        event.setFov(this.cameraFov.value().floatValue());
    }

    private void setupViewBobbing(float f, String type) {
        if (!this.viewBobbingInThirdPerson.value()
                && BridgeRef.getGameSettings().bridge$isThirdPersonView()) {
            return;
        }

        EntityPlayerBridge player = Bridge.getInstance().bridge$getMinecraft().bridge$getThePlayer();
        float distanceWalked = player.bridge$getDistanceWalkedModified() - player.bridge$getPrevDistanceWalkedModified();
        float multipliedWalked = player.bridge$getDistanceWalkedModified() + distanceWalked * f;
        float f2 = player.bridge$getPrevCameraYaw() + (player.bridge$getCameraYaw() - player.bridge$getPrevCameraYaw()) * f;
        float f3 = player.bridge$getPrevCameraPitch() + (player.bridge$getCameraPitch() - player.bridge$getPrevCameraPitch()) * f;

        if (!this.bobScreen.value() && type.equalsIgnoreCase("screen")) {
            return;
        }

        if (!this.bobHand.value() && type.equalsIgnoreCase("hand")) {
            return;
        }

        GL11.glTranslatef(MathHelper.sin(multipliedWalked * 3.141593F) * f2 * 0.5F, -Math.abs(MathHelper.cos(multipliedWalked * 3.141593F) * f2), 0.0F);
        GL11.glRotatef(MathHelper.sin(multipliedWalked * 3.141593F) * f2 * 3F, 0.0F, 0.0F, 1.0F);
        GL11.glRotatef(Math.abs(MathHelper.cos(multipliedWalked * 3.141593F + 0.2F) * f2) * 5F, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(f3, 1.0F, 0.0F, 0.0F);
    }

    private void getModernCamera(CameraChangeEvent event) {
        event.cancel();

        if (currentPerspective == PerspectiveView.THIRD) {
            event.setPitch(event.getPitch() + 180F);
        }

        if (currentPerspective == PerspectiveView.THIRD) {
            GL11.glRotatef(180F, 0.0F, 1.0F, 0.0F);
        }
    }

}