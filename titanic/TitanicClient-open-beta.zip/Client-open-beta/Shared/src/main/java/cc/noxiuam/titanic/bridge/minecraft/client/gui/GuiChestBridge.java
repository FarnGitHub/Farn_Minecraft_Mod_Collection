package cc.noxiuam.titanic.bridge.minecraft.client.gui;

import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface GuiChestBridge extends GuiScreenBridge {
}
