package cc.noxiuam.titanic.event.impl.chat;

import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ChatReceivedEvent extends AbstractEvent {

    public String message;

}
