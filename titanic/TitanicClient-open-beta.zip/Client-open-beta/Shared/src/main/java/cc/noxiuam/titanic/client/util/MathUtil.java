package cc.noxiuam.titanic.client.util;

import lombok.experimental.UtilityClass;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
@UtilityClass
public class MathUtil {

    private static final double[] SIN_TABLE = new double[8192];

    public int floor_double(double d) {
        int i = (int) d;
        return d < (double) i ? i - 1 : i;
    }

    public static double sin(final double n) {
        return cos(n - 1.5707963267948966);
    }

    public static double cos(final double n) {
        int n2 = (int)(n / 6.283185307179586 % 1.0 * 16384.0);
        if (n2 < 0) {
            n2 += 16384;
        }
        if (n2 >= 8192) {
            return -SIN_TABLE[n2 - 8192];
        }
        return SIN_TABLE[n2];
    }

    static {
        for (int i = 0; i < 8192; ++i) {
            SIN_TABLE[i] = Math.cos(i / 8192.0f * 3.141592653589793);
        }
    }

}
