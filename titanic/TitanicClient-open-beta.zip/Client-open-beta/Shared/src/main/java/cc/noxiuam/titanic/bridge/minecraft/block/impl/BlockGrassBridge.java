package cc.noxiuam.titanic.bridge.minecraft.block.impl;

import cc.noxiuam.titanic.bridge.minecraft.block.BlockBridge;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public interface BlockGrassBridge extends BlockBridge {
}
