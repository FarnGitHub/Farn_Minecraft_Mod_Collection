package cc.noxiuam.titanic.client.module.impl.fix;

import cc.noxiuam.titanic.client.module.AbstractModule;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.client.util.CaseUtils;
import com.google.common.collect.ImmutableList;

import java.util.Arrays;

public abstract class AbstractFixModule extends AbstractModule {

    public AbstractFixModule(String name) {
        super(
                CaseUtils.toCamelCase(name, false),
                name,
                "No Description.",
                true,
                MinecraftVersion.getAllVersions(),
                ImmutableList.of()
        );
    }

}