package cc.noxiuam.titanic.client.util.chat;

import com.google.common.collect.Maps;
import lombok.Getter;

import java.util.Map;

public enum ChatColor {

    BLACK('0', 0x00, 0xFF000000, 0x20000000),
    DARK_BLUE('1', 0x1, 0xFF0000AA, 0x200000AA),
    DARK_GREEN('2', 0x2, 0xFF00AA00, 0x2000AA00),
    DARK_AQUA('3', 0x3, 0xFF00AAAA, 0x2000AAAA),
    DARK_RED('4', 0x4, 0xFFAA0000, 0x20AA0000),
    DARK_PURPLE('5', 0x5, 0xFFAA00AA, 0x20AA00AA),
    GOLD('6', 0x6, 0xFFFFAA00, 0x20FFAA00),
    GRAY('7', 0x7, 0xFFAAAAAA, 0x20AAAAAA),
    DARK_GRAY('8', 0x8, 0xFF555555, 0x20555555),
    BLUE('9', 0x9, 0xFF5555FF, 0x205555FF),
    GREEN('a', 0xA, 0xFF55FF55, 0x2055FF55),
    AQUA('b', 0xB, 0xFF55FFFF, 0x2055FFFF),
    RED('c', 0xC, 0xFFFF5555, 0x20FF5555),
    LIGHT_PURPLE('d', 0xD, 0xFFFF55FF, 0x20FF55FF),
    YELLOW('e', 0xE, 0xFFFFFF55, 0x20FFFF55),
    WHITE('f', 0xF, -1, 0x20FFFFFF),
    RESET('r', 0x15, -1, 0x20FFFFFF);

    public static final char COLOR_CHAR = '\u00A7';
    private final static Map<Integer, ChatColor> BY_ID = Maps.newHashMap();
    private final static Map<Character, ChatColor> BY_CHAR = Maps.newHashMap();

    static {
        for (ChatColor color : values()) {
            BY_ID.put(color.intCode, color);
            BY_CHAR.put(color.code, color);
        }
    }

    @Getter
    private final int intCode;
    @Getter
    private final int solidColor;
    @Getter
    private final int sneakColor;
    private final char code;
    private final boolean isFormat;
    private final String toString;

    ChatColor(char code, int intCode, int solidColor, int sneakColor) {
        this(code, intCode, solidColor, sneakColor, false);
    }

    ChatColor(char code, int intCode, int solidColor, int sneakColor, boolean isFormat) {
        this.code = code;
        this.intCode = intCode;
        this.solidColor = solidColor;
        this.sneakColor = sneakColor;
        this.isFormat = isFormat;
        this.toString = new String(new char[]{COLOR_CHAR, code});
    }

    public char getChar() {
        return code;
    }

    @Override
    public String toString() {
        return toString;
    }

    public boolean isColor() {
        return !isFormat && this != RESET;
    }

}
