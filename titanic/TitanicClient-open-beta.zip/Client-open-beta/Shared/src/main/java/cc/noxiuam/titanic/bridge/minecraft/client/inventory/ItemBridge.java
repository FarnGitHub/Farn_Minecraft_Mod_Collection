package cc.noxiuam.titanic.bridge.minecraft.client.inventory;

public interface ItemBridge {

    int bridge$getShiftedIndex();

}
