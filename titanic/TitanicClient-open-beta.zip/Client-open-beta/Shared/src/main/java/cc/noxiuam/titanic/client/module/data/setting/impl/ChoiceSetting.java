package cc.noxiuam.titanic.client.module.data.setting.impl;

import cc.noxiuam.titanic.client.module.data.setting.AbstractSetting;
import cc.noxiuam.titanic.client.ui.screen.module.container.module.setting.ModuleSettingsContainer;
import cc.noxiuam.titanic.client.ui.component.type.setting.AbstractSettingComponent;
import cc.noxiuam.titanic.client.ui.component.type.setting.impl.MultiOptionComponent;
import com.google.gson.JsonObject;
import lombok.Getter;

@Getter
public class ChoiceSetting extends AbstractSetting<String> {

    private final String[] acceptedValues;

    public ChoiceSetting(String id, String name, String defaultValue, String... acceptedValues) {
        super(id, name, defaultValue);
        this.acceptedValues = acceptedValues;
    }

    @Override
    public AbstractSettingComponent<String> getComponent(ModuleSettingsContainer list) {
        return new MultiOptionComponent(this, list);
    }

    @Override
    public void save(JsonObject configObject) {
        configObject.addProperty(this.id(), this.value());
    }

    @Override
    public void load(JsonObject configObject) {
        String value = configObject.get(this.id()).getAsString();

        if (!this.isOptionValid(value)) {
            this.value(this.defaultValue());
            return;
        }

        this.value(value);
    }

    /**
     * Checks if the loaded value is valid or not.
     * <p>
     * @param optionToFind - the option it has to find or else it will reset the setting.
     * @return - is it valid?
     */
    public boolean isOptionValid(String optionToFind) {
        for (String value : this.acceptedValues) {
            if (value.equals(optionToFind)) {
                return true;
            }
        }
        return false;
    }

}
