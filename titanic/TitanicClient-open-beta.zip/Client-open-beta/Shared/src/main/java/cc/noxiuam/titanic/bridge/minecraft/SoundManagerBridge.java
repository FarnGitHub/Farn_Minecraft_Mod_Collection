package cc.noxiuam.titanic.bridge.minecraft;

public interface SoundManagerBridge {

    void bridge$playSound(String sound, float volume, float pitch);

}
