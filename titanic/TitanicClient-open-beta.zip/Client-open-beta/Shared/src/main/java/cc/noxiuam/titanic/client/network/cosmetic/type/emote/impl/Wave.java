package cc.noxiuam.titanic.client.network.cosmetic.type.emote.impl;

import cc.noxiuam.titanic.bridge.minecraft.entity.EntityPlayerBridge;
import cc.noxiuam.titanic.bridge.minecraft.model.ModelBipedBridge;
import cc.noxiuam.titanic.client.network.cosmetic.type.emote.AbstractEmote;
import cc.noxiuam.titanic.client.ui.transition.impl.CosineTransition;
import cc.noxiuam.titanic.client.ui.transition.impl.FloatTransition;

/**
 * @author Noxiuam
 * https://noxiuam.cc
 */
public class Wave extends AbstractEmote {

    private final FloatTransition name = new FloatTransition(250L);
    private final FloatTransition resourceLoc = new FloatTransition(250L);
    private final CosineTransition waveTransitionTime = new CosineTransition(500L);

    public Wave() {
        super(new FloatTransition(2000L));
        this.name.startTransition();
    }

    @Override
    public void playEmote(EntityPlayerBridge player, ModelBipedBridge modelBiped, float partialTicks) {
        float nameFadeAmount = 1.0F;
        float waveFadeAmount = 0.5F;

        if (this.name.getDuration() > this.duration.getUsedTime()) {
            nameFadeAmount = this.name.getFadeAmount();
        } else if (this.duration.getRemainingTime() <= this.resourceLoc.getDuration()) {
            if (!this.resourceLoc.hasStarted()) {
                this.resourceLoc.startTransition();
            }

            nameFadeAmount = 1.0F - this.resourceLoc.getFadeAmount();
        } else {
            if (!this.waveTransitionTime.hasStarted()) {
                this.waveTransitionTime.startTransitionFromPoint(125.0F);
                this.waveTransitionTime.loopAnimation();
            }

            waveFadeAmount = this.waveTransitionTime.getFadeAmount();
        }

        modelBiped.bridge$getLeftArm().bridge$setRotateAngleX((float) Math.toRadians(-150.0F * nameFadeAmount));
        modelBiped.bridge$getLeftArm().bridge$setRotateAngleZ((float) Math.toRadians(40.0F * waveFadeAmount - 20.0F));
    }

    @Override
    public void tickEmote(EntityPlayerBridge player, float partialTicks) {
    }

}
