package cc.noxiuam.titanic.client.ui.screen.module.component.data;

import cc.noxiuam.titanic.client.ui.component.type.setting.AbstractSettingComponent;
import lombok.Getter;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Getter
public class SettingPage {

    public final List<AbstractSettingComponent<?>> settingComponents = new CopyOnWriteArrayList<>();

}
