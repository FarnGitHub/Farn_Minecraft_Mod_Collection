package cc.noxiuam.titanic.event.impl.world.player.model;

import cc.noxiuam.titanic.bridge.minecraft.entity.EntityPlayerBridge;
import cc.noxiuam.titanic.bridge.minecraft.model.ModelBipedBridge;
import cc.noxiuam.titanic.client.network.cosmetic.type.emote.data.ModelRenderStage;
import cc.noxiuam.titanic.event.AbstractEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Noxiuam
 * https://noxiuam.cc
 */
@Getter
@AllArgsConstructor
public class ModelRenderEvent extends AbstractEvent {

    private final ModelRenderStage stage;

    private final EntityPlayerBridge player;

    private final ModelBipedBridge model;

    private final float partialTicks;

}

