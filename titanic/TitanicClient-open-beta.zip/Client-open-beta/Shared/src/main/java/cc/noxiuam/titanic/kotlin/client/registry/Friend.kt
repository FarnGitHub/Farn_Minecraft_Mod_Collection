package cc.noxiuam.titanic.kotlin.client.registry

import cc.noxiuam.titanic.client.registry.AbstractLoadable
import cc.noxiuam.titanic.client.util.CaseUtils
import com.google.gson.JsonObject

class Friend(private var username: String, private var nickname: String) : AbstractLoadable() {

    override fun save(obj: JsonObject?) {
        obj!!.add(
                CaseUtils.toCamelCase(username, false),
                serialized
        )
    }

    override fun load(obj: JsonObject?) {
        // Loading done via friend manager.
    }

    override fun getSerialized(): JsonObject {
        val friendObject = JsonObject()
        friendObject.addProperty("username", username)
        friendObject.addProperty("nickname", nickname)
        return friendObject
    }

    fun getPreferredName(): String {
        return nickname.ifEmpty { username }
    }

    // manual for now
    fun getUsername() : String {
        return username
    }

    fun getNickname() : String {
        return nickname
    }

}