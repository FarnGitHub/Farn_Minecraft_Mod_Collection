package cc.noxiuam.titanic.bridge.minecraft.client.gui;

import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;

public interface GuiChatBridge extends GuiScreenBridge {

    default String bridge$getDefaultMessage() {
        return "";
    }

    void bridge$setChatMessage(String msg);

    String bridge$getChatMessage();

    int bridge$getUpdateCounter();

}
