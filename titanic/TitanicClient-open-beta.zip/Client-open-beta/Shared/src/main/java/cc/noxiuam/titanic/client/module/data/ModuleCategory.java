package cc.noxiuam.titanic.client.module.data;

public enum ModuleCategory {

    ALL,
    HUD,
    GUI,
    CHAT

}
