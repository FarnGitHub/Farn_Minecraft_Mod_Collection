package cc.noxiuam.titanic.event.impl.gui.chat;

import cc.noxiuam.titanic.event.AbstractEvent;

public class ChatTextBoxBackgroundDrawEvent extends AbstractEvent {
}
