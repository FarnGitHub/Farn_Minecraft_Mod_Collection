package cc.noxiuam.titanic.bridge.minecraft.block.impl;

import cc.noxiuam.titanic.bridge.minecraft.block.BlockBridge;

public interface BlockDoorBridge extends BlockBridge {
}
