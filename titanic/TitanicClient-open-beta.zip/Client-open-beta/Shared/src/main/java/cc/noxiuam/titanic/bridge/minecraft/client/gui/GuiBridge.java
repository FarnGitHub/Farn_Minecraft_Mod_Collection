package cc.noxiuam.titanic.bridge.minecraft.client.gui;

public interface GuiBridge {

    default void bridge$drawTexturedModalRect(int x, int y, int textureX, int textureY, int width, int height) {}

}
