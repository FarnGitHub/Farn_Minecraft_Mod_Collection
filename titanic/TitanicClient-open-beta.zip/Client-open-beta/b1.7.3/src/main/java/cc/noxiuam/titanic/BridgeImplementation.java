package cc.noxiuam.titanic;

import cc.noxiuam.titanic.bridge.CustomGuiScreen;
import cc.noxiuam.titanic.bridge.IBridge;
import cc.noxiuam.titanic.bridge.minecraft.block.BlockBridge;
import cc.noxiuam.titanic.bridge.minecraft.block.MaterialBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.GameSettingsBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.MinecraftBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.WorldBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiButtonBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiChatBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.chat.FontAllowedCharactersBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import cc.noxiuam.titanic.bridge.minecraft.renderer.TessellatorBridge;
import cc.noxiuam.titanic.bridge.minecraft.util.ImageBufferDownloadBridge;
import cc.noxiuam.titanic.bridge.minecraft.util.ScreenShotHelperBridge;
import net.minecraft.client.Minecraft;
import net.minecraft.src.*;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public class BridgeImplementation implements IBridge {

    @Override
    public MinecraftBridge bridge$getMinecraft() {
        return Minecraft.getMinecraft();
    }

    @Override
    public GameSettingsBridge bridge$getGameSettings() {
        return Minecraft.getMinecraft().gameSettings;
    }

    @Override
    public WorldBridge bridge$getTheWorld() {
        return Minecraft.getMinecraft().theWorld;
    }

    @Override
    public TessellatorBridge bridge$createTessellator() {
        return Tessellator.instance;
    }

    @Override
    public FontAllowedCharactersBridge bridge$getFontAllowedChars() {
        return new FontAllowedCharacters();
    }

    @Override
    public ImageBufferDownloadBridge bridge$createImageBufferDownload() {
        return new ImageBufferDownload();
    }

    @Override
    public ScreenShotHelperBridge bridge$createScreenshotHelper() {
        return new ScreenShotHelper();
    }

    @Override
    public MaterialBridge bridge$getPortalMaterial() {
        return Material.portal;
    }

    @Override
    public BlockBridge bridge$getBlock() {
        return new Block();
    }

    @Override
    public GuiScreenBridge bridge$initCustomGuiScreen(GuiScreenBridge screen) {
        return new CustomGuiScreen(screen);
    }

    @Override
    public GuiScreenBridge bridge$getGuiMultiplayer() {
        return new GuiMultiplayer(new GuiMainMenu());
    }

    @Override
    public GuiScreenBridge bridge$getGuiConnecting(MinecraftBridge mc, String address, int port) {
        return new GuiConnecting((Minecraft) mc, address, port);
    }

    @Override
    public GuiButtonBridge bridge$createNewGuiButton(int id, int x, int y, int width, int height, String text) {
        return new GuiButton(
                id,
                x,
                y,
                width,
                height,
                text
        );
    }

    @Override
    public GuiChatBridge bridge$createGuiChatWithDefaultText(String text) {
        GuiChat guiChat = new GuiChat();
        guiChat.bridge$setChatMessage(text);
        return guiChat;
    }

}
