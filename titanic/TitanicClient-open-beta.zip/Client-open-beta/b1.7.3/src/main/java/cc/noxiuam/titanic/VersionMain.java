package cc.noxiuam.titanic;

import cc.noxiuam.titanic.client.IVersionImpl;
import cc.noxiuam.titanic.client.registry.MinecraftVersion;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public class VersionMain implements IVersionImpl {

    public VersionMain() {
        Titanic.getInstance()
                .getBridge()
                .setupBridge(new BridgeImplementation());
    }

    @Override
    public MinecraftVersion getVersion() {
        return MinecraftVersion.B1_7_3;
    }

}
