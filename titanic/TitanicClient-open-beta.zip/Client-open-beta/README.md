# Titanic
A QOL client for Legacy Minecraft Versions.

Join the [Discord](https://discord.gg/Q3YBDerR2k)!

![image](img/mods.png)

## Which versions will this client support?
The client will support any Legacy Minecraft version that has an active server running on it.

## Is this client bannable on servers?
No, we are in contact with server owners and plan to satisfy all rules.

Titanic will come with a Bukkit API that will allow servers to stop the use of certain features on the server.

## Things left to do before release state
- [ ] Console controller support
- [ ] Create a way to detect JBanned users, notify them if they are banned
- [ ] Bukkit API to allow servers to disable certain features on the server

### Performance
- [ ] Entity culling
- [ ] Block culling - Render blocks that only can be seen