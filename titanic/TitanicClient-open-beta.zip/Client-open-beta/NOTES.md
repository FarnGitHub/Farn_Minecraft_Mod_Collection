fh.class - GuiContainer.java
fz.class - ItemStack.java

``` centered line for position checking:

        RenderUtil.drawRect(
                this.width / 2 - 1,
                0,
                this.width / 2 + 1,
                this.height,
                -1
        );

```