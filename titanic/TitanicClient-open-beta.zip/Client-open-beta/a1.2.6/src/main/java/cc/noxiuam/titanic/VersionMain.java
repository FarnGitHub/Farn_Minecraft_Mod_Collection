package cc.noxiuam.titanic;

import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.kotlin.client.VersionImpl;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public class VersionMain implements VersionImpl {

    public VersionMain() {
        Client.getInstance()
                .getBridge()
                .setupBridge(new BridgeImplementation());
        Ref.AUTO_LOGIN_AUTH_MESSAGE = "§fWelcome to §aAlwaysAlpha!";
    }

    @Override
    public MinecraftVersion getVersion() {
        return MinecraftVersion.A1_2_6;
    }

}
