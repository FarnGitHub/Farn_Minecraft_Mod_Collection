import cc.noxiuam.titanic.CosmeticWriter;

public class Start {

    public static void main(String[] args) {
        new CosmeticWriter();
    }

}
