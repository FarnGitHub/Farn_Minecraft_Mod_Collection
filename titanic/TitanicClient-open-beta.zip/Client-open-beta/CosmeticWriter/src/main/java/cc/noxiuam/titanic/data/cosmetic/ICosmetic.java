package cc.noxiuam.titanic.data.cosmetic;


public interface ICosmetic {

    String getName();
    String getDescription();

    boolean isEquippedByDefault();

    String getType();
    String getLocation();

}
