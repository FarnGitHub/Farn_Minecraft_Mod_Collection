package cc.noxiuam.titanic.bridge;

import cc.noxiuam.titanic.bridge.minecraft.client.gui.GuiButtonBridge;
import cc.noxiuam.titanic.bridge.minecraft.client.gui.screen.GuiScreenBridge;
import lombok.AllArgsConstructor;
import lombok.Getter;
import net.minecraft.src.GuiScreen;

/**
 * Just something to make sense of the local variables between versions.
 */
@Getter
@AllArgsConstructor
public class CustomGuiScreen extends GuiScreen {

    private GuiScreenBridge screen;

    @Override
    public void initGui() {
        this.screen.bridge$initGui();
    }

    @Override
    public void bridge$drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.screen.bridge$drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void bridge$mouseClicked(int mouseX, int mouseY, int button) {
        this.screen.bridge$mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void bridge$mouseMovedOrUp(int mouseX, int mouseY, int button) {
        this.screen.bridge$mouseMovedOrUp(mouseX, mouseY, button);
    }

    @Override
    public void bridge$keyTyped(char c, int n) {
        this.screen.bridge$keyTyped(c, n);
    }

    @Override
    public void bridge$onGuiClosed() {
        this.screen.bridge$onGuiClosed();
    }

    @Override
    public void bridge$actionPerformed(GuiButtonBridge button) {
        this.screen.bridge$actionPerformed(button);
    }

    @Override
    public void bridge$updateScreen() {
        this.screen.bridge$updateScreen();
    }

}
