# Gradle: The Build Tool Of Nightmares

`src/main/java` contains the client code; `src/minecraft/java` is for the modified game code and is ignored in favour of `patches`.

### Setup
Runs RetroMCP and `patch`.
```
./gradlew setup
```

### Patch
Copies the source from MCP and applies the patches. This will override any changes made without `diff`!
```
./gradlew patch
```

### Diff
Generates the patches. Do this before you commit or stash otherwise your changes will be ignored!
```
./gradlew diff
```