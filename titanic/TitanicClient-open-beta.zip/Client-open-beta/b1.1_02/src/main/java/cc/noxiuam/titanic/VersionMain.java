package cc.noxiuam.titanic;

import cc.noxiuam.titanic.client.registry.MinecraftVersion;
import cc.noxiuam.titanic.kotlin.client.VersionImpl;

/**
 * @author Noxiuam
 * <a href="https://noxiuam.cc">...</a>
 */
public class VersionMain implements VersionImpl {

    public VersionMain() {
        Client.getInstance()
                .getBridge()
                .setupBridge(new BridgeImplementation());
    }

    @Override
    public MinecraftVersion getVersion() {
        return MinecraftVersion.B1_1_02;
    }

}
