package net.minecraft.src;

import me.icanttellyou.mods.worldtypes.farn.WorldTypeOptions;
import me.icanttellyou.mods.worldtypes.proxy.world.DimensionOverworldProxy;
import net.minecraft.client.Minecraft;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class mod_WorldTypes extends BaseMod {
    public Minecraft mc = ModLoader.getMinecraftInstance();
    public static boolean isDevEnv;
    public static boolean unsupportedEnvironment;

    public static int generator = 0;
    public static int biomeGenerator = 0;
    public static int singleBiome = 3;
    public static List<BiomeGenBase> biomes = new ArrayList<>();
    public static EnumWorldTypes[] enumWorldTypes = EnumWorldTypes.values();
    public static EnumBiomeGenerators[] enumBiomeGenerators = EnumBiomeGenerators.values();


    @Override
    public String Version() {
        return "1.0";
    }

    @Override
    public void ModsLoaded() {
        DimensionBase.list.remove(0);
        new DimensionOverworldProxy();
        Field[] fields = BiomeGenBase.class.getFields();
        for(Field f : fields) {
            try {
                if (f.getType().equals(BiomeGenBase.class)) biomes.add((BiomeGenBase) f.get(BiomeGenBase.class));
            } catch (IllegalAccessException e) {
                throw new RuntimeException("Unable to get biomes!", e);
            }
        }

        WorldTypeOptions.init();
    }

    public enum EnumWorldTypes {
        //to avoid stuff from going baaaad, put ones that rely on vanilla code before the custom ones.
        NORMAL("default", "Default"),
        //SKY("sky", "Sky"),
        FLAT("flat", "Flat"),
        TWOD("2d", "2D Perlin"),
        ALPHA("alpha", "Alpha");

        public final String worldType;
        public final String displayName;
        EnumWorldTypes(String s, String s2) {
            worldType = s;
            displayName = s2;
        }
    }

    public enum EnumBiomeGenerators {
        NORMAL("default", "Default"),
        SINGLE("single", "Single Biome");

        public final String biomeGenerator;
        public final String displayName;

        EnumBiomeGenerators(String s, String s2) {
            biomeGenerator = s;
            displayName = s2;
        }
    }

    static {
        try {
            Class.forName("net.minecraft.src.Block");
            unsupportedEnvironment = false;
            isDevEnv = true;
        } catch (ClassNotFoundException e) {
            try {
                Class.forName("uu");
                unsupportedEnvironment = false;
            } catch (ClassNotFoundException ex) {
                System.err.println("Unsupported environment! Minecraft is either reobfuscated or you are using non-MCP mappings!");
                unsupportedEnvironment = true;
            }
            isDevEnv = false;
        }
    }
}
