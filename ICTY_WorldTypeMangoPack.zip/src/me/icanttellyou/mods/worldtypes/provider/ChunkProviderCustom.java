package me.icanttellyou.mods.worldtypes.provider;

import me.icanttellyou.mods.worldtypes.farn.WorldTypeOptions;
import me.icanttellyou.mods.worldtypes.terrain.AlphaTerrainGenerator;
import me.icanttellyou.mods.worldtypes.terrain.FlatTerrainGenerator;
import me.icanttellyou.mods.worldtypes.terrain.ITerrainGenerator;
import me.icanttellyou.mods.worldtypes.terrain.TwoDTerrainGenerator;
import net.minecraft.src.*;
import worldgen.WorldGeneratorOverrides;
import worldgen.api.ChunkProviderGenerateGenerator;
import worldsettings.api.settings.SettingSupplier;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class ChunkProviderCustom extends ChunkProviderGenerate {
    private final Random rand;
    private final World worldObj;
    private final MapGenBase caveGenerator;
    private BiomeGenBase[] biomesForGeneration;
    //vanilla terrain generators
    public List<IChunkProvider> chunkProviders = new ArrayList<>();
    //custom terrain generators, which are more bare-bones since they do not work as chunk providers.
    public List<ITerrainGenerator> terrainGenerators = new ArrayList<>();

    private boolean flatWorld = false;
    private int generatorIndex = 0;

    public ChunkProviderCustom(World world1, long j2) {
        super(world1, j2);
        worldObj = world1;
        rand = new Random(j2);
//        switch (mod_WorldTypes.enumWorldTypes[generator].worldType) {
//            default:
                caveGenerator = new MapGenCaves();
//                break;
//        }
        //chunkProviders.add(new ChunkProviderSky(world1, j2));
        chunkProviders.add(new ChunkProviderGenerate(world1, j2));
        terrainGenerators.add(new FlatTerrainGenerator(world1, j2));
        terrainGenerators.add(new TwoDTerrainGenerator(world1, j2));
        terrainGenerators.add(new AlphaTerrainGenerator(world1, j2));
        generatorIndex = WorldTypeOptions.getGeneratorType();
        flatWorld = mod_WorldTypes.enumWorldTypes[generatorIndex].worldType.equals("flat");
    }

    public void generateTerrain(int i1, int i2, byte[] b3, BiomeGenBase[] biomeGenBase4, double[] d5) {
        switch (mod_WorldTypes.enumWorldTypes[generatorIndex].worldType) {
            default:
                ((ChunkProviderGenerate)chunkProviders.get(0)).generateTerrain(i1, i2, b3, biomeGenBase4, d5);
                break;
            case "flat":
            case "2d":
            case "alpha":
                terrainGenerators.get(WorldTypeOptions.getGeneratorType() - chunkProviders.toArray().length).generateTerrain(i1, i2, b3, biomeGenBase4, d5);
                break;
        }
    }

    public void replaceBlocksForBiome(int i1, int i2, byte[] b3, BiomeGenBase[] biomeGenBase4) {
        switch (mod_WorldTypes.enumWorldTypes[generatorIndex].worldType) {
            default:
                ((ChunkProviderGenerate)chunkProviders.get(0)).replaceBlocksForBiome(i1, i2, b3, biomeGenBase4);
                break;
            case "flat":
                break;
        }
    }

    @Override
    public Chunk prepareChunk(int i1, int i2) {
        return this.provideChunk(i1, i2);
    }

    @Override
    public Chunk provideChunk(int i1, int i2) {
        this.rand.setSeed((long)i1 * 341873128712L + (long)i2 * 132897987541L);
        byte[] b3 = new byte[32768];
        Chunk chunk4 = new Chunk(this.worldObj, b3, i1, i2);
        this.biomesForGeneration = this.worldObj.getWorldChunkManager().loadBlockGeneratorData(this.biomesForGeneration, i1 * 16, i2 * 16, 16, 16);
        double[] d5 = this.worldObj.getWorldChunkManager().temperature;

        long currentLastTimeLoaded = WorldGeneratorOverrides.getLastTimeLoaded();
        if (generators == null || currentLastTimeLoaded != lastTimeLoaded) {
            generators = WorldGeneratorOverrides.getChunkProviderGenerators(ChunkProviderGenerateGenerator.class);
            lastTimeLoaded = currentLastTimeLoaded;
        }

        if(!flatWorld) {
            for (ChunkProviderGenerateGenerator generator : generators) {
                generator.preTerrain(this, this.rand, b3, chunk4, this.biomesForGeneration, d5);
            }
        }
        this.generateTerrain(i1, i2, b3, this.biomesForGeneration, d5);
        if(!flatWorld) {
            for (ChunkProviderGenerateGenerator generator : generators) {
                generator.preReplaceBlocks(this, this.rand, b3, chunk4, this.biomesForGeneration, d5);
            }
            this.replaceBlocksForBiome(i1, i2, b3, this.biomesForGeneration);
            for (ChunkProviderGenerateGenerator generator : generators) {
                generator.preReplaceBlocks(this, this.rand, b3, chunk4, this.biomesForGeneration, d5);
            }
            this.replaceBlocksForBiome(i1, i2, b3, this.biomesForGeneration);

            for (ChunkProviderGenerateGenerator generator : generators) {
                generator.preCaves(this, this.rand, b3, chunk4, this.biomesForGeneration, d5);
            }
            this.caveGenerator.func_867_a(this, this.worldObj, i1, i2, b3);
        }

        if(!flatWorld) {
            for (ChunkProviderGenerateGenerator generator : generators) {
                generator.preLight(this, this.rand, b3, chunk4, this.biomesForGeneration, d5);
            }
        }
        chunk4.func_1024_c();
        if(!flatWorld) {
            for (ChunkProviderGenerateGenerator generator : generators) {
                generator.post(this, this.rand, b3, chunk4, this.biomesForGeneration, d5);
            }
        }

        return chunk4;
    }

    @Override
    public void populate(IChunkProvider iChunkProvider1, int i2, int i3) {
        switch (mod_WorldTypes.enumWorldTypes[generatorIndex].worldType) {
            default:
                chunkProviders.get(0).populate(iChunkProvider1, i2, i3);
                break;
            case "flat":
            case "alpha":
                terrainGenerators.get(generatorIndex - chunkProviders.toArray().length).populate(iChunkProvider1, i2, i3);
                if (WorldGeneratorOverrides.isCustomGenerationEnabledSurface()) {
                    for (Map.Entry<BaseMod, SettingSupplier<Boolean>> entry : WorldGeneratorOverrides.getModsOverridingGenerateSurface().entrySet()) {
                        if (entry.getValue().getValue()) {
                            entry.getKey().GenerateSurface(this.worldObj, this.rand, i2, i3);
                        }
                    }
                }
                break;
        }
    }

    public String makeString() {
        return flatWorld ? "No Gen" : WorldGeneratorOverrides.getGenerateMakeString();
    }
}
