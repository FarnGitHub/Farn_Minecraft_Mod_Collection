package me.icanttellyou.mods.worldtypes.farn;

import net.minecraft.src.mod_WorldTypes;
import worldsettings.api.gui.impl.GuiButtonSwitchMulti;

public class MultiButtonsBiomes extends GuiButtonSwitchMulti<Integer> {

    public MultiButtonsBiomes(int id, int x, int y, String displayString) {
        super(id, x, y, displayString, WorldTypeOptions.singleBiomeSettings, fillWithIndex(), getDisplayNameArray());
    }

    private static String[] getDisplayNameArray() {
        String[] enumWorldTypesArray = new String[mod_WorldTypes.biomes.size()];
        for(int i = 0; i < enumWorldTypesArray.length; ++i) {
            enumWorldTypesArray[i] = mod_WorldTypes.biomes.get(i).biomeName;
        }

        return enumWorldTypesArray;
    }


    private static Integer[] fillWithIndex() {
        Integer[] enumWorldTypesArray = new Integer[mod_WorldTypes.biomes.size()];
        for(int i = 0; i < enumWorldTypesArray.length; ++i) {
            enumWorldTypesArray[i] = i;
        }

        return enumWorldTypesArray;
    }
}
