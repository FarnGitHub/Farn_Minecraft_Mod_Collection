package me.icanttellyou.mods.worldtypes.farn;

import net.minecraft.src.ModLoader;
import net.minecraft.src.mod_WorldTypes;
import worldsettings.WorldSettingsConfiguration;
import worldsettings.api.gui.impl.GuiSimpleConfiguration;
import worldsettings.api.settings.ConfigurationSupplier;
import worldsettings.api.settings.SettingSupplier;
import worldsettings.api.settings.impl.ConfigurationDetailedSlot;
import worldsettings.api.settings.impl.Setting;

public class WorldTypeOptions {

    public static final SettingSupplier<Integer> worldTypeSettings = new Setting<Integer>("world_type", mod_WorldTypes.EnumWorldTypes.NORMAL.ordinal(), Integer.class);

    public static final SettingSupplier<Integer> singleBiomeSettings = new Setting<Integer>("single_biome", 3, Integer.class);

    public static final SettingSupplier<Boolean> singleBiomeSettingsEnabled = new Setting<Boolean>("single_biome_enabled", false, Boolean.class);

    public static final String LANG_WORLD_TYPE = "icanttellyou.worldtype";
    private static GuiSimpleConfiguration generatorWorldTypeGUI = new GuiSimpleConfiguration(LANG_WORLD_TYPE) {

        @Override
        public void initGui() {
            this.registeredButtons.clear();
            MultiButtonsBiomes biomesButtons;
            this.registeredButtons.add(new MultiButtonsWorldTypes(this.getNextButtonID(), 0, 0, "World Type"));
            this.registeredButtons.add(biomesButtons = new MultiButtonsBiomes(this.getNextButtonID(), 0, 0, "Single Biome Types"));
            this.registeredButtons.add(new ButtonsSingleBiomesToggle(this.getNextButtonID(), 0, 0, "Single Biome", singleBiomeSettingsEnabled, biomesButtons));
            this.initButtons();
        }

    };
    public static ConfigurationSupplier generatorWorldTypeConfiguration = new ConfigurationDetailedSlot(generatorWorldTypeGUI, "world_type", LANG_WORLD_TYPE, "", "");

    public static int getGeneratorType() {
        return (Integer) generatorWorldTypeConfiguration.get("world_type").getValue();
    }

    public static int getSingleBiomeType() {
        return (Integer) generatorWorldTypeConfiguration.get("single_biome").getValue();
    }

    public static boolean getSingleBiomeEnabled() {
        return (Boolean) generatorWorldTypeConfiguration.get("single_biome_enabled").getValue();
    }

    public static void init() {
        ModLoader.AddLocalization(LANG_WORLD_TYPE, "World Types");
        generatorWorldTypeConfiguration.put(worldTypeSettings);
        generatorWorldTypeConfiguration.put(singleBiomeSettings);
        generatorWorldTypeConfiguration.put(singleBiomeSettingsEnabled);
        WorldSettingsConfiguration.registerConfiguration(generatorWorldTypeConfiguration);
    }
}
