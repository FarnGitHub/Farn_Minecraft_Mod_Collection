package me.icanttellyou.mods.worldtypes.farn;

import net.minecraft.src.ModLoader;
import worldsettings.api.gui.impl.GuiButtonSwitch;
import worldsettings.api.settings.SettingSupplier;

public class ButtonsSingleBiomesToggle extends GuiButtonSwitch {
    private final MultiButtonsBiomes multiButtonsBiomes;

    public ButtonsSingleBiomesToggle(int id, int x, int y, String displayString, SettingSupplier<Boolean> setting, MultiButtonsBiomes biomesButtonsRaw) {
        super(id, x, y, displayString, setting);
        multiButtonsBiomes = biomesButtonsRaw;
        setMultiBiomesButtonsActive();
    }

    public void onClick() {
        super.onClick();
        setMultiBiomesButtonsActive();
    }

    private void setMultiBiomesButtonsActive() {
        try {
            SettingSupplier<Boolean> supplier = (SettingSupplier<Boolean>)ModLoader.getPrivateValue(GuiButtonSwitch.class, this, "setting");
            multiButtonsBiomes.enabled = supplier.getValue();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
}
