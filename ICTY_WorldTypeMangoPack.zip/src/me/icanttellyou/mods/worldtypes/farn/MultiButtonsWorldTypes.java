package me.icanttellyou.mods.worldtypes.farn;

import net.minecraft.src.mod_WorldTypes;
import worldsettings.api.gui.impl.GuiButtonSwitchMulti;

public class MultiButtonsWorldTypes extends GuiButtonSwitchMulti<Integer> {

    public MultiButtonsWorldTypes(int id, int x, int y, String displayString) {
        super(id, x, y, displayString, WorldTypeOptions.worldTypeSettings, fillWithIndex(), getDisplayNameArray());
    }

    private static String[] getDisplayNameArray() {
        String[] enumWorldTypesArray = new String[mod_WorldTypes.EnumWorldTypes.values().length];
        for(int i = 0; i < enumWorldTypesArray.length; ++i) {
            enumWorldTypesArray[i] = mod_WorldTypes.EnumWorldTypes.values()[i].displayName;
        }

        return enumWorldTypesArray;
    }


    private static Integer[] fillWithIndex() {
        Integer[] enumWorldTypesArray = new Integer[mod_WorldTypes.EnumWorldTypes.values().length];
        for(int i = 0; i < enumWorldTypesArray.length; ++i) {
            enumWorldTypesArray[i] = i;
        }

        return enumWorldTypesArray;
    }

    public void onClick() {
        super.onClick();
    }
}
