package farn.skin_sound_fix.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.unmapped.C_1023567;
import net.minecraft.unmapped.C_8730536;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(C_1023567.class)
public class InputPlayerSkinMixin {

	@WrapOperation(method="<init>", at = @At(value = "FIELD", target = "Lnet/minecraft/client/entity/living/player/InputPlayerEntity;skin:Ljava/lang/String;", ordinal = 0))
	public void skinFix(C_1023567 instance, String value, Operation<Void> original, @Local(argsOnly = true, index = 3) C_8730536 session) {
		instance.f_0929868 = "https://betacraft.uk/MinecraftSkins/" + session.f_0507139 + ".png";
	}

}
