package farn.skin_sound_fix.mixin;

import net.minecraft.unmapped.C_9029783;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(C_9029783.class)
public class ResourceThreadMixin {
	@ModifyConstant(method = "run", constant = @Constant(stringValue = "http://s3.amazonaws.com/MinecraftResources/"), remap = false)
	private String getResourcesUrl(String def) {
		return "http://s3.betacraft.uk:11702/MinecraftResources/";
	}
}
