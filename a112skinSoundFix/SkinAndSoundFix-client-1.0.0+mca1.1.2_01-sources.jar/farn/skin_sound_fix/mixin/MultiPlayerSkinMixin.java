package farn.skin_sound_fix.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.unmapped.C_1214754;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(C_1214754.class)
public class MultiPlayerSkinMixin {

	@WrapOperation(method="<init>", at = @At(value = "FIELD", target = "Lnet/minecraft/client/entity/living/player/RemotePlayerEntity;skin:Ljava/lang/String;", ordinal = 0))
	public void skinFix(C_1214754 instance, String value, Operation<Void> original, @Local(argsOnly = true, index = 2) String username) {
		instance.f_0929868 = "https://betacraft.uk/MinecraftSkins/" + username + ".png";
	}

}
