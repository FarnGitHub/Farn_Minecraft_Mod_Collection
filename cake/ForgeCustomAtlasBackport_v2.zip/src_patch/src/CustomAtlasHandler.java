package net.minecraft.src;

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

import java.lang.reflect.Field;
import java.util.*;

public class CustomAtlasHandler {
	static HashMap<List<Integer>, Tessellator> tessellators=new HashMap<>();
	static HashMap<String, Integer> textures=new HashMap<>();
	static boolean inWorld=false;
	static HashSet<List<Integer>> renderTextureTest=new HashSet<>();
	static ArrayList<List<Integer>> renderTextureList=new ArrayList<>();
	public static Minecraft mc;

	protected static void bindTessellator(int tex, int sub) {
		List<Integer> key=Arrays.asList(tex,sub);
		Tessellator t;
		if(!tessellators.containsKey(key)) {
			t=new Tessellator();
			tessellators.put(key,t);
		} else {
			t=tessellators.get(key);
		}
		if(inWorld && !renderTextureTest.contains(key)) {
			renderTextureTest.add(key);
			renderTextureList.add(key);
			t.startDrawingQuads();
			t.setTranslationD(Tessellator.firstInstance.xOffset,
				Tessellator.firstInstance.yOffset,
				Tessellator.firstInstance.zOffset);
		}
		Tessellator.instance=t;
	}

	protected static void bindTexture(String name, int sub) {
		int n;
		if(!textures.containsKey(name)) {
			n= getMC().renderEngine
				.getTexture(name);
			textures.put(name,n);
		} else {
			n=textures.get(name);
		}
		if(!inWorld) {
			Tessellator.instance=Tessellator.firstInstance;
			GL11.glBindTexture(GL11.GL_TEXTURE_2D,n);
			return;
		}
		bindTessellator(n,sub);
	}

	protected static void unbindTexture() {
		Tessellator.instance=Tessellator.firstInstance;
		if(!inWorld) {
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, getMC().renderEngine.getTexture("/terrain.png"));
		}
	}

	static int renderPass=-1;
	public static void beforeRenderPass(int pass) {
		renderPass=pass;
		Tessellator.instance=Tessellator.firstInstance;
		Tessellator.renderingWorldRenderer=true;
		GL11.glBindTexture(GL11.GL_TEXTURE_2D,getMC().renderEngine.getTexture("/terrain.png"));
		renderTextureTest.clear();
		renderTextureList.clear();
		inWorld=true;
	}

	public static void afterRenderPass() {
		renderPass=-1;
		inWorld=false;
		for(List<Integer> l : renderTextureList) {
			Integer[] tn= l.toArray(new Integer[0]);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D,tn[0]);
			Tessellator t= tessellators.get(l);
			t.draw();
		}
		GL11.glBindTexture(GL11.GL_TEXTURE_2D,getMC().renderEngine.getTexture("/terrain.png"));
		Tessellator.instance=Tessellator.firstInstance;
		Tessellator.renderingWorldRenderer=false;
	}

	public static void beforeBlockRender(Block block,
			RenderBlocks renderblocks) {
		if (block instanceof CustomAtlasProvider && renderblocks.overrideBlockTexture == -1) {
			CustomAtlasProvider itp=(CustomAtlasProvider)block;
			bindTexture(itp.getTextureFile(),0);
		}
	}

	public static void afterBlockRender(Block block,
			RenderBlocks renderblocks) {
		if (block instanceof CustomAtlasProvider
				&& renderblocks.overrideBlockTexture == -1) {
			unbindTexture();
		}
	}

	public static void overrideTexture(Object o) {
		if (o instanceof CustomAtlasProvider) {
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, getMC().renderEngine
				.getTexture(((CustomAtlasProvider) (o))
					.getTextureFile()));
		}
	}

	//Compatibility with Zyga's MoreItemSprite
	public static MISEntry getMIS(int icon) {
		String itemsAtlasPath = "/gui/items.png";
		if(icon > 255) {
			int index = 1;
			for(; icon > 255; icon -= 256) index++;
			itemsAtlasPath =   "/gui/items" + index + ".png";
		}
		return new MISEntry(icon,itemsAtlasPath);
	}

	//Get the Minecraft INSTANCE
	//Beware that this method will crash the game when running on retroMCP
	//It run fine on normal Minecraft instance though
	public static Minecraft getMC()
	{
		if(mc == null)
		{
			try {
				ThreadGroup group = Thread.currentThread().getThreadGroup();
				int i = group.activeCount();
				Thread[] threads = new Thread[i];
				group.enumerate(threads);
				for(int j = 0; j < threads.length; j++) {
					if(!threads[j].getName().equals("Minecraft main thread")) {
						continue;
					}
					Field targetF = Thread.class.getDeclaredField("target");
					targetF.setAccessible(true);
					mc = (Minecraft)targetF.get(threads[j]);
					break;
				}

			} catch(Exception securityexception) {
				throw new RuntimeException(securityexception);
			}
		}
		return mc;
	}

	public static class MISEntry {
		public int icon;
		String atlas;

		public MISEntry(int icon, String atlas) {
			this.icon = icon;
			this.atlas = atlas;
		}
	}
}

