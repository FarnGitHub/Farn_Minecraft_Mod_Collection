package net.minecraft.src;

public interface CustomAtlasProvider {

    String getTextureFile();
}
