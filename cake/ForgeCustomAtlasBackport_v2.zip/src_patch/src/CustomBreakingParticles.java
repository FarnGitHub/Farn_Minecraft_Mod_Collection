package net.minecraft.src;

import java.util.ArrayList;
import java.util.List;

public class CustomBreakingParticles {
	public String texture;
	public List<EntityFX> particles = new ArrayList<>();
}
