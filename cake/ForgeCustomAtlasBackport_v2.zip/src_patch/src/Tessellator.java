package net.minecraft.src;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.Arrays;

import org.lwjgl.opengl.ARBVertexBufferObject;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GLContext;

public class Tessellator {
	private static boolean convertQuadsToTriangles = true;
	private static boolean tryVBO = false;
	private static boolean useVBO = false;
	private int[] rawBuffer;
	private int vertexCount = 0;
	private double textureU;
	private double textureV;
	private int color;
	private boolean hasColor = false;
	private boolean hasTexture = false;
	private boolean hasNormals = false;
	private int rawBufferIndex = 0;
	private int addedVertices = 0;
	private boolean isColorDisabled = false;
	private int drawMode;
	public double xOffset;
	public double yOffset;
	public double zOffset;
	private int normal;
	private boolean isDrawing = false;
	private int vboIndex = 0;

	public static boolean renderingWorldRenderer=false;
    public boolean defaultTexture=false;
    private int rawBufferSize;
    private static int vboCount;
    private static IntBuffer vertexBuffers;
    private static int nativeBufferSize;
    private static int trivertsInBuffer;
    private static ByteBuffer byteBuffer;
    private static IntBuffer intBuffer;
    private static FloatBuffer floatBuffer;
    public static Tessellator instance;
    public static Tessellator firstInstance;

	public Tessellator() {
		this.rawBuffer = null;
		this.vertexCount = 0;
		this.hasColor = false;
		this.hasTexture = false;
		this.hasNormals = false;
		this.rawBufferIndex = 0;
		this.addedVertices = 0;
		this.isColorDisabled = false;
		this.isDrawing = false;
		this.vboIndex = 0;
		this.defaultTexture = false;
		this.rawBufferSize = 0;
		rawBuffer=null;
		rawBufferSize=0;
	}

	public void draw() {
		if(!this.isDrawing) {
			throw new IllegalStateException("Not tesselating!");
		} else {
			this.isDrawing = false;
			int offs=0;
			while(offs < vertexCount) {
				int vtc;
				if(drawMode == 7 && convertQuadsToTriangles) {
					vtc=Math.min(vertexCount-offs,trivertsInBuffer);
				} else {
					vtc=Math.min(vertexCount-offs,nativeBufferSize>>5);
				}

				intBuffer.clear();
				intBuffer.put(this.rawBuffer, offs*8, vtc*8);
				byteBuffer.position(0);
				byteBuffer.limit(vtc*32);
				offs+=vtc;
				if(useVBO) {
					this.vboIndex = (this.vboIndex + 1) % vboCount;
					ARBVertexBufferObject.glBindBufferARB(GL15.GL_ARRAY_BUFFER, vertexBuffers.get(this.vboIndex));
					ARBVertexBufferObject.glBufferDataARB(GL15.GL_ARRAY_BUFFER, byteBuffer, GL15.GL_STREAM_DRAW);
				}

				if(this.hasTexture) {
					if(useVBO) {
						GL11.glTexCoordPointer(2, GL11.GL_FLOAT, 32, 12L);
					} else {
						floatBuffer.position(3);
						GL11.glTexCoordPointer(2, 32, floatBuffer);
					}

					GL11.glEnableClientState(GL11.GL_TEXTURE_COORD_ARRAY);
				}

				if(this.hasColor) {
					if(useVBO) {
						GL11.glColorPointer(4, GL11.GL_UNSIGNED_BYTE, 32, 20L);
					} else {
						byteBuffer.position(20);
						GL11.glColorPointer(4, true, 32, byteBuffer);
					}

					GL11.glEnableClientState(GL11.GL_COLOR_ARRAY);
				}

				if(this.hasNormals) {
					if(useVBO) {
						GL11.glNormalPointer(GL11.GL_BYTE, 32, 24L);
					} else {
						byteBuffer.position(24);
						GL11.glNormalPointer(32, byteBuffer);
					}

					GL11.glEnableClientState(GL11.GL_NORMAL_ARRAY);
				}

				if(useVBO) {
					GL11.glVertexPointer(3, GL11.GL_FLOAT, 32, 0L);
				} else {
					floatBuffer.position(0);
					GL11.glVertexPointer(3, 32, floatBuffer);
				}

				GL11.glEnableClientState(GL11.GL_VERTEX_ARRAY);
				if(this.drawMode == 7 && convertQuadsToTriangles) {
					GL11.glDrawArrays(GL11.GL_TRIANGLES, GL11.GL_POINTS, vtc);
				} else {
					GL11.glDrawArrays(this.drawMode, GL11.GL_POINTS, vtc);
				}

				GL11.glDisableClientState(GL11.GL_VERTEX_ARRAY);
				if(this.hasTexture) {
					GL11.glDisableClientState(GL11.GL_TEXTURE_COORD_ARRAY);
				}

				if(this.hasColor) {
					GL11.glDisableClientState(GL11.GL_COLOR_ARRAY);
				}

				if(this.hasNormals) {
					GL11.glDisableClientState(GL11.GL_NORMAL_ARRAY);
				}
			}

			if(rawBufferSize>0x20000 && rawBufferIndex<(rawBufferSize<<3)) {
				rawBufferSize=0;
				rawBuffer=null;
			}
			this.reset();
		}
	}

	private void reset() {
		this.vertexCount = 0;
		byteBuffer.clear();
		this.rawBufferIndex = 0;
		this.addedVertices = 0;
	}

	public void startDrawingQuads() {
		this.startDrawing(7);
	}

	public void startDrawing(int var1) {
		if(this.isDrawing) {
			throw new IllegalStateException("Already tesselating!");
		} else {
			this.isDrawing = true;
			this.reset();
			this.drawMode = var1;
			this.hasNormals = false;
			this.hasColor = false;
			this.hasTexture = false;
			this.isColorDisabled = false;
		}
	}

	public void setTextureUV(double var1, double var3) {
		this.hasTexture = true;
		this.textureU = var1;
		this.textureV = var3;
	}

	public void setColorOpaque_F(float var1, float var2, float var3) {
		this.setColorOpaque((int)(var1 * 255.0F), (int)(var2 * 255.0F), (int)(var3 * 255.0F));
	}

	public void setColorRGBA_F(float var1, float var2, float var3, float var4) {
		this.setColorRGBA((int)(var1 * 255.0F), (int)(var2 * 255.0F), (int)(var3 * 255.0F), (int)(var4 * 255.0F));
	}

	public void setColorOpaque(int var1, int var2, int var3) {
		this.setColorRGBA(var1, var2, var3, 255);
	}

	public void setColorRGBA(int var1, int var2, int var3, int var4) {
		if(!this.isColorDisabled) {
			if(var1 > 255) {
				var1 = 255;
			}

			if(var2 > 255) {
				var2 = 255;
			}

			if(var3 > 255) {
				var3 = 255;
			}

			if(var4 > 255) {
				var4 = 255;
			}

			if(var1 < 0) {
				var1 = 0;
			}

			if(var2 < 0) {
				var2 = 0;
			}

			if(var3 < 0) {
				var3 = 0;
			}

			if(var4 < 0) {
				var4 = 0;
			}

			this.hasColor = true;
			this.color = var4 << 24 | var3 << 16 | var2 << 8 | var1;
		}
	}

	public void addVertexWithUV(double var1, double var3, double var5, double var7, double var9) {
		this.setTextureUV(var7, var9);
		this.addVertex(var1, var3, var5);
	}

	public void addVertex(double var1, double var3, double var5) {
		++this.addedVertices;
		if(rawBufferIndex >= rawBufferSize-32) {
			if(rawBufferSize==0) {
				rawBufferSize=0x10000;
				rawBuffer=new int[rawBufferSize];
			} else {
				rawBufferSize*=2;
				rawBuffer= Arrays.copyOf(rawBuffer,rawBufferSize);
			}
		}

		if(this.drawMode == 7 && convertQuadsToTriangles && this.addedVertices % 4 == 0) {
			for(int var7 = 0; var7 < 2; ++var7) {
				int var8 = 8 * (3 - var7);
				if(this.hasTexture) {
					this.rawBuffer[this.rawBufferIndex + 3] = this.rawBuffer[this.rawBufferIndex - var8 + 3];
					this.rawBuffer[this.rawBufferIndex + 4] = this.rawBuffer[this.rawBufferIndex - var8 + 4];
				}

				if(this.hasColor) {
					this.rawBuffer[this.rawBufferIndex + 5] = this.rawBuffer[this.rawBufferIndex - var8 + 5];
				}

				this.rawBuffer[this.rawBufferIndex + 0] = this.rawBuffer[this.rawBufferIndex - var8 + 0];
				this.rawBuffer[this.rawBufferIndex + 1] = this.rawBuffer[this.rawBufferIndex - var8 + 1];
				this.rawBuffer[this.rawBufferIndex + 2] = this.rawBuffer[this.rawBufferIndex - var8 + 2];
				++this.vertexCount;
				this.rawBufferIndex += 8;
			}
		}

		if(this.hasTexture) {
			this.rawBuffer[this.rawBufferIndex + 3] = Float.floatToRawIntBits((float)this.textureU);
			this.rawBuffer[this.rawBufferIndex + 4] = Float.floatToRawIntBits((float)this.textureV);
		}

		if(this.hasColor) {
			this.rawBuffer[this.rawBufferIndex + 5] = this.color;
		}

		if(this.hasNormals) {
			this.rawBuffer[this.rawBufferIndex + 6] = this.normal;
		}

		this.rawBuffer[this.rawBufferIndex + 0] = Float.floatToRawIntBits((float)(var1 + this.xOffset));
		this.rawBuffer[this.rawBufferIndex + 1] = Float.floatToRawIntBits((float)(var3 + this.yOffset));
		this.rawBuffer[this.rawBufferIndex + 2] = Float.floatToRawIntBits((float)(var5 + this.zOffset));
		this.rawBufferIndex += 8;
		++this.vertexCount;

	}

	public void setColorOpaque_I(int var1) {
		int var2 = var1 >> 16 & 255;
		int var3 = var1 >> 8 & 255;
		int var4 = var1 & 255;
		this.setColorOpaque(var2, var3, var4);
	}

	public void disableColor() {
		this.isColorDisabled = true;
	}

	public void setNormal(float var1, float var2, float var3) {
		if(!this.isDrawing) {
			System.out.println("But..");
		}

		this.hasNormals = true;
		byte var4 = (byte)((int)(var1 * 128.0F));
		byte var5 = (byte)((int)(var2 * 127.0F));
		byte var6 = (byte)((int)(var3 * 127.0F));
		this.normal = var4 | var5 << 8 | var6 << 16;
	}

	public void setTranslationD(double var1, double var3, double var5) {
		this.xOffset = var1;
		this.yOffset = var3;
		this.zOffset = var5;
	}

	public void setTranslationF(float var1, float var2, float var3) {
		this.xOffset += (double)var1;
		this.yOffset += (double)var2;
		this.zOffset += (double)var3;
	}

	static {
		instance=new Tessellator();
		firstInstance=instance;
		firstInstance.defaultTexture=true;

		nativeBufferSize = 0x200000;
		trivertsInBuffer = (nativeBufferSize/48)*6;
		byteBuffer = GLAllocation.createDirectByteBuffer(nativeBufferSize * 4);
		intBuffer = byteBuffer.asIntBuffer();
		floatBuffer = byteBuffer.asFloatBuffer();
		useVBO = tryVBO && GLContext.getCapabilities().GL_ARB_vertex_buffer_object;
		vboCount = 10;
		if(useVBO) {
			vertexBuffers = GLAllocation.createDirectIntBuffer(vboCount);
			ARBVertexBufferObject.glGenBuffersARB(vertexBuffers);
		}
	}
}
