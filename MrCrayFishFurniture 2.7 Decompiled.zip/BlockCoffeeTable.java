import java.util.Random;
import net.minecraft.src.Block;
import net.minecraft.src.Material;
import net.minecraft.src.World;

public class BlockCoffeeTable
extends Block {
    protected BlockCoffeeTable(int i, Material material) {
        super(i, material);
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.5f, 1.0f);
    }

    @Override
    public boolean isOpaqueCube() {
        return false;
    }

    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }

    @Override
    public int getRenderType() {
        return mod_FurnitureMod.renderCoffeeTable;
    }

    @Override
    public int idDropped(int i, Random random, int j) {
        if (i == 1) {
            return mod_FurnitureMod.itemCoffeeTableWood.itemID;
        }
        if (i == 2) {
            return mod_FurnitureMod.itemCoffeeTableStone.itemID;
        }
        return i;
    }

    @Override
    public int idPicked(World par1World, int par2, int par3, int par4) {
        if (par1World.getBlockMetadata(par2, par3, par4) == 1) {
            return mod_FurnitureMod.itemCoffeeTableWood.itemID;
        }
        if (par1World.getBlockMetadata(par2, par3, par4) == 2) {
            return mod_FurnitureMod.itemCoffeeTableStone.itemID;
        }
        return this.blockID;
    }
}
