import java.util.List;
import java.util.Random;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.Material;
import net.minecraft.src.World;

public class BlockChair
extends BlockMountable {
    protected BlockChair(int i, int j, Material material) {
        super(i, j, material);
    }

    @Override
    public boolean isOpaqueCube() {
        return false;
    }

    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }

    @Override
    public int getRenderType() {
        return mod_FurnitureMod.renderChair;
    }

    @Override
    public boolean onBlockActivated(World world, int i, int j, int k, EntityPlayer entityplayer, int par6, float par7, float par8, float par9) {
        return BlockChair.onBlockActivated(world, i, j, k, entityplayer, 0.5f, 0.6f, 0.5f, 0, 0, 0, 0);
    }

    @Override
    public boolean shouldSideBeRendered(IBlockAccess iblockaccess, int i, int j, int k, int l) {
        return super.shouldSideBeRendered(iblockaccess, i, j, k, l);
    }

    @Override
    public void addCollisionBoxesToList(World par1World, int i, int j, int k, AxisAlignedBB par5AxisAlignedBB, List arrayList, Entity par7Entity) {
        int l = par1World.getBlockMetadata(i, j, k);
        if (l == 0) {
            this.setBlockBounds(0.8f, 0.6f, 0.1f, 0.9f, 1.2f, 0.9f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            this.setBlockBounds(0.1f, 0.0f, 0.1f, 0.9f, 0.6f, 0.9f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
        } else if (l == 1) {
            this.setBlockBounds(0.1f, 0.6f, 0.1f, 0.2f, 1.2f, 0.9f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            this.setBlockBounds(0.1f, 0.0f, 0.1f, 0.9f, 0.6f, 0.9f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
        } else if (l == 2) {
            this.setBlockBounds(0.1f, 0.6f, 0.8f, 0.9f, 1.2f, 0.9f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            this.setBlockBounds(0.1f, 0.0f, 0.1f, 0.9f, 0.6f, 0.9f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
        } else if (l == 3) {
            this.setBlockBounds(0.1f, 0.6f, 0.1f, 0.9f, 1.2f, 0.2f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            this.setBlockBounds(0.1f, 0.0f, 0.1f, 0.9f, 0.6f, 0.9f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
        }
    }

    @Override
    public AxisAlignedBB getSelectedBoundingBoxFromPool(World par1World, int par2, int par3, int par4) {
        this.setBlockBounds(0.1f, 0.0f, 0.1f, 0.9f, 1.2f, 0.9f);
        return super.getCollisionBoundingBoxFromPool(par1World, par2, par3, par4);
    }

    @Override
    public int idDropped(int i, Random random, int j) {
        if (this.blockID == mod_FurnitureMod.chairWood.blockID) {
            return mod_FurnitureMod.itemChairWood.itemID;
        }
        if (this.blockID == mod_FurnitureMod.chairStone.blockID) {
            return mod_FurnitureMod.itemChairStone.itemID;
        }
        return i;
    }

    @Override
    public int idPicked(World par1World, int par2, int par3, int par4) {
        if (this.blockID == mod_FurnitureMod.chairWood.blockID) {
            return mod_FurnitureMod.itemChairWood.itemID;
        }
        if (this.blockID == mod_FurnitureMod.chairStone.blockID) {
            return mod_FurnitureMod.itemChairStone.itemID;
        }
        return this.blockID;
    }
}
