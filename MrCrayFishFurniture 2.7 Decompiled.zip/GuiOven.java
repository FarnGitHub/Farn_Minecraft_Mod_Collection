import net.minecraft.src.GuiContainer;
import net.minecraft.src.InventoryPlayer;
import org.lwjgl.opengl.GL11;

public class GuiOven
extends GuiContainer {
    private TileEntityOven OvenInventory;

    public GuiOven(InventoryPlayer inventoryplayer, TileEntityOven tileEntityFreezer) {
        super(new ContainerOven(inventoryplayer, tileEntityFreezer));
        this.OvenInventory = tileEntityFreezer;
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int par1, int par2) {
        this.fontRenderer.drawString("Oven", 75, 6, 0x404040);
        this.fontRenderer.drawString("Inventory", 8, this.ySize - 96 + 2, 0x404040);
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float f, int i, int j) {
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        this.mc.renderEngine.bindTexture("/gui/oven.png");
        int l = (this.width - this.xSize) / 2;
        int i1 = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(l, i1, 0, 0, this.xSize, this.ySize);
        int var7 = this.OvenInventory.getCoolProgressScaled(24);
        this.drawTexturedModalRect(l + 75, i1 + 20, 176, 14, var7 + 1, 16);
        this.drawTexturedModalRect(l + 66, i1 + 40, 176, 0, 14, 14);
        this.drawTexturedModalRect(l + 81, i1 + 40, 176, 0, 14, 14);
        this.drawTexturedModalRect(l + 96, i1 + 40, 176, 0, 14, 14);
    }
}
