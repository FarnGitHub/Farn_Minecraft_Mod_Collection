import java.util.HashMap;
import java.util.Map;
import net.minecraft.src.Block;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;

public class FreezerRecipes {
    private static final FreezerRecipes solidifyingBase = new FreezerRecipes();
    private Map solidifyingList = new HashMap();

    public static final FreezerRecipes solidifying() {
        return solidifyingBase;
    }

    private FreezerRecipes() {
        this.addSolidifying(Item.bucketLava.itemID, new ItemStack(Block.obsidian));
        this.addSolidifying(Item.bucketWater.itemID, new ItemStack(Block.ice));
        this.addSolidifying(Item.rottenFlesh.itemID, new ItemStack(Item.porkRaw));
        this.addSolidifying(Item.rottenFlesh.itemID, new ItemStack(Item.porkRaw));
        this.addSolidifying(Item.slimeBall.itemID, new ItemStack(Item.snowball));
        this.addSolidifying(Item.poisonousPotato.itemID, new ItemStack(Item.potato));
        this.addSolidifying(Item.rottenFlesh.itemID, new ItemStack(mod_FurnitureMod.itemFlesh));
    }

    public void addSolidifying(int i, ItemStack itemstack) {
        this.solidifyingList.put(i, itemstack);
    }

    public ItemStack getSolidifyingResult(int i) {
        return (ItemStack)this.solidifyingList.get(i);
    }

    public Map getSolidifyingList() {
        return this.solidifyingList;
    }
}
