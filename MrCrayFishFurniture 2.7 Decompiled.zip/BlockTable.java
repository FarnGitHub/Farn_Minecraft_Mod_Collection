import java.util.Random;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.Material;
import net.minecraft.src.World;

public class BlockTable
extends Block {
    protected BlockTable(int i, Material material) {
        super(i, material);
    }

    @Override
    public boolean isOpaqueCube() {
        return false;
    }

    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }

    @Override
    public int getRenderType() {
        return mod_FurnitureMod.renderTable;
    }

    @Override
    public int idDropped(int i, Random random, int j) {
        if (i == 1) {
            return mod_FurnitureMod.itemTableWood.itemID;
        }
        if (i == 2) {
            return mod_FurnitureMod.itemTableStone.itemID;
        }
        return i;
    }

    @Override
    public boolean shouldSideBeRendered(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5) {
        return super.shouldSideBeRendered(par1IBlockAccess, par2, par3, par4, par5);
    }

    @Override
    public boolean onBlockActivated(World par1World, int par2, int par3, int par4, EntityPlayer par5EntityPlayer, int par6, float par7, float par8, float par9) {
        return false;
    }

    @Override
    public AxisAlignedBB getSelectedBoundingBoxFromPool(World par1World, int par2, int par3, int par4) {
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        return super.getCollisionBoundingBoxFromPool(par1World, par2, par3, par4);
    }

    @Override
    public int idPicked(World par1World, int par2, int par3, int par4) {
        if (par1World.getBlockMetadata(par2, par3, par4) == 1) {
            return mod_FurnitureMod.itemTableWood.itemID;
        }
        if (par1World.getBlockMetadata(par2, par3, par4) == 2) {
            return mod_FurnitureMod.itemTableStone.itemID;
        }
        return this.blockID;
    }
}
