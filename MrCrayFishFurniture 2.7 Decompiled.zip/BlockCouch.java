import java.util.List;
import java.util.Random;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.World;

public class BlockCouch
extends BlockMountable {
    protected BlockCouch(int i, int j, Material material) {
        super(i, j, material);
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.6f, 1.0f);
    }

    @Override
    public boolean isOpaqueCube() {
        return false;
    }

    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }

    @Override
    public int getRenderType() {
        return mod_FurnitureMod.renderCouchLeft;
    }

    @Override
    public boolean onBlockActivated(World world, int i, int j, int k, EntityPlayer entityplayer, int par6, float par7, float par8, float par9) {
        return BlockCouch.onBlockActivated(world, i, j, k, entityplayer, 0.5f, 0.6f, 0.5f, 0, 0, 0, 0);
    }

    @Override
    public void addCollisionBoxesToList(World par1World, int i, int j, int k, AxisAlignedBB par5AxisAlignedBB, List arrayList, Entity par7Entity) {
        int l = par1World.getBlockMetadata(i, j, k);
        if (l == 0) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.6f, 1.0f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            this.setBlockBounds(0.75f, 0.6f, 0.0f, 1.0f, 1.2f, 1.0f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            if (par1World.isAirBlock(i, j, k - 1) && !par1World.isAirBlock(i, j, k + 1) && par1World.getBlockId(i - 1, j, k) != mod_FurnitureMod.couchBlackID && par1World.getBlockId(i - 1, j, k) != mod_FurnitureMod.couchBrownID && par1World.getBlockId(i - 1, j, k) != mod_FurnitureMod.couchGreenID && par1World.getBlockId(i - 1, j, k) != mod_FurnitureMod.couchRedID && par1World.getBlockId(i - 1, j, k) != mod_FurnitureMod.couchWhiteID) {
                this.setBlockBounds(-0.001f, 0.5f, -0.2f, 1.001f, 0.9f, 0.05f);
                super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            } else if (!par1World.isAirBlock(i, j, k - 1) && par1World.isAirBlock(i, j, k + 1) && par1World.getBlockId(i - 1, j, k) != mod_FurnitureMod.couchBlackID && par1World.getBlockId(i - 1, j, k) != mod_FurnitureMod.couchBrownID && par1World.getBlockId(i - 1, j, k) != mod_FurnitureMod.couchGreenID && par1World.getBlockId(i - 1, j, k) != mod_FurnitureMod.couchRedID && par1World.getBlockId(i - 1, j, k) != mod_FurnitureMod.couchWhiteID) {
                this.setBlockBounds(-0.001f, 0.5f, 0.95f, 1.001f, 0.9f, 1.2f);
                super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            } else if (!par1World.isAirBlock(i, j, k - 1) | !par1World.isAirBlock(i, j, k + 1)) {
                if (par1World.getBlockId(i - 1, j, k) == mod_FurnitureMod.couchBlackID | par1World.getBlockId(i - 1, j, k) == mod_FurnitureMod.couchBrownID | par1World.getBlockId(i - 1, j, k) == mod_FurnitureMod.couchGreenID | par1World.getBlockId(i - 1, j, k) == mod_FurnitureMod.couchRedID | par1World.getBlockId(i - 1, j, k) == mod_FurnitureMod.couchWhiteID) {
                    if (par1World.getBlockMetadata(i - 1, j, k) == 2) {
                        this.setBlockBounds(0.0f, 0.6f, 0.75f, 0.75f, 1.2f, 1.0f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                    if (par1World.getBlockMetadata(i - 1, j, k) == 3) {
                        this.setBlockBounds(0.0f, 0.6f, 0.0f, 0.75f, 1.2f, 0.25f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                    if (par1World.getBlockMetadata(i - 1, j, k) == 0 | par1World.getBlockMetadata(i - 1, j, k) == 1 && !par1World.isAirBlock(i, j, k + 1)) {
                        this.setBlockBounds(-0.001f, 0.5f, -0.2f, 1.001f, 0.9f, 0.05f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                    if (par1World.getBlockMetadata(i - 1, j, k) == 0 | par1World.getBlockMetadata(i - 1, j, k) == 1 && !par1World.isAirBlock(i, j, k - 1)) {
                        this.setBlockBounds(-0.001f, 0.5f, 0.95f, 1.001f, 0.9f, 1.2f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                }
            } else if (par1World.isAirBlock(i, j, k - 1) && par1World.isAirBlock(i, j, k + 1)) {
                if (par1World.getBlockId(i - 1, j, k) == mod_FurnitureMod.couchBlackID | par1World.getBlockId(i - 1, j, k) == mod_FurnitureMod.couchBrownID | par1World.getBlockId(i - 1, j, k) == mod_FurnitureMod.couchGreenID | par1World.getBlockId(i - 1, j, k) == mod_FurnitureMod.couchRedID | par1World.getBlockId(i - 1, j, k) == mod_FurnitureMod.couchWhiteID) {
                    if (par1World.getBlockMetadata(i - 1, j, k) == 2) {
                        this.setBlockBounds(0.0f, 0.6f, 0.75f, 0.75f, 1.2f, 1.0f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    } else if (par1World.getBlockMetadata(i - 1, j, k) == 3) {
                        this.setBlockBounds(0.0f, 0.6f, 0.0f, 0.75f, 1.2f, 0.25f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    } else {
                        this.setBlockBounds(-0.001f, 0.5f, -0.2f, 1.001f, 0.9f, 0.05f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                        this.setBlockBounds(-0.001f, 0.5f, 0.95f, 1.001f, 0.9f, 1.2f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                } else {
                    this.setBlockBounds(-0.001f, 0.5f, -0.2f, 1.001f, 0.9f, 0.05f);
                    super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    this.setBlockBounds(-0.001f, 0.5f, 0.95f, 1.001f, 0.9f, 1.2f);
                    super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                }
            }
        }
        if (l == 2) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.6f, 1.0f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            this.setBlockBounds(0.0f, 0.6f, 0.75f, 1.0f, 1.2f, 1.0f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            if (par1World.isAirBlock(i + 1, j, k) && !par1World.isAirBlock(i - 1, j, k) && par1World.getBlockId(i, j, k - 1) != mod_FurnitureMod.couchBlackID && par1World.getBlockId(i, j, k - 1) != mod_FurnitureMod.couchBrownID && par1World.getBlockId(i, j, k - 1) != mod_FurnitureMod.couchGreenID && par1World.getBlockId(i, j, k - 1) != mod_FurnitureMod.couchRedID && par1World.getBlockId(i, j, k - 1) != mod_FurnitureMod.couchWhiteID) {
                this.setBlockBounds(0.95f, 0.5f, -0.001f, 1.2f, 0.9f, 1.001f);
                super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            } else if (par1World.isAirBlock(i - 1, j, k) && !par1World.isAirBlock(i + 1, j, k) && par1World.getBlockId(i, j, k - 1) != mod_FurnitureMod.couchBlackID && par1World.getBlockId(i, j, k - 1) != mod_FurnitureMod.couchBrownID && par1World.getBlockId(i, j, k - 1) != mod_FurnitureMod.couchGreenID && par1World.getBlockId(i, j, k - 1) != mod_FurnitureMod.couchRedID && par1World.getBlockId(i, j, k - 1) != mod_FurnitureMod.couchWhiteID) {
                this.setBlockBounds(-0.2f, 0.5f, -0.001f, 0.05f, 0.9f, 1.001f);
                super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            } else if (!par1World.isAirBlock(i + 1, j, k) | !par1World.isAirBlock(i - 1, j, k)) {
                if (par1World.getBlockId(i, j, k - 1) == mod_FurnitureMod.couchBlackID | par1World.getBlockId(i, j, k - 1) == mod_FurnitureMod.couchBrownID | par1World.getBlockId(i, j, k - 1) == mod_FurnitureMod.couchGreenID | par1World.getBlockId(i, j, k - 1) == mod_FurnitureMod.couchRedID | par1World.getBlockId(i, j, k - 1) == mod_FurnitureMod.couchWhiteID) {
                    if (par1World.getBlockMetadata(i, j, k - 1) == 1) {
                        this.setBlockBounds(0.0f, 0.6f, 0.0f, 0.25f, 1.2f, 0.75f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                    if (par1World.getBlockMetadata(i, j, k - 1) == 0) {
                        this.setBlockBounds(0.75f, 0.6f, 0.0f, 1.0f, 1.2f, 0.75f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                    if (par1World.getBlockMetadata(i, j, k - 1) == 2 | par1World.getBlockMetadata(i, j, k - 1) == 3 && !par1World.isAirBlock(i - 1, j, k)) {
                        this.setBlockBounds(0.95f, 0.5f, -0.001f, 1.2f, 0.9f, 1.001f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                    if (par1World.getBlockMetadata(i, j, k - 1) == 2 | par1World.getBlockMetadata(i, j, k - 1) == 3 && !par1World.isAirBlock(i + 1, j, k)) {
                        this.setBlockBounds(-0.2f, 0.5f, -0.001f, 0.05f, 0.9f, 1.001f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                }
            } else if (par1World.isAirBlock(i + 1, j, k) && par1World.isAirBlock(i - 1, j, k)) {
                if (par1World.getBlockId(i, j, k - 1) == mod_FurnitureMod.couchBlackID | par1World.getBlockId(i, j, k - 1) == mod_FurnitureMod.couchBrownID | par1World.getBlockId(i, j, k - 1) == mod_FurnitureMod.couchGreenID | par1World.getBlockId(i, j, k - 1) == mod_FurnitureMod.couchRedID | par1World.getBlockId(i, j, k - 1) == mod_FurnitureMod.couchWhiteID) {
                    if (par1World.getBlockMetadata(i, j, k - 1) == 1) {
                        this.setBlockBounds(0.0f, 0.6f, 0.0f, 0.25f, 1.2f, 0.75f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    } else if (par1World.getBlockMetadata(i, j, k - 1) == 0) {
                        this.setBlockBounds(0.75f, 0.6f, 0.0f, 1.0f, 1.2f, 0.75f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    } else {
                        this.setBlockBounds(0.95f, 0.5f, -0.001f, 1.2f, 0.9f, 1.001f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                        this.setBlockBounds(-0.2f, 0.5f, -0.001f, 0.05f, 0.9f, 1.001f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                } else {
                    this.setBlockBounds(0.95f, 0.5f, -0.001f, 1.2f, 0.9f, 1.001f);
                    super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    this.setBlockBounds(-0.2f, 0.5f, -0.001f, 0.05f, 0.9f, 1.001f);
                    super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                }
            }
        }
        if (l == 1) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.6f, 1.0f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            this.setBlockBounds(0.0f, 0.6f, 0.0f, 0.25f, 1.2f, 1.0f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            if (par1World.isAirBlock(i, j, k - 1) && !par1World.isAirBlock(i, j, k + 1) && par1World.getBlockId(i + 1, j, k) != mod_FurnitureMod.couchBlackID && par1World.getBlockId(i + 1, j, k) != mod_FurnitureMod.couchBrownID && par1World.getBlockId(i + 1, j, k) != mod_FurnitureMod.couchGreenID && par1World.getBlockId(i + 1, j, k) != mod_FurnitureMod.couchRedID && par1World.getBlockId(i + 1, j, k) != mod_FurnitureMod.couchWhiteID) {
                this.setBlockBounds(-0.001f, 0.5f, -0.2f, 1.001f, 0.9f, 0.05f);
                super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            } else if (!par1World.isAirBlock(i, j, k - 1) && par1World.isAirBlock(i, j, k + 1) && par1World.getBlockId(i + 1, j, k) != mod_FurnitureMod.couchBlackID && par1World.getBlockId(i + 1, j, k) != mod_FurnitureMod.couchBrownID && par1World.getBlockId(i + 1, j, k) != mod_FurnitureMod.couchGreenID && par1World.getBlockId(i + 1, j, k) != mod_FurnitureMod.couchRedID && par1World.getBlockId(i + 1, j, k) != mod_FurnitureMod.couchWhiteID) {
                this.setBlockBounds(-0.001f, 0.5f, 0.95f, 1.001f, 0.9f, 1.2f);
                super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            } else if (!par1World.isAirBlock(i, j, k + 1) | !par1World.isAirBlock(i, j, k - 1)) {
                if (par1World.getBlockId(i + 1, j, k) == mod_FurnitureMod.couchBlackID | par1World.getBlockId(i + 1, j, k) == mod_FurnitureMod.couchBrownID | par1World.getBlockId(i + 1, j, k) == mod_FurnitureMod.couchGreenID | par1World.getBlockId(i + 1, j, k) == mod_FurnitureMod.couchRedID | par1World.getBlockId(i + 1, j, k) == mod_FurnitureMod.couchWhiteID) {
                    if (par1World.getBlockMetadata(i + 1, j, k) == 2) {
                        this.setBlockBounds(0.0f, 0.6f, 0.75f, 1.0f, 1.2f, 1.0f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                    if (par1World.getBlockMetadata(i + 1, j, k) == 3) {
                        this.setBlockBounds(0.0f, 0.6f, 0.0f, 1.0f, 1.2f, 0.25f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                    if (par1World.getBlockMetadata(i + 1, j, k) == 1 | par1World.getBlockMetadata(i + 1, j, k) == 0 && !par1World.isAirBlock(i, j, k + 1)) {
                        this.setBlockBounds(-0.001f, 0.5f, -0.2f, 1.001f, 0.9f, 0.05f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                    if (par1World.getBlockMetadata(i + 1, j, k) == 1 | par1World.getBlockMetadata(i + 1, j, k) == 0 && !par1World.isAirBlock(i, j, k - 1)) {
                        this.setBlockBounds(-0.001f, 0.5f, 0.95f, 1.001f, 0.9f, 1.2f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                }
            } else if (par1World.isAirBlock(i, j, k - 1) && par1World.isAirBlock(i, j, k + 1)) {
                if (par1World.getBlockId(i + 1, j, k) == mod_FurnitureMod.couchBlackID | par1World.getBlockId(i + 1, j, k) == mod_FurnitureMod.couchBrownID | par1World.getBlockId(i + 1, j, k) == mod_FurnitureMod.couchGreenID | par1World.getBlockId(i + 1, j, k) == mod_FurnitureMod.couchRedID | par1World.getBlockId(i + 1, j, k) == mod_FurnitureMod.couchWhiteID) {
                    if (par1World.getBlockMetadata(i + 1, j, k) == 2) {
                        this.setBlockBounds(0.0f, 0.6f, 0.75f, 1.0f, 1.2f, 1.0f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    } else if (par1World.getBlockMetadata(i + 1, j, k) == 3) {
                        this.setBlockBounds(0.0f, 0.6f, 0.0f, 1.0f, 1.2f, 0.25f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    } else {
                        this.setBlockBounds(-0.001f, 0.5f, 0.95f, 1.001f, 0.9f, 1.2f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                        this.setBlockBounds(-0.001f, 0.5f, -0.2f, 1.001f, 0.9f, 0.05f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                } else {
                    this.setBlockBounds(-0.001f, 0.5f, 0.95f, 1.001f, 0.9f, 1.2f);
                    super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    this.setBlockBounds(-0.001f, 0.5f, -0.2f, 1.001f, 0.9f, 0.05f);
                    super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                }
            }
        }
        if (l == 3) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.6f, 1.0f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            this.setBlockBounds(0.0f, 0.6f, 0.0f, 1.0f, 1.2f, 0.25f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            if (par1World.isAirBlock(i + 1, j, k) && !par1World.isAirBlock(i - 1, j, k) && par1World.getBlockId(i, j, k + 1) != mod_FurnitureMod.couchBlackID && par1World.getBlockId(i, j, k + 1) != mod_FurnitureMod.couchBrownID && par1World.getBlockId(i, j, k + 1) != mod_FurnitureMod.couchGreenID && par1World.getBlockId(i, j, k + 1) != mod_FurnitureMod.couchRedID && par1World.getBlockId(i, j, k + 1) != mod_FurnitureMod.couchWhiteID) {
                this.setBlockBounds(0.95f, 0.5f, -0.001f, 1.2f, 0.9f, 1.001f);
                super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            } else if (par1World.isAirBlock(i - 1, j, k) && !par1World.isAirBlock(i + 1, j, k) && par1World.getBlockId(i, j, k + 1) != mod_FurnitureMod.couchBlackID && par1World.getBlockId(i, j, k + 1) != mod_FurnitureMod.couchBrownID && par1World.getBlockId(i, j, k + 1) != mod_FurnitureMod.couchGreenID && par1World.getBlockId(i, j, k + 1) != mod_FurnitureMod.couchRedID && par1World.getBlockId(i, j, k + 1) != mod_FurnitureMod.couchWhiteID) {
                this.setBlockBounds(-0.2f, 0.5f, -0.001f, 0.05f, 0.9f, 1.001f);
                super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
            } else if (!par1World.isAirBlock(i + 1, j, k) | !par1World.isAirBlock(i - 1, j, k)) {
                if (par1World.getBlockId(i, j, k + 1) == mod_FurnitureMod.couchBlackID | par1World.getBlockId(i, j, k + 1) == mod_FurnitureMod.couchBrownID | par1World.getBlockId(i, j, k + 1) == mod_FurnitureMod.couchGreenID | par1World.getBlockId(i, j, k + 1) == mod_FurnitureMod.couchRedID | par1World.getBlockId(i, j, k + 1) == mod_FurnitureMod.couchWhiteID) {
                    if (par1World.getBlockMetadata(i, j, k + 1) == 0) {
                        this.setBlockBounds(0.75f, 0.6f, 0.25f, 1.0f, 1.2f, 1.0f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                    if (par1World.getBlockMetadata(i, j, k + 1) == 1) {
                        this.setBlockBounds(0.0f, 0.6f, 0.25f, 0.25f, 1.2f, 1.0f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                    if (par1World.getBlockMetadata(i, j, k + 1) == 2 | par1World.getBlockMetadata(i, j, k + 1) == 3 && !par1World.isAirBlock(i - 1, j, k)) {
                        this.setBlockBounds(0.95f, 0.5f, -0.001f, 1.2f, 0.9f, 1.001f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                    if (par1World.getBlockMetadata(i, j, k + 1) == 2 | par1World.getBlockMetadata(i, j, k + 1) == 3 && !par1World.isAirBlock(i + 1, j, k)) {
                        this.setBlockBounds(-0.2f, 0.5f, -0.001f, 0.05f, 0.9f, 1.001f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                }
            } else if (par1World.isAirBlock(i + 1, j, k) && par1World.isAirBlock(i - 1, j, k)) {
                if (par1World.getBlockId(i, j, k + 1) == mod_FurnitureMod.couchBlackID | par1World.getBlockId(i, j, k + 1) == mod_FurnitureMod.couchBrownID | par1World.getBlockId(i, j, k + 1) == mod_FurnitureMod.couchGreenID | par1World.getBlockId(i, j, k + 1) == mod_FurnitureMod.couchRedID | par1World.getBlockId(i, j, k + 1) == mod_FurnitureMod.couchWhiteID) {
                    if (par1World.getBlockMetadata(i, j, k + 1) == 0) {
                        this.setBlockBounds(0.75f, 0.6f, 0.25f, 1.0f, 1.2f, 1.0f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    } else if (par1World.getBlockMetadata(i, j, k + 1) == 1) {
                        this.setBlockBounds(0.0f, 0.6f, 0.25f, 0.25f, 1.2f, 1.0f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    } else {
                        this.setBlockBounds(-0.2f, 0.5f, -0.001f, 0.05f, 0.9f, 1.001f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                        this.setBlockBounds(0.95f, 0.5f, -0.001f, 1.2f, 0.9f, 1.001f);
                        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    }
                } else {
                    this.setBlockBounds(-0.2f, 0.5f, -0.001f, 0.05f, 0.9f, 1.001f);
                    super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                    this.setBlockBounds(0.95f, 0.5f, -0.001f, 1.2f, 0.9f, 1.001f);
                    super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
                }
            }
        }
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.6f, 1.0f);
    }

    public void onBlockPlacedBy(World world, int i, int j, int k, EntityLiving entityliving) {
        int l = MathHelper.floor_double((double)(entityliving.rotationYaw * 4.0f / 360.0f) + 0.5) & 3;
        if (l == 0) {
            world.setBlockMetadataWithNotify(i, j, k, 2, 0);
        }
        if (l == 1) {
            world.setBlockMetadataWithNotify(i, j, k, 1, 0);
        }
        if (l == 2) {
            world.setBlockMetadataWithNotify(i, j, k, 3, 0);
        }
        if (l == 3) {
            world.setBlockMetadataWithNotify(i, j, k, 0, 0);
        }
    }

    @Override
    public int idPicked(World par1World, int par2, int par3, int par4) {
        if (this.blockID == mod_FurnitureMod.couchWhite.blockID) {
            return mod_FurnitureMod.itemCouchWhite.itemID;
        }
        if (this.blockID == mod_FurnitureMod.couchGreen.blockID) {
            return mod_FurnitureMod.itemCouchGreen.itemID;
        }
        if (this.blockID == mod_FurnitureMod.couchBrown.blockID) {
            return mod_FurnitureMod.itemCouchBrown.itemID;
        }
        if (this.blockID == mod_FurnitureMod.couchRed.blockID) {
            return mod_FurnitureMod.itemCouchRed.itemID;
        }
        if (this.blockID == mod_FurnitureMod.couchBlack.blockID) {
            return mod_FurnitureMod.itemCouchBlack.itemID;
        }
        return this.blockID;
    }

    @Override
    public int idDropped(int i, Random random, int j) {
        if (this.blockID == mod_FurnitureMod.couchWhite.blockID) {
            return mod_FurnitureMod.itemCouchWhite.itemID;
        }
        if (this.blockID == mod_FurnitureMod.couchGreen.blockID) {
            return mod_FurnitureMod.itemCouchGreen.itemID;
        }
        if (this.blockID == mod_FurnitureMod.couchBrown.blockID) {
            return mod_FurnitureMod.itemCouchBrown.itemID;
        }
        if (this.blockID == mod_FurnitureMod.couchRed.blockID) {
            return mod_FurnitureMod.itemCouchRed.itemID;
        }
        if (this.blockID == mod_FurnitureMod.couchBlack.blockID) {
            return mod_FurnitureMod.itemCouchBlack.itemID;
        }
        return this.blockID;
    }
}
