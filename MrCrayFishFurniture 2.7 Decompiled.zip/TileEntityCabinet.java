import net.minecraft.src.EntityPlayer;
import net.minecraft.src.IInventory;
import net.minecraft.src.ItemStack;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.NBTTagList;
import net.minecraft.src.TileEntity;

public class TileEntityCabinet
extends TileEntity
implements IInventory {
    private ItemStack[] cabinetContents = new ItemStack[36];

    @Override
    public int getSizeInventory() {
        return 27;
    }

    @Override
    public ItemStack getStackInSlot(int par1) {
        return this.cabinetContents[par1];
    }

    @Override
    public ItemStack decrStackSize(int par1, int par2) {
        if (this.cabinetContents[par1] != null) {
            if (this.cabinetContents[par1].stackSize <= par2) {
                ItemStack var3 = this.cabinetContents[par1];
                this.cabinetContents[par1] = null;
                this.onInventoryChanged();
                return var3;
            }
            ItemStack var3 = this.cabinetContents[par1].splitStack(par2);
            if (this.cabinetContents[par1].stackSize == 0) {
                this.cabinetContents[par1] = null;
            }
            this.onInventoryChanged();
            return var3;
        }
        return null;
    }

    @Override
    public ItemStack getStackInSlotOnClosing(int par1) {
        if (this.cabinetContents[par1] != null) {
            ItemStack var2 = this.cabinetContents[par1];
            this.cabinetContents[par1] = null;
            return var2;
        }
        return null;
    }

    @Override
    public void setInventorySlotContents(int par1, ItemStack par2ItemStack) {
        this.cabinetContents[par1] = par2ItemStack;
        if (par2ItemStack != null && par2ItemStack.stackSize > this.getInventoryStackLimit()) {
            par2ItemStack.stackSize = this.getInventoryStackLimit();
        }
        this.onInventoryChanged();
    }

    @Override
    public String getInvName() {
        return "Cabinet";
    }

    @Override
    public void readFromNBT(NBTTagCompound par1NBTTagCompound) {
        super.readFromNBT(par1NBTTagCompound);
        NBTTagList var2 = par1NBTTagCompound.getTagList("cabinetItems");
        this.cabinetContents = new ItemStack[this.getSizeInventory()];
        for (int var3 = 0; var3 < var2.tagCount(); ++var3) {
            NBTTagCompound var4 = (NBTTagCompound)var2.tagAt(var3);
            int var5 = var4.getByte("cabinetSlot") & 0xFF;
            if (var5 < 0 || var5 >= this.cabinetContents.length) continue;
            this.cabinetContents[var5] = ItemStack.loadItemStackFromNBT(var4);
        }
    }

    @Override
    public void writeToNBT(NBTTagCompound par1NBTTagCompound) {
        super.writeToNBT(par1NBTTagCompound);
        NBTTagList var2 = new NBTTagList();
        for (int var3 = 0; var3 < this.cabinetContents.length; ++var3) {
            if (this.cabinetContents[var3] == null) continue;
            NBTTagCompound var4 = new NBTTagCompound();
            var4.setByte("cabinetSlot", (byte)var3);
            this.cabinetContents[var3].writeToNBT(var4);
            var2.appendTag(var4);
        }
        par1NBTTagCompound.setTag("cabinetItems", var2);
    }

    @Override
    public int getInventoryStackLimit() {
        return 64;
    }

    @Override
    public boolean isUseableByPlayer(EntityPlayer par1EntityPlayer) {
        return this.worldObj.getBlockTileEntity(this.xCoord, this.yCoord, this.zCoord) != this ? false : par1EntityPlayer.getDistanceSq((double)this.xCoord + 0.5, (double)this.yCoord + 0.5, (double)this.zCoord + 0.5) <= 64.0;
    }

    @Override
    public void updateContainingBlockInfo() {
        super.updateContainingBlockInfo();
    }

    @Override
    public void updateEntity() {
        super.updateEntity();
    }

    @Override
    public void openChest() {
    }

    @Override
    public void closeChest() {
    }

    @Override
    public void invalidate() {
        this.updateContainingBlockInfo();
        super.invalidate();
    }

    @Override
    public boolean isInvNameLocalized() {
        return false;
    }

    @Override
    public boolean isStackValidForSlot(int var1, ItemStack var2) {
        return false;
    }
}
