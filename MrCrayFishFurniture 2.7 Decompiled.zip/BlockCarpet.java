import java.util.Random;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Icon;
import net.minecraft.src.IconRegister;
import net.minecraft.src.Material;
import net.minecraft.src.World;

public class BlockCarpet
extends Block {
    private Icon icon1;
    private Icon icon2;
    private Icon icon3;
    private Icon icon4;
    private Icon icon5;

    protected BlockCarpet(int i, Material material) {
        super(i, material);
    }

    @Override
    public boolean isOpaqueCube() {
        return false;
    }

    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }

    @Override
    public int getRenderType() {
        return mod_FurnitureMod.renderCarpet;
    }

    @Override
    public int idDropped(int i, Random random, int j) {
        if (i == 1) {
            return mod_FurnitureMod.itemCarpetBlack.itemID;
        }
        if (i == 2) {
            return mod_FurnitureMod.itemCarpetBrown.itemID;
        }
        if (i == 3) {
            return mod_FurnitureMod.itemCarpetRed.itemID;
        }
        if (i == 4) {
            return mod_FurnitureMod.itemCarpetWhite.itemID;
        }
        if (i == 5) {
            return mod_FurnitureMod.itemCarpetGreen.itemID;
        }
        return i;
    }

    @Override
    public int idPicked(World par1World, int par2, int par3, int par4) {
        if (par1World.getBlockMetadata(par2, par3, par4) == 1) {
            return mod_FurnitureMod.itemCarpetBlack.itemID;
        }
        if (par1World.getBlockMetadata(par2, par3, par4) == 2) {
            return mod_FurnitureMod.itemCarpetBrown.itemID;
        }
        if (par1World.getBlockMetadata(par2, par3, par4) == 3) {
            return mod_FurnitureMod.itemCarpetRed.itemID;
        }
        if (par1World.getBlockMetadata(par2, par3, par4) == 4) {
            return mod_FurnitureMod.itemCarpetWhite.itemID;
        }
        if (par1World.getBlockMetadata(par2, par3, par4) == 5) {
            return mod_FurnitureMod.itemCarpetGreen.itemID;
        }
        return par2;
    }

    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k) {
        return null;
    }

    @Override
    public AxisAlignedBB getSelectedBoundingBoxFromPool(World par1World, int par2, int par3, int par4) {
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.001f, 1.0f);
        return super.getCollisionBoundingBoxFromPool(par1World, par2, par3, par4);
    }

    public boolean blockActivated(World world, int i, int j, int k, EntityPlayer entityplayer) {
        return true;
    }

    @Override
    public Icon getBlockTextureFromSideAndMetadata(int par1, int par2) {
        if (par2 == 1) {
            this.blockIcon = this.icon1;
        }
        if (par2 == 2) {
            this.blockIcon = this.icon2;
        }
        if (par2 == 3) {
            this.blockIcon = this.icon3;
        }
        if (par2 == 4) {
            this.blockIcon = this.icon4;
        }
        if (par2 == 5) {
            this.blockIcon = this.icon5;
        }
        return this.blockIcon;
    }

    public void func_94332_a(IconRegister par1IconRegister) {
        this.icon1 = par1IconRegister.registerIcon("cloth_15");
        this.icon2 = par1IconRegister.registerIcon("cloth_12");
        this.icon3 = par1IconRegister.registerIcon("cloth_14");
        this.icon4 = par1IconRegister.registerIcon("cloth_0");
        this.icon5 = par1IconRegister.registerIcon("cloth_13");
    }
}
