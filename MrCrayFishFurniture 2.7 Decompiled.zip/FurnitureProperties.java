import java.util.Collections;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;

public class FurnitureProperties
extends Properties {
    @Override
    public synchronized Enumeration keys() {
        Enumeration<Object> enumeration = super.keys();
        Vector<Object> vector = new Vector<Object>();
        while (enumeration.hasMoreElements()) {
            vector.add(enumeration.nextElement());
        }
        Collections.sort(vector);
        return vector.elements();
    }
}
