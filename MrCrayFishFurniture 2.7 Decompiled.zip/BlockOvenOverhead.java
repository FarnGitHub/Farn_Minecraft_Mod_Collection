import java.util.List;
import java.util.Random;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.Entity;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.Material;
import net.minecraft.src.World;

public class BlockOvenOverhead
extends Block {
    protected BlockOvenOverhead(int i, Material material) {
        super(i, material);
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.6f, 1.0f);
    }

    @Override
    public boolean isOpaqueCube() {
        return false;
    }

    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }

    @Override
    public int getRenderType() {
        return mod_FurnitureMod.renderOvenOverhead;
    }

    @Override
    public boolean shouldSideBeRendered(IBlockAccess iblockaccess, int i, int j, int k, int l) {
        return super.shouldSideBeRendered(iblockaccess, i, j, k, l);
    }

    @Override
    public void addCollisionBoxesToList(World par1World, int i, int j, int k, AxisAlignedBB par5AxisAlignedBB, List arrayList, Entity par7Entity) {
        int l = par1World.getBlockMetadata(i, j, k);
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.2f, 1.0f);
        super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
        if (par1World.getBlockMetadata(i, j, k) == 0) {
            this.setBlockBounds(0.2f, 0.2f, 0.5f, 0.8f, 1.0f, 1.0f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
        } else if (par1World.getBlockMetadata(i, j, k) == 2) {
            this.setBlockBounds(0.2f, 0.2f, 0.0f, 0.8f, 1.0f, 0.5f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
        } else if (par1World.getBlockMetadata(i, j, k) == 1) {
            this.setBlockBounds(0.0f, 0.2f, 0.2f, 0.5f, 1.0f, 0.8f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
        } else if (par1World.getBlockMetadata(i, j, k) == 3) {
            this.setBlockBounds(0.5f, 0.2f, 0.2f, 1.0f, 1.0f, 0.8f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
        }
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.6f, 1.0f);
    }

    @Override
    public int idDropped(int i, Random random, int j) {
        if (this.blockID == mod_FurnitureMod.chairWood.blockID) {
            return mod_FurnitureMod.itemChairWood.itemID;
        }
        if (this.blockID == mod_FurnitureMod.chairStone.blockID) {
            return mod_FurnitureMod.itemChairStone.itemID;
        }
        return i;
    }

    @Override
    public int idPicked(World par1World, int par2, int par3, int par4) {
        return mod_FurnitureMod.itemOvenOverhead.itemID;
    }
}
