import java.util.List;
import java.util.Random;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.World;

public class BlockWindowDecoration
extends Block {
    protected BlockWindowDecoration(int i, Material material) {
        super(i, material);
    }

    @Override
    public boolean isOpaqueCube() {
        return false;
    }

    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }

    @Override
    public int getRenderType() {
        return mod_FurnitureMod.renderWindowDecoration;
    }

    @Override
    public void onNeighborBlockChange(World par1World, int par2, int par3, int par4, int par5) {
        int blindsClosed = mod_FurnitureMod.blindsClosed.blockID;
    }

    public void addCollidingBlockToList(World par1World, int i, int j, int k, AxisAlignedBB par5AxisAlignedBB, List arrayList, Entity par7Entity) {
        int l = par1World.getBlockMetadata(i, j, k);
        if (l == 0) {
            this.setBlockBounds(0.0f, 0.0f, 0.9f, 1.0f, 1.0f, 1.0f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
        } else if (l == 2) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.1f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
        } else if (l == 1) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 0.1f, 1.0f, 1.0f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
        } else if (l == 3) {
            this.setBlockBounds(0.9f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
            super.addCollisionBoxesToList(par1World, i, j, k, par5AxisAlignedBB, arrayList, par7Entity);
        }
    }

    @Override
    public AxisAlignedBB getSelectedBoundingBoxFromPool(World world, int i, int j, int k) {
        int l = world.getBlockMetadata(i, j, k);
        if (l == 0) {
            this.setBlockBounds(0.0f, 0.0f, 0.9f, 1.0f, 1.0f, 1.0f);
            super.getSelectedBoundingBoxFromPool(world, i, j, k);
        } else if (l == 2) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.1f);
            super.getSelectedBoundingBoxFromPool(world, i, j, k);
        } else if (l == 1) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 0.1f, 1.0f, 1.0f);
            super.getSelectedBoundingBoxFromPool(world, i, j, k);
        } else if (l == 3) {
            this.setBlockBounds(0.9f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
            super.getSelectedBoundingBoxFromPool(world, i, j, k);
        }
        return super.getSelectedBoundingBoxFromPool(world, i, j, k);
    }

    public void onBlockPlacedBy(World world, int i, int j, int k, EntityLiving entityliving) {
        int l = MathHelper.floor_double((double)(entityliving.rotationYaw * 4.0f / 360.0f) + 0.5) & 3;
        if (l == 0) {
            world.setBlockMetadataWithNotify(i, j, k, 2, 0);
        }
        if (l == 1) {
            world.setBlockMetadataWithNotify(i, j, k, 1, 0);
        }
        if (l == 2) {
            world.setBlockMetadataWithNotify(i, j, k, 3, 0);
        }
        if (l == 3) {
            world.setBlockMetadataWithNotify(i, j, k, 0, 0);
        }
    }

    @Override
    public int idDropped(int i, Random random, int j) {
        if (this.blockID == mod_FurnitureMod.blinds.blockID || this.blockID == mod_FurnitureMod.blindsClosed.blockID) {
            return mod_FurnitureMod.itemBlinds.itemID;
        }
        if (this.blockID == mod_FurnitureMod.curtains.blockID || this.blockID == mod_FurnitureMod.curtainsClosed.blockID) {
            return mod_FurnitureMod.itemCurtains.itemID;
        }
        return 0;
    }

    @Override
    public boolean onBlockActivated(World par1World, int par2, int par3, int par4, EntityPlayer par5EntityPlayer, int par6, float par7, float par8, float par9) {
        int l = par1World.getBlockMetadata(par2, par3, par4);
        if (this.blockID == mod_FurnitureMod.blinds.blockID) {
            par1World.setBlock(par2, par3, par4, mod_FurnitureMod.blindsClosed.blockID, l, 0);
        }
        if (this.blockID == mod_FurnitureMod.curtains.blockID) {
            par1World.setBlock(par2, par3, par4, mod_FurnitureMod.curtainsClosed.blockID, l, 0);
        }
        return true;
    }

    @Override
    public int idPicked(World par1World, int par2, int par3, int par4) {
        if (this.blockID == mod_FurnitureMod.blinds.blockID) {
            return mod_FurnitureMod.itemBlinds.itemID;
        }
        if (this.blockID == mod_FurnitureMod.curtains.blockID) {
            return mod_FurnitureMod.itemCurtains.itemID;
        }
        return this.blockID;
    }
}
