import net.minecraft.src.Block;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.IInventory;
import net.minecraft.src.ItemStack;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.NBTTagList;
import net.minecraft.src.TileEntity;

public class TileEntityFreezer
extends TileEntity
implements IInventory {
    private ItemStack[] freezerItemStacks = new ItemStack[3];
    public int freezerFreezeTime = 0;
    public int currentItemCoolTime = 0;
    public int freezerCoolTime = 0;

    @Override
    public int getSizeInventory() {
        return this.freezerItemStacks.length;
    }

    @Override
    public ItemStack getStackInSlot(int i) {
        return this.freezerItemStacks[i];
    }

    @Override
    public ItemStack decrStackSize(int i, int j) {
        if (this.freezerItemStacks[i] != null) {
            if (this.freezerItemStacks[i].stackSize <= j) {
                ItemStack itemstack = this.freezerItemStacks[i];
                this.freezerItemStacks[i] = null;
                return itemstack;
            }
            ItemStack itemstack1 = this.freezerItemStacks[i].splitStack(j);
            if (this.freezerItemStacks[i].stackSize == 0) {
                this.freezerItemStacks[i] = null;
            }
            return itemstack1;
        }
        return null;
    }

    @Override
    public ItemStack getStackInSlotOnClosing(int par1) {
        if (this.freezerItemStacks[par1] != null) {
            ItemStack itemstack = this.freezerItemStacks[par1];
            this.freezerItemStacks[par1] = null;
            return itemstack;
        }
        return null;
    }

    @Override
    public void setInventorySlotContents(int i, ItemStack itemstack) {
        this.freezerItemStacks[i] = itemstack;
        if (itemstack != null && itemstack.stackSize > this.getInventoryStackLimit()) {
            itemstack.stackSize = this.getInventoryStackLimit();
        }
    }

    @Override
    public String getInvName() {
        return "Freezer";
    }

    @Override
    public void readFromNBT(NBTTagCompound par1NBTTagCompound) {
        super.readFromNBT(par1NBTTagCompound);
        NBTTagList nbttaglist = par1NBTTagCompound.getTagList("Items");
        this.freezerItemStacks = new ItemStack[this.getSizeInventory()];
        for (int i = 0; i < nbttaglist.tagCount(); ++i) {
            NBTTagCompound nbttagcompound = (NBTTagCompound)nbttaglist.tagAt(i);
            byte byte0 = nbttagcompound.getByte("Slot");
            if (byte0 < 0 || byte0 >= this.freezerItemStacks.length) continue;
            this.freezerItemStacks[byte0] = ItemStack.loadItemStackFromNBT(nbttagcompound);
        }
        this.freezerCoolTime = par1NBTTagCompound.getShort("CoolTime");
        this.freezerFreezeTime = par1NBTTagCompound.getShort("FreezeTime");
        this.currentItemCoolTime = TileEntityFreezer.getItemFreezeTime(this.freezerItemStacks[1]);
    }

    @Override
    public void writeToNBT(NBTTagCompound par1NBTTagCompound) {
        super.writeToNBT(par1NBTTagCompound);
        par1NBTTagCompound.setShort("CoolTime", (short)this.freezerCoolTime);
        par1NBTTagCompound.setShort("FreezeTime", (short)this.freezerFreezeTime);
        NBTTagList nbttaglist = new NBTTagList();
        for (int i = 0; i < this.freezerItemStacks.length; ++i) {
            if (this.freezerItemStacks[i] == null) continue;
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            nbttagcompound.setByte("Slot", (byte)i);
            this.freezerItemStacks[i].writeToNBT(nbttagcompound);
            nbttaglist.appendTag(nbttagcompound);
        }
        par1NBTTagCompound.setTag("Items", nbttaglist);
    }

    @Override
    public int getInventoryStackLimit() {
        return 64;
    }

    public int getCoolProgressScaled(int i) {
        return this.freezerCoolTime * i / 200;
    }

    public int getFreezeTimeRemainingScaled(int i) {
        if (this.currentItemCoolTime == 0) {
            this.currentItemCoolTime = 200;
        }
        return this.freezerFreezeTime * i / this.currentItemCoolTime;
    }

    public boolean isFreezing() {
        return this.freezerFreezeTime > 0;
    }

    @Override
    public void updateEntity() {
        boolean flag = this.freezerFreezeTime > 0;
        boolean flag1 = false;
        if (this.freezerFreezeTime > 0) {
            --this.freezerFreezeTime;
        }
        if (!this.worldObj.isRemote) {
            if (this.freezerFreezeTime == 0 && this.canSolidify()) {
                this.currentItemCoolTime = this.freezerFreezeTime = TileEntityFreezer.getItemFreezeTime(this.freezerItemStacks[1]);
                if (this.freezerFreezeTime > 0) {
                    flag1 = true;
                    if (this.freezerItemStacks[1] != null) {
                        --this.freezerItemStacks[1].stackSize;
                        if (this.freezerItemStacks[1].stackSize == 0) {
                            this.freezerItemStacks[1] = null;
                        }
                    }
                }
            }
            if (this.isFreezing() && this.canSolidify()) {
                ++this.freezerCoolTime;
                if (this.freezerCoolTime == 200) {
                    this.freezerCoolTime = 0;
                    this.solidifyItem();
                    flag1 = true;
                }
            } else {
                this.freezerCoolTime = 0;
            }
        }
        if (flag != this.freezerFreezeTime > 0) {
            flag1 = true;
        }
        if (flag1) {
            this.onInventoryChanged();
        }
    }

    private boolean canSolidify() {
        if (this.freezerItemStacks[0] == null) {
            return false;
        }
        ItemStack var1 = FreezerRecipes.solidifying().getSolidifyingResult(this.freezerItemStacks[0].getItem().itemID);
        return var1 == null ? false : (this.freezerItemStacks[2] == null ? true : (!this.freezerItemStacks[2].isItemEqual(var1) ? false : (this.freezerItemStacks[2].stackSize < this.getInventoryStackLimit() && this.freezerItemStacks[2].stackSize < this.freezerItemStacks[2].getMaxStackSize() ? true : this.freezerItemStacks[2].stackSize < var1.getMaxStackSize())));
    }

    public void solidifyItem() {
        if (!this.canSolidify()) {
            return;
        }
        ItemStack itemstack = FreezerRecipes.solidifying().getSolidifyingResult(this.freezerItemStacks[0].getItem().itemID);
        if (this.freezerItemStacks[2] == null) {
            this.freezerItemStacks[2] = itemstack.copy();
        } else if (this.freezerItemStacks[2].itemID == itemstack.itemID) {
            this.freezerItemStacks[2].stackSize += itemstack.stackSize;
        }
        if (this.freezerItemStacks[0].getItem().hasContainerItem()) {
            this.freezerItemStacks[0] = new ItemStack(this.freezerItemStacks[0].getItem().getContainerItem());
        } else {
            --this.freezerItemStacks[0].stackSize;
        }
        if (this.freezerItemStacks[0].stackSize <= 0) {
            this.freezerItemStacks[0] = null;
        }
    }

    private static int getItemFreezeTime(ItemStack itemstack) {
        if (itemstack == null) {
            return 0;
        }
        int i = itemstack.getItem().itemID;
        if (i == mod_FurnitureMod.itemCoolPack.itemID) {
            return 2500;
        }
        if (i == Block.ice.blockID) {
            return 5000;
        }
        return 0;
    }

    public static boolean isItemFuel(ItemStack itemstack) {
        return TileEntityFreezer.getItemFreezeTime(itemstack) > 0;
    }

    @Override
    public boolean isUseableByPlayer(EntityPlayer entityplayer) {
        return this.worldObj.getBlockTileEntity(this.xCoord, this.yCoord, this.zCoord) != this ? false : entityplayer.getDistanceSq((double)this.xCoord + 0.5, (double)this.yCoord + 0.5, (double)this.zCoord + 0.5) <= 64.0;
    }

    @Override
    public void openChest() {
    }

    @Override
    public void closeChest() {
    }

    @Override
    public boolean isInvNameLocalized() {
        return false;
    }

    @Override
    public boolean isStackValidForSlot(int var1, ItemStack var2) {
        return false;
    }
}
