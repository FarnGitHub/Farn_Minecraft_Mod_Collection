import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MathHelper;
import net.minecraft.src.World;

public class ItemCouchWhite
extends Item {
    protected ItemCouchWhite(int i) {
        super(i);
        this.maxStackSize = 8;
    }

    @Override
    public boolean onItemUse(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, World par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10) {
        int rotate = MathHelper.floor_double((double)(par2EntityPlayer.rotationYaw * 4.0f / 360.0f) + 0.5) & 3;
        if (rotate == 0 && par3World.isAirBlock(par4, par5 + 1, par6)) {
            par3World.setBlock(par4, par5 + 1, par6, mod_FurnitureMod.couchWhite.blockID, 2, 3);
        }
        if (rotate == 1 && par3World.isAirBlock(par4, par5 + 1, par6)) {
            par3World.setBlock(par4, par5 + 1, par6, mod_FurnitureMod.couchWhite.blockID, 1, 3);
        }
        if (rotate == 2 && par3World.isAirBlock(par4, par5 + 1, par6)) {
            par3World.setBlock(par4, par5 + 1, par6, mod_FurnitureMod.couchWhite.blockID, 3, 3);
        }
        if (rotate == 3 && par3World.isAirBlock(par4, par5 + 1, par6)) {
            par3World.setBlock(par4, par5 + 1, par6, mod_FurnitureMod.couchWhite.blockID, 0, 3);
        }
        --par1ItemStack.stackSize;
        return true;
    }
}
