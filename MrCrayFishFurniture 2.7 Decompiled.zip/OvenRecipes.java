import java.util.HashMap;
import java.util.Map;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;

public class OvenRecipes {
    private static final OvenRecipes cookingBase = new OvenRecipes();
    private Map cookingList = new HashMap();

    public static final OvenRecipes cooking() {
        return cookingBase;
    }

    private OvenRecipes() {
        this.addFoodToCookable(Item.porkRaw.itemID, new ItemStack(Item.porkCooked));
        this.addFoodToCookable(Item.beefRaw.itemID, new ItemStack(Item.beefCooked));
        this.addFoodToCookable(Item.chickenRaw.itemID, new ItemStack(Item.chickenCooked));
        this.addFoodToCookable(Item.fishRaw.itemID, new ItemStack(Item.fishCooked));
        this.addFoodToCookable(Item.potato.itemID, new ItemStack(Item.bakedPotato));
        this.addFoodToCookable(mod_FurnitureMod.itemFlesh.itemID, new ItemStack(mod_FurnitureMod.itemCookedFlesh));
    }

    public void addFoodToCookable(int i, ItemStack itemstack) {
        this.cookingList.put(i, itemstack);
    }

    public ItemStack getCookingResult(int i) {
        return (ItemStack)this.cookingList.get(i);
    }

    public Map getCookingList() {
        return this.cookingList;
    }
}
