import java.util.Random;
import net.minecraft.src.Block;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Material;
import net.minecraft.src.World;

public class BlockLampOff
extends Block {
    public BlockLampOff(int i, Material material) {
        super(i, material);
        float f = 0.375f;
        this.setBlockBounds(0.5f - f, 0.0f, 0.5f - f, 0.5f + f, 0.8f, 0.5f + f);
    }

    @Override
    public boolean isOpaqueCube() {
        return false;
    }

    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }

    @Override
    public int getRenderType() {
        return mod_FurnitureMod.renderLamp;
    }

    @Override
    public void onNeighborBlockChange(World par1World, int par2, int par3, int par4, int par5) {
        if (par1World.isBlockIndirectlyGettingPowered(par2, par3, par4)) {
            par1World.setBlock(par2, par3, par4, mod_FurnitureMod.lampOn.blockID, 0, 0);
        }
    }

    @Override
    public boolean onBlockActivated(World par1World, int par2, int par3, int par4, EntityPlayer par5EntityPlayer, int par6, float par7, float par8, float par9) {
        if (par1World.isBlockIndirectlyGettingPowered(par2, par3, par4) | par1World.getBlockId(par2, par3 - 1, par4) == mod_FurnitureMod.bedsideCabinet.blockID) {
            par1World.setBlock(par2, par3, par4, mod_FurnitureMod.lampOn.blockID, 0, 0);
            par1World.notifyBlocksOfNeighborChange(par2, par3 - 1, par4, this.blockID);
            if (par1World.getBlockId(par2, par3, par4) == Block.redstoneWire.blockID) {
                par1World.notifyBlocksOfNeighborChange(par2, par3 - 2, par4, this.blockID);
            }
        } else {
            par5EntityPlayer.addChatMessage("Make sure lamp is powered by redstone or is on bedside cabinet.");
        }
        return true;
    }

    @Override
    public int idDropped(int i, Random random, int j) {
        return mod_FurnitureMod.itemLamp.itemID;
    }

    @Override
    public int idPicked(World par1World, int par2, int par3, int par4) {
        return mod_FurnitureMod.itemLamp.itemID;
    }
}
