import java.util.Random;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.BlockContainer;
import net.minecraft.src.Container;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntityPlayerMP;
import net.minecraft.src.EntityPlayerSP;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.ItemStack;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.TileEntity;
import net.minecraft.src.World;

public class BlockFreezer
extends BlockContainer {
    private Random freezerRand = new Random();
    private final boolean isActive;
    private static boolean keepFreezerInventory = false;

    protected BlockFreezer(int par1, boolean par2) {
        super(par1, Material.rock);
        this.isActive = par2;
    }

    @Override
    public int idDropped(int par1, Random par2Random, int par3) {
        return mod_FurnitureMod.itemFridge.itemID;
    }

    @Override
    public boolean isOpaqueCube() {
        return false;
    }

    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }

    @Override
    public int getRenderType() {
        return mod_FurnitureMod.renderFridge;
    }

    @Override
    public AxisAlignedBB getSelectedBoundingBoxFromPool(World par1World, int par2, int par3, int par4) {
        this.setBlockBounds(0.0625f, 0.0f, 0.0625f, 0.9375f, 1.0f, 0.9375f);
        return super.getCollisionBoundingBoxFromPool(par1World, par2, par3, par4);
    }

    @Override
    public boolean onBlockActivated(World par1World, int par2, int par3, int par4, EntityPlayer par5EntityPlayer, int par6, float par7, float par8, float par9) {
        TileEntityFreezer tileEntityFreezer = (TileEntityFreezer)par1World.getBlockTileEntity(par2, par3, par4);
        if (par5EntityPlayer instanceof EntityPlayerMP) {
            ModLoader.serverOpenWindow((EntityPlayerMP)((EntityPlayerMP)par5EntityPlayer), (Container)new ContainerFreezer(par5EntityPlayer.inventory, tileEntityFreezer), (int)11, (int)par2, (int)par3, (int)par4);
        } else {
            ModLoader.openGUI((EntityPlayer)((EntityPlayerSP)par5EntityPlayer), (GuiScreen)new GuiFreezer(par5EntityPlayer.inventory, (TileEntityFreezer)par1World.getBlockTileEntity(par2, par3, par4)));
        }
        return true;
    }

    public static void updateFreezerBlockState(boolean par0, World par1World, int par2, int par3, int par4) {
        int i = par1World.getBlockMetadata(par2, par3, par4);
        TileEntity tileentity = par1World.getBlockTileEntity(par2, par3, par4);
        keepFreezerInventory = true;
        if (par0) {
            par1World.setBlockMetadataWithNotify(par2, par3, par4, mod_FurnitureMod.fridge.blockID, 0);
        } else {
            par1World.setBlockMetadataWithNotify(par2, par3, par4, mod_FurnitureMod.fridge.blockID, 0);
        }
        keepFreezerInventory = false;
        par1World.setBlockMetadataWithNotify(par2, par3, par4, i, 0);
        if (tileentity != null) {
            tileentity.validate();
            par1World.setBlockTileEntity(par2, par3, par4, tileentity);
        }
    }

    public void onBlockPlacedBy(World par1World, int par2, int par3, int par4, EntityLiving par5EntityLiving) {
        int i = MathHelper.floor_double((double)(par5EntityLiving.rotationYaw * 4.0f / 360.0f) + 0.5) & 3;
        if (i == 0) {
            par1World.setBlockMetadataWithNotify(par2, par3, par4, 0, 10);
        }
        if (i == 1) {
            par1World.setBlockMetadataWithNotify(par2, par3, par4, 3, 10);
        }
        if (i == 2) {
            par1World.setBlockMetadataWithNotify(par2, par3, par4, 1, 10);
        }
        if (i == 3) {
            par1World.setBlockMetadataWithNotify(par2, par3, par4, 2, 10);
        }
    }

    @Override
    public void breakBlock(World par1World, int par2, int par3, int par4, int par5, int par6) {
        TileEntityFreezer var7 = (TileEntityFreezer)par1World.getBlockTileEntity(par2, par3, par4);
        if (var7 != null) {
            for (int var8 = 0; var8 < var7.getSizeInventory(); ++var8) {
                ItemStack var9 = var7.getStackInSlot(var8);
                if (var9 == null) continue;
                float var10 = this.freezerRand.nextFloat() * 0.8f + 0.1f;
                float var11 = this.freezerRand.nextFloat() * 0.8f + 0.1f;
                float var12 = this.freezerRand.nextFloat() * 0.8f + 0.1f;
                while (var9.stackSize > 0) {
                    int var13 = this.freezerRand.nextInt(21) + 10;
                    if (var13 > var9.stackSize) {
                        var13 = var9.stackSize;
                    }
                    var9.stackSize -= var13;
                    EntityItem var14 = new EntityItem(par1World, (float)par2 + var10, (float)par3 + var11, (float)par4 + var12, new ItemStack(var9.itemID, var13, var9.getItemDamage()));
                    if (var9.hasTagCompound()) {
                        var14.getEntityItem().setTagCompound((NBTTagCompound)var9.getTagCompound().copy());
                    }
                    float var15 = 0.05f;
                    var14.motionX = (float)this.freezerRand.nextGaussian() * var15;
                    var14.motionY = (float)this.freezerRand.nextGaussian() * var15 + 0.2f;
                    var14.motionZ = (float)this.freezerRand.nextGaussian() * var15;
                    par1World.spawnEntityInWorld(var14);
                }
            }
        }
        par1World.setBlockToAir(par2, par3 + 1, par4);
        super.breakBlock(par1World, par2, par3, par4, par5, par6);
    }

    @Override
    public TileEntity createNewTileEntity(World var1) {
        return new TileEntityFreezer();
    }

    @Override
    public int idPicked(World par1World, int par2, int par3, int par4) {
        return mod_FurnitureMod.itemFridge.itemID;
    }
}
