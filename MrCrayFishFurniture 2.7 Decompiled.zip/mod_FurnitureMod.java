import net.minecraft.src.Block;
import net.minecraft.src.CreativeTabs;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityClientPlayerMP;
import net.minecraft.src.GuiContainer;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.Item;
import net.minecraft.src.ItemFood;
import net.minecraft.src.ItemStack;
import net.minecraft.src.Material;
import net.minecraft.src.Packet23VehicleSpawn;
import net.minecraft.src.RenderBlocks;
import net.minecraft.src.World;

public class mod_FurnitureMod
extends BaseMod {
    @MLProp
    public static int itemBedsideCabinetID = 1000;
    @MLProp
    public static int itemTableWoodID = 1001;
    @MLProp
    public static int itemChairWoodID = 1002;
    @MLProp
    public static int itemCabinetID = 1003;
    @MLProp
    public static int itemCoffeeTableWoodID = 1004;
    @MLProp
    public static int itemFridgeID = 1005;
    @MLProp
    public static int itemCouchWhiteID = 1006;
    @MLProp
    public static int itemCouchGreenID = 1007;
    @MLProp
    public static int itemCouchBrownID = 1008;
    @MLProp
    public static int itemCouchRedID = 1009;
    @MLProp
    public static int itemCouchBlackID = 1010;
    @MLProp
    public static int itemBlindsID = 1011;
    @MLProp
    public static int itemCurtainsID = 1012;
    @MLProp
    public static int itemCarpetWhiteID = 1013;
    @MLProp
    public static int itemCarpetGreenID = 1014;
    @MLProp
    public static int itemCarpetBrownID = 1015;
    @MLProp
    public static int itemCarpetRedID = 1016;
    @MLProp
    public static int itemCarpetBlackID = 1017;
    @MLProp
    public static int itemLampID = 1018;
    @MLProp
    public static int itemCoolPackID = 1019;
    @MLProp
    public static int itemChairStoneID = 1020;
    @MLProp
    public static int itemTableStoneID = 1021;
    @MLProp
    public static int itemCoffeeTableStoneID = 1022;
    @MLProp
    public static int itemOvenID = 1023;
    @MLProp
    public static int itemOvenOverheadID = 1024;
    @MLProp
    public static int itemFleshID = 1025;
    @MLProp
    public static int itemCookedFleshID = 1026;
    @MLProp
    public static int ovenOverheadID = 223;
    @MLProp
    public static int ovenID = 224;
    @MLProp
    public static int bedsideCabinetID = 225;
    @MLProp
    public static int coffeeTableStoneID = 226;
    @MLProp
    public static int tableStoneID = 227;
    @MLProp
    public static int chairStoneID = 228;
    @MLProp
    public static int lampOnID = 229;
    @MLProp
    public static int lampOffID = 230;
    @MLProp
    public static int coffeeTableWoodID = 231;
    @MLProp
    public static int tableWoodID = 232;
    @MLProp
    public static int chairWoodID = 233;
    @MLProp
    public static int freezerID = 234;
    @MLProp
    public static int fridgeID = 235;
    @MLProp
    public static int cabinetID = 236;
    @MLProp
    public static int couchWhiteID = 237;
    @MLProp
    public static int couchGreenID = 239;
    @MLProp
    public static int couchBrownID = 241;
    @MLProp
    public static int couchRedID = 243;
    @MLProp
    public static int couchBlackID = 245;
    @MLProp
    public static int carpetID = 247;
    @MLProp
    public static int blindsID = 252;
    @MLProp
    public static int blindsClosedID = 253;
    @MLProp
    public static int curtainsID = 254;
    @MLProp
    public static int curtainsClosedID = 255;
    public static int White = 64;
    public static int Green = 145;
    public static int Brown = 161;
    public static int Red = 129;
    public static int Black = 113;
    public static byte guiIDCabinet = (byte)120;
    public static byte guiIDFridge = (byte)121;
    public static byte guiIDFreezer = (byte)122;
    public static byte guiIDBedsideCabinet = (byte)123;
    public static Item itemTableWood;
    public static Item itemTableStone;
    public static Item itemChairWood;
    public static Item itemChairStone;
    public static Item itemCabinet;
    public static Item itemCoffeeTableWood;
    public static Item itemCoffeeTableStone;
    public static Item itemFridge;
    public static Item itemCouchWhite;
    public static Item itemCouchGreen;
    public static Item itemCouchBrown;
    public static Item itemCouchRed;
    public static Item itemCouchBlack;
    public static Item itemBlinds;
    public static Item itemCurtains;
    public static Item itemCarpetWhite;
    public static Item itemCarpetGreen;
    public static Item itemCarpetBrown;
    public static Item itemCarpetRed;
    public static Item itemCarpetBlack;
    public static Item itemLamp;
    public static Item itemBedsideCabinet;
    public static Item itemCoolPack;
    public static Item itemSlidingDoor;
    public static Item itemOven;
    public static Item itemOvenOverhead;
    public static Item itemFlesh;
    public static Item itemCookedFlesh;
    public static Block lampOn;
    public static Block lampOff;
    public static Block coffeeTableWood;
    public static Block coffeeTableStone;
    public static Block tableWood;
    public static Block tableStone;
    public static Block chairWood;
    public static Block chairStone;
    public static Block freezer;
    public static Block fridge;
    public static Block cabinet;
    public static Block couchWhite;
    public static Block couchGreen;
    public static Block couchBrown;
    public static Block couchRed;
    public static Block couchBlack;
    public static Block carpet;
    public static Block blinds;
    public static Block blindsClosed;
    public static Block curtains;
    public static Block curtainsClosed;
    public static Block bedsideCabinet;
    public static Block oven;
    public static Block ovenOverhead;
    public static final int cabinetGuiID = 10;
    public static final int freezerGuiID = 11;
    public static final int fridgeGuiID = 12;
    public static final int bedsideCabinetGuiID = 13;
    public static final int ovenGuiID = 14;
    public static int renderTable;
    public static int renderChair;
    public static int renderCouchLeft;
    public static int renderCouchRight;
    public static int renderWindowDecoration;
    public static int renderCoffeeTable;
    public static int renderCarpet;
    public static int renderFridge;
    public static int renderCabinet;
    public static int renderLamp;
    public static int renderBedsideCabinet;
    public static int renderOven;
    public static int renderOvenOverhead;

    public void load() {
        ModLoader.registerEntityID(EntityMountableBlock.class, (String)"Mountable Block", (int)101);
        ModLoader.addEntityTracker((BaseMod)this, EntityMountableBlock.class, (int)101, (int)10, (int)250, (boolean)false);
        ModLoader.registerTileEntity(TileEntityFridge.class, (String)"Fridge");
        ModLoader.registerTileEntity(TileEntityCabinet.class, (String)"Cabinet");
        ModLoader.registerTileEntity(TileEntityFreezer.class, (String)"Freezer");
        ModLoader.registerTileEntity(TileEntityOven.class, (String)"Oven");
        ModLoader.registerTileEntity(TileEntityBedsideCabinet.class, (String)"Bedside Cabinet");
        ModLoader.registerContainerID((BaseMod)this, (int)10);
        ModLoader.registerContainerID((BaseMod)this, (int)11);
        ModLoader.registerContainerID((BaseMod)this, (int)12);
        ModLoader.registerContainerID((BaseMod)this, (int)13);
        ModLoader.registerContainerID((BaseMod)this, (int)14);
        lampOn = new BlockLampOn(lampOnID, Material.glass).getIndirectPowerOutput("obsidian").setLightValue(1.0f).setHardness(0.75f);
        lampOff = new BlockLampOff(lampOffID, Material.glass).getIndirectPowerOutput("obsidian").setHardness(0.75f);
        coffeeTableWood = new BlockCoffeeTable(coffeeTableWoodID, Material.wood).getIndirectPowerOutput("wood").setHardness(1.0f);
        coffeeTableStone = new BlockCoffeeTable(coffeeTableStoneID, Material.rock).getIndirectPowerOutput("stonebrick").setHardness(1.5f);
        tableWood = new BlockTable(tableWoodID, Material.wood).getIndirectPowerOutput("wood").setHardness(1.0f);
        tableStone = new BlockTable(tableStoneID, Material.rock).getIndirectPowerOutput("stonebrick").setHardness(1.5f);
        chairWood = new BlockChair(chairWoodID, 0, Material.wood).getIndirectPowerOutput("wood").setHardness(1.0f);
        chairStone = new BlockChair(chairStoneID, 0, Material.rock).getIndirectPowerOutput("stonebrick").setHardness(1.5f);
        freezer = new BlockFreezer(freezerID, false).getIndirectPowerOutput("blockIron").setHardness(2.0f);
        fridge = new BlockFridge(fridgeID).getIndirectPowerOutput("blockIron").setHardness(2.0f);
        cabinet = new BlockCabinet(cabinetID, Material.wood).getIndirectPowerOutput("wood").setHardness(1.0f);
        couchWhite = new BlockCouch(couchWhiteID, 0, Material.cloth).getIndirectPowerOutput("cloth_0").setHardness(0.5f);
        couchGreen = new BlockCouch(couchGreenID, 0, Material.cloth).getIndirectPowerOutput("cloth_13").setHardness(0.5f);
        couchBrown = new BlockCouch(couchBrownID, 0, Material.cloth).getIndirectPowerOutput("cloth_12").setHardness(0.5f);
        couchRed = new BlockCouch(couchRedID, 0, Material.cloth).getIndirectPowerOutput("cloth_14").setHardness(0.5f);
        couchBlack = new BlockCouch(couchBlackID, 0, Material.cloth).getIndirectPowerOutput("cloth_15").setHardness(0.5f);
        carpet = new BlockCarpet(carpetID, Material.cloth).getIndirectPowerOutput("cloth").setHardness(0.5f);
        blinds = new BlockWindowDecoration(blindsID, Material.glass).getIndirectPowerOutput("wood").setHardness(0.5f);
        blindsClosed = new BlockWindowDecorationClosed(blindsClosedID, Material.glass).getIndirectPowerOutput("wood").setHardness(0.5f);
        curtains = new BlockWindowDecoration(curtainsID, Material.cloth).getIndirectPowerOutput("cloth_14").setHardness(0.5f);
        curtainsClosed = new BlockWindowDecorationClosed(curtainsClosedID, Material.cloth).getIndirectPowerOutput("cloth_14").setHardness(0.5f);
        bedsideCabinet = new BlockBedsideCabinet(bedsideCabinetID, Material.wood).getIndirectPowerOutput("wood").setHardness(1.0f);
        oven = new BlockOven(ovenID, false).getIndirectPowerOutput("blockIron").setHardness(0.5f);
        ovenOverhead = new BlockOvenOverhead(ovenOverheadID, Material.rock).getIndirectPowerOutput("stoneslab_top").setHardness(0.5f);
        itemTableWood = new ItemBlockCustom(itemTableWoodID, tableWoodID, 1).setUnlocalizedName("itemtablewood").setCreativeTab(CreativeTabs.tabDecorations);
        itemTableStone = new ItemBlockCustom(itemTableStoneID, tableStoneID, 2).setUnlocalizedName("itemtablestone").setCreativeTab(CreativeTabs.tabDecorations);
        itemChairWood = new ItemChair(itemChairWoodID, chairWoodID).setUnlocalizedName("itemchairwood").setCreativeTab(CreativeTabs.tabDecorations);
        itemChairStone = new ItemChair(itemChairStoneID, chairStoneID).setUnlocalizedName("itemchairstone").setCreativeTab(CreativeTabs.tabDecorations);
        itemCabinet = new ItemOven(itemCabinetID, cabinetID).setUnlocalizedName("itemcabinet").setCreativeTab(CreativeTabs.tabDecorations);
        itemCoffeeTableWood = new ItemBlockCustom(itemCoffeeTableWoodID, coffeeTableWoodID, 1).setUnlocalizedName("itemcoffeetablewood").setCreativeTab(CreativeTabs.tabDecorations);
        itemCoffeeTableStone = new ItemBlockCustom(itemCoffeeTableStoneID, coffeeTableStoneID, 2).setUnlocalizedName("itemcoffeetablestone").setCreativeTab(CreativeTabs.tabDecorations);
        itemFridge = new ItemFridge(itemFridgeID).setUnlocalizedName("itemfridge").setCreativeTab(CreativeTabs.tabDecorations);
        itemCouchWhite = new ItemCouchWhite(itemCouchWhiteID).setUnlocalizedName("itemcouchwhite").setCreativeTab(CreativeTabs.tabDecorations);
        itemCouchGreen = new ItemCouchGreen(itemCouchGreenID).setUnlocalizedName("itemcouchgreen").setCreativeTab(CreativeTabs.tabDecorations);
        itemCouchBrown = new ItemCouchBrown(itemCouchBrownID).setUnlocalizedName("itemcouchbrown").setCreativeTab(CreativeTabs.tabDecorations);
        itemCouchRed = new ItemCouchRed(itemCouchRedID).setUnlocalizedName("itemcouchred").setCreativeTab(CreativeTabs.tabDecorations);
        itemCouchBlack = new ItemCouchBlack(itemCouchBlackID).setUnlocalizedName("itemcouchblack").setCreativeTab(CreativeTabs.tabDecorations);
        itemBlinds = new ItemOven(itemBlindsID, blindsID).setUnlocalizedName("itemblinds").setCreativeTab(CreativeTabs.tabDecorations);
        itemCurtains = new ItemOven(itemCurtainsID, curtainsID).setUnlocalizedName("itemcurtains").setCreativeTab(CreativeTabs.tabDecorations);
        itemCarpetWhite = new ItemCarpet(itemCarpetWhiteID, 4).setUnlocalizedName("itemcarpetwhite").setCreativeTab(CreativeTabs.tabDecorations);
        itemCarpetGreen = new ItemCarpet(itemCarpetGreenID, 5).setUnlocalizedName("itemcarpetgreen").setCreativeTab(CreativeTabs.tabDecorations);
        itemCarpetBrown = new ItemCarpet(itemCarpetBrownID, 2).setUnlocalizedName("itemcarpetbrown").setCreativeTab(CreativeTabs.tabDecorations);
        itemCarpetRed = new ItemCarpet(itemCarpetRedID, 3).setUnlocalizedName("itemcarpetred").setCreativeTab(CreativeTabs.tabDecorations);
        itemCarpetBlack = new ItemCarpet(itemCarpetBlackID, 1).setUnlocalizedName("itemcarpetblack").setCreativeTab(CreativeTabs.tabDecorations);
        itemLamp = new ItemBlockCustom(itemLampID, lampOffID, 0).setUnlocalizedName("itemlamp").setCreativeTab(CreativeTabs.tabDecorations);
        itemBedsideCabinet = new ItemBlockCustom(itemBedsideCabinetID, bedsideCabinetID, 0).setUnlocalizedName("itembedsidecabinet").setCreativeTab(CreativeTabs.tabDecorations);
        itemCoolPack = new Item(itemCoolPackID).setUnlocalizedName("itemcoolpack").setCreativeTab(CreativeTabs.tabDecorations);
        itemOven = new ItemOven(itemOvenID, ovenID).setUnlocalizedName("itemoven").setCreativeTab(CreativeTabs.tabDecorations);
        itemOvenOverhead = new ItemOven(itemOvenOverheadID, ovenOverheadID).setUnlocalizedName("itemovenoverhead").setCreativeTab(CreativeTabs.tabDecorations);
        itemFlesh = new ItemFood(itemFleshID, 2, false).setUnlocalizedName("itemflesh").setCreativeTab(CreativeTabs.tabFood);
        itemCookedFlesh = new ItemFood(itemCookedFleshID, 4, false).setUnlocalizedName("itemfleshcooked").setCreativeTab(CreativeTabs.tabFood);
        ModLoader.addName((Object)itemTableWood, (String)"Wooden Table");
        ModLoader.addName((Object)itemTableStone, (String)"Stone Table");
        ModLoader.addName((Object)itemChairWood, (String)"Wooden Chair");
        ModLoader.addName((Object)itemChairStone, (String)"Stone Chair");
        ModLoader.addName((Object)itemFridge, (String)"Fridge");
        ModLoader.addName((Object)itemBlinds, (String)"Blinds");
        ModLoader.addName((Object)itemCurtains, (String)"Curtains");
        ModLoader.addName((Object)itemCouchWhite, (String)"White Couch");
        ModLoader.addName((Object)itemCouchGreen, (String)"Green Couch");
        ModLoader.addName((Object)itemCouchBrown, (String)"Brown Couch");
        ModLoader.addName((Object)itemCouchRed, (String)"Red Couch");
        ModLoader.addName((Object)itemCouchBlack, (String)"Black Couch");
        ModLoader.addName((Object)itemCabinet, (String)"Cabinet");
        ModLoader.addName((Object)itemCoolPack, (String)"Cooling Pack");
        ModLoader.addName((Object)itemCoffeeTableWood, (String)"Wooden Coffee Table");
        ModLoader.addName((Object)itemCoffeeTableStone, (String)"Stone Coffee Table");
        ModLoader.addName((Object)itemCarpetWhite, (String)"White Carpet");
        ModLoader.addName((Object)itemCarpetGreen, (String)"Green Carpet");
        ModLoader.addName((Object)itemCarpetBrown, (String)"Brown Carpet");
        ModLoader.addName((Object)itemCarpetRed, (String)"Red Carpet");
        ModLoader.addName((Object)itemCarpetBlack, (String)"Black Carpet");
        ModLoader.addName((Object)itemLamp, (String)"Lamp");
        ModLoader.addName((Object)itemBedsideCabinet, (String)"Bedside Cabinet");
        ModLoader.addName((Object)itemOven, (String)"Oven");
        ModLoader.addName((Object)itemOvenOverhead, (String)"Oven Overhead");
        ModLoader.addName((Object)itemFlesh, (String)"Flesh");
        ModLoader.addName((Object)itemCookedFlesh, (String)"Cooked Flesh");
        ModLoader.addRecipe((ItemStack)new ItemStack(itemTableWood, 1), (Object[])new Object[]{"***", " * ", " * ", Character.valueOf('*'), Block.planks});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemTableStone, 1), (Object[])new Object[]{"***", " * ", " * ", Character.valueOf('*'), Block.cobblestone});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemChairWood, 1), (Object[])new Object[]{"*  ", "***", "* *", Character.valueOf('*'), Block.planks});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemChairStone, 1), (Object[])new Object[]{"*  ", "***", "* *", Character.valueOf('*'), Block.cobblestone});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCouchWhite, 1), (Object[])new Object[]{"***", "***", Character.valueOf('*'), new ItemStack(Block.cloth, 1, 0)});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCouchGreen, 1), (Object[])new Object[]{"***", "***", Character.valueOf('*'), new ItemStack(Block.cloth, 1, 13)});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCouchBrown, 1), (Object[])new Object[]{"***", "***", Character.valueOf('*'), new ItemStack(Block.cloth, 1, 12)});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCouchRed, 1), (Object[])new Object[]{"***", "***", Character.valueOf('*'), new ItemStack(Block.cloth, 1, 14)});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCouchBlack, 1), (Object[])new Object[]{"***", "***", Character.valueOf('*'), new ItemStack(Block.cloth, 1, 15)});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemFridge, 1), (Object[])new Object[]{"***", "*@*", "*@*", Character.valueOf('*'), Item.ingotIron, Character.valueOf('@'), Block.chest});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCabinet, 1), (Object[])new Object[]{"***", "*@*", "***", Character.valueOf('*'), Block.planks, Character.valueOf('@'), Block.trapdoor});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCurtains, 2), (Object[])new Object[]{"@@@", "* *", "@ @", Character.valueOf('*'), Item.ingotGold, Character.valueOf('@'), new ItemStack(Block.cloth, 1, 14)});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemBlinds, 2), (Object[])new Object[]{"***", "***", "***", Character.valueOf('*'), Item.stick});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCoolPack, 2), (Object[])new Object[]{"***", "*@*", "***", Character.valueOf('*'), Block.glass, Character.valueOf('@'), Item.bucketWater});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCoffeeTableWood, 1), (Object[])new Object[]{"***", "* *", Character.valueOf('*'), Block.planks});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCoffeeTableStone, 1), (Object[])new Object[]{"***", "* *", Character.valueOf('*'), Block.cobblestone});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCarpetRed, 4), (Object[])new Object[]{"**", Character.valueOf('*'), new ItemStack(Block.cloth, 1, 14)});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCarpetBrown, 4), (Object[])new Object[]{"**", Character.valueOf('*'), new ItemStack(Block.cloth, 1, 12)});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCarpetGreen, 4), (Object[])new Object[]{"**", Character.valueOf('*'), new ItemStack(Block.cloth, 1, 13)});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCarpetWhite, 4), (Object[])new Object[]{"**", Character.valueOf('*'), new ItemStack(Block.cloth, 1, 0)});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemCarpetBlack, 4), (Object[])new Object[]{"**", Character.valueOf('*'), new ItemStack(Block.cloth, 1, 15)});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemLamp, 2), (Object[])new Object[]{"***", "*@*", " & ", Character.valueOf('*'), Block.cloth, Character.valueOf('@'), Block.glowStone, Character.valueOf('&'), Block.obsidian});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemBedsideCabinet, 1), (Object[])new Object[]{"***", "*@*", "*@*", Character.valueOf('*'), Block.planks, Character.valueOf('@'), Block.trapdoor});
        ModLoader.addRecipe((ItemStack)new ItemStack(itemOven, 1), (Object[])new Object[]{"***", "*@*", "***", Character.valueOf('*'), Block.blockSteel, Character.valueOf('@'), Block.furnaceIdle});
        Object[] objectArray = new Object[7];
        objectArray[0] = " * ";
        objectArray[1] = " * ";
        objectArray[2] = "*@*";
        objectArray[3] = Character.valueOf('*');
        objectArray[4] = Item.ingotIron;
        objectArray[5] = Character.valueOf('@');
        objectArray[6] = Block.glowStone;
        ModLoader.addRecipe((ItemStack)new ItemStack(itemOvenOverhead, 1), (Object[])objectArray);
        ModLoader.addSmelting((int)mod_FurnitureMod.itemFlesh.itemID, (ItemStack)new ItemStack(itemCookedFlesh), (float)0.05f);
        renderTable = ModLoader.getUniqueBlockModelID((BaseMod)this, (boolean)false);
        renderChair = ModLoader.getUniqueBlockModelID((BaseMod)this, (boolean)false);
        renderCouchLeft = ModLoader.getUniqueBlockModelID((BaseMod)this, (boolean)false);
        renderCouchRight = ModLoader.getUniqueBlockModelID((BaseMod)this, (boolean)false);
        renderWindowDecoration = ModLoader.getUniqueBlockModelID((BaseMod)this, (boolean)false);
        renderCoffeeTable = ModLoader.getUniqueBlockModelID((BaseMod)this, (boolean)false);
        renderCarpet = ModLoader.getUniqueBlockModelID((BaseMod)this, (boolean)false);
        renderFridge = ModLoader.getUniqueBlockModelID((BaseMod)this, (boolean)false);
        renderCabinet = ModLoader.getUniqueBlockModelID((BaseMod)this, (boolean)false);
        renderLamp = ModLoader.getUniqueBlockModelID((BaseMod)this, (boolean)false);
        renderBedsideCabinet = ModLoader.getUniqueBlockModelID((BaseMod)this, (boolean)false);
        renderOven = ModLoader.getUniqueBlockModelID((BaseMod)this, (boolean)false);
        renderOvenOverhead = ModLoader.getUniqueBlockModelID((BaseMod)this, (boolean)false);
        ModLoader.setInGameHook((BaseMod)this, (boolean)true, (boolean)true);
        ModLoader.setInGUIHook((BaseMod)this, (boolean)true, (boolean)true);
    }

    public GuiContainer getContainerGUI(EntityClientPlayerMP player, int id, int x, int y, int z) {
        switch (id) {
            case 10: {
                return new GuiCabinet(player.inventory, (TileEntityCabinet)player.worldObj.getBlockTileEntity(x, y, z));
            }
            case 11: {
                return new GuiFreezer(player.inventory, (TileEntityFreezer)player.worldObj.getBlockTileEntity(x, y, z));
            }
            case 12: {
                return new GuiFridge(player.inventory, (TileEntityFridge)player.worldObj.getBlockTileEntity(x, y, z));
            }
            case 13: {
                return new GuiBedsideCabinet(player.inventory, (TileEntityBedsideCabinet)player.worldObj.getBlockTileEntity(x, y, z));
            }
            case 14: {
                return new GuiOven(player.inventory, (TileEntityOven)player.worldObj.getBlockTileEntity(x, y, z));
            }
        }
        return null;
    }

    public Entity spawnEntity(int entityId, World worldClient, double x, double y, double z) {
        switch (entityId) {
            case 101: {
                return new EntityMountableBlock(worldClient, x, y, z);
            }
        }
        return null;
    }

    public Packet23VehicleSpawn getSpawnPacket(Entity entity, int type) {
        if (entity instanceof EntityMountableBlock) {
            return new Packet23VehicleSpawn(entity, type);
        }
        return null;
    }

    public boolean renderWorldBlock(RenderBlocks renderblocks, IBlockAccess iblockaccess, int i, int j, int k, Block block, int l) {
        if (l == renderTable) {
            return this.renderTable(block, i, j, k, renderblocks, iblockaccess);
        }
        if (l == renderChair) {
            return this.renderChair(block, i, j, k, renderblocks, iblockaccess);
        }
        if (l == renderCouchLeft) {
            return this.renderCouchLeft(block, i, j, k, renderblocks, iblockaccess);
        }
        if (l == renderWindowDecoration) {
            return this.renderWindowDecoration(block, i, j, k, renderblocks, iblockaccess);
        }
        if (l == renderCoffeeTable) {
            return this.renderCoffeeTable(block, i, j, k, renderblocks, iblockaccess);
        }
        if (l == renderCarpet) {
            return this.renderCarpet(block, i, j, k, renderblocks, iblockaccess);
        }
        if (l == renderFridge) {
            return this.renderFridge(block, i, j, k, renderblocks, iblockaccess);
        }
        if (l == renderCabinet) {
            return this.renderCabinet(block, i, j, k, renderblocks, iblockaccess);
        }
        if (l == renderLamp) {
            return this.renderLamp(block, i, j, k, renderblocks, iblockaccess);
        }
        if (l == renderBedsideCabinet) {
            return this.renderBedsideCabinet(block, i, j, k, renderblocks, iblockaccess);
        }
        if (l == renderOven) {
            return this.renderOven(block, i, j, k, renderblocks, iblockaccess);
        }
        if (l == renderOvenOverhead) {
            return this.renderOvenOverhead(block, i, j, k, renderblocks, iblockaccess);
        }
        return false;
    }

    public boolean renderTable(Block block, int i, int j, int k, RenderBlocks renderblocks, IBlockAccess world) {
        renderblocks.renderAllFaces = true;
        if (world.getBlockId(i, j, k) == tableWoodID) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
            if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.175f, 0.0, 0.375, 0.425f, 0.9f, 0.625);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.575f, 0.0, 0.375, 0.825f, 0.9f, 0.625);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.375, 0.0, 0.175f, 0.625, 0.9f, 0.425f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.375, 0.0, 0.575f, 0.625, 0.9f, 0.825f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.175f, 0.0, 0.175f, 0.425f, 0.9f, 0.425f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.175f, 0.0, 0.575f, 0.425f, 0.9f, 0.825f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.575f, 0.0, 0.575f, 0.825f, 0.9f, 0.825f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.575f, 0.0, 0.175f, 0.825f, 0.9f, 0.425f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (!(world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID || world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID || world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID || world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID)) {
                renderblocks.setRenderBounds(0.575f, 0.0, 0.375, 0.825f, 0.9f, 0.625);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
            if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.175f, 0.0, 0.375, 0.425f, 0.9f, 0.625);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.575f, 0.0, 0.375, 0.825f, 0.9f, 0.625);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.375, 0.0, 0.175f, 0.625, 0.9f, 0.425f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.375, 0.0, 0.575f, 0.625, 0.9f, 0.825f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.175f, 0.0, 0.175f, 0.425f, 0.9f, 0.425f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.175f, 0.0, 0.575f, 0.425f, 0.9f, 0.825f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.575f, 0.0, 0.575f, 0.825f, 0.9f, 0.825f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID) {
                renderblocks.setRenderBounds(0.575f, 0.0, 0.175f, 0.825f, 0.9f, 0.425f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (!(world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID || world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID || world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableWood.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableWood.blockID)) {
                renderblocks.setRenderBounds(0.375, 0.0, 0.375, 0.625, 0.9f, 0.625);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
        }
        if (world.getBlockId(i, j, k) == tableStoneID) {
            renderblocks.overrideBlockTexture = Block.cobblestone.getBlockTextureFromSide(1);
            if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableStone.blockID) {
                renderblocks.setRenderBounds(0.175f, 0.0, 0.375, 0.425f, 0.9f, 0.625);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableStone.blockID) {
                renderblocks.setRenderBounds(0.575f, 0.0, 0.375, 0.825f, 0.9f, 0.625);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableStone.blockID) {
                renderblocks.setRenderBounds(0.375, 0.0, 0.175f, 0.625, 0.9f, 0.425f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableStone.blockID) {
                renderblocks.setRenderBounds(0.375, 0.0, 0.575f, 0.625, 0.9f, 0.825f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableStone.blockID) {
                renderblocks.setRenderBounds(0.175f, 0.0, 0.175f, 0.425f, 0.9f, 0.425f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableStone.blockID) {
                renderblocks.setRenderBounds(0.175f, 0.0, 0.575f, 0.425f, 0.9f, 0.825f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableStone.blockID) {
                renderblocks.setRenderBounds(0.575f, 0.0, 0.575f, 0.825f, 0.9f, 0.825f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableStone.blockID) {
                renderblocks.setRenderBounds(0.575f, 0.0, 0.175f, 0.825f, 0.9f, 0.425f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (!(world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableStone.blockID || world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableStone.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableStone.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableStone.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableStone.blockID || world.getBlockId(i + 1, j, k) != mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.tableStone.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.tableStone.blockID)) {
                if (world.getBlockId(i - 1, j, k) == mod_FurnitureMod.tableStone.blockID) {
                    renderblocks.setRenderBounds(0.575f, 0.0, 0.375, 0.825f, 0.9f, 0.625);
                    renderblocks.renderStandardBlock(block, i, j, k);
                } else {
                    renderblocks.setRenderBounds(0.375, 0.0, 0.375, 0.625, 0.9f, 0.625);
                    renderblocks.renderStandardBlock(block, i, j, k);
                }
            }
        }
        renderblocks.setRenderBounds(0.0, 0.9f, 0.0, 1.0, 1.0, 1.0);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.overrideBlockTexture = null;
        return true;
    }

    public boolean renderChair(Block block, int i, int j, int k, RenderBlocks renderblocks, IBlockAccess blockAccess) {
        int l = blockAccess.getBlockMetadata(i, j, k);
        if (blockAccess.getBlockId(i, j, k) == chairWoodID) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
        } else if (blockAccess.getBlockId(i, j, k) == chairStoneID) {
            renderblocks.overrideBlockTexture = Block.cobblestone.getBlockTextureFromSide(1);
        }
        renderblocks.renderAllFaces = true;
        if (l == 0) {
            renderblocks.setRenderBounds(0.1f, 0.0, 0.1f, 0.2f, 0.5, 0.2f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.8f, 0.0, 0.8f, 0.9f, 0.5, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.8f, 0.0, 0.1f, 0.9f, 0.5, 0.2f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1f, 0.0, 0.8f, 0.2f, 0.5, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.8f, 0.6f, 0.1f, 0.9f, 1.2f, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1f, 0.5, 0.1f, 0.9f, 0.6f, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (l == 1) {
            renderblocks.setRenderBounds(0.1f, 0.0, 0.1f, 0.2f, 0.5, 0.2f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.8f, 0.0, 0.8f, 0.9f, 0.5, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.8f, 0.0, 0.1f, 0.9f, 0.5, 0.2f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1f, 0.0, 0.8f, 0.2f, 0.5, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1f, 0.6f, 0.1f, 0.2f, 1.2f, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1f, 0.5, 0.1f, 0.9f, 0.6f, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (l == 2) {
            renderblocks.setRenderBounds(0.1f, 0.0, 0.1f, 0.2f, 0.5, 0.2f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.8f, 0.0, 0.8f, 0.9f, 0.5, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.8f, 0.0, 0.1f, 0.9f, 0.5, 0.2f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1f, 0.0, 0.8f, 0.2f, 0.5, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1f, 0.6f, 0.8f, 0.9f, 1.2f, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1f, 0.5, 0.1f, 0.9f, 0.6f, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (l == 3) {
            renderblocks.setRenderBounds(0.1f, 0.0, 0.1f, 0.2f, 0.5, 0.2f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.8f, 0.0, 0.8f, 0.9f, 0.5, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.8f, 0.0, 0.1f, 0.9f, 0.5, 0.2f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1f, 0.0, 0.8f, 0.2f, 0.5, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1f, 0.6f, 0.1f, 0.9f, 1.2f, 0.2f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1f, 0.5, 0.1f, 0.9f, 0.6f, 0.9f);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        renderblocks.setRenderBounds(0.1f, 0.0, 0.1f, 0.9f, 1.2f, 0.9f);
        renderblocks.overrideBlockTexture = null;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean renderCouchLeft(Block block, int i, int j, int k, RenderBlocks renderblocks, IBlockAccess blockAccess) {
        block64: {
            block44: {
                block68: {
                    block67: {
                        block66: {
                            block65: {
                                int l;
                                block57: {
                                    block43: {
                                        block63: {
                                            block60: {
                                                block62: {
                                                    block61: {
                                                        block59: {
                                                            block58: {
                                                                block50: {
                                                                    block42: {
                                                                        block56: {
                                                                            block53: {
                                                                                block55: {
                                                                                    block54: {
                                                                                        block52: {
                                                                                            block51: {
                                                                                                block45: {
                                                                                                    block41: {
                                                                                                        block49: {
                                                                                                            block48: {
                                                                                                                block47: {
                                                                                                                    block46: {
                                                                                                                        l = blockAccess.getBlockMetadata(i, j, k);
                                                                                                                        renderblocks.renderAllFaces = true;
                                                                                                                        if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.couchWhite.blockID) {
                                                                                                                            renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 0);
                                                                                                                        } else if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.couchGreen.blockID) {
                                                                                                                            renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 13);
                                                                                                                        } else if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.couchBrown.blockID) {
                                                                                                                            renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 12);
                                                                                                                        } else if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.couchRed.blockID) {
                                                                                                                            renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 14);
                                                                                                                        } else if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.couchBlack.blockID) {
                                                                                                                            renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 15);
                                                                                                                        }
                                                                                                                        if (l != 0) break block45;
                                                                                                                        if (!blockAccess.isAirBlock(i, j, k - 1) || blockAccess.isAirBlock(i, j, k + 1)) break block46;
                                                                                                                        if (blockAccess.getBlockId(i - 1, j, k) == couchBlackID) break block46;
                                                                                                                        if (blockAccess.getBlockId(i - 1, j, k) == couchBrownID) break block46;
                                                                                                                        if (blockAccess.getBlockId(i - 1, j, k) == couchGreenID) break block46;
                                                                                                                        if (blockAccess.getBlockId(i - 1, j, k) == couchRedID) break block46;
                                                                                                                        if (blockAccess.getBlockId(i - 1, j, k) == couchWhiteID) break block46;
                                                                                                                        renderblocks.setRenderBounds(-0.001f, 0.5, -0.2f, 1.001f, 0.9f, 0.05f);
                                                                                                                        renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                                        break block41;
                                                                                                                    }
                                                                                                                    if (blockAccess.isAirBlock(i, j, k - 1) || !blockAccess.isAirBlock(i, j, k + 1)) break block47;
                                                                                                                    if (blockAccess.getBlockId(i - 1, j, k) == couchBlackID) break block47;
                                                                                                                    if (blockAccess.getBlockId(i - 1, j, k) == couchBrownID) break block47;
                                                                                                                    if (blockAccess.getBlockId(i - 1, j, k) == couchGreenID) break block47;
                                                                                                                    if (blockAccess.getBlockId(i - 1, j, k) == couchRedID) break block47;
                                                                                                                    if (blockAccess.getBlockId(i - 1, j, k) == couchWhiteID) break block47;
                                                                                                                    renderblocks.setRenderBounds(-0.001f, 0.5, 0.95f, 1.001f, 0.9f, 1.2f);
                                                                                                                    renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                                    break block41;
                                                                                                                }
                                                                                                                if (!(!blockAccess.isAirBlock(i, j, k - 1) | !blockAccess.isAirBlock(i, j, k + 1))) break block48;
                                                                                                                boolean bl = blockAccess.getBlockId(i - 1, j, k) == couchBlackID;
                                                                                                                if (bl | blockAccess.getBlockId(i - 1, j, k) == couchBrownID | blockAccess.getBlockId(i - 1, j, k) == couchGreenID | blockAccess.getBlockId(i - 1, j, k) == couchRedID | blockAccess.getBlockId(i - 1, j, k) == couchWhiteID) {
                                                                                                                    if (blockAccess.getBlockMetadata(i - 1, j, k) == 2) {
                                                                                                                        renderblocks.setRenderBounds(0.0, 0.6f, 0.75, 0.75, 1.2f, 1.0);
                                                                                                                        renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                                    }
                                                                                                                    if (blockAccess.getBlockMetadata(i - 1, j, k) == 3) {
                                                                                                                        renderblocks.setRenderBounds(0.0, 0.6f, 0.0, 0.75, 1.2f, 0.25);
                                                                                                                        renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                                    }
                                                                                                                    if (blockAccess.getBlockMetadata(i - 1, j, k) == 0 | blockAccess.getBlockMetadata(i - 1, j, k) == 1 && !blockAccess.isAirBlock(i, j, k + 1) && blockAccess.isAirBlock(i, j, k - 1)) {
                                                                                                                        renderblocks.setRenderBounds(-0.001f, 0.5, -0.2f, 1.001f, 0.9f, 0.05f);
                                                                                                                        renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                                    }
                                                                                                                    if (blockAccess.getBlockMetadata(i - 1, j, k) == 0 | blockAccess.getBlockMetadata(i - 1, j, k) == 1 && !blockAccess.isAirBlock(i, j, k - 1) && blockAccess.isAirBlock(i, j, k + 1)) {
                                                                                                                        renderblocks.setRenderBounds(-0.001f, 0.5, 0.95f, 1.001f, 0.9f, 1.2f);
                                                                                                                        renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                                    }
                                                                                                                }
                                                                                                                break block41;
                                                                                                            }
                                                                                                            if (!blockAccess.isAirBlock(i, j, k - 1) || !blockAccess.isAirBlock(i, j, k + 1)) break block41;
                                                                                                            boolean bl = blockAccess.getBlockId(i - 1, j, k) == couchBlackID;
                                                                                                            if (!(bl | blockAccess.getBlockId(i - 1, j, k) == couchBrownID | blockAccess.getBlockId(i - 1, j, k) == couchGreenID | blockAccess.getBlockId(i - 1, j, k) == couchRedID | blockAccess.getBlockId(i - 1, j, k) == couchWhiteID)) break block49;
                                                                                                            if (blockAccess.getBlockMetadata(i - 1, j, k) == 2) {
                                                                                                                renderblocks.setRenderBounds(0.0, 0.6f, 0.75, 0.75, 1.2f, 1.0);
                                                                                                                renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                                break block41;
                                                                                                            } else if (blockAccess.getBlockMetadata(i - 1, j, k) == 3) {
                                                                                                                renderblocks.setRenderBounds(0.0, 0.6f, 0.0, 0.75, 1.2f, 0.25);
                                                                                                                renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                                break block41;
                                                                                                            } else {
                                                                                                                renderblocks.setRenderBounds(-0.001f, 0.5, -0.2f, 1.001f, 0.9f, 0.05f);
                                                                                                                renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                                renderblocks.setRenderBounds(-0.001f, 0.5, 0.95f, 1.001f, 0.9f, 1.2f);
                                                                                                                renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                            }
                                                                                                            break block41;
                                                                                                        }
                                                                                                        renderblocks.setRenderBounds(-0.001f, 0.5, -0.2f, 1.001f, 0.9f, 0.05f);
                                                                                                        renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                        renderblocks.setRenderBounds(-0.001f, 0.5, 0.95f, 1.001f, 0.9f, 1.2f);
                                                                                                        renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                    }
                                                                                                    renderblocks.setRenderBounds(0.0, 0.0, 0.0, 1.0, 0.6f, 1.0);
                                                                                                    renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                    renderblocks.setRenderBounds(0.75, 0.6f, 0.0, 1.0, 1.2f, 1.0);
                                                                                                    renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                }
                                                                                                if (l != 2) break block50;
                                                                                                if (!blockAccess.isAirBlock(i + 1, j, k) || blockAccess.isAirBlock(i - 1, j, k)) break block51;
                                                                                                if (blockAccess.getBlockId(i, j, k - 1) == couchBlackID) break block51;
                                                                                                if (blockAccess.getBlockId(i, j, k - 1) == couchBrownID) break block51;
                                                                                                if (blockAccess.getBlockId(i, j, k - 1) == couchGreenID) break block51;
                                                                                                if (blockAccess.getBlockId(i, j, k - 1) == couchRedID) break block51;
                                                                                                if (blockAccess.getBlockId(i, j, k - 1) == couchWhiteID) break block51;
                                                                                                renderblocks.setRenderBounds(0.95f, 0.5, -0.001f, 1.2f, 0.9f, 1.001f);
                                                                                                renderblocks.renderStandardBlock(block, i, j, k);
                                                                                                break block42;
                                                                                            }
                                                                                            if (!blockAccess.isAirBlock(i - 1, j, k) || blockAccess.isAirBlock(i + 1, j, k)) break block52;
                                                                                            if (blockAccess.getBlockId(i, j, k - 1) == couchBlackID) break block52;
                                                                                            if (blockAccess.getBlockId(i, j, k - 1) == couchBrownID) break block52;
                                                                                            if (blockAccess.getBlockId(i, j, k - 1) == couchGreenID) break block52;
                                                                                            if (blockAccess.getBlockId(i, j, k - 1) == couchRedID) break block52;
                                                                                            if (blockAccess.getBlockId(i, j, k - 1) == couchWhiteID) break block52;
                                                                                            renderblocks.setRenderBounds(-0.2f, 0.5, -0.001f, 0.05f, 0.9f, 1.001f);
                                                                                            renderblocks.renderStandardBlock(block, i, j, k);
                                                                                            break block42;
                                                                                        }
                                                                                        if (!(!blockAccess.isAirBlock(i + 1, j, k) | !blockAccess.isAirBlock(i - 1, j, k))) break block53;
                                                                                        boolean bl = blockAccess.getBlockId(i, j, k - 1) == couchBlackID;
                                                                                        if (!(bl | blockAccess.getBlockId(i, j, k - 1) == couchBrownID | blockAccess.getBlockId(i, j, k - 1) == couchGreenID | blockAccess.getBlockId(i, j, k - 1) == couchRedID | blockAccess.getBlockId(i, j, k - 1) == couchWhiteID)) break block42;
                                                                                        if (blockAccess.getBlockMetadata(i, j, k - 1) != 1) break block54;
                                                                                        renderblocks.setRenderBounds(0.0, 0.6f, 0.0, 0.25, 1.2f, 0.75);
                                                                                        renderblocks.renderStandardBlock(block, i, j, k);
                                                                                        break block42;
                                                                                    }
                                                                                    if (blockAccess.getBlockMetadata(i, j, k - 1) != 0) break block55;
                                                                                    renderblocks.setRenderBounds(0.75, 0.6f, 0.0, 1.0, 1.2f, 0.75);
                                                                                    renderblocks.renderStandardBlock(block, i, j, k);
                                                                                    break block42;
                                                                                }
                                                                                if (blockAccess.getBlockMetadata(i, j, k - 1) == 2 | blockAccess.getBlockMetadata(i, j, k - 1) == 3 && !blockAccess.isAirBlock(i - 1, j, k) && blockAccess.isAirBlock(i + 1, j, k)) {
                                                                                    renderblocks.setRenderBounds(0.95f, 0.5, -0.001f, 1.2f, 0.9f, 1.001f);
                                                                                    renderblocks.renderStandardBlock(block, i, j, k);
                                                                                    break block42;
                                                                                } else if (blockAccess.getBlockMetadata(i, j, k - 1) == 2 | blockAccess.getBlockMetadata(i, j, k - 1) == 3 && !blockAccess.isAirBlock(i + 1, j, k) && blockAccess.isAirBlock(i - 1, j, k)) {
                                                                                    renderblocks.setRenderBounds(-0.2f, 0.5, -0.001f, 0.05f, 0.9f, 1.001f);
                                                                                    renderblocks.renderStandardBlock(block, i, j, k);
                                                                                }
                                                                                break block42;
                                                                            }
                                                                            if (!blockAccess.isAirBlock(i + 1, j, k) || !blockAccess.isAirBlock(i - 1, j, k)) break block42;
                                                                            boolean bl = blockAccess.getBlockId(i, j, k - 1) == couchBlackID;
                                                                            if (!(bl | blockAccess.getBlockId(i, j, k - 1) == couchBrownID | blockAccess.getBlockId(i, j, k - 1) == couchGreenID | blockAccess.getBlockId(i, j, k - 1) == couchRedID | blockAccess.getBlockId(i, j, k - 1) == couchWhiteID)) break block56;
                                                                            if (blockAccess.getBlockMetadata(i, j, k - 1) == 1) {
                                                                                renderblocks.setRenderBounds(0.0, 0.6f, 0.0, 0.25, 1.2f, 0.75);
                                                                                renderblocks.renderStandardBlock(block, i, j, k);
                                                                                break block42;
                                                                            } else if (blockAccess.getBlockMetadata(i, j, k - 1) == 0) {
                                                                                renderblocks.setRenderBounds(0.75, 0.6f, 0.0, 1.0, 1.2f, 0.75);
                                                                                renderblocks.renderStandardBlock(block, i, j, k);
                                                                                break block42;
                                                                            } else {
                                                                                renderblocks.setRenderBounds(0.95f, 0.5, -0.001f, 1.2f, 0.9f, 1.001f);
                                                                                renderblocks.renderStandardBlock(block, i, j, k);
                                                                                renderblocks.setRenderBounds(-0.2f, 0.5, -0.001f, 0.05f, 0.9f, 1.001f);
                                                                                renderblocks.renderStandardBlock(block, i, j, k);
                                                                            }
                                                                            break block42;
                                                                        }
                                                                        renderblocks.setRenderBounds(0.95f, 0.5, -0.001f, 1.2f, 0.9f, 1.001f);
                                                                        renderblocks.renderStandardBlock(block, i, j, k);
                                                                        renderblocks.setRenderBounds(-0.2f, 0.5, -0.001f, 0.05f, 0.9f, 1.001f);
                                                                        renderblocks.renderStandardBlock(block, i, j, k);
                                                                    }
                                                                    renderblocks.setRenderBounds(0.0, 0.0, 0.0, 1.0, 0.6f, 1.0);
                                                                    renderblocks.renderStandardBlock(block, i, j, k);
                                                                    renderblocks.setRenderBounds(0.0, 0.6f, 0.75, 1.0, 1.2f, 1.0);
                                                                    renderblocks.renderStandardBlock(block, i, j, k);
                                                                }
                                                                if (l != 1) break block57;
                                                                if (!blockAccess.isAirBlock(i, j, k - 1) || blockAccess.isAirBlock(i, j, k + 1)) break block58;
                                                                if (blockAccess.getBlockId(i + 1, j, k) == couchBlackID) break block58;
                                                                if (blockAccess.getBlockId(i + 1, j, k) == couchBrownID) break block58;
                                                                if (blockAccess.getBlockId(i + 1, j, k) == couchGreenID) break block58;
                                                                if (blockAccess.getBlockId(i + 1, j, k) == couchRedID) break block58;
                                                                if (blockAccess.getBlockId(i + 1, j, k) == couchWhiteID) break block58;
                                                                renderblocks.setRenderBounds(-0.001f, 0.5, -0.2f, 1.001f, 0.9f, 0.05f);
                                                                renderblocks.renderStandardBlock(block, i, j, k);
                                                                break block43;
                                                            }
                                                            if (blockAccess.isAirBlock(i, j, k - 1) || !blockAccess.isAirBlock(i, j, k + 1)) break block59;
                                                            if (blockAccess.getBlockId(i + 1, j, k) == couchBlackID) break block59;
                                                            if (blockAccess.getBlockId(i + 1, j, k) == couchBrownID) break block59;
                                                            if (blockAccess.getBlockId(i + 1, j, k) == couchGreenID) break block59;
                                                            if (blockAccess.getBlockId(i + 1, j, k) == couchRedID) break block59;
                                                            if (blockAccess.getBlockId(i + 1, j, k) == couchWhiteID) break block59;
                                                            renderblocks.setRenderBounds(-0.001f, 0.5, 0.95f, 1.001f, 0.9f, 1.2f);
                                                            renderblocks.renderStandardBlock(block, i, j, k);
                                                            break block43;
                                                        }
                                                        if (!(!blockAccess.isAirBlock(i, j, k + 1) | !blockAccess.isAirBlock(i, j, k - 1))) break block60;
                                                        boolean bl = blockAccess.getBlockId(i + 1, j, k) == couchBlackID;
                                                        if (!(bl | blockAccess.getBlockId(i + 1, j, k) == couchBrownID | blockAccess.getBlockId(i + 1, j, k) == couchGreenID | blockAccess.getBlockId(i + 1, j, k) == couchRedID | blockAccess.getBlockId(i + 1, j, k) == couchWhiteID)) break block43;
                                                        if (blockAccess.getBlockMetadata(i + 1, j, k) != 2) break block61;
                                                        renderblocks.setRenderBounds(0.0, 0.6f, 0.75, 1.0, 1.2f, 1.0);
                                                        renderblocks.renderStandardBlock(block, i, j, k);
                                                        break block43;
                                                    }
                                                    if (blockAccess.getBlockMetadata(i + 1, j, k) != 3) break block62;
                                                    renderblocks.setRenderBounds(0.0, 0.6f, 0.0, 1.0, 1.2f, 0.25);
                                                    renderblocks.renderStandardBlock(block, i, j, k);
                                                    break block43;
                                                }
                                                if (blockAccess.getBlockMetadata(i + 1, j, k) == 1 | blockAccess.getBlockMetadata(i + 1, j, k) == 0 && !blockAccess.isAirBlock(i, j, k + 1) && blockAccess.isAirBlock(i, j, k - 1)) {
                                                    renderblocks.setRenderBounds(-0.001f, 0.5, -0.2f, 1.001f, 0.9f, 0.05f);
                                                    renderblocks.renderStandardBlock(block, i, j, k);
                                                    break block43;
                                                } else if (blockAccess.getBlockMetadata(i + 1, j, k) == 1 | blockAccess.getBlockMetadata(i + 1, j, k) == 0 && !blockAccess.isAirBlock(i, j, k - 1) && blockAccess.isAirBlock(i, j, k + 1)) {
                                                    renderblocks.setRenderBounds(-0.001f, 0.5, 0.95f, 1.001f, 0.9f, 1.2f);
                                                    renderblocks.renderStandardBlock(block, i, j, k);
                                                }
                                                break block43;
                                            }
                                            if (!blockAccess.isAirBlock(i, j, k - 1) || !blockAccess.isAirBlock(i, j, k + 1)) break block43;
                                            boolean bl = blockAccess.getBlockId(i + 1, j, k) == couchBlackID;
                                            if (!(bl | blockAccess.getBlockId(i + 1, j, k) == couchBrownID | blockAccess.getBlockId(i + 1, j, k) == couchGreenID | blockAccess.getBlockId(i + 1, j, k) == couchRedID | blockAccess.getBlockId(i + 1, j, k) == couchWhiteID)) break block63;
                                            if (blockAccess.getBlockMetadata(i + 1, j, k) == 2) {
                                                renderblocks.setRenderBounds(0.0, 0.6f, 0.75, 1.0, 1.2f, 1.0);
                                                renderblocks.renderStandardBlock(block, i, j, k);
                                                break block43;
                                            } else if (blockAccess.getBlockMetadata(i + 1, j, k) == 3) {
                                                renderblocks.setRenderBounds(0.0, 0.6f, 0.0, 1.0, 1.2f, 0.25);
                                                renderblocks.renderStandardBlock(block, i, j, k);
                                                break block43;
                                            } else {
                                                renderblocks.setRenderBounds(-0.001f, 0.5, 0.95f, 1.001f, 0.9f, 1.2f);
                                                renderblocks.renderStandardBlock(block, i, j, k);
                                                renderblocks.setRenderBounds(-0.001f, 0.5, -0.2f, 1.001f, 0.9f, 0.05f);
                                                renderblocks.renderStandardBlock(block, i, j, k);
                                            }
                                            break block43;
                                        }
                                        renderblocks.setRenderBounds(-0.001f, 0.5, 0.95f, 1.001f, 0.9f, 1.2f);
                                        renderblocks.renderStandardBlock(block, i, j, k);
                                        renderblocks.setRenderBounds(-0.001f, 0.5, -0.2f, 1.001f, 0.9f, 0.05f);
                                        renderblocks.renderStandardBlock(block, i, j, k);
                                    }
                                    renderblocks.setRenderBounds(0.0, 0.0, 0.0, 1.0, 0.6f, 1.0);
                                    renderblocks.renderStandardBlock(block, i, j, k);
                                    renderblocks.setRenderBounds(0.0, 0.6f, 0.0, 0.25, 1.2f, 1.0);
                                    renderblocks.renderStandardBlock(block, i, j, k);
                                }
                                if (l != 3) break block64;
                                if (!blockAccess.isAirBlock(i + 1, j, k) || blockAccess.isAirBlock(i - 1, j, k)) break block65;
                                if (blockAccess.getBlockId(i, j, k + 1) == couchBlackID) break block65;
                                if (blockAccess.getBlockId(i, j, k + 1) == couchBrownID) break block65;
                                if (blockAccess.getBlockId(i, j, k + 1) == couchGreenID) break block65;
                                if (blockAccess.getBlockId(i, j, k + 1) == couchRedID) break block65;
                                if (blockAccess.getBlockId(i, j, k + 1) == couchWhiteID) break block65;
                                renderblocks.setRenderBounds(0.95f, 0.5, -0.001f, 1.2f, 0.9f, 1.001f);
                                renderblocks.renderStandardBlock(block, i, j, k);
                                break block44;
                            }
                            if (!blockAccess.isAirBlock(i - 1, j, k) || blockAccess.isAirBlock(i + 1, j, k)) break block66;
                            if (blockAccess.getBlockId(i, j, k + 1) == couchBlackID) break block66;
                            if (blockAccess.getBlockId(i, j, k + 1) == couchBrownID) break block66;
                            if (blockAccess.getBlockId(i, j, k + 1) == couchGreenID) break block66;
                            if (blockAccess.getBlockId(i, j, k + 1) == couchRedID) break block66;
                            if (blockAccess.getBlockId(i, j, k + 1) == couchWhiteID) break block66;
                            renderblocks.setRenderBounds(-0.2f, 0.5, -0.001f, 0.05f, 0.9f, 1.001f);
                            renderblocks.renderStandardBlock(block, i, j, k);
                            break block44;
                        }
                        if (!(!blockAccess.isAirBlock(i + 1, j, k) | !blockAccess.isAirBlock(i - 1, j, k))) break block67;
                        boolean bl = blockAccess.getBlockId(i, j, k + 1) == couchBlackID;
                        if (bl | blockAccess.getBlockId(i, j, k + 1) == couchBrownID | blockAccess.getBlockId(i, j, k + 1) == couchGreenID | blockAccess.getBlockId(i, j, k + 1) == couchRedID | blockAccess.getBlockId(i, j, k + 1) == couchWhiteID) {
                            if (blockAccess.getBlockMetadata(i, j, k + 1) == 0) {
                                renderblocks.setRenderBounds(0.75, 0.6f, 0.25, 1.0, 1.2f, 1.0);
                                renderblocks.renderStandardBlock(block, i, j, k);
                            }
                            if (blockAccess.getBlockMetadata(i, j, k + 1) == 1) {
                                renderblocks.setRenderBounds(0.0, 0.6f, 0.25, 0.25, 1.2f, 1.0);
                                renderblocks.renderStandardBlock(block, i, j, k);
                            }
                            if (blockAccess.getBlockMetadata(i, j, k + 1) == 2 | blockAccess.getBlockMetadata(i, j, k + 1) == 3 && !blockAccess.isAirBlock(i - 1, j, k) && blockAccess.isAirBlock(i + 1, j, k)) {
                                renderblocks.setRenderBounds(0.95f, 0.5, -0.001f, 1.2f, 0.9f, 1.001f);
                                renderblocks.renderStandardBlock(block, i, j, k);
                            }
                            if (blockAccess.getBlockMetadata(i, j, k + 1) == 2 | blockAccess.getBlockMetadata(i, j, k + 1) == 3 && !blockAccess.isAirBlock(i + 1, j, k) && blockAccess.isAirBlock(i - 1, j, k)) {
                                renderblocks.setRenderBounds(-0.2f, 0.5, -0.001f, 0.05f, 0.9f, 1.001f);
                                renderblocks.renderStandardBlock(block, i, j, k);
                            }
                        }
                        break block44;
                    }
                    if (!blockAccess.isAirBlock(i + 1, j, k) || !blockAccess.isAirBlock(i - 1, j, k)) break block44;
                    boolean bl = blockAccess.getBlockId(i, j, k + 1) == couchBlackID;
                    if (!(bl | blockAccess.getBlockId(i, j, k + 1) == couchBrownID | blockAccess.getBlockId(i, j, k + 1) == couchGreenID | blockAccess.getBlockId(i, j, k + 1) == couchRedID | blockAccess.getBlockId(i, j, k + 1) == couchWhiteID)) break block68;
                    if (blockAccess.getBlockMetadata(i, j, k + 1) == 0) {
                        renderblocks.setRenderBounds(0.75, 0.6f, 0.25, 1.0, 1.2f, 1.0);
                        renderblocks.renderStandardBlock(block, i, j, k);
                        break block44;
                    } else if (blockAccess.getBlockMetadata(i, j, k + 1) == 1) {
                        renderblocks.setRenderBounds(0.0, 0.6f, 0.25, 0.25, 1.2f, 1.0);
                        renderblocks.renderStandardBlock(block, i, j, k);
                        break block44;
                    } else {
                        renderblocks.setRenderBounds(-0.2f, 0.5, -0.001f, 0.05f, 0.9f, 1.001f);
                        renderblocks.renderStandardBlock(block, i, j, k);
                        renderblocks.setRenderBounds(0.95f, 0.5, -0.001f, 1.2f, 0.9f, 1.001f);
                        renderblocks.renderStandardBlock(block, i, j, k);
                    }
                    break block44;
                }
                renderblocks.setRenderBounds(-0.2f, 0.5, -0.001f, 0.05f, 0.9f, 1.001f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.95f, 0.5, -0.001f, 1.2f, 0.9f, 1.001f);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
            renderblocks.setRenderBounds(0.0, 0.0, 0.0, 1.0, 0.6f, 1.0);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.0, 0.6f, 0.0, 1.0, 1.2f, 0.25);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        renderblocks.overrideBlockTexture = null;
        return true;
    }

    public boolean renderWindowDecoration(Block block, int i, int j, int k, RenderBlocks renderblocks, IBlockAccess blockAccess) {
        int l = blockAccess.getBlockMetadata(i, j, k);
        renderblocks.renderAllFaces = true;
        if (l == 0) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.0, 0.875, 0.875, 1.0, 1.0, 1.0);
            renderblocks.renderStandardBlock(block, i, j, k);
            if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.blinds.blockID) {
                renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.0, 0.0, 0.9375, 1.0, 0.0625, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.125, 0.9375, 1.0, 0.1875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.25, 0.9375, 1.0, 0.3125, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.375, 0.9375, 1.0, 0.4375, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.5, 0.9375, 1.0, 0.5625, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.625, 0.9375, 1.0, 0.6875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.75, 0.9375, 1.0, 0.8125, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 0);
                renderblocks.setRenderBounds(0.921875, 0.125, 0.90625, 0.953125, 0.875, 0.9375);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.blindsClosed.blockID) {
                renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.0, 0.0, 0.9375, 1.0, 0.875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 0);
                renderblocks.setRenderBounds(0.921875, 0.5, 0.90625, 0.953125, 0.875, 0.9375);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
            if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.curtains.blockID) {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 14);
                renderblocks.setRenderBounds(0.8125, 0.125, 0.9375, 1.0, 0.25, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.875, 0.3125, 0.9375, 1.0, 0.375, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.8125, 0.375, 0.9375, 1.0, 0.5, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.75, 0.5, 0.9375, 1.0, 0.6875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.6875, 0.6875, 0.9375, 1.0, 0.875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.125, 0.9375, 0.1875, 0.25, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.3125, 0.9375, 0.125, 0.375, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.375, 0.9375, 0.1875, 0.5, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.5, 0.9375, 0.25, 0.6875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.6875, 0.9375, 0.3125, 0.875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.blockGold.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.875, 0.25, 0.9375, 1.0, 0.3125, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.25, 0.9375, 0.125, 0.3125, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.curtainsClosed.blockID) {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 14);
                renderblocks.setRenderBounds(0.0, 0.0625, 0.9375, 1.0, 0.875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.blockGold.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.9375, 0.1875, 0.9374f, 1.0001f, 0.3125, 0.9999f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(-1.0E-4f, 0.1875, 0.9374f, 0.0626f, 0.3125, 0.9999f);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
        }
        if (l == 2) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.0, 0.875, 0.0, 1.0, 1.0, 0.125);
            renderblocks.renderStandardBlock(block, i, j, k);
            if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.blinds.blockID) {
                renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.0, 0.0, 0.0, 1.0, 0.0625, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.125, 0.0, 1.0, 0.1875, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.25, 0.0, 1.0, 0.3125, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.375, 0.0, 1.0, 0.4375, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.5, 0.0, 1.0, 0.5625, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.625, 0.0, 1.0, 0.6875, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.75, 0.0, 1.0, 0.8125, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 0);
                renderblocks.setRenderBounds(0.046875, 0.125, 0.0625, 0.078125, 0.875, 0.09375);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.blindsClosed.blockID) {
                renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.0, 0.0, 0.0, 1.0, 0.875, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 0);
                renderblocks.setRenderBounds(0.046875, 0.5, 0.0625, 0.078125, 0.875, 0.09375);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
            if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.curtains.blockID) {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 14);
                renderblocks.setRenderBounds(0.8125, 0.125, 0.0, 1.0, 0.25, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.875, 0.3125, 0.0, 1.0, 0.375, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.8125, 0.375, 0.0, 1.0, 0.5, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.75, 0.5, 0.0, 1.0, 0.6875, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.6875, 0.6875, 0.0, 1.0, 0.875, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.125, 0.0, 0.1875, 0.25, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.3125, 0.0, 0.125, 0.375, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.375, 0.0, 0.1875, 0.5, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.5, 0.0, 0.25, 0.6875, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.6875, 0.0, 0.3125, 0.875, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.blockGold.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.875, 0.25, 0.0, 1.0, 0.3125, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.25, 0.0, 0.125, 0.3125, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.curtainsClosed.blockID) {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 14);
                renderblocks.setRenderBounds(0.0, 0.0625, 0.0, 1.0, 0.875, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.blockGold.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.9375, 0.1875, 1.0E-4f, 1.0001f, 0.3125, 0.0626f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(-1.0E-4f, 0.1875, 1.0E-4f, 0.0626f, 0.3125, 0.0626f);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
        }
        if (l == 1) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.0, 0.875, 0.0, 0.125, 1.0, 1.0);
            renderblocks.renderStandardBlock(block, i, j, k);
            if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.blinds.blockID) {
                renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.0, 0.0, 0.0, 0.0625, 0.0625, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.125, 0.0, 0.0625, 0.1875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.25, 0.0, 0.0625, 0.3125, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.375, 0.0, 0.0625, 0.4375, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.5, 0.0, 0.0625, 0.5625, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.625, 0.0, 0.0625, 0.6875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.75, 0.0, 0.0625, 0.8125, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 0);
                renderblocks.setRenderBounds(0.09375, 0.125, 0.953125, 0.0625, 0.875, 0.921875);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.blindsClosed.blockID) {
                renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.0, 0.0, 0.0, 0.0625, 0.875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 0);
                renderblocks.setRenderBounds(0.09375, 0.5, 0.953125, 0.0625, 0.875, 0.921875);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
            if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.curtains.blockID) {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 14);
                renderblocks.setRenderBounds(0.0, 0.125, 0.0, 0.0625, 0.25, 0.1875);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.3125, 0.0, 0.0625, 0.375, 0.125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.375, 0.0, 0.0625, 0.5, 0.1875);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.5, 0.0, 0.0625, 0.6875, 0.25);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.6875, 0.0, 0.0625, 0.875, 0.3125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.125, 0.8125, 0.0625, 0.25, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.3125, 0.875, 0.0625, 0.375, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.375, 0.8125, 0.0625, 0.5, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.5, 0.75, 0.0625, 0.6875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.6875, 0.6875, 0.0625, 0.875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.blockGold.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(1.0E-4f, 0.25, 0.0, 0.0626f, 0.3125, 0.125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(1.0E-4f, 0.25, 0.875, 0.0626f, 0.3125, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.curtainsClosed.blockID) {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 14);
                renderblocks.setRenderBounds(0.0, 0.0625, 0.0, 0.0625, 0.875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.blockGold.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(1.0E-4f, 0.1875, -1.0E-4f, 0.0626f, 0.3125, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(1.0E-4f, 0.1875, 0.9375, 0.0626f, 0.3125, 1.0001f);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
        }
        if (l == 3) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.875, 0.875, 0.0, 1.0, 1.0, 1.0);
            renderblocks.renderStandardBlock(block, i, j, k);
            if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.blinds.blockID) {
                renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.9375, 0.0, 0.0, 1.0, 0.0625, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.125, 0.0, 1.0, 0.1875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.25, 0.0, 1.0, 0.3125, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.375, 0.0, 1.0, 0.4375, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.5, 0.0, 1.0, 0.5625, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.625, 0.0, 1.0, 0.6875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.75, 0.0, 1.0, 0.8125, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 0);
                renderblocks.setRenderBounds(0.90625, 0.124f, 0.046875, 0.9375, 0.875, 0.078125);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.blindsClosed.blockID) {
                renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.9375, 0.0, 0.0, 1.0, 0.875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 0);
                renderblocks.setRenderBounds(0.90625, 0.5, 0.046875, 0.9375, 0.875, 0.078125);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
            if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.curtains.blockID) {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 14);
                renderblocks.setRenderBounds(0.9375, 0.125, 0.0, 1.0, 0.25, 0.1875);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.3125, 0.0, 1.0, 0.375, 0.125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.375, 0.0, 1.0, 0.5, 0.1875);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.5, 0.0, 1.0, 0.6875, 0.25);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.6875, 0.0, 1.0, 0.875, 0.3125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.125, 0.8125, 1.0, 0.25, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.3125, 0.875, 1.0, 0.375, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.375, 0.8125, 1.0, 0.5, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.5, 0.75, 1.0, 0.6875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.6875, 0.6875, 1.0, 0.875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.blockGold.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.9374f, 0.25, 0.0, 0.9999f, 0.3125, 0.125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9374f, 0.25, 0.875, 0.9999f, 0.3125, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (blockAccess.getBlockId(i, j, k) == mod_FurnitureMod.curtainsClosed.blockID) {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 14);
                renderblocks.setRenderBounds(0.9375, 0.0625, 0.0, 1.0, 0.875, 1.0001f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.blockGold.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.9374f, 0.1875, -1.0E-4f, 0.9999f, 0.3125, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9374f, 0.1875, 0.9375, 0.9999f, 0.3125, 1.00011f);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
        }
        renderblocks.overrideBlockTexture = null;
        return true;
    }

    public boolean renderCoffeeTable(Block block, int i, int j, int k, RenderBlocks renderblocks, IBlockAccess world) {
        renderblocks.renderAllFaces = true;
        if (world.getBlockId(i, j, k) == coffeeTableWoodID) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.0, 0.4f, 0.0, 1.0, 0.5, 1.0);
            renderblocks.renderStandardBlock(block, i, j, k);
            if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableWood.blockID) {
                renderblocks.setRenderBounds(0.0, 0.0, 0.0, 0.1f, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.0, 0.9f, 0.1f, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableWood.blockID) {
                renderblocks.setRenderBounds(0.9f, 0.0, 0.0, 1.0, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9f, 0.0, 0.9f, 1.0, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableWood.blockID) {
                renderblocks.setRenderBounds(0.9f, 0.0, 0.0, 1.0, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.0, 0.0, 0.1f, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableWood.blockID) {
                renderblocks.setRenderBounds(0.0, 0.0, 0.9f, 0.1f, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9f, 0.0, 0.9f, 1.0, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableWood.blockID) {
                renderblocks.setRenderBounds(0.0, 0.0, 0.0, 0.1f, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableWood.blockID) {
                renderblocks.setRenderBounds(0.0, 0.0, 0.9f, 0.1f, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableWood.blockID) {
                renderblocks.setRenderBounds(0.9f, 0.0, 0.9f, 1.0, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableWood.blockID) {
                renderblocks.setRenderBounds(0.9f, 0.0, 0.0, 1.0, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (!(world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableWood.blockID || world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableWood.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableWood.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableWood.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableWood.blockID || world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableWood.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableWood.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableWood.blockID)) {
                renderblocks.setRenderBounds(0.9f, 0.0, 0.0, 1.0, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.0, 0.0, 0.1f, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.0, 0.9f, 0.1f, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9f, 0.0, 0.9f, 1.0, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
        }
        if (world.getBlockId(i, j, k) == coffeeTableStoneID) {
            renderblocks.overrideBlockTexture = Block.cobblestone.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.0, 0.4f, 0.0, 1.0, 0.5, 1.0);
            renderblocks.renderStandardBlock(block, i, j, k);
            if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableStone.blockID) {
                renderblocks.setRenderBounds(0.0, 0.0, 0.0, 0.1f, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.0, 0.9f, 0.1f, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableStone.blockID) {
                renderblocks.setRenderBounds(0.9f, 0.0, 0.0, 1.0, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9f, 0.0, 0.9f, 1.0, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableStone.blockID) {
                renderblocks.setRenderBounds(0.9f, 0.0, 0.0, 1.0, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.0, 0.0, 0.1f, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableStone.blockID) {
                renderblocks.setRenderBounds(0.0, 0.0, 0.9f, 0.1f, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9f, 0.0, 0.9f, 1.0, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableStone.blockID) {
                renderblocks.setRenderBounds(0.0, 0.0, 0.0, 0.1f, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableStone.blockID) {
                renderblocks.setRenderBounds(0.0, 0.0, 0.9f, 0.1f, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableStone.blockID) {
                renderblocks.setRenderBounds(0.9f, 0.0, 0.9f, 1.0, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableStone.blockID) {
                renderblocks.setRenderBounds(0.9f, 0.0, 0.0, 1.0, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else if (!(world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableStone.blockID || world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableStone.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableStone.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableStone.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableStone.blockID || world.getBlockId(i + 1, j, k) != mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) == mod_FurnitureMod.coffeeTableStone.blockID || world.getBlockId(i + 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k + 1) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i - 1, j, k) == mod_FurnitureMod.coffeeTableStone.blockID && world.getBlockId(i, j, k - 1) != mod_FurnitureMod.coffeeTableStone.blockID)) {
                renderblocks.setRenderBounds(0.9f, 0.0, 0.0, 1.0, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.0, 0.0, 0.1f, 0.4f, 0.1f);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.0, 0.9f, 0.1f, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9f, 0.0, 0.9f, 1.0, 0.4f, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
        }
        renderblocks.overrideBlockTexture = null;
        return true;
    }

    public boolean renderCarpet(Block block, int i, int j, int k, RenderBlocks renderblocks, IBlockAccess blockAccess) {
        renderblocks.renderAllFaces = true;
        int l = blockAccess.getBlockMetadata(i, j, k);
        if (l == 1) {
            renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 15);
        }
        if (l == 2) {
            renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 12);
        }
        if (l == 3) {
            renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 14);
        }
        if (l == 4) {
            renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 0);
        }
        if (l == 5) {
            renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 13);
        }
        renderblocks.setRenderBounds(0.0, 0.0, 0.0, 1.0, 0.01f, 1.0);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.overrideBlockTexture = null;
        return true;
    }

    public boolean renderFridge(Block block, int i, int j, int k, RenderBlocks renderblocks, IBlockAccess world) {
        renderblocks.renderAllFaces = true;
        renderblocks.overrideBlockTexture = Block.blockSteel.getBlockTextureFromSide(1);
        renderblocks.setRenderBounds(0.0625, 0.0, 0.0625, 0.9375, 1.0, 0.9375);
        renderblocks.renderStandardBlock(block, i, j, k);
        if (world.getBlockMetadata(i, j, k) == 1) {
            if (world.getBlockId(i, j, k) == fridgeID) {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 15);
                renderblocks.setRenderBounds(1.0, 0.125, 0.875, 0.9375, 0.75, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(1.0, 0.6875, 0.8125, 0.9375, 0.75, 0.75);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(1.0, 0.125, 0.8125, 0.9375, 0.1875, 0.75);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.stone.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.03125, 0.0, 0.1875, 0.0625, 0.0625, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.03125, 0.125, 0.1875, 0.0625, 0.1875, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.03125, 0.25, 0.1875, 0.0625, 0.3125, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.03125, 0.0625, 0.1875, 0.0625, 0.125, 0.25);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.03125, 0.1875, 0.75, 0.0625, 0.25, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 15);
                renderblocks.setRenderBounds(1.0, 0.5, 0.875, 0.9375, 0.875, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(1.0, 0.8125, 0.8125, 0.9375, 0.875, 0.75);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(1.0, 0.5, 0.8125, 0.9375, 0.5625, 0.75);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.stone.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.0, 0.0625, 0.1875, 0.0625, 0.3125, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.03125, 0.9375, 0.75, 0.0625, 1.0, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
            renderblocks.setRenderBounds(0.03125, 0.3125, 0.1875, 0.0625, 0.375, 0.25);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.03125, 0.5625, 0.1875, 0.0625, 0.625, 0.25);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.03125, 0.8125, 0.1875, 0.0625, 0.875, 0.25);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.03125, 0.4375, 0.75, 0.0625, 0.5, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.03125, 0.6875, 0.75, 0.0625, 0.75, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.03125, 0.375, 0.1875, 0.0625, 0.4375, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.03125, 0.5, 0.1875, 0.0625, 0.5625, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.03125, 0.625, 0.1875, 0.0625, 0.6875, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.03125, 0.75, 0.1875, 0.0625, 0.8125, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.03125, 0.875, 0.1875, 0.0625, 0.9375, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 2) {
            if (world.getBlockId(i, j, k) == fridgeID) {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 15);
                renderblocks.setRenderBounds(0.8125, 0.125, 0.0, 0.875, 0.8125, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.75, 0.75, 0.0, 0.8125, 0.8125, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.75, 0.125, 0.0, 0.8125, 0.1875, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.stone.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.1875, 0.0, 0.9375, 0.8125, 0.0625, 0.96875);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.1875, 0.125, 0.9375, 0.8125, 0.1875, 0.96875);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.1875, 0.25, 0.9375, 0.8125, 0.3f, 0.96875);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.1875, 0.06255f, 0.9375, 0.25, 0.125, 0.96875);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.75, 0.1875, 0.9375, 0.8125, 0.25, 0.96875);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 15);
                renderblocks.setRenderBounds(0.8125, 0.5, 0.0, 0.875, 0.875, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.75, 0.5, 0.0, 0.8125, 0.5625, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.75, 0.8125, 0.0, 0.8125, 0.875, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.stone.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.75, 0.9375, 0.9375, 0.8125, 1.0, 0.96875);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.1875, 0.0625, 0.9375, 0.8125, 0.3125, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
            renderblocks.setRenderBounds(0.1875, 0.3125, 0.9375, 0.25, 0.375, 0.96875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.5625, 0.9375, 0.25, 0.625, 0.96875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.8125, 0.9375, 0.25, 0.875, 0.96875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.75, 0.4375, 0.9375, 0.8125, 0.5, 0.96875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.75, 0.6875, 0.9375, 0.8125, 0.75, 0.96875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.375, 0.9375, 0.8125, 0.4375, 0.96875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.5, 0.9375, 0.8125, 0.5625, 0.96875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.625, 0.9375, 0.8125, 0.6875, 0.96875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.75, 0.9375, 0.8125, 0.8125, 0.96875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.875, 0.9375, 0.8125, 0.9375, 0.96875);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 3) {
            if (world.getBlockId(i, j, k) == fridgeID) {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 15);
                renderblocks.setRenderBounds(0.125, 0.125, 0.9375, 0.1875, 0.75, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.1875, 0.125, 0.9375, 0.25, 0.1875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.1875, 0.6875, 0.9375, 0.25, 0.75, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.stone.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.1875, 0.0, 0.03125, 0.8125, 0.0625, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.1875, 0.125, 0.03125, 0.8125, 0.1875, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.1875, 0.25, 0.03125, 0.8125, 0.3125, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.75, 0.0, 0.03125, 0.8125, 0.0625, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.75, 0.1875, 0.03125, 0.8125, 0.25, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.1875, 0.0625, 0.03125, 0.25, 0.125, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
            } else {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 15);
                renderblocks.setRenderBounds(0.125, 0.5, 0.9375, 0.1875, 0.875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.1875, 0.5, 0.9375, 0.25, 0.5625, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.1875, 0.8125, 0.9375, 0.25, 0.875, 1.0);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.stone.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.75, 0.9375, 0.9375, 0.8125, 1.0, 0.96875);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.1875, 0.0625, 0.0, 0.8125, 0.3125, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.75, 0.9375, 0.03125, 0.8125, 1.0, 0.0625);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
            renderblocks.setRenderBounds(0.1875, 0.3125, 0.03125, 0.25, 0.375, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.5625, 0.03125, 0.25, 0.625, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.8125, 0.03125, 0.25, 0.875, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.75, 0.4375, 0.03125, 0.8125, 0.5, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.75, 0.6875, 0.03125, 0.8125, 0.75, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.375, 0.03125, 0.8125, 0.4375, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.5, 0.03125, 0.8125, 0.5625, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.625, 0.03125, 0.8125, 0.6875, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.75, 0.03125, 0.8125, 0.8125, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.875, 0.03125, 0.8125, 0.9375, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 0) {
            if (world.getBlockId(i, j, k) == fridgeID) {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 15);
                renderblocks.setRenderBounds(0.0, 0.125, 0.125, 0.0625, 0.75, 0.1875);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.125, 0.1875, 0.0625, 0.1875, 0.25);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.6875, 0.1875, 0.0625, 0.75, 0.25);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.stone.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.9375, 0.0, 0.1875, 0.96875, 0.0625, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.125, 0.1875, 0.96875, 0.1875, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.25, 0.1875, 0.96875, 0.3125, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.0625, 0.1875, 0.96875, 0.125, 0.25);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.1875, 0.75, 0.96875, 0.25, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
            if (world.getBlockMetadata(i, j, k) == 0 && world.getBlockId(i, j, k) == freezerID) {
                renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 15);
                renderblocks.setRenderBounds(0.0, 0.5, 0.125, 0.0625, 0.875, 0.1875);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.5, 0.1875, 0.0625, 0.5625, 0.25);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.0, 0.8125, 0.1875, 0.0625, 0.875, 0.25);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.overrideBlockTexture = Block.stone.getBlockTextureFromSide(1);
                renderblocks.setRenderBounds(0.9375, 0.0625, 0.1875, 1.0, 0.3125, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
                renderblocks.setRenderBounds(0.9375, 0.9375, 0.75, 0.96875, 1.0, 0.8125);
                renderblocks.renderStandardBlock(block, i, j, k);
            }
            renderblocks.setRenderBounds(0.9375, 0.3125, 0.1875, 0.96875, 0.375, 0.25);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.9375, 0.5625, 0.1875, 0.96875, 0.625, 0.25);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.9375, 0.8125, 0.1875, 0.96875, 0.875, 0.25);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.9375, 0.4375, 0.75, 0.96875, 0.5, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.9375, 0.6875, 0.75, 0.96875, 0.75, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.9375, 0.375, 0.1875, 0.96875, 0.4375, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.9375, 0.5, 0.1875, 0.96875, 0.5625, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.9375, 0.625, 0.1875, 0.96875, 0.6875, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.9375, 0.75, 0.1875, 0.96875, 0.8125, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.9375, 0.875, 0.1875, 0.96875, 0.9375, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        renderblocks.overrideBlockTexture = null;
        return true;
    }

    public boolean renderCabinet(Block block, int i, int j, int k, RenderBlocks renderblocks, IBlockAccess world) {
        renderblocks.renderAllFaces = true;
        renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSideAndMetadata(1, 2);
        renderblocks.setRenderBounds(0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
        renderblocks.renderStandardBlock(block, i, j, k);
        if (world.getBlockMetadata(i, j, k) == 1) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSideAndMetadata(1, 1);
            renderblocks.setRenderBounds(0.5, 0.0625, 0.0625, 1.0625, 0.9375, 0.9375);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.overrideBlockTexture = Block.blockSteel.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.9375, 0.375, 0.8125, 1.1f, 0.75, 0.875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.9375, 0.6875, 0.75, 1.1f, 0.75, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.9375, 0.375, 0.75, 1.1f, 0.4375, 0.8125);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 2) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSideAndMetadata(1, 1);
            renderblocks.setRenderBounds(0.0625, 0.0625, 0.5, 0.9375, 0.9375, 1.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.overrideBlockTexture = Block.blockSteel.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.125, 0.375, 0.9375, 0.1875, 0.75, 1.1f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.375, 0.9375, 0.25, 0.4375, 1.1f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.1875, 0.6875, 0.9375, 0.25, 0.75, 1.1f);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 3) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSideAndMetadata(1, 1);
            renderblocks.setRenderBounds(-0.0625, 0.0625, 0.0625, 0.5, 0.9375, 0.9375);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.overrideBlockTexture = Block.blockSteel.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(-0.1f, 0.375, 0.125, 0.0625, 0.75, 0.1875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(-0.1f, 0.375, 0.1875, 0.0625, 0.4375, 0.25);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(-0.1f, 0.6875, 0.1875, 0.0625, 0.75, 0.25);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 0) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSideAndMetadata(1, 1);
            renderblocks.setRenderBounds(0.0625, 0.0625, -0.0625, 0.9375, 0.9375, 0.5);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.overrideBlockTexture = Block.blockSteel.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.8125, 0.375, -0.1f, 0.875, 0.75, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.75, 0.375, -0.1f, 0.8125, 0.4375, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.75, 0.6875, -0.1f, 0.8125, 0.75, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        renderblocks.overrideBlockTexture = null;
        return true;
    }

    public boolean renderLamp(Block block, int i, int j, int k, RenderBlocks renderblocks, IBlockAccess world) {
        renderblocks.renderAllFaces = true;
        renderblocks.overrideBlockTexture = Block.cloth.getBlockTextureFromSideAndMetadata(1, 0);
        renderblocks.setRenderBounds(0.3f, 0.85f, 0.3f, 0.7f, 0.9f, 0.7f);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.setRenderBounds(0.2f, 0.8f, 0.2f, 0.8f, 0.85f, 0.8f);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.setRenderBounds(0.15f, 0.7f, 0.15f, 0.85f, 0.8f, 0.85f);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.setRenderBounds(0.1f, 0.5, 0.1f, 0.9f, 0.7f, 0.9f);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.overrideBlockTexture = Block.obsidian.getBlockTextureFromSide(1);
        renderblocks.setRenderBounds(0.45f, 0.0, 0.45f, 0.55f, 0.6f, 0.55f);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.setRenderBounds(0.25, 0.0, 0.25, 0.75, 0.3125, 0.75);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.overrideBlockTexture = null;
        return true;
    }

    public boolean renderBedsideCabinet(Block block, int i, int j, int k, RenderBlocks renderblocks, IBlockAccess world) {
        renderblocks.renderAllFaces = true;
        if (world.getBlockMetadata(i, j, k) == 0) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSideAndMetadata(1, 1);
            renderblocks.setRenderBounds(0.0, 0.125, 0.125, 0.0625, 0.4375, 0.875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.0, 0.5625, 0.125, 0.0625, 0.87f, 0.875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.25, 0.25, 0.375, 0.0625, 0.87f, 0.875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(-0.03f, 0.25, 0.375, 0.0625, 0.3125, 0.625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(-0.03f, 0.6875, 0.375, 0.0625, 0.75, 0.625);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 2) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSideAndMetadata(1, 1);
            renderblocks.setRenderBounds(0.125, 0.125, 0.0, 0.875, 0.4375, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.125, 0.5625, 0.0, 0.875, 0.87f, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.375, 0.25, -0.03f, 0.625, 0.3125, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.375, 0.6875, -0.03f, 0.625, 0.75, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 1) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSideAndMetadata(1, 1);
            renderblocks.setRenderBounds(0.9375, 0.125, 0.125, 1.0, 0.4375, 0.875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.9375, 0.5625, 0.125, 1.0, 0.87f, 0.875);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(1.0, 0.25, 0.375, 1.03f, 0.3125, 0.625);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(1.0, 0.6875, 0.375, 1.03f, 0.75, 0.625);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 3) {
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSideAndMetadata(1, 1);
            renderblocks.setRenderBounds(0.125, 0.125, 0.9375, 0.875, 0.4375, 1.0);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.125, 0.5625, 0.9375, 0.875, 0.87f, 1.0);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.375, 0.25, 0.375, 0.625, 0.3125, 1.03f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.setRenderBounds(0.375, 0.6875, 0.375, 0.625, 0.75, 1.03f);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        renderblocks.overrideBlockTexture = Block.planks.getBlockTextureFromSide(1);
        renderblocks.setRenderBounds(0.0625, 0.1f, 0.0625, 0.9375, 0.9f, 0.9375);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.overrideBlockTexture = Block.wood.getBlockTextureFromSide(2);
        renderblocks.setRenderBounds(0.0, 0.0, 0.0, 1.0, 0.1f, 1.0);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.setRenderBounds(0.0, 0.9f, 0.0, 1.0, 1.0, 1.0);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.overrideBlockTexture = null;
        return false;
    }

    public boolean renderOven(Block block, int i, int j, int k, RenderBlocks renderblocks, IBlockAccess world) {
        renderblocks.renderAllFaces = true;
        renderblocks.overrideBlockTexture = Block.blockNetherQuartz.getBlockTextureFromSide(1);
        renderblocks.setRenderBounds(0.0625, 0.0, 0.0625, 0.9375, 1.0, 0.9375);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.overrideBlockTexture = Block.obsidian.getBlockTextureFromSide(1);
        renderblocks.setRenderBounds(0.1875, 0.5, 0.1875, 0.4325f, 1.0625, 0.4375);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.setRenderBounds(0.1875, 0.5, 0.5625, 0.4325f, 1.0625, 0.8125);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.setRenderBounds(0.5625, 0.5, 0.1875, 0.8125, 1.0625, 0.4375);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.setRenderBounds(0.5625, 0.5, 0.5625, 0.8125, 1.0625, 0.8125);
        renderblocks.renderStandardBlock(block, i, j, k);
        renderblocks.overrideBlockTexture = Block.blockNetherQuartz.getBlockTextureFromSide(1);
        if (world.getBlockMetadata(i, j, k) == 0) {
            renderblocks.setRenderBounds(0.0625, 0.0, 0.8749f, 0.9376f, 1.1875, 1.0);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.overrideBlockTexture = Block.blockSteel.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.2f, 0.2f, 0.0, 0.8f, 0.8125, 0.0625);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 2) {
            renderblocks.setRenderBounds(0.0624f, 0.0, 0.0, 0.9376f, 1.1875, 0.125);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.overrideBlockTexture = Block.blockSteel.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.2f, 0.2f, 0.9375, 0.8f, 0.8125, 1.0);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 1) {
            renderblocks.setRenderBounds(0.0, 0.0, 0.0624f, 0.125, 1.1875, 0.9376f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.overrideBlockTexture = Block.blockSteel.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.9375, 0.2f, 0.2f, 1.0, 0.8125, 0.8f);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 3) {
            renderblocks.setRenderBounds(0.875, 0.0, 0.0624f, 1.0, 1.1875, 0.9376f);
            renderblocks.renderStandardBlock(block, i, j, k);
            renderblocks.overrideBlockTexture = Block.blockSteel.getBlockTextureFromSide(1);
            renderblocks.setRenderBounds(0.0, 0.2f, 0.2f, 0.0625, 0.8125, 0.8f);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        renderblocks.overrideBlockTexture = null;
        return false;
    }

    public boolean renderOvenOverhead(Block block, int i, int j, int k, RenderBlocks renderblocks, IBlockAccess world) {
        renderblocks.renderAllFaces = true;
        renderblocks.overrideBlockTexture = Block.stoneSingleSlab.getBlockTextureFromSide(1);
        renderblocks.setRenderBounds(0.0, 0.0, 0.0, 1.0, 0.2f, 1.0);
        renderblocks.renderStandardBlock(block, i, j, k);
        if (world.getBlockMetadata(i, j, k) == 0) {
            renderblocks.setRenderBounds(0.2f, 0.2f, 0.5, 0.8f, 1.0, 1.0);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 2) {
            renderblocks.setRenderBounds(0.2f, 0.2f, 0.0, 0.8f, 1.0, 0.5);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 1) {
            renderblocks.setRenderBounds(0.0, 0.2f, 0.2f, 0.5, 1.0, 0.8f);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        if (world.getBlockMetadata(i, j, k) == 3) {
            renderblocks.setRenderBounds(0.5, 0.2f, 0.2f, 1.0, 1.0, 0.8f);
            renderblocks.renderStandardBlock(block, i, j, k);
        }
        renderblocks.overrideBlockTexture = null;
        return false;
    }

    public String getVersion() {
        return "Furniture Mod v2.7 - 1.5.1";
    }
}
