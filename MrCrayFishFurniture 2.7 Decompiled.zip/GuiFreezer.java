import net.minecraft.src.GuiContainer;
import net.minecraft.src.InventoryPlayer;
import org.lwjgl.opengl.GL11;

public class GuiFreezer
extends GuiContainer {
    private TileEntityFreezer FreezerInventory;

    public GuiFreezer(InventoryPlayer inventoryplayer, TileEntityFreezer tileentityfreezer) {
        super(new ContainerFreezer(inventoryplayer, tileentityfreezer));
        this.FreezerInventory = tileentityfreezer;
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int par1, int par2) {
        this.fontRenderer.drawString("Freezer", 8, 6, 0x404040);
        this.fontRenderer.drawString("Inventory", 8, this.ySize - 96 + 2, 0x404040);
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float f, int i, int j) {
        int var7;
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        this.mc.renderEngine.bindTexture("/gui/freezer.png");
        int l = (this.width - this.xSize) / 2;
        int i1 = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(l, i1, 0, 0, this.xSize, this.ySize);
        if (this.FreezerInventory.isFreezing()) {
            var7 = this.FreezerInventory.getFreezeTimeRemainingScaled(12);
            this.drawTexturedModalRect(l + 15, i1 + 40 - var7, 176, 12 - var7, 14, var7 + 2);
        }
        var7 = this.FreezerInventory.getCoolProgressScaled(24);
        this.drawTexturedModalRect(l + 86, i1 + 27, 176, 14, var7 + 1, 16);
    }
}
