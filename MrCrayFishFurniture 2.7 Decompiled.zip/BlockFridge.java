import java.util.Random;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.BlockContainer;
import net.minecraft.src.Container;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntityPlayerMP;
import net.minecraft.src.EntityPlayerSP;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.ItemStack;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.TileEntity;
import net.minecraft.src.World;

public class BlockFridge
extends BlockContainer {
    private Random freezerRand = new Random();

    protected BlockFridge(int i) {
        super(i, Material.iron);
    }

    @Override
    public boolean isOpaqueCube() {
        return false;
    }

    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }

    @Override
    public int getRenderType() {
        return mod_FurnitureMod.renderFridge;
    }

    @Override
    public AxisAlignedBB getSelectedBoundingBoxFromPool(World par1World, int par2, int par3, int par4) {
        this.setBlockBounds(0.0625f, 0.0f, 0.0625f, 0.9375f, 1.0f, 0.9375f);
        return super.getCollisionBoundingBoxFromPool(par1World, par2, par3, par4);
    }

    public void onBlockPlacedBy(World world, int i, int j, int k, EntityLiving entityliving) {
        int l = MathHelper.floor_double((double)(entityliving.rotationYaw * 4.0f / 360.0f) + 0.5) & 3;
        if (l == 0) {
            world.setBlockMetadataWithNotify(i, j, k, 2, 0);
        }
        if (l == 1) {
            world.setBlockMetadataWithNotify(i, j, k, 1, 0);
        }
        if (l == 2) {
            world.setBlockMetadataWithNotify(i, j, k, 3, 0);
        }
        if (l == 3) {
            world.setBlockMetadataWithNotify(i, j, k, 0, 0);
        }
    }

    public void onBlockDestroyedByPlayer(World world, int i, int j, int k, int l, int l1) {
        this.dropBlockAsItem_do(world, i, j - 1, k, new ItemStack(0, 0, 0));
    }

    @Override
    public int idDropped(int i, Random random, int j) {
        return mod_FurnitureMod.itemFridge.itemID;
    }

    @Override
    public void breakBlock(World par1World, int par2, int par3, int par4, int par5, int par6) {
        TileEntityFridge var7 = (TileEntityFridge)par1World.getBlockTileEntity(par2, par3, par4);
        if (var7 != null) {
            for (int var8 = 0; var8 < var7.getSizeInventory(); ++var8) {
                ItemStack var9 = var7.getStackInSlot(var8);
                if (var9 == null) continue;
                float var10 = this.freezerRand.nextFloat() * 0.8f + 0.1f;
                float var11 = this.freezerRand.nextFloat() * 0.8f + 0.1f;
                float var12 = this.freezerRand.nextFloat() * 0.8f + 0.1f;
                while (var9.stackSize > 0) {
                    int var13 = this.freezerRand.nextInt(21) + 10;
                    if (var13 > var9.stackSize) {
                        var13 = var9.stackSize;
                    }
                    var9.stackSize -= var13;
                    EntityItem var14 = new EntityItem(par1World, (float)par2 + var10, (float)par3 + var11, (float)par4 + var12, new ItemStack(var9.itemID, var13, var9.getItemDamage()));
                    if (var9.hasTagCompound()) {
                        var14.getEntityItem().setTagCompound((NBTTagCompound)var9.getTagCompound().copy());
                    }
                    float var15 = 0.05f;
                    var14.motionX = (float)this.freezerRand.nextGaussian() * var15;
                    var14.motionY = (float)this.freezerRand.nextGaussian() * var15 + 0.2f;
                    var14.motionZ = (float)this.freezerRand.nextGaussian() * var15;
                    par1World.spawnEntityInWorld(var14);
                }
            }
        }
        par1World.setBlockToAir(par2, par3 - 1, par4);
        super.breakBlock(par1World, par2, par3, par4, par5, par6);
    }

    @Override
    public boolean onBlockActivated(World par1World, int par2, int par3, int par4, EntityPlayer par5EntityPlayer, int par6, float par7, float par8, float par9) {
        TileEntityFridge tileEntityFridge = (TileEntityFridge)par1World.getBlockTileEntity(par2, par3, par4);
        if (par5EntityPlayer instanceof EntityPlayerMP) {
            ModLoader.serverOpenWindow((EntityPlayerMP)((EntityPlayerMP)par5EntityPlayer), (Container)new ContainerFridge(par5EntityPlayer.inventory, tileEntityFridge), (int)12, (int)par2, (int)par3, (int)par4);
        } else {
            ModLoader.openGUI((EntityPlayer)((EntityPlayerSP)par5EntityPlayer), (GuiScreen)new GuiFridge(par5EntityPlayer.inventory, (TileEntityFridge)par1World.getBlockTileEntity(par2, par3, par4)));
        }
        return true;
    }

    @Override
    public TileEntity createNewTileEntity(World var1) {
        return new TileEntityFridge();
    }

    @Override
    public int idPicked(World par1World, int par2, int par3, int par4) {
        return mod_FurnitureMod.itemFridge.itemID;
    }
}
