import net.minecraft.src.EntityPlayer;
import net.minecraft.src.IInventory;
import net.minecraft.src.ItemStack;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.NBTTagList;
import net.minecraft.src.TileEntity;

public class TileEntityOven
extends TileEntity
implements IInventory {
    private ItemStack[] ovenItemStacks = new ItemStack[50];
    public int ovenCookTime = 0;
    public int currentItemCoolTime = 0;
    public int ovenCookingTime = 0;

    @Override
    public int getSizeInventory() {
        return this.ovenItemStacks.length;
    }

    @Override
    public ItemStack getStackInSlot(int i) {
        return this.ovenItemStacks[i];
    }

    @Override
    public ItemStack decrStackSize(int i, int j) {
        if (this.ovenItemStacks[i] != null) {
            if (this.ovenItemStacks[i].stackSize <= j) {
                ItemStack itemstack = this.ovenItemStacks[i];
                this.ovenItemStacks[i] = null;
                return itemstack;
            }
            ItemStack itemstack1 = this.ovenItemStacks[i].splitStack(j);
            if (this.ovenItemStacks[i].stackSize == 0) {
                this.ovenItemStacks[i] = null;
            }
            return itemstack1;
        }
        return null;
    }

    @Override
    public ItemStack getStackInSlotOnClosing(int par1) {
        if (this.ovenItemStacks[par1] != null) {
            ItemStack itemstack = this.ovenItemStacks[par1];
            this.ovenItemStacks[par1] = null;
            return itemstack;
        }
        return null;
    }

    @Override
    public void setInventorySlotContents(int i, ItemStack itemstack) {
        this.ovenItemStacks[i] = itemstack;
        if (itemstack != null && itemstack.stackSize > this.getInventoryStackLimit()) {
            itemstack.stackSize = this.getInventoryStackLimit();
        }
    }

    @Override
    public String getInvName() {
        return "Freezer";
    }

    @Override
    public void readFromNBT(NBTTagCompound par1NBTTagCompound) {
        super.readFromNBT(par1NBTTagCompound);
        NBTTagList nbttaglist = par1NBTTagCompound.getTagList("Items");
        this.ovenItemStacks = new ItemStack[this.getSizeInventory()];
        for (int i = 0; i < nbttaglist.tagCount(); ++i) {
            NBTTagCompound nbttagcompound = (NBTTagCompound)nbttaglist.tagAt(i);
            byte byte0 = nbttagcompound.getByte("Slot");
            if (byte0 < 0 || byte0 >= this.ovenItemStacks.length) continue;
            this.ovenItemStacks[byte0] = ItemStack.loadItemStackFromNBT(nbttagcompound);
        }
        this.ovenCookingTime = par1NBTTagCompound.getShort("CoolTime");
        this.ovenCookTime = par1NBTTagCompound.getShort("FreezeTime");
        this.currentItemCoolTime = TileEntityOven.getItemFreezeTime(this.ovenItemStacks[1]);
    }

    @Override
    public void writeToNBT(NBTTagCompound par1NBTTagCompound) {
        super.writeToNBT(par1NBTTagCompound);
        par1NBTTagCompound.setShort("CoolTime", (short)this.ovenCookingTime);
        par1NBTTagCompound.setShort("FreezeTime", (short)this.ovenCookTime);
        NBTTagList nbttaglist = new NBTTagList();
        for (int i = 0; i < this.ovenItemStacks.length; ++i) {
            if (this.ovenItemStacks[i] == null) continue;
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            nbttagcompound.setByte("Slot", (byte)i);
            this.ovenItemStacks[i].writeToNBT(nbttagcompound);
            nbttaglist.appendTag(nbttagcompound);
        }
        par1NBTTagCompound.setTag("Items", nbttaglist);
    }

    @Override
    public int getInventoryStackLimit() {
        return 64;
    }

    public int getCoolProgressScaled(int i) {
        return this.ovenCookingTime * i / 150;
    }

    public int getFreezeTimeRemainingScaled(int i) {
        if (this.currentItemCoolTime == 0) {
            this.currentItemCoolTime = 150;
        }
        return this.ovenCookTime * i / this.currentItemCoolTime;
    }

    public boolean isFreezing() {
        return this.ovenCookTime > 0;
    }

    @Override
    public void updateEntity() {
        boolean flag = this.ovenCookTime > 0;
        boolean flag1 = false;
        if (this.ovenCookTime > 0) {
            --this.ovenCookTime;
        }
        if (!this.worldObj.isRemote) {
            if (this.ovenCookTime == 0 && this.canSolidify()) {
                this.currentItemCoolTime = this.ovenCookTime = TileEntityOven.getItemFreezeTime(this.ovenItemStacks[0]);
                if (this.ovenCookTime > 0) {
                    flag1 = true;
                    if (this.ovenItemStacks[0] != null) {
                        --this.ovenItemStacks[0].stackSize;
                        if (this.ovenItemStacks[0].stackSize == 0) {
                            this.ovenItemStacks[0] = null;
                        }
                    }
                }
            }
            if (this.canSolidify()) {
                ++this.ovenCookingTime;
                if (this.ovenCookingTime == 150) {
                    this.ovenCookingTime = 0;
                    this.solidifyItems();
                    flag1 = true;
                }
            } else {
                this.ovenCookingTime = 0;
            }
        }
        if (flag != this.ovenCookTime > 0) {
            flag1 = true;
        }
        if (flag1) {
            this.onInventoryChanged();
        }
    }

    private boolean canSolidify() {
        if (this.ovenItemStacks[3] == null && this.ovenItemStacks[6] == null && this.ovenItemStacks[9] == null && this.ovenItemStacks[4] == null && this.ovenItemStacks[7] == null && this.ovenItemStacks[10] == null && this.ovenItemStacks[5] == null && this.ovenItemStacks[8] == null && this.ovenItemStacks[11] == null) {
            return false;
        }
        if (this.ovenItemStacks[3] != null) {
            ItemStack var1 = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[3].getItem().itemID);
            return var1 == null ? false : (this.ovenItemStacks[12] == null ? true : (!this.ovenItemStacks[12].isItemEqual(var1) ? false : (this.ovenItemStacks[12].stackSize < this.getInventoryStackLimit() && this.ovenItemStacks[12].stackSize < this.ovenItemStacks[12].getMaxStackSize() ? true : this.ovenItemStacks[12].stackSize < var1.getMaxStackSize())));
        }
        if (this.ovenItemStacks[6] != null) {
            ItemStack var1 = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[6].getItem().itemID);
            return var1 == null ? false : (this.ovenItemStacks[15] == null ? true : (!this.ovenItemStacks[15].isItemEqual(var1) ? false : (this.ovenItemStacks[15].stackSize < this.getInventoryStackLimit() && this.ovenItemStacks[15].stackSize < this.ovenItemStacks[15].getMaxStackSize() ? true : this.ovenItemStacks[15].stackSize < var1.getMaxStackSize())));
        }
        if (this.ovenItemStacks[9] != null) {
            ItemStack var1 = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[9].getItem().itemID);
            return var1 == null ? false : (this.ovenItemStacks[18] == null ? true : (!this.ovenItemStacks[18].isItemEqual(var1) ? false : (this.ovenItemStacks[18].stackSize < this.getInventoryStackLimit() && this.ovenItemStacks[18].stackSize < this.ovenItemStacks[18].getMaxStackSize() ? true : this.ovenItemStacks[18].stackSize < var1.getMaxStackSize())));
        }
        if (this.ovenItemStacks[4] != null) {
            ItemStack var1 = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[4].getItem().itemID);
            return var1 == null ? false : (this.ovenItemStacks[13] == null ? true : (!this.ovenItemStacks[13].isItemEqual(var1) ? false : (this.ovenItemStacks[13].stackSize < this.getInventoryStackLimit() && this.ovenItemStacks[13].stackSize < this.ovenItemStacks[13].getMaxStackSize() ? true : this.ovenItemStacks[13].stackSize < var1.getMaxStackSize())));
        }
        if (this.ovenItemStacks[7] != null) {
            ItemStack var1 = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[7].getItem().itemID);
            return var1 == null ? false : (this.ovenItemStacks[16] == null ? true : (!this.ovenItemStacks[16].isItemEqual(var1) ? false : (this.ovenItemStacks[16].stackSize < this.getInventoryStackLimit() && this.ovenItemStacks[16].stackSize < this.ovenItemStacks[16].getMaxStackSize() ? true : this.ovenItemStacks[16].stackSize < var1.getMaxStackSize())));
        }
        if (this.ovenItemStacks[10] != null) {
            ItemStack var1 = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[10].getItem().itemID);
            return var1 == null ? false : (this.ovenItemStacks[19] == null ? true : (!this.ovenItemStacks[19].isItemEqual(var1) ? false : (this.ovenItemStacks[19].stackSize < this.getInventoryStackLimit() && this.ovenItemStacks[19].stackSize < this.ovenItemStacks[19].getMaxStackSize() ? true : this.ovenItemStacks[19].stackSize < var1.getMaxStackSize())));
        }
        if (this.ovenItemStacks[5] != null) {
            ItemStack var1 = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[5].getItem().itemID);
            return var1 == null ? false : (this.ovenItemStacks[14] == null ? true : (!this.ovenItemStacks[14].isItemEqual(var1) ? false : (this.ovenItemStacks[14].stackSize < this.getInventoryStackLimit() && this.ovenItemStacks[14].stackSize < this.ovenItemStacks[14].getMaxStackSize() ? true : this.ovenItemStacks[14].stackSize < var1.getMaxStackSize())));
        }
        if (this.ovenItemStacks[8] != null) {
            ItemStack var1 = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[8].getItem().itemID);
            return var1 == null ? false : (this.ovenItemStacks[17] == null ? true : (!this.ovenItemStacks[17].isItemEqual(var1) ? false : (this.ovenItemStacks[17].stackSize < this.getInventoryStackLimit() && this.ovenItemStacks[17].stackSize < this.ovenItemStacks[17].getMaxStackSize() ? true : this.ovenItemStacks[17].stackSize < var1.getMaxStackSize())));
        }
        if (this.ovenItemStacks[11] != null) {
            ItemStack var1 = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[11].getItem().itemID);
            return var1 == null ? false : (this.ovenItemStacks[20] == null ? true : (!this.ovenItemStacks[20].isItemEqual(var1) ? false : (this.ovenItemStacks[20].stackSize < this.getInventoryStackLimit() && this.ovenItemStacks[20].stackSize < this.ovenItemStacks[20].getMaxStackSize() ? true : this.ovenItemStacks[20].stackSize < var1.getMaxStackSize())));
        }
        return false;
    }

    public void solidifyItems() {
        if (!this.canSolidify()) {
            return;
        }
        if (this.ovenItemStacks[3] != null) {
            ItemStack itemstack = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[3].getItem().itemID);
            if (this.ovenItemStacks[12] == null) {
                this.ovenItemStacks[12] = itemstack.copy();
            } else if (this.ovenItemStacks[12].itemID == itemstack.itemID) {
                this.ovenItemStacks[12].stackSize += itemstack.stackSize;
            }
            if (this.ovenItemStacks[3].getItem().hasContainerItem()) {
                this.ovenItemStacks[3] = new ItemStack(this.ovenItemStacks[3].getItem().getContainerItem());
            } else {
                --this.ovenItemStacks[3].stackSize;
            }
            if (this.ovenItemStacks[3].stackSize <= 0) {
                this.ovenItemStacks[3] = null;
            }
        } else if (this.ovenItemStacks[6] != null) {
            ItemStack itemstack = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[6].getItem().itemID);
            if (this.ovenItemStacks[15] == null) {
                this.ovenItemStacks[15] = itemstack.copy();
            } else if (this.ovenItemStacks[15].itemID == itemstack.itemID) {
                this.ovenItemStacks[15].stackSize += itemstack.stackSize;
            }
            if (this.ovenItemStacks[6].getItem().hasContainerItem()) {
                this.ovenItemStacks[6] = new ItemStack(this.ovenItemStacks[6].getItem().getContainerItem());
            } else {
                --this.ovenItemStacks[6].stackSize;
            }
            if (this.ovenItemStacks[6].stackSize <= 0) {
                this.ovenItemStacks[6] = null;
            }
        } else if (this.ovenItemStacks[9] != null) {
            ItemStack itemstack = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[9].getItem().itemID);
            if (this.ovenItemStacks[18] == null) {
                this.ovenItemStacks[18] = itemstack.copy();
            } else if (this.ovenItemStacks[18].itemID == itemstack.itemID) {
                this.ovenItemStacks[18].stackSize += itemstack.stackSize;
            }
            if (this.ovenItemStacks[9].getItem().hasContainerItem()) {
                this.ovenItemStacks[9] = new ItemStack(this.ovenItemStacks[9].getItem().getContainerItem());
            } else {
                --this.ovenItemStacks[9].stackSize;
            }
            if (this.ovenItemStacks[9].stackSize <= 0) {
                this.ovenItemStacks[9] = null;
            }
        } else if (this.ovenItemStacks[4] != null) {
            ItemStack itemstack = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[4].getItem().itemID);
            if (this.ovenItemStacks[13] == null) {
                this.ovenItemStacks[13] = itemstack.copy();
            } else if (this.ovenItemStacks[13].itemID == itemstack.itemID) {
                this.ovenItemStacks[13].stackSize += itemstack.stackSize;
            }
            if (this.ovenItemStacks[4].getItem().hasContainerItem()) {
                this.ovenItemStacks[4] = new ItemStack(this.ovenItemStacks[4].getItem().getContainerItem());
            } else {
                --this.ovenItemStacks[4].stackSize;
            }
            if (this.ovenItemStacks[4].stackSize <= 0) {
                this.ovenItemStacks[4] = null;
            }
        } else if (this.ovenItemStacks[7] != null) {
            ItemStack itemstack = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[7].getItem().itemID);
            if (this.ovenItemStacks[16] == null) {
                this.ovenItemStacks[16] = itemstack.copy();
            } else if (this.ovenItemStacks[16].itemID == itemstack.itemID) {
                this.ovenItemStacks[16].stackSize += itemstack.stackSize;
            }
            if (this.ovenItemStacks[7].getItem().hasContainerItem()) {
                this.ovenItemStacks[7] = new ItemStack(this.ovenItemStacks[7].getItem().getContainerItem());
            } else {
                --this.ovenItemStacks[7].stackSize;
            }
            if (this.ovenItemStacks[7].stackSize <= 0) {
                this.ovenItemStacks[7] = null;
            }
        } else if (this.ovenItemStacks[10] != null) {
            ItemStack itemstack = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[10].getItem().itemID);
            if (this.ovenItemStacks[19] == null) {
                this.ovenItemStacks[19] = itemstack.copy();
            } else if (this.ovenItemStacks[19].itemID == itemstack.itemID) {
                this.ovenItemStacks[19].stackSize += itemstack.stackSize;
            }
            if (this.ovenItemStacks[10].getItem().hasContainerItem()) {
                this.ovenItemStacks[10] = new ItemStack(this.ovenItemStacks[10].getItem().getContainerItem());
            } else {
                --this.ovenItemStacks[10].stackSize;
            }
            if (this.ovenItemStacks[10].stackSize <= 0) {
                this.ovenItemStacks[10] = null;
            }
        } else if (this.ovenItemStacks[5] != null) {
            ItemStack itemstack = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[5].getItem().itemID);
            if (this.ovenItemStacks[14] == null) {
                this.ovenItemStacks[14] = itemstack.copy();
            } else if (this.ovenItemStacks[14].itemID == itemstack.itemID) {
                this.ovenItemStacks[14].stackSize += itemstack.stackSize;
            }
            if (this.ovenItemStacks[5].getItem().hasContainerItem()) {
                this.ovenItemStacks[5] = new ItemStack(this.ovenItemStacks[5].getItem().getContainerItem());
            } else {
                --this.ovenItemStacks[5].stackSize;
            }
            if (this.ovenItemStacks[5].stackSize <= 0) {
                this.ovenItemStacks[5] = null;
            }
        } else if (this.ovenItemStacks[8] != null) {
            ItemStack itemstack = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[8].getItem().itemID);
            if (this.ovenItemStacks[17] == null) {
                this.ovenItemStacks[17] = itemstack.copy();
            } else if (this.ovenItemStacks[17].itemID == itemstack.itemID) {
                this.ovenItemStacks[17].stackSize += itemstack.stackSize;
            }
            if (this.ovenItemStacks[8].getItem().hasContainerItem()) {
                this.ovenItemStacks[8] = new ItemStack(this.ovenItemStacks[8].getItem().getContainerItem());
            } else {
                --this.ovenItemStacks[8].stackSize;
            }
            if (this.ovenItemStacks[8].stackSize <= 0) {
                this.ovenItemStacks[8] = null;
            }
        } else if (this.ovenItemStacks[11] != null) {
            ItemStack itemstack = OvenRecipes.cooking().getCookingResult(this.ovenItemStacks[11].getItem().itemID);
            if (this.ovenItemStacks[20] == null) {
                this.ovenItemStacks[20] = itemstack.copy();
            } else if (this.ovenItemStacks[20].itemID == itemstack.itemID) {
                this.ovenItemStacks[20].stackSize += itemstack.stackSize;
            }
            if (this.ovenItemStacks[11].getItem().hasContainerItem()) {
                this.ovenItemStacks[11] = new ItemStack(this.ovenItemStacks[11].getItem().getContainerItem());
            } else {
                --this.ovenItemStacks[11].stackSize;
            }
            if (this.ovenItemStacks[11].stackSize <= 0) {
                this.ovenItemStacks[11] = null;
            }
        }
    }

    private static int getItemFreezeTime(ItemStack itemstack) {
        return 0;
    }

    public static boolean isItemFuel(ItemStack itemstack) {
        return TileEntityOven.getItemFreezeTime(itemstack) > 0;
    }

    @Override
    public boolean isUseableByPlayer(EntityPlayer entityplayer) {
        return this.worldObj.getBlockTileEntity(this.xCoord, this.yCoord, this.zCoord) != this ? false : entityplayer.getDistanceSq((double)this.xCoord + 0.5, (double)this.yCoord + 0.5, (double)this.zCoord + 0.5) <= 64.0;
    }

    @Override
    public void openChest() {
    }

    @Override
    public void closeChest() {
    }

    public boolean func_94042_c() {
        return false;
    }

    @Override
    public boolean isInvNameLocalized() {
        return false;
    }

    @Override
    public boolean isStackValidForSlot(int var1, ItemStack var2) {
        return false;
    }
}
