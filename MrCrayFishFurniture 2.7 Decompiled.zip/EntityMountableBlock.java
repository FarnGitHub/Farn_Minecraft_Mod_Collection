import net.minecraft.src.Entity;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;

public class EntityMountableBlock
extends Entity {
    protected int orgBlockPosX;
    protected int orgBlockPosY;
    protected int orgBlockPosZ;
    protected int orgBlockID;

    public EntityMountableBlock(World world) {
        super(world);
        this.noClip = true;
        this.preventEntitySpawning = true;
        this.width = 0.0f;
        this.height = 0.0f;
    }

    public EntityMountableBlock(World world, double d, double d1, double d2) {
        super(world);
        this.noClip = true;
        this.preventEntitySpawning = true;
        this.width = 0.0f;
        this.height = 0.0f;
        this.setPosition(d, d1, d2);
    }

    public EntityMountableBlock(World world, EntityPlayer entityplayer, int i, int j, int k, float mountingX, float mountingY, float mountingZ) {
        super(world);
        this.noClip = true;
        this.preventEntitySpawning = true;
        this.width = 0.0f;
        this.height = 0.0f;
        this.orgBlockPosX = i;
        this.orgBlockPosY = j;
        this.orgBlockPosZ = k;
        this.orgBlockID = world.getBlockId(i, j, k);
        this.setPosition(mountingX, mountingY, mountingZ);
    }

    @Override
    public boolean interact(EntityPlayer entityplayer) {
        if (this.riddenByEntity != null && this.riddenByEntity instanceof EntityPlayer && this.riddenByEntity != entityplayer) {
            return true;
        }
        if (!this.worldObj.isRemote) {
            entityplayer.mountEntity(this);
        }
        return true;
    }

    @Override
    public void onEntityUpdate() {
        this.worldObj.theProfiler.startSection("entityBaseTick");
        if (this.riddenByEntity == null || this.riddenByEntity.isDead) {
            this.setDead();
        } else if (this.worldObj.getBlockId(this.orgBlockPosX, this.orgBlockPosY, this.orgBlockPosZ) != this.orgBlockID) {
            this.interact((EntityPlayer)this.riddenByEntity);
        }
        ++this.ticksExisted;
        this.worldObj.theProfiler.endSection();
    }

    @Override
    public void entityInit() {
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
    }
}
