import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.World;

public class ItemCarpet
extends Item {
    private int colour;

    public ItemCarpet(int i, int metadata) {
        super(i);
        this.colour = metadata;
    }

    @Override
    public boolean onItemUse(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, World par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10) {
        if (par3World.isAirBlock(par4, par5 + 1, par6)) {
            par3World.setBlock(par4, par5 + 1, par6, mod_FurnitureMod.carpetID, this.colour, 3);
        }
        --par1ItemStack.stackSize;
        return true;
    }
}
