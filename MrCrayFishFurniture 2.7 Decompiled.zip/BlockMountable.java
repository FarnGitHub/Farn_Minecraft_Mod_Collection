import java.util.List;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Material;
import net.minecraft.src.World;

public class BlockMountable
extends Block {
    public BlockMountable(int x, Material material) {
        super(x, material);
    }

    public BlockMountable(int x, int y, Material material) {
        super(x, material);
    }

    @Override
    public boolean onBlockActivated(World world, int i, int j, int k, EntityPlayer entityplayer, int par6, float par7, float par8, float par9) {
        return BlockMountable.onBlockActivated(world, i, j, k, entityplayer, 0.5f, 1.0f, 0.5f, 0, 0, 0, 0);
    }

    public static boolean onBlockActivated(World world, int i, int j, int k, EntityPlayer entityplayer, float y) {
        return BlockMountable.onBlockActivated(world, i, j, k, entityplayer, 0.5f, y, 0.5f, 0, 0, 0, 0);
    }

    public static boolean onBlockActivated(World world, int i, int j, int k, EntityPlayer entityplayer, float x, float y, float z, int north, int south, int east, int west) {
        if (!world.isRemote) {
            List listEMB = world.getEntitiesWithinAABB(EntityMountableBlock.class, AxisAlignedBB.getBoundingBox(i, j, k, (double)i + 1.0, (double)j + 1.0, (double)k + 1.0).expand(1.0, 1.0, 1.0));
            for (EntityMountableBlock entitytocheck : listEMB) {
                if (entitytocheck.orgBlockPosX != i || entitytocheck.orgBlockPosY != j || entitytocheck.orgBlockPosZ != k) continue;
                entitytocheck.interact(entityplayer);
                return true;
            }
            float mountingX = (float)i + x;
            float mountingY = (float)j + y;
            float mountingZ = (float)k + z;
            if (north != south) {
                int md = world.getBlockMetadata(i, j, k);
                if (md == east) {
                    mountingX = (float)(i + 1) - z;
                    mountingZ = (float)k + x;
                } else if (md == south) {
                    mountingX = (float)(i + 1) - x;
                    mountingZ = (float)(k + 1) - z;
                } else if (md == west) {
                    mountingX = (float)i + z;
                    mountingZ = (float)(k + 1) - x;
                }
            }
            EntityMountableBlock nemb = new EntityMountableBlock(world, entityplayer, i, j, k, mountingX, mountingY, mountingZ);
            world.spawnEntityInWorld(nemb);
            nemb.interact(entityplayer);
            return true;
        }
        return true;
    }
}
