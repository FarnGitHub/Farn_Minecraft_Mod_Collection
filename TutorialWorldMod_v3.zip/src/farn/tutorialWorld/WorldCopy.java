package farn.tutorialWorld;

import net.minecraft.src.mod_TutorialWorld;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLDecoder;

public class WorldCopy {
    public static final File ModJarPath;
    public static final String worldFileName = "TutorialWorld";
    public static final String worldDisplayName = "Tutorial World";
    public static final String worldResourcePath = "farn/tutorialWorld/TutorialWorld.zip";

    public static void unzip(InputStream zipStream, File targetDir) throws Exception {
        byte[] buffer = new byte[16384];

        try (java.util.zip.ZipInputStream zis = new java.util.zip.ZipInputStream(zipStream)) {
            java.util.zip.ZipEntry entry;

            while ((entry = zis.getNextEntry()) != null) {
                File outFile = new File(targetDir, entry.getName());

                if (entry.isDirectory()) {
                    outFile.mkdirs();
                } else {
                    outFile.getParentFile().mkdirs();
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        int len;
                        while ((len = zis.read(buffer)) > 0) {
                            fos.write(buffer, 0, len);
                        }
                    }
                }

                zis.closeEntry();
            }
        }
    }

    public static void cloneTutorialWorld() {
        try {
            File saves = mod_TutorialWorld.getSaveDirectory();
            File target = new File(saves, worldFileName);

            if (target.exists()) {
                System.out.println("[Tutorial World] World already exists.");
                return;
            }

            target.mkdirs();

            // Find zip inside the mod JAR
            InputStream zipStream = mod_TutorialWorld.class.getClassLoader()
                    .getResourceAsStream(worldResourcePath);

            if (zipStream == null) {
                throw new RuntimeException("world.zip not found inside mod jar!");
            }

            unzip(zipStream, target);

            System.out.println("[Tutorial World] Successfully extracted tutorial world.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static {
        try {
            String rawJarPath = URLDecoder.decode(mod_TutorialWorld.class.getProtectionDomain().getCodeSource().getLocation().getPath(), "UTF-8");
            rawJarPath = rawJarPath.replace("jar:", "").replace("file:/", "").replace("file:\\", ""); /* replace scheme part */
            if(rawJarPath.contains(".jar!")) {
                rawJarPath = rawJarPath.substring(0, rawJarPath.lastIndexOf(".jar!") + ".jar".length());
            }
            rawJarPath = new File(rawJarPath).getAbsolutePath();
            ModJarPath = new File(rawJarPath);
        } catch(Exception e) {
            throw new RuntimeException("[Tutorial World] can't find a jar path for this mod");
        }
    }
}
