package net.minecraft.src;

import farn.tutorialWorld.ButtonTutorialWorld;
import farn.tutorialWorld.WorldCopy;
import net.minecraft.client.Minecraft;
import overrideapi.OverrideAPI;

import java.io.File;

public class mod_TutorialWorld extends BaseMod {

    public static File getSaveDirectory() {
        if(ModLoader.getMinecraftInstance().getSaveLoader() instanceof SaveFormatOld) {
            return ((SaveFormatOld)ModLoader.getMinecraftInstance().getSaveLoader()).field_22180_a;
        }
        return new File(Minecraft.getMinecraftDir(), "saves");
    }

    public mod_TutorialWorld() {
        OverrideAPI.registerButtonHandler(new ButtonTutorialWorld());
        ModLoader.SetInGUIHook(this, true, false);
    }

    public boolean OnTickInGUI(Minecraft mc, GuiScreen screen) {
        if(ButtonTutorialWorld.joinTutorialWorldRequested) {
            ButtonTutorialWorld.joinTutorialWorldRequested = false;
            mc.playerController = new PlayerControllerSP(OverrideAPI.getMinecraftInstance());
            if(mc.getSaveLoader().func_22173_b(WorldCopy.worldFileName) == null) {
                WorldCopy.cloneTutorialWorld();
            }
            mc.startWorld(WorldCopy.worldFileName, WorldCopy.worldDisplayName, 0);
            mc.displayGuiScreen(null);
        }
        return true;
    }

    @Override
    public String Version() {
        return "1.0.0";
    }
}
